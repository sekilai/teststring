//
//  SCOverlayController.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCOverlayController : UIPresentationController

@property CGSize overlaySize; // Overlayサイズ

// 水平方向の表示位置
typedef NS_ENUM(NSInteger, SCOverlayHorizontally) {
    kOLH_Left = 0, // 左端
    kOLH_Center,   // 中央
    kOLH_Right     // 右端
};
@property (nonatomic) SCOverlayHorizontally overlayHorizontally;

// 垂直方向の表示位置
typedef NS_ENUM(NSInteger, SCOverlayVertically) {
    kOLV_Top = 0, // 上端
    kOLV_Center,  // 中央
    kOLV_Bottom   // 下端
};
@property (nonatomic) SCOverlayVertically overlayVertically;

@end
