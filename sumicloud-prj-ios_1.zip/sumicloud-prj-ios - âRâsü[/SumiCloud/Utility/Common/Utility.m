//
//  Utility.m
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/06/28.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "Utility.h"
#import "SCSystemData.h"
#import "BaseRequest.h"
#import "Constants.h"
#import "DbAccessControllDao.h"

@implementation Utility

+(NSString *)solveNullOrEmpty:(NSString*) string{
    if (string == nil || [string isKindOfClass:[NSNull class]] || string.length == 0 || [string isEqualToString:@"---"]) {
        return @"";
    }
    return string;
}

+ (void)setRequest:(BaseRequest *)request {
    request.brand = [SCSystemData getBrand];
    request.model = [SCSystemData getModel];
    request.osVersion = [SCSystemData getOsVersion];
    request.appVersion = [SCSystemData getAppVersion];
    request.account = [[NSUserDefaults standardUserDefaults] stringForKey:PRE_ACCOUNT];
    request.userPW = [[[DbAccessControllDao alloc] init] getAccountPassword:request.account];
}

+ (int)expirationCountFromRemainDay:(NSString *)remainDays {
    
    int res = 0;
    if(remainDays.length == 0){
        return res;
    }
    
    int remainDayint = [remainDays intValue];
    if(remainDayint >=3){
        res = 3;
    }else {
        res = remainDayint;
    }
   
    return res;
}

+ (UIImage *)imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}

@end
