//
//  Constants.h
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/03.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

#define PRE_ACCOUNT @"ACCOUNT"
#define PRE_PASSWORD @"PASSWORD"

#define PRE_CEHCKBOX @"CEHCKBOX"

#define PASSCODE_AES_KEY @"c3da0a4ea293b6f06e45455b8503ffab"
#define PASSCODE_AES_IV @"d9e091d358163e375712b8e7034d709b"
#define PASSWORD_AES_KEY @"50464B4D747845396D76707862556A58"

#define ERROR_DOMAIN @"jp.co.sei.RentalApp"

typedef enum {
    SUCCESS = 0,
    WIFI_TIMEOUT = -1,
    COMMAND_POST_ERROR = -2,
    COMMAND_TIME_OUT = -3,
    COMMAND_RESULT_ERROR = -4,
    COMMAND_SPLICER_NOT_READY = -33,
    COMMAND_DATE_ERROR = -16,
    COMMAND_RESULT_ERROR_1 = -12,
    COMMAND_RESULT_ERROR_2 = -13,
    COMMAND_RESULT_ERROR_3 = -14,
    COMMAND_RESULT_ERROR_4 = -15,
    COMMAND_RESULT_ERROR_9 = -31,
    COMMAND_CANCEL = -5,
    UNKNOW_ERROR = -6,

    NET_HTTPCODE_FAIL = -7,
    NET_CONNECT_FAIL = -8,
    NET_COMMAND_TIME_OUT = -9,
    NET_UNKNOW_ERROR = -10,
    NET_JSON_RESULT_ERROR = -11,

    COMMAND_ERROR_BUSY = -17,
    COMMAND_ERROR_LOCK = -18,
    CANCELED = -19,
    CANCELED_LOGIN = -35,

    kBF_MU_RA_LOCK = -20,
    kBF_MU_RA_UNLOCK = -21,
    kBF_MU_LOCK_CLEAR = -22,

    COMMAND_RESULT_ERROR_E1 = -23,
    COMMAND_RESULT_ERROR_E2 = -24,
    COMMAND_RESULT_ERROR_E3 = -25,
    COMMAND_RESULT_ERROR_E4 = -29,
    COMMAND_RESULT_ERROR_E9 = -30,

    COMMAND_PO00_COMMAND_ERROR = -26,
    COMMAND_PO00_POST_ERROR = -27,
    COMMAND_PO00_COMMAND_TIME_OUT = -28,
    WIFI_ERROR = -34,

} RESULT_CODE;

#endif /* Constants_h */
