//
//  SCAccountCheck.m
//  SumiCloud
//
//  Created by fsi_mac_6 on 2019/2/6.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCAccountCheck.h"

@implementation SCAccountCheck

+(BOOL)checkIDorEmail:(NSString *)account andPassWord:(NSString *)password {
    if ([self checkEmail:account] && [self checkPassWord:password]) {
        return true;
    }
    return false;
}

+(BOOL)checkEmail:(NSString *)account {
    NSString *pattern = @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+$";
    NSRegularExpression *regex = [[NSRegularExpression alloc] initWithPattern:pattern options:0 error:nil];
    NSArray *results = [regex matchesInString:account options:0 range:NSMakeRange(0, account.length)];
    if ([results count] < 1) {
        return false;
    }
    return true;
}

+(BOOL)checkPassWord:(NSString *)password {
    //check password
    NSString *pwpattern = @"^[a-z,A-Z,0-9]{8,32}$";
    NSRegularExpression *pwregex = [[NSRegularExpression alloc] initWithPattern:pwpattern options:0 error:nil];
    NSArray *results = [pwregex matchesInString:password options:0 range:NSMakeRange(0, password.length)];
    if ([results count] < 1) {
        return false;
    }
    return true;
}

@end
