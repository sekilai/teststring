//
//  DigestTool.m
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/05.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import "DigestTool.h"
#import <CommonCrypto/CommonDigest.h>
#import "SCLogUtil.h"

@implementation DigestTool
// sha512
+ (NSData *)digest:(NSData *)data {
    uint8_t digest[CC_SHA512_DIGEST_LENGTH];
    CC_SHA512(data.bytes, (CC_LONG)data.length, digest);
    return [NSData dataWithBytes:digest length:CC_SHA512_DIGEST_LENGTH];
}

+ (NSString *)encodePassword:(NSString *)rawPass salt:(NSString *)salt {
    NSString * saltedPass = [self mergePasswordAndSalt:rawPass salt:salt];
    NSData * data = [self digest:[saltedPass dataUsingEncoding:NSUTF8StringEncoding]];
    for(int i = 1; i < 10000; i++){
        data = [self digest:data];
    }
    NSMutableString* result = [NSMutableString stringWithCapacity:CC_SHA512_DIGEST_LENGTH * 2];
    for(int i = 0; i < CC_SHA512_DIGEST_LENGTH; i++){
        [result appendFormat:@"%02x", ((uint8_t *)data.bytes)[i]];
    }
    return result;
}

+ (NSString *) mergePasswordAndSalt:(NSString *)password salt:(NSString *)salt {
    if (!password) {
        password = @"";
    }
    if (salt) {
        if (([salt rangeOfString:@"{"].location != NSNotFound) || ([salt rangeOfString:@"}"].location != NSNotFound)) {
            DDLogWarn(@"Cannot use { or }");
        }
    }
    
    if ((salt == nil) || [@"" isEqualToString:salt]) {
        return password;
    } else {
        return [NSString stringWithFormat:@"%@{%@}",password,salt];
    }
}

+ (NSString *)decimalNumber:(NSDecimalNumber *)decimalNumber divide:(int)value withScale:(int)scale{
    
    NSDecimalNumberHandler *roundingBehavior = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:NSRoundPlain
                                                                                                      scale:scale
                                                                                           raiseOnExactness:NO
                                                                                            raiseOnOverflow:NO
                                                                                           raiseOnUnderflow:NO
                                                                                        raiseOnDivideByZero:NO];
    

    NSDecimalNumber *result = [decimalNumber decimalNumberByDividingBy:[NSDecimalNumber decimalNumberWithString:[NSString stringWithFormat:@"%d",value]] withBehavior:roundingBehavior];
    if (scale == 6) {
       NSString *resultstr = [NSString stringWithFormat:@"%0.6f", [result floatValue]];
        return resultstr;
    }
    NSString *resultstr = [NSString stringWithFormat:@"%0.2f", [result floatValue]];
    return resultstr;
}


@end
