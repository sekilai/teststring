//
//  AESUtil.m
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/05.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import "AESUtil.h"
#import "FBEncryptorAES.h"
#import "Constants.h"

@implementation AESUtil

+ (NSString *)encrypt:(NSString*)key target:(NSString*)target {
    NSData * encData = [FBEncryptorAES encryptData:[target dataUsingEncoding:NSUTF8StringEncoding]
                                               key:[FBEncryptorAES dataForHexString:key]
                                                iv:[FBEncryptorAES dataForHexString:PASSCODE_AES_IV]];
    return [FBEncryptorAES hexStringForData:encData];
}

+ (NSString *)decrypt:(NSString*)key target:(NSString*)target {
    NSData * targetData = [FBEncryptorAES decryptData:[FBEncryptorAES dataForHexString:target]
                                                  key:[FBEncryptorAES dataForHexString:key]
                                                   iv:[FBEncryptorAES dataForHexString:PASSCODE_AES_IV]];
    return [[NSString alloc] initWithData:targetData encoding:NSUTF8StringEncoding];
}
@end
