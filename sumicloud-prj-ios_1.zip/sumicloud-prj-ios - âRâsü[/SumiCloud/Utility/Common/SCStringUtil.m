//
//  SCStringUtil.m
//  SumiCloud
//
//  Created by FSI on 2015/06/30.
//  Copyright (c) 2015年 SEI Optifrontier Co., Ltd. All rights reserved.
//

#import "SCStringUtil.h"

@implementation NSString (SCStringUtil)

/**
 *    文字列の分割、""対応
 *
 *    @param separator 分割文字 「"」と改行が入っちゃいけない
 *
 *    @return 分割されたリスト
 */
- (NSArray *)componentsSeparatedByStringWithoutDoubleQuotes:(NSString *)separator
{
    if([separator rangeOfString:@"\""].location != NSNotFound){
        return nil;
    }
    if([separator rangeOfCharacterFromSet:[NSCharacterSet newlineCharacterSet]].location != NSNotFound){
        return nil;
    }
    NSMutableArray *results = [[NSMutableArray alloc] init];
    NSString *pattern = [NSString stringWithFormat:@"(?:^|%@)\"?((?<=\")[^\"]*|[^%@\"]*)\"?(?=%@|$)",separator,separator,separator];
    NSRegularExpression *nameExpression = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionAllowCommentsAndWhitespace error:nil];
    NSArray *matches = [nameExpression matchesInString:self
                                               options:0
                                                 range:NSMakeRange(0, [self length])];
    for (NSTextCheckingResult *match in matches) {
        NSRange matchRange = [match rangeAtIndex:1];
        NSString *matchString = [self substringWithRange:matchRange];
        [results addObject:matchString];
    }
    
    return [NSArray arrayWithArray:results];
}

+ (NSString *)stringConnectByCommaWithArray:(NSArray *)stringArray{
    NSString * tempStr = @"";
    for (int i = 0; i < [stringArray count]; i++) {
        if (i == 0) {
            tempStr = [tempStr stringByAppendingString:[stringArray objectAtIndex:i]];
        } else {
            tempStr = [tempStr stringByAppendingFormat:@",%@",[stringArray objectAtIndex:i]];
        }
    }
    return tempStr;
}

@end
