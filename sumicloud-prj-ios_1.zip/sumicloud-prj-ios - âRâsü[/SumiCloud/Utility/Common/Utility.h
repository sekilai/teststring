//
//  Utility.h
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/06/28.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseRequest.h"
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Utility : NSObject

+(NSString *)solveNullOrEmpty:(NSString*) string;
+ (void)setRequest:(BaseRequest *)request;
+ (int)expirationCountFromRemainDay:(NSString *)remainDays;
+ (UIImage *)imageWithColor:(UIColor *)color;
@end

NS_ASSUME_NONNULL_END
