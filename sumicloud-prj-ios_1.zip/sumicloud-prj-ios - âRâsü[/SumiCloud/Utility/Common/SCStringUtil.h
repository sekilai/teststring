//
//  SCStringUtil.h
//  SumiCloud
//
//  Created by FSI on 2015/06/30.
//  Copyright (c) 2015年 SEI Optifrontier Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (SCStringUtil)

/**
 *    文字列の分割、""対応
 *
 *    @param separator 分割文字 「"」と改行が入っちゃいけない
 *
 *    @return 分割されたリスト
 */
- (NSArray *)componentsSeparatedByStringWithoutDoubleQuotes:(NSString *)separator;
+ (NSString *)stringConnectByCommaWithArray:(NSArray *)stringArray;

@end
