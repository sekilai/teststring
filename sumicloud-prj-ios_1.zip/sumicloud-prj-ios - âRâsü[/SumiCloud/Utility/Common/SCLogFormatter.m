//
//  SCLogFormatter.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/14.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCLogFormatter.h"

@implementation SCLogFormatter

/**
 インスタンス生成

 @return <#return value description#>
 */
- (instancetype)init {
    
    self = [super init];
    if (self) {
        
        self.datetimeFormatter = [[NSDateFormatter alloc] init];
        self.datetimeFormatter.calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
        self.datetimeFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss:SSS";
        
        self.localtimeFormatter = [[NSDateFormatter alloc] init];
        self.localtimeFormatter.calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
        self.localtimeFormatter.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"JST"];
        self.localtimeFormatter.dateFormat = @"HH:mm:ss";
    }
    
    return self;
}

/**
 ログフォーマット

 @param logMessage <#logMessage description#>

 @return <#return value description#>
 */
- (NSString *)formatLogMessage:(DDLogMessage *)logMessage {

    NSString* logLevel = @"";
    switch (logMessage.flag) {
        case DDLogFlagError:
            logLevel = @"E";
            break;
        case DDLogFlagWarning:
            logLevel = @"W";
            break;
        case DDLogFlagInfo:
            logLevel = @"I";
            break;
        case DDLogFlagDebug:
            logLevel = @"D";
            break;
        default:
            logLevel = @"V";
            break;
    }
    
    return [[NSString alloc] initWithFormat:@"%@,%@(%@),[JST %@],%@,%@",
            logLevel,
            [self.datetimeFormatter stringFromDate:logMessage.timestamp],
            logMessage.threadID,
            [self.localtimeFormatter stringFromDate:logMessage.timestamp],
            logMessage.function,
            logMessage.message];
}

@end
