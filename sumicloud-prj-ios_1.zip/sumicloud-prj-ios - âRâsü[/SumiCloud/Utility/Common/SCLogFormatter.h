//
//  SCLogFormatter.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/14.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <CocoaLumberjack/CocoaLumberjack.h>

@interface SCLogFormatter : NSObject <DDLogFormatter>

@property (nonatomic) NSDateFormatter* datetimeFormatter;
@property (nonatomic) NSDateFormatter* localtimeFormatter;

@end
