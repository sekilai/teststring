//
//  DigestTool.h
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/05.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DigestTool : NSObject
+ (NSString *)encodePassword:(NSString *)rawPass salt:(NSString *)salt;
+ (NSString *)decimalNumber:(NSDecimalNumber *)decimalNumber divide:(int)value withScale:(int)scale;
@end
