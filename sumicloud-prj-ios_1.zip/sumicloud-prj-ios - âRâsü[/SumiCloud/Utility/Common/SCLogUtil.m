//
//  SCLogUtil.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCLogUtil.h"
#import "SCLogFormatter.h"

#import <LumberjackConsole/PTEDashboard.h>

#ifdef DEBUG
const int ddLogLevel = DDLogLevelVerbose;
#else
const int ddLogLevel = DDLogLevelVerbose;
#endif

@implementation SCLogUtil

/**
 ログ出力初期化
 */
+ (void)initLogUtil {
    
    // Xcode コンソール出力
    DDTTYLogger* debugger = [DDTTYLogger sharedInstance];
    debugger.logFormatter = [[SCLogFormatter alloc] init]; // ログフォーマット指定
    [DDLog addLogger:debugger];
    
    // ファイル出力
    NSString* logRoot = [self getLogRoot];
    DDLogDebug(@"ログファイル格納パス >> %@", logRoot);
    
    DDLogFileManagerDefault* logFileMan = [[DDLogFileManagerDefault alloc] initWithLogsDirectory:logRoot];
    logFileMan.maximumNumberOfLogFiles = 15; // ログファイル履歴数
    DDFileLogger* fileLogger = [[DDFileLogger alloc] initWithLogFileManager:logFileMan];
    fileLogger.rollingFrequency = 60 * 60 * 24; // ログファイル切り替え単位（１日）
    fileLogger.maximumFileSize = 1024 * 1024; // ログファイルサイズ（1M）
    fileLogger.logFormatter = [[SCLogFormatter alloc] init]; // ログフォーマット指定
    [DDLog addLogger:fileLogger];
    
    // LumberjackConsole出力
#ifdef DEBUG
    // アプリが起動しない（例外発生）する場合があるので、一旦コメント
    //[[PTEDashboard sharedDashboard] show];
#endif
}

/**
 ログ出力パス取得
 
 @return <#return value description#>
 */
+ (NSString *)getLogRoot {
    
    NSArray* pathDocuments = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    NSString* ret = [[pathDocuments firstObject] stringByAppendingPathComponent:@"Logs"];
    return ret;
}

@end
