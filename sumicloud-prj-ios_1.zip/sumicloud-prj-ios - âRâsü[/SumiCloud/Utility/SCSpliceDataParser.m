//
//  SCSpliceDataParser.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2017/01/31.
//  Copyright © 2017年 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataParser.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"

@interface SCSpliceDataParser ()

@property (nonatomic) NSDictionary* parseDefine;

@property (nonatomic) NSString* serialNo;
@property (nonatomic) NSData* spliceData;
@property (nonatomic) NSInteger pos;

@property (nonatomic) NSMutableDictionary* recordSpliceData; // パース後の接続データ(1レコード)

@end

@implementation SCSpliceDataParser

/**
 インスタンス生成

 @return <#return value description#>
 */
- (id)init {

    self = [super init];
    if (self) {
        
        NSString* filePath = [[NSBundle mainBundle] pathForResource:@"SpliceDataParser" ofType:@"plist"];
        self.parseDefine = [NSDictionary dictionaryWithContentsOfFile:filePath];
        
        self.serialNo = @"";
        self.spliceData = nil;
        self.pos = 0;
        self.maxCount = 0;
        self.currentCount = 0;
        self.recordSpliceData = nil;
    }
    
    return self;
}

/**
 パースする接続データを設定

 @param serialNo <#serialNo description#>
 @param spliceData <#spliceData description#>
 */
- (void)setSpliceData:(NSString *)serialNo spliceData:(NSData *)spliceData {
    
    self.serialNo = serialNo;
    self.spliceData = spliceData;
    self.pos = 0;
    self.maxCount = 0;
    self.currentCount = 0;
    self.recordSpliceData = [NSMutableDictionary dictionaryWithCapacity:0];
}

/**
 ファイルサイズ確認

 @return YES:ファイルサイズ正常 / NO:ファイルサイズ異常
 */
- (BOOL)isRecordSize {
    
    BOOL ret = NO;

    NSDictionary* dicModel = self.parseDefine[@"default"];
    if ([SCSystemData isModelType72C:self.serialNo] || [SCSystemData isModelTypeZ2C:self.serialNo]) {
        
        dicModel = self.parseDefine[@"T72C"];
    }
    
    if ([SCSystemData isModelType72M:self.serialNo]) {
        dicModel = self.parseDefine[@"T72M"];
    }
    
    if ([SCSystemData isModelTypeT502:self.serialNo]) {
        dicModel = self.parseDefine[@"T502"];
    }
    
    NSNumber* recordSize = dicModel[@"recordSize"];
    if (0 == (self.spliceData.length % [recordSize integerValue])) {
        
        ret = YES;
        
        self.maxCount = self.spliceData.length / [recordSize integerValue];
    }
    
    DDLogDebug(@"接続データファイルのサイズ確認[%@]", ret ? @"正常" : @"異常");
    
    return ret;
}

/**
 接続データの展開

 @return YES:データあり / NO:データなし
 */
- (BOOL)getSpliceData {

    BOOL ret = NO;
    
    @autoreleasepool {
        
        self.recordSpliceData = [NSMutableDictionary dictionaryWithCapacity:0];
        
        NSDictionary* dicModel = self.parseDefine[@"default"];
        if ([SCSystemData isModelType72C:self.serialNo] ||
            [SCSystemData isModelTypeZ2C:self.serialNo] ) {
            
            dicModel = self.parseDefine[@"T72C"];
        } else if ([SCSystemData isModelType72M:self.serialNo]) {
            dicModel = self.parseDefine[@"T72M"];
        } else if ([SCSystemData isModelTypeT502:self.serialNo]) {
            dicModel = self.parseDefine[@"T502"];
        }
        
        NSNumber* recordSize = dicModel[@"recordSize"];
        
        self.currentCount = self.pos / [recordSize integerValue];
        if (self.currentCount < self.maxCount) {
            
            ret = YES;
            
            self.recordSpliceData[kSC_SP_splice_data_info] = [self.spliceData subdataWithRange:NSMakeRange(self.pos, [recordSize integerValue])];
            
            for (NSDictionary* dicContents in dicModel[@"contents"]) {

                @autoreleasepool {
                    
                    NSString* name = dicContents[@"name"];
                    NSNumber* length = dicContents[@"length"];
                    NSString* type = dicContents[@"type"];
                    
                    NSLog(@"dicContents[name] == %@", name);
                    
                    if ([type isEqualToString:@"int16_t"]) {

                        self.recordSpliceData[name] = [self parseWithINT16:[length integerValue] dicBlank:dicContents[@"displayBlank"]];
                    } else if ([type isEqualToString:@"uint16_t"]) {

                        self.recordSpliceData[name] = [self parseWithUINT16:[length integerValue] dicBlank:dicContents[@"displayBlank"]];
                    } else if ([type isEqualToString:@"char"]) {
                        
                        char numData = 0;
                        [self.spliceData getBytes:&numData range:NSMakeRange(self.pos, [length integerValue])];
                        self.recordSpliceData[name] = [[NSString alloc] initWithFormat:@"%d", numData];
                    } else if ([type isEqualToString:@"u_char"]) {
                        
                        u_char numData = 0;
                        [self.spliceData getBytes:&numData range:NSMakeRange(self.pos, [length integerValue])];
                        self.recordSpliceData[name] = [[NSString alloc] initWithFormat:@"%d", numData];
                    } else if ([type isEqualToString:@"DATETIME"]) {
                        
                        u_char numData = 0;
                        [self.spliceData getBytes:&numData range:NSMakeRange(self.pos, [length integerValue])];
                        self.recordSpliceData[name] = [[NSString alloc] initWithFormat:@"%02d", numData];
                    } else if ([type isEqualToString:@"DATETIME2"]) {
                        
                        uint16_t numData = 0;
                        [self.spliceData getBytes:&numData range:NSMakeRange(self.pos, [length integerValue])];
                        self.recordSpliceData[name] = [[NSString alloc] initWithFormat:@"%02d", numData];
                    } else if ([type isEqualToString:@"STRING"]) {
                        
                        char* textData = (char *)malloc([length integerValue] + 1);
                        memset(textData, 0x00, [length integerValue] + 1);
                        memcpy(textData, [[self.spliceData subdataWithRange:NSMakeRange(self.pos, [length integerValue])] bytes], [length integerValue]);
                        self.recordSpliceData[name] = [[NSString alloc] initWithCString:textData encoding:NSASCIIStringEncoding];
                        free(textData);
                        textData = NULL;
                    } else {
                        
                        // パース定義されていない type は、length 分読み飛ばす
                        //NSLog(@"パース定義未設定<<%@ : %@>>", name, dicContents[@"和名"]);
                    }
                    self.pos = self.pos + [length integerValue];
                }
            }
            //NSLog(@"%@", self.recordSpliceData);
        }
        
        self.currentCount = self.pos / [recordSize integerValue];
    }
    
    return ret;
}

/**
 項目値取得

 @param itemName 項目名
 @return <#return value description#>
 */
- (id)recordItem:(NSString *)itemName {

    id ret = nil;
    
    if (([itemName isEqualToString:kSC_SP_standard_loss])      // (No. 33)推定損失許容値
        || ([itemName isEqualToString:kSC_SP_angle_left])      // (No.107)左端面角度
        || ([itemName isEqualToString:kSC_SP_angle_right])     // (No.108)右端面角度
        || ([itemName isEqualToString:kSC_SP_align_bef])       // (No.109)軸ずれ量（融着前）
        || ([itemName isEqualToString:kSC_SP_deform_bef])      // (No.110)軸ずれ角度（融着前）
        || ([itemName isEqualToString:kSC_SP_eccentric_left])  // (No.111)左偏心量
        || ([itemName isEqualToString:kSC_SP_eccentric_right]) // (No.112)右偏心量
        || ([itemName isEqualToString:kSC_SP_loss])            // (No.113)推定ロス値
        || ([itemName isEqualToString:kSC_SP_align])           // (No.114)軸ずれ量（融着後）
        || ([itemName isEqualToString:kSC_SP_deform])          // (No.115)軸ずれ角度（融着後）
        || ([itemName isEqualToString:kSC_SP_core_offset])     // (No.144)コアずれ量
        || ([itemName isEqualToString:kSC_SP_core_left])       // (No.147)左コア径
        || ([itemName isEqualToString:kSC_SP_core_right])) {   // (No.148)右コア径
        
        // スマホ表示項目(パース結果を書式変換して表示)
        ret = [self formatConversion:itemName];
    } else if (([itemName isEqualToString:kSC_SP_memo])            // (No.  3)メモ
        || ([itemName isEqualToString:kSC_SP_arc_count])           // (No.  6)放電回数
        || ([itemName isEqualToString:kSC_SP_temp])                // (No. 10)気温
        || ([itemName isEqualToString:kSC_SP_error_no])            // (No.116)エラー情報
        || ([itemName isEqualToString:kSC_SP_adjust_vy])           // (No.120)調心回数(VY)
        || ([itemName isEqualToString:kSC_SP_adjust_vx])           // (No.121)調心回数(VX)
        || ([itemName isEqualToString:kSC_SP_press])               // (No.145)気圧
        || ([itemName isEqualToString:kSC_SP_format_ver])          // (No.151)フォーマットバージョン
        || ([itemName isEqualToString:kSC_SP_detect_left])         // 心線識別(左)
        || ([itemName isEqualToString:kSC_SP_detect_right])        // 心線識別(右)
        || ([itemName isEqualToString:kSC_SP_splice_data_info])) { // 接続データ情報(1レコード分のバイナリデータ)
        
        // スマホ表示項目(パース結果をそのまま表示)
        ret = self.recordSpliceData[itemName];
    } else if ([itemName isEqualToString:kSC_SP_pow_supply]) { // (No.  8)電源供給
        
        // スマホ画面表示項目(パース結果を文字列に変更して表示)
        ret = [self displayConversion:itemName];
    } else if ([itemName isEqualToString:kSC_SP_datetime]) { // (No.  5)接続開始日時

        // 接続データPKキー項目
        ret = [[NSString alloc] initWithFormat:@"20%@/%@/%@ %@:%@:%@",
               self.recordSpliceData[@"year"],
               self.recordSpliceData[@"month"],
               self.recordSpliceData[@"day"],
               self.recordSpliceData[@"hour"],
               self.recordSpliceData[@"min"],
               self.recordSpliceData[@"sec"]];
    } else if (([itemName isEqualToString:kSC_SP_spattering_time])       // (No. 13)清掃放電時間
               || ([itemName isEqualToString:kSC_SP_arc_gap])            // (No. 20)端面間隔
               || ([itemName isEqualToString:kSC_SP_limit_cleave_angle]) // (No. 21)端面角度許容値
               || ([itemName isEqualToString:kSC_SP_fusion_time])        // (No. 22)放電時間
               || ([itemName isEqualToString:kSC_SP_prefusion_time])     // (No. 24)予備放電時間
               || ([itemName isEqualToString:kSC_SP_over_lap])           // (No. 25)押し込み量
               || ([itemName isEqualToString:kSC_SP_put_to_pull])        // (No. 27)引き戻し開始時間
               || ([itemName isEqualToString:kSC_SP_pull])               // (No. 28)引き戻し量
               || ([itemName isEqualToString:kSC_SP_spot_l])             // (No. 30)MFD-左
               || ([itemName isEqualToString:kSC_SP_spot_r])             // (No. 31)MFD-右
               || ([itemName isEqualToString:kSC_SP_estloss_coeff])      // (No. 32)推定ロス補正係数
               || ([itemName isEqualToString:kSC_SP_rearc_time])         // (No. 34)追加放電時間
               || ([itemName isEqualToString:kSC_SP_fiber_angle_limit])  // (No. 40)ファイバ接続角許容値
               || ([itemName isEqualToString:kSC_SP_offset_loss])        // (No. 42)推定ロス加算
               || ([itemName isEqualToString:kSC_SP_missmatch_coef])     // (No. 66)MFDミスマッチ用係数
               || ([itemName isEqualToString:kSC_SP_attenuation])        // (No. 94)ATTN目標減衰量
               || ([itemName isEqualToString:kSC_SP_attn_factor])
               || ([itemName isEqualToString:kSC_SP_limit_err_offset])
               || ([itemName isEqualToString:kSC_SP_limit_err_gap])
               || ([itemName isEqualToString:kSC_SP_limit_err_irregular])) {     // (No. 95)ATTN校正係数

        // スマホ画面非表示項目(パース結果を書式変換)
        ret = [self formatConversion:itemName];
    } else if (([itemName isEqualToString:kSC_SP_splice_type_method])    // (No. 15)接続モード
               || ([itemName isEqualToString:kSC_SP_pull_sw])            // (No. 26)引き戻し接続
               || ([itemName isEqualToString:kSC_SP_hdcm])               // (No. 37)推定ロス算出モード
               || ([itemName isEqualToString:kSC_SP_adjust_type])        // (No. 38)調心方法
               || ([itemName isEqualToString:kSC_SP_wavelength])         // (No. 41)波長
               || ([itemName isEqualToString:kSC_SP_template_condition]) // (No. 54)テンプレート条件
               || ([itemName isEqualToString:kSC_SP_arc_power_coeff_sw]) // (No. 71)オート放電パワー
               || ([itemName isEqualToString:kSC_SP_fiber_detection])) { // (No. 76)ファイバ種類識別
        
        // スマホ画面非表示項目(パース結果を文字列に変更)
        ret = [self displayConversion:itemName];
    } else if (([itemName isEqualToString:kSC_SP_arc_power_turning])                // (No. 17)放電パワー調整値
               || ([itemName isEqualToString:kSC_SP_electrode_position_turning])) { // (No. 19)ファイバ接続位置調整値
        
        // スマホ画面非表示項目(パース結果を文字列に変更)
        ret = [self displayFormat:itemName];
    } else {
        
        // (no.  1)登録状態
        // (No.  2)画像有りフラグ
        // (No. 16)放電パワー
        // (No. 18)ファイバ接続位置
        // (No. 44)接続条件名称
        // (No.141)継続可能エラー情報１
        // (No.142)継続可能エラー情報２
        // (No.146)電極棒補正位置
        // スマホ画面非表示項目(パース結果を加工しない)
        ret = self.recordSpliceData[itemName];
    }
    // 接続データがSumiCloudサーバ上で0埋め表示になるの問題修正
    if (ret == nil) {
        if (self.recordSpliceData[itemName]) {
            ret = self.recordSpliceData[itemName];
        } else {
            ret = @"";
        }
    }

    return ret;
}

- (id)recordItemT502:(NSString *)itemName {
    id ret = nil;
    
    if (([itemName isEqualToString:kSC_SP_core_left])       // (No.147)左コア径
        || ([itemName isEqualToString:kSC_SP_core_right])
        || [itemName isEqualToString:kSC_SP_loss]) {   // (No.148)右コア径
        
        // スマホ表示項目(パース結果を書式変換して表示)
        ret = [self formatConversionT502:itemName];
    }
    
    
    
    if (ret == nil) {
        if (self.recordSpliceData[itemName]) {
            ret = self.recordSpliceData[itemName];
        } else {
            ret = @"";
        }
    }
    
    return ret;
        
}

/**
 接続データ画像ファイル名取得

 @param index ファイル番号
 @return !"": ファイル名 / "": 画像ファイルなし
 */
- (NSString *)getSpliceImageName:(NSInteger)index {
    
    NSString* ret = @"";

    if (index <= [self.recordSpliceData[kSC_SP_img_flg] integerValue]) {
        
        switch (index) {
            case 1:
                ret = [[NSString alloc] initWithFormat:@"20%@_%@_%@_%@%@%@.jpg",
                       self.recordSpliceData[@"year"],
                       self.recordSpliceData[@"month"],
                       self.recordSpliceData[@"day"],
                       self.recordSpliceData[@"hour"],
                       self.recordSpliceData[@"min"],
                       self.recordSpliceData[@"sec"]];
                break;
            case 2:
                ret = [[NSString alloc] initWithFormat:@"20%@_%@_%@_%@%@%@-1.jpg",
                       self.recordSpliceData[@"year"],
                       self.recordSpliceData[@"month"],
                       self.recordSpliceData[@"day"],
                       self.recordSpliceData[@"hour"],
                       self.recordSpliceData[@"min"],
                       self.recordSpliceData[@"sec"]];
                break;
            case 3:
                ret = [[NSString alloc] initWithFormat:@"20%@_%@_%@_%@%@%@-2.jpg",
                       self.recordSpliceData[@"year"],
                       self.recordSpliceData[@"month"],
                       self.recordSpliceData[@"day"],
                       self.recordSpliceData[@"hour"],
                       self.recordSpliceData[@"min"],
                       self.recordSpliceData[@"sec"]];
                break;
            case 4:
                ret = [[NSString alloc] initWithFormat:@"20%@_%@_%@_%@%@%@-3.jpg",
                       self.recordSpliceData[@"year"],
                       self.recordSpliceData[@"month"],
                       self.recordSpliceData[@"day"],
                       self.recordSpliceData[@"hour"],
                       self.recordSpliceData[@"min"],
                       self.recordSpliceData[@"sec"]];
                break;
            case 5:
                ret = [[NSString alloc] initWithFormat:@"20%@_%@_%@_%@%@%@-4.jpg",
                       self.recordSpliceData[@"year"],
                       self.recordSpliceData[@"month"],
                       self.recordSpliceData[@"day"],
                       self.recordSpliceData[@"hour"],
                       self.recordSpliceData[@"min"],
                       self.recordSpliceData[@"sec"]];
                break;
                
            default:
                break;
        }
    }

    return ret;
}

/**
 接続データ画像ファイル名取得(T72C)

 @param index <#index description#>
 @return <#return value description#>
 */
- (NSArray *)getSpliceImageName2:(NSInteger)index {

    NSMutableArray* ret = [NSMutableArray arrayWithCapacity:0];

    if (index <= [self.recordSpliceData[kSC_SP_img_flg] integerValue]) {
        
        [ret addObject:[[NSString alloc] initWithFormat:@"20%@%@%@%@%@%@_%@_x.jpg",
                        self.recordSpliceData[@"year"],
                        self.recordSpliceData[@"month"],
                        self.recordSpliceData[@"day"],
                        self.recordSpliceData[@"hour"],
                        self.recordSpliceData[@"min"],
                        self.recordSpliceData[@"sec"],
                        [NSNumber numberWithInteger:index]]];

        [ret addObject:[[NSString alloc] initWithFormat:@"20%@%@%@%@%@%@_%@_y.jpg",
                        self.recordSpliceData[@"year"],
                        self.recordSpliceData[@"month"],
                        self.recordSpliceData[@"day"],
                        self.recordSpliceData[@"hour"],
                        self.recordSpliceData[@"min"],
                        self.recordSpliceData[@"sec"],
                        [NSNumber numberWithInteger:index]]];
    }
    
    return [NSArray arrayWithArray:ret];
}


#pragma mark - Private Method

/**
 UINT16 項目のパース

 @param length データ長
 @param dicBlank ブランク表示判定設定
 @return <#return value description#>
 */
- (NSString *)parseWithUINT16:(NSInteger)length dicBlank:(NSDictionary *)dicBlank {

    NSString* ret = @"";
    uint16_t numData = 0;
    [self.spliceData getBytes:&numData range:NSMakeRange(self.pos, length)];
    ret = [[NSString alloc] initWithFormat:@"%d", numData];
    // ブランク判定
    if (dicBlank) {
        
        NSNumber* isBlank = dicBlank[@"isBlank"];
        if (isBlank) {
            
            if (numData == [isBlank unsignedShortValue]) {
                
                ret = @"";
            }
        }
        
        NSString* dataStatus = dicBlank[kSC_SP_data_status];
        NSString* adjustType = dicBlank[kSC_SP_adjust_type];
        
        if (dataStatus.length) {
            
            if ([dataStatus isEqualToString:self.recordSpliceData[kSC_SP_data_status]]) {
                ret = @"";
            }
        }
        
        if (adjustType.length) {
            
            if ([adjustType isEqualToString:self.recordSpliceData[kSC_SP_adjust_type]]) {
                ret = @"";
            }
        }
    }

    return ret;
}

/**
 INT16 項目のパース
 
 @param length データ長
 @param dicBlank ブランク表示判定設定
 @return <#return value description#>
 */
- (NSString *)parseWithINT16:(NSInteger)length dicBlank:(NSDictionary *)dicBlank {
    
    NSString* ret = @"";
    Byte dataBytes[length];
    [self.spliceData getBytes:dataBytes range:NSMakeRange(self.pos, length)];
    int16_t numData = dataBytes[length - 1]<<8|dataBytes[0];
    ret = [[NSString alloc] initWithFormat:@"%d", numData];
    // ブランク判定
    if (dicBlank) {
        
        NSNumber* isBlank = dicBlank[@"isBlank"];
        if (isBlank) {
            
            if (numData == [isBlank shortValue]) {
                
                ret = @"";
            }
        }
        
        NSString* dataStatus = dicBlank[kSC_SP_data_status];
        NSString* adjustType = dicBlank[kSC_SP_adjust_type];

        if (dataStatus.length) {
            if ([dataStatus isEqualToString:self.recordSpliceData[kSC_SP_data_status]]) {
                ret = @"";
            }
        }
        
        if (adjustType.length) {
            if ([adjustType isEqualToString:self.recordSpliceData[kSC_SP_adjust_type]]) {
                ret = @"";
            }
        }
    }
    
    return ret;
}

/**
 表示文字列変換

 @param itemName 項目名
 @return <#return value description#>
 */
- (NSString *)displayConversion:(NSString *)itemName {
    
    NSString* ret = @"";
    
    NSDictionary* dicDisplayConversion = self.parseDefine[@"displayConversion"];
    NSDictionary* dicConv = dicDisplayConversion[itemName];
    ret = dicConv[self.recordSpliceData[itemName]];

    return ret;
}

/**
 表示フォーマット変換

 @param itemName 項目名
 @return <#return value description#>
 */
- (NSString *)displayFormat:(NSString *)itemName {
    
    NSString* ret = @"";
    
    NSDictionary* dicDisplayConversion = self.parseDefine[@"displayFormat"];
    NSDictionary* dicConv = dicDisplayConversion[itemName];

    NSString* format = dicConv[@"format"];
    NSString* calculation = dicConv[@"subtraction"];

    ret = [[NSString alloc] initWithFormat:format,
           ([self.recordSpliceData[itemName] integerValue] - [calculation integerValue])];

    return ret;
}

- (NSString *)displayFormat_72M:(NSString *)itemName {
    
    NSString* ret = @"";
    
    NSDictionary* dicDisplayConversion = self.parseDefine[@"displayFormat"];
    NSDictionary* dicConv = dicDisplayConversion[itemName];
    
    NSString* format = dicConv[@"format"];
    NSString* calculation = dicConv[@"subtraction_72M"];
    
    ret = [[NSString alloc] initWithFormat:format,
           ([self.recordSpliceData[itemName] integerValue] - [calculation integerValue])];
    
    return ret;
}

/**
 数値項目のフォーマット変換

 @param itemName 項目名
 @return <#return value description#>
 */
- (NSString *)formatConversion:(NSString *)itemName {
    
    NSString* ret = @"";
    
    NSDictionary* dicFormatConversion = self.parseDefine[@"formatConversion"];
    NSDictionary* dicConv = dicFormatConversion[itemName];
    NSString* format = dicConv[@"format"];
    NSNumber* scale = dicConv[@"scale"];
    NSString* calculation = dicConv[@"division"];

    if (((NSString *)self.recordSpliceData[itemName]).length) {

        if (scale) {
            
            double itemVal = [self.recordSpliceData[itemName] doubleValue] / [calculation integerValue];
            NSDecimalNumber* decimal = [NSDecimalNumber decimalNumberWithString:[[NSString alloc] initWithFormat:@"%f", itemVal]];
            NSDecimalNumberHandler* decimalHandler = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:NSRoundPlain scale:[scale integerValue] raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:NO];
            decimal = [decimal decimalNumberByRoundingAccordingToBehavior:decimalHandler];
            ret = [decimal stringValue];

            NSRange dotRange = [ret rangeOfString:@"."];
            if (NSNotFound == dotRange.location) {
                
                ret = [[NSString alloc] initWithFormat:format, [ret doubleValue]];
            }
        } else if (format) {
            
            ret = [[NSString alloc] initWithFormat:format,
                   [self.recordSpliceData[itemName] doubleValue] / [calculation integerValue]];
        }
    }
    
    return ret;
}

- (NSString *)formatConversionT502:(NSString *)itemName {
    
    NSString* ret = @"";
    
    NSDictionary* dicFormatConversion = self.parseDefine[@"formatConversionT502"];
    NSDictionary* dicConv = dicFormatConversion[itemName];
    NSString* format = dicConv[@"format"];
    NSNumber* scale = dicConv[@"scale"];
    NSString* calculation = dicConv[@"division"];

    if (((NSString *)self.recordSpliceData[itemName]).length) {
        
        if ([self.recordSpliceData[itemName] doubleValue] == 0xffff) {
            return @"---";
        }
        
        if (scale) {
            
            double itemVal = [self.recordSpliceData[itemName] doubleValue] / [calculation integerValue];
            NSDecimalNumber* decimal = [NSDecimalNumber decimalNumberWithString:[[NSString alloc] initWithFormat:@"%f", itemVal]];
            NSDecimalNumberHandler* decimalHandler = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:NSRoundPlain scale:[scale integerValue] raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:NO];
            decimal = [decimal decimalNumberByRoundingAccordingToBehavior:decimalHandler];
            ret = [decimal stringValue];

            NSRange dotRange = [ret rangeOfString:@"."];
            if (NSNotFound == dotRange.location) {
                
                ret = [[NSString alloc] initWithFormat:format, [ret doubleValue]];
            }
        } else if (format) {
            
            ret = [[NSString alloc] initWithFormat:format,
                   [self.recordSpliceData[itemName] doubleValue] / [calculation integerValue]];
        }
    }
    
    return ret;
}

- (NSString *)formatConversion:(NSString *)itemName andTypeName:(NSString *)typeName{
    
    NSString* ret = @"";
    
    NSDictionary* dicFormatConversion = self.parseDefine[@"formatConversion"];
    NSDictionary* dicConv = dicFormatConversion[typeName];
    NSString* format = dicConv[@"format"];
    NSNumber* scale = dicConv[@"scale"];
    NSString* calculation = dicConv[@"division"];
    
    if ([self.recordSpliceData[itemName] doubleValue] == 0xFFFF ||
        [self.recordSpliceData[itemName] doubleValue] == -1) {
        return @"--";
    }
    
    if (((NSString *)self.recordSpliceData[itemName]).length) {
        
        if (scale) {
            
            double itemVal = [self.recordSpliceData[itemName] doubleValue] / [calculation integerValue];
            NSDecimalNumber* decimal = [NSDecimalNumber decimalNumberWithString:[[NSString alloc] initWithFormat:@"%f", itemVal]];
            NSDecimalNumberHandler* decimalHandler = [NSDecimalNumberHandler decimalNumberHandlerWithRoundingMode:NSRoundPlain scale:[scale integerValue] raiseOnExactness:NO raiseOnOverflow:NO raiseOnUnderflow:NO raiseOnDivideByZero:NO];
            decimal = [decimal decimalNumberByRoundingAccordingToBehavior:decimalHandler];
            ret = [decimal stringValue];
            
            NSRange dotRange = [ret rangeOfString:@"."];
            if (NSNotFound == dotRange.location) {
                
                ret = [[NSString alloc] initWithFormat:format, [ret doubleValue]];
            }
        } else if (format) {
            
            ret = [[NSString alloc] initWithFormat:format,
                   [self.recordSpliceData[itemName] doubleValue] / [calculation integerValue]];
        }
    }
    
    return ret;
}

@end
