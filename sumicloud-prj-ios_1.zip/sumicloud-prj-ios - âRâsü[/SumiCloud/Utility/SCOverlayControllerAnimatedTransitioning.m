//
//  SCOverlayControllerAnimatedTransitioning.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCOverlayControllerAnimatedTransitioning.h"
#import "SCLogUtil.h"

@interface SCOverlayControllerAnimatedTransitioning ()

@property BOOL isPresent;

@end

@implementation SCOverlayControllerAnimatedTransitioning

/**
 Overlayアニメーション初期化
 
 @param present YES:表示 / NO:非表示
 
 @return <#return value description#>
 */
- (instancetype)initWithPresent:(BOOL)present {
    
    DDLogDebug(@"%@", present ? @"YES" : @"NO");
    
    self = [super init];
    if (self) {
        
        self.isPresent = present;
    }
    
    return self;
}

/**
 アニメーション時間
 
 @param transitionContext <#transitionContext description#>
 
 @return <#return value description#>
 */
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    
    return 0.5f;
}

/**
 アニメーション
 
 @param transitionContext <#transitionContext description#>
 */
- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    
    if (self.isPresent) {
        
        // Overlay表示
        [self animatePresentTransition:transitionContext];
    } else {
        
        // Overlay非表示
        [self animateDissmissalTransition:transitionContext];
    }
}


#pragma mark - Private Method

/**
 Overlay表示
 
 @param transitionContext <#transitionContext description#>
 */
- (void)animatePresentTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    
    DDLogDebug(@"Overlay表示");
    
    UIViewController* vwConFrom = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController* vwConTo = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView* vwContainer = [transitionContext containerView];
    
    [vwContainer insertSubview:vwConTo.view aboveSubview:vwConFrom.view];
    
    [UIView animateWithDuration:[self transitionDuration:transitionContext] animations:^{
        
        CGRect rect = vwConTo.view.frame;
        
        if (kOLAD_LeftToRight == self.overlayAnimationDirection) {
            
            // 左から右
            rect.origin.x += vwContainer.bounds.size.width;
        } else if (kOLAD_RightToLeft == self.overlayAnimationDirection) {
            
            // 右から左
            rect.origin.x -= vwContainer.bounds.size.width;
        } else if (kOLAD_TopToBottom == self.overlayAnimationDirection) {
            
            // 上から下
            rect.origin.y += vwContainer.bounds.size.height;
        } else if (kOLAD_BottomToTop == self.overlayAnimationDirection) {
            
            // 下から上
            rect.origin.y -= vwContainer.bounds.size.height;
        }
        vwConTo.view.frame = rect;
    } completion:^(BOOL finished) {
        
        [transitionContext completeTransition:YES];
    }];
}

/**
 Overlay非表示
 
 @param transitionContext <#transitionContext description#>
 */
- (void)animateDissmissalTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    
    DDLogDebug(@"Overlay非表示");
    
    UIViewController* vwConFrom = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIView* vwContainer = [transitionContext containerView];
    
    [UIView animateWithDuration:[self transitionDuration:transitionContext] animations:^{
        
        CGRect rect = vwConFrom.view.frame;
        
        if (kOLAD_LeftToRight == self.overlayAnimationDirection) {
            
            // 左から右
            rect.origin.x -= vwContainer.bounds.size.width;
        } else if (kOLAD_RightToLeft == self.overlayAnimationDirection) {
            
            // 右から左
            rect.origin.x += vwContainer.bounds.size.width;
        } else if (kOLAD_TopToBottom == self.overlayAnimationDirection) {
            
            // 上から下
            rect.origin.y -= vwContainer.bounds.size.height;
        } else if (kOLAD_BottomToTop == self.overlayAnimationDirection) {
            
            // 下から上
            rect.origin.y += vwContainer.bounds.size.height;
        }
        vwConFrom.view.frame = rect;
    } completion:^(BOOL finished) {
        
        [transitionContext completeTransition:YES];
    }];
}

@end
