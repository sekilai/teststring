//
//  SCImageBrowseViewController.h
//  SumiCloud
//
//  Created by fsi_mac_6 on 2019/10/03.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCImageBrowseViewController : UIViewController
    
@property (strong, nonatomic) UIImage *mainImage;
    
@end

