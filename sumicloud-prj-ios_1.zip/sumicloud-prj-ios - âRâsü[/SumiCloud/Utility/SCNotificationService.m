//
//  SCNotificationService.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/11/16.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCNotificationService.h"
#import "SCLogUtil.h"

#import <UserNotifications/UserNotifications.h>

// TODO:iOS9 の通知の仕組みを生かすため、未使用
//@interface SCNotificationService() <UNUserNotificationCenterDelegate>
//
//@end
// TODO:iOS9 の通知の仕組みを生かすため、未使用

@implementation SCNotificationService

/**
 インスタンス生成

 @return <#return value description#>
 */
+ (instancetype)sharedInstance {
    
    static id instance = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        DDLogDebug(@"");
        
        instance = [[self alloc] init];
        [instance initNotification];
    });
    
    return instance;
}

/**
 通知機能初期化
 */
- (void)initNotification {
    
    if (NSFoundationVersionNumber_iOS_9_x_Max < floor(NSFoundationVersionNumber)) {

        DDLogInfo(@"デバイスのOSは、iOS9_x_Max 以降");
        
        // iOS9_x_Max 以降
        UNUserNotificationCenter* notificationCenter = [UNUserNotificationCenter currentNotificationCenter];
        // TODO:iOS9 の通知の仕組みを生かすため、未使用
        //notificationCenter.delegate = self;
        // TODO:iOS9 の通知の仕組みを生かすため、未使用

        // 使用許可確認
        [notificationCenter requestAuthorizationWithOptions:UNAuthorizationOptionAlert|UNAuthorizationOptionBadge|UNAuthorizationOptionSound|UNAuthorizationOptionCarPlay completionHandler:^(BOOL granted, NSError * _Nullable error) {
            
            if (error) {
                
                DDLogError(@"%@", error.description);
            } else {
                
                if (granted) {
                    
                    // 許可された
                    DDLogInfo(@"通知が許可された");
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [[UIApplication sharedApplication] registerForRemoteNotifications];
                    });

                } else {
                    
                    // 許可されない
                    DDLogWarn(@"通知が許可されない");
                }
            }
        }];
    } else {
        
        DDLogInfo(@"デバイスのOSは、iOS9_x_Max 以前");

        // iOS9_x_Max 以前
        if ([[UIApplication sharedApplication] respondsToSelector:@selector(registerUserNotificationSettings:)]) {
            
            // 使用許可確認
            UIUserNotificationSettings* settings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert | UIUserNotificationTypeSound | UIUserNotificationTypeBadge categories:nil];
            [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
        }
    }
}

/**
 通知の送信

 @param alertMsg <#alertMsg description#>
 @param info <#info description#>
 */
- (void)sendNotification:(NSString *)alertMsg info:(NSDictionary *)info {
    
    if (NSFoundationVersionNumber_iOS_9_x_Max < floor(NSFoundationVersionNumber)) {
        
        // iOS9_x_Max 以降
        
        // iOS10は、同じ id の通知を重複して通知センターに表示せず、最後の通知で通知センターを更新する
        UNUserNotificationCenter* notificationCenter = [UNUserNotificationCenter currentNotificationCenter];
        UNMutableNotificationContent* notification = [[UNMutableNotificationContent alloc] init];
        notification.body = alertMsg;
        notification.userInfo = info;
        BOOL notifyType = [info[kSC_NS_NotifyType] boolValue];
        if (notifyType) {
            
            notification.sound = [UNNotificationSound soundNamed:@"alarm.caf"];
        }
        UNTimeIntervalNotificationTrigger* trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
        
        UNNotificationRequest* request = [UNNotificationRequest requestWithIdentifier:info[kSC_NS_Alert] content:notification trigger:trigger];
        [notificationCenter addNotificationRequest:request withCompletionHandler:^(NSError * _Nullable error) {
            
            if (error) {
                
                DDLogError(@"ローカル通知送信エラー <<%@>>", error);
                return;
            }
            
            DDLogDebug(@"ローカル通知送信");
        }];
    } else {
        
        // iOS9_x_Max 以前
        
        // スケジュールされている通知を取得
        NSArray* listLocalNotification = [[NSArray alloc] initWithArray:[[UIApplication sharedApplication] scheduledLocalNotifications] copyItems:YES];
        
        // スケジュールされている通知を破棄
        [[UIApplication sharedApplication] cancelAllLocalNotifications];
        
        // ペアリングのアラート以外の通知を再登録
        for (UILocalNotification* notification in listLocalNotification) {
            
            if ([kSC_NS_SecurityLock isEqualToString:notification.userInfo[kSC_NS_Alert]]) {
                
                DDLogDebug(@"ペアリングのアラートを削除 <%@>", notification);
            } else {
                
                [[UIApplication sharedApplication] scheduleLocalNotification:notification];
            }
        }
        
        // 新しいローカル通知を作成
        UILocalNotification* notification = [[UILocalNotification alloc] init];
        notification.fireDate = [NSDate date];
        notification.timeZone = [NSTimeZone defaultTimeZone];
        notification.alertBody = alertMsg;
        notification.userInfo = info;
        BOOL notifyType = [info[kSC_NS_NotifyType] boolValue];
        if (notifyType) {
            
            notification.soundName = @"alarm.caf";
        }
        [[UIApplication sharedApplication] scheduleLocalNotification:notification];
    }
}


// TODO:iOS9 の通知の仕組みを生かすため、未使用
#pragma mark - UNUserNotificationCenterDelegate

/**
 フォアグラウンド時に、通知を受信すると呼び出される
 ※iOS9_x_Max 以降

 @param center <#center description#>
 @param notification <#notification description#>
 @param completionHandler <#completionHandler description#>
 */
//- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler {
//
//    DDLogDebug(@"フォアグラウンド時に、通知を受信");
//
//    // フォアグラウンド時にもバナーが表示されるようにする
//    completionHandler(UNNotificationPresentationOptionAlert|UNNotificationPresentationOptionBadge|UNNotificationPresentationOptionSound);
//}

/**
 通知のバナーをタップすると呼び出される
 ※iOS9_x_Max 以降

 @param center <#center description#>
 @param response <#response description#>
 @param completionHandler <#completionHandler description#>
 */
//- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)())completionHandler {
//
//    DDLogDebug(@"通知のバナーをタップ");
//
//    completionHandler();
//}

// TODO:iOS9 の通知の仕組みを生かすため、未使用

@end
