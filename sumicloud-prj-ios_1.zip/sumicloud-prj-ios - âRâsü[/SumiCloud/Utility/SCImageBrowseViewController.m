//
//  SCImageBrowseViewController.m
//  SumiCloud
//
//  Created by fsi_mac_6 on 2019/10/03.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCImageBrowseViewController.h"

@interface SCImageBrowseViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *mainImageView;

@end

@implementation SCImageBrowseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.mainImageView.image = self.mainImage;
    self.view.backgroundColor = [UIColor clearColor];
}
- (IBAction)closeBtn:(id)sender {
    [self dismissViewControllerAnimated:false completion:nil];
}

@end
