//
//  SCSpliceDataParser.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2017/01/31.
//  Copyright © 2017年 fsi_mac5d_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCSpliceDataParser : NSObject

@property (nonatomic) NSInteger maxCount;     // 接続データ取得件数
@property (nonatomic) NSInteger currentCount; // 接続データパース実施件数

- (void)setSpliceData:(NSString *)serialNo spliceData:(NSData *)spliceData;

- (BOOL)isRecordSize;

- (BOOL)getSpliceData;
- (NSString *)formatConversion:(NSString *)itemName andTypeName:(NSString *)typeName;

- (id)recordItem:(NSString *)itemName;
- (id)recordItemT502:(NSString *)itemName;
- (NSString *)getSpliceImageName:(NSInteger)index;
- (NSArray *)getSpliceImageName2:(NSInteger)index;
- (NSString *)displayFormat_72M:(NSString *)itemName;
@end


#pragma mark - Const

static NSString* const kSC_SP_data_status                = @"data_status";                // (No.  1)登録状態
static NSString* const kSC_SP_img_flg                    = @"img_flg";                    // (No.  2)画像有りフラグ
static NSString* const kSC_SP_memo                       = @"memo";                       // (No.  3)メモ
static NSString* const kSC_SP_datetime                   = @"datetime";                   // (No.  5)接続開始日時
static NSString* const kSC_SP_arc_count                  = @"arc_count";                  // (No.  6)放電回数
static NSString* const kSC_SP_pow_supply                 = @"pow_supply";                 // (No.  8)電源供給
static NSString* const kSC_SP_temp                       = @"temp";                       // (No. 10)気温【華氏の値】
static NSString* const kSC_SP_spattering_time            = @"spattering_time";            // (No. 13)清掃放電時間
static NSString* const kSC_SP_splice_type_method         = @"splice_type_method";         // (No. 15)接続モード
static NSString* const kSC_SP_arc_power                  = @"arc_power";                  // (No. 16)放電パワー
static NSString* const kSC_SP_arc_power_turning          = @"arc_power_turning";          // (No. 17)放電パワー調整値
static NSString* const kSC_SP_electrode_position         = @"electrode_position";         // (No. 18)ファイバ接続位置
static NSString* const kSC_SP_electrode_position_turning = @"electrode_position_turning"; // (No. 19)ファイバ接続位置調整値
static NSString* const kSC_SP_arc_gap                    = @"arc_gap";                    // (No. 20)端面間隔
static NSString* const kSC_SP_limit_cleave_angle         = @"limit_cleave_angle";         // (No. 21)端面角度許容値
static NSString* const kSC_SP_fusion_time                = @"fusion_time";                // (No. 22)放電時間
static NSString* const kSC_SP_prefusion_time             = @"prefusion_time";             // (No. 24)予備放電時間
static NSString* const kSC_SP_over_lap                   = @"over_lap";                   // (No. 25)押し込み量
static NSString* const kSC_SP_pull_sw                    = @"pull_sw";                    // (No. 26)引き戻し接続
static NSString* const kSC_SP_put_to_pull                = @"put_to_pull";                // (No. 27)引き戻し開始時間
static NSString* const kSC_SP_pull                       = @"pull";                       // (No. 28)引き戻し量
static NSString* const kSC_SP_spot_l                     = @"spot_l";                     // (No. 30)MFD-左
static NSString* const kSC_SP_spot_r                     = @"spot_r";                     // (No. 31)MFD-右
static NSString* const kSC_SP_estloss_coeff              = @"estloss_coeff";              // (No. 32)推定ロス補正係数
static NSString* const kSC_SP_standard_loss              = @"standard_loss";              // (No. 33)推定損失許容値
static NSString* const kSC_SP_rearc_time                 = @"rearc_time";                 // (No. 34)追加放電時間
static NSString* const kSC_SP_hdcm                       = @"hdcm";                       // (No. 37)推定ロス算出モード
static NSString* const kSC_SP_adjust_type                = @"adjust_type";                // (No. 38)調心方法
static NSString* const kSC_SP_fiber_angle_limit          = @"fiber_angle_limit";          // (No. 40)ファイバ接続角許容値
static NSString* const kSC_SP_wavelength                 = @"wavelength";                 // (No. 41)波長
static NSString* const kSC_SP_offset_loss                = @"offset_loss";                // (No. 42)推定ロス加算
static NSString* const kSC_SP_splice_name                = @"splice_name";                // (No. 44)接続条件名称
static NSString* const kSC_SP_template_condition         = @"template_condition";         // (No. 54)テンプレート条件
static NSString* const kSC_SP_missmatch_coef             = @"missmatch_coef";             // (No. 66)MFDミスマッチ用係数
static NSString* const kSC_SP_arc_power_coeff_sw         = @"arc_power_coeff_sw";         // (No. 71)オート放電パワー
static NSString* const kSC_SP_fiber_detection            = @"fiber_detection";            // (No. 76)ファイバ種類識別
static NSString* const kSC_SP_attenuation                = @"attenuation";                // (No. 94)ATTN目標減衰量
static NSString* const kSC_SP_attn_factor                = @"attn_factor";                // (No. 95)ATTN校正係数
static NSString* const kSC_SP_angle_left                 = @"angle_left";                 // (No.107)左端面角度
static NSString* const kSC_SP_angle_right                = @"angle_right";                // (No.108)右端面角度
static NSString* const kSC_SP_align_bef                  = @"align_bef";                  // (No.109)軸ずれ量（融着前）
static NSString* const kSC_SP_deform_bef                 = @"deform_bef";                 // (No.110)軸ずれ角度（融着前）
static NSString* const kSC_SP_eccentric_left             = @"eccentric_left";             // (No.111)左偏心量
static NSString* const kSC_SP_eccentric_right            = @"eccentric_right";            // (No.112)右偏心量
static NSString* const kSC_SP_loss                       = @"loss";                       // (No.113)推定ロス値
static NSString* const kSC_SP_align                      = @"align";                      // (No.114)軸ずれ量（融着後）
static NSString* const kSC_SP_deform                     = @"deform";                     // (No.115)軸ずれ角度（融着後）
static NSString* const kSC_SP_error_no                   = @"error_no";                   // (No.116)エラー情報
static NSString* const kSC_SP_adjust_vy                  = @"adjust_vy";                  // (No.120)調心回数(VY)
static NSString* const kSC_SP_adjust_vx                  = @"adjust_vx";                  // (No.121)調心回数(VX)
static NSString* const kSC_SP_error1                     = @"error1";                     // (No.141)継続可能エラー情報１
static NSString* const kSC_SP_error2                     = @"error2";                     // (No.142)継続可能エラー情報２
static NSString* const kSC_SP_core_offset                = @"core_offset";                // (No.144)コアずれ量
static NSString* const kSC_SP_press                      = @"press";                      // (No.145)気圧
static NSString* const kSC_SP_correct_point              = @"correct_point";              // (No.146)電極棒補正位置
static NSString* const kSC_SP_core_left                  = @"core_left";                  // (No.147)左コア径
static NSString* const kSC_SP_core_right                 = @"core_right";                 // (No.148)右コア径
static NSString* const kSC_SP_format_ver                 = @"format_ver";                 // (No.151)フォーマットバージョン

static NSString* const kSC_SP_splice_data_info           = @"splice_data_info";           // 接続データ情報(1レコード分のバイナリデータ)
static NSString* const kSC_SP_detect_left                = @"detect_left";                // 心線識別(左)
static NSString* const kSC_SP_detect_right               = @"detect_right";               // 心線識別(右)

static NSString* const kSC_SP_irregular_left_x           = @"irregular_left_x";
static NSString* const kSC_SP_irregular_right_x          = @"irregular_right_x";
static NSString* const kSC_SP_irregular_left_y           = @"irregular_left_y";
static NSString* const kSC_SP_irregular_right_y          = @"irregular_right_y";
static NSString* const kSC_SP_limit_err_offset           = @"limit_err_offset";
static NSString* const kSC_SP_limit_err_gap              = @"limit_err_gap";
static NSString* const kSC_SP_limit_err_irregular        = @"limit_err_irregular";
static NSString* const kSC_SP_fiber_count                = @"fiber_count";
static NSString* const kSC_SP_template_name              = @"template_name";
static NSString* const kSC_SP_estimate_display_flag      = @"estimate_display_flag";
static NSString* const kSC_SP_nanotune_method            = @"nanotune_method";

