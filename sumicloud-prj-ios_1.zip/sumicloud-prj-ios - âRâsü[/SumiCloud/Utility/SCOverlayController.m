//
//  SCOverlayController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCOverlayController.h"
#import "SCLogUtil.h"

@interface SCOverlayController ()

@property UIView* vwDimming;

@end

@implementation SCOverlayController

/**
 Overlay表示される ViewControllerのサイズ・表示位置を算出
 
 @return <#return value description#>
 */
- (CGRect)frameOfPresentedViewInContainerView {
    
    CGRect ret = CGRectZero;
    
    ret.size = [self sizeForChildContentContainer:self.presentedViewController withParentContainerSize:self.containerView.bounds.size];
    
    if (kOLH_Center == self.overlayHorizontally) {
        
        // 水平方向（中央）
        ret.origin.x = (self.containerView.bounds.size.width / 2.0f) - (ret.size.width / 2.0f);
    } else if (kOLH_Right == self.overlayHorizontally) {
        
        // 水平方向（右端）
        ret.origin.x = self.containerView.bounds.size.width - ret.size.width;
    } else {
        
        // 水平方向（左端）
        ret.origin.x = 0.0f;
    }
    
    if (kOLV_Center == self.overlayVertically) {
        
        // 垂直方向（中央）
        ret.origin.y = (self.containerView.bounds.size.height / 2.0f) - (ret.size.height / 2.0f);
    } else if (kOLV_Bottom == self.overlayVertically) {
        
        // 垂直方向（下端）
        ret.origin.y = self.containerView.bounds.size.height - ret.size.height;
    } else {
        
        // 垂直方向（上端）
        ret.origin.y = 0.0f;
    }
    
    DDLogDebug(@"<x,y>=<%f,%f> / <width,height>=<%f,%f>", ret.origin.x, ret.origin.y, ret.size.width, ret.size.height);
    
    return ret;
}

/**
 Overlay表示される ViewControllerのサイズを算出
 
 @param container  <#container description#>
 @param parentSize <#parentSize description#>
 
 @return <#return value description#>
 */
- (CGSize)sizeForChildContentContainer:(id<UIContentContainer>)container withParentContainerSize:(CGSize)parentSize {
    
    return self.overlaySize;
}

/**
 PresentationControllerの初期化
 
 @param presentedViewController  <#presentedViewController description#>
 @param presentingViewController <#presentingViewController description#>
 
 @return <#return value description#>
 */
- (instancetype)initWithPresentedViewController:(UIViewController *)presentedViewController presentingViewController:(UIViewController *)presentingViewController {
    
    self = [super initWithPresentedViewController:presentedViewController presentingViewController:presentingViewController];
    if (self) {
        
        self.vwDimming = [[UIView alloc] init];
        self.vwDimming.backgroundColor = [UIColor colorWithWhite:0.0f alpha:0.4f];
        self.vwDimming.alpha = 0.0f;
    }
    
    return self;
}

/**
 フェードイン
 */
- (void)presentationTransitionWillBegin {
    
    UITapGestureRecognizer* tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapActionClose:)];
    tapGesture.numberOfTapsRequired = 1;
    self.vwDimming.gestureRecognizers = [NSArray arrayWithObject:tapGesture];
    
    self.vwDimming.frame = self.containerView.bounds;
    self.vwDimming.alpha = 0.0f;
    [self.containerView insertSubview:self.vwDimming atIndex:0];
    
    if (self.presentedViewController.transitionCoordinator) {
        
        [self.presentedViewController.transitionCoordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
            
            self.vwDimming.alpha = 1.0f;
        } completion:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
        }];
    } else {
        
        self.vwDimming.alpha = 1.0f;
    }
}

/**
 Overlay表示のキャンセル
 
 @param completed <#completed description#>
 */
- (void)presentationTransitionDidEnd:(BOOL)completed {
    
    if (!completed) {
        
        [self.vwDimming removeFromSuperview];
    }
}

/**
 フェードアウト
 */
- (void)dismissalTransitionWillBegin {
    
    if (self.presentedViewController.transitionCoordinator) {
        
        [self.presentedViewController.transitionCoordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
            
            self.vwDimming.alpha = 0.0f;
        } completion:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
        }];
    } else {
        
        self.vwDimming.alpha = 0.0f;
    }
}

/**
 Overlay非表示
 
 @param completed <#completed description#>
 */
- (void)dismissalTransitionDidEnd:(BOOL)completed {
    
    if (completed) {
        
        [self.vwDimming removeFromSuperview];
    }
}

/**
 レイアウト変更
 */
- (void)containerViewWillLayoutSubviews {
    
    self.vwDimming.frame = self.containerView.bounds;
    self.presentedView.frame = [self frameOfPresentedViewInContainerView];
}


#pragma mark - Action

/**
 Overlay閉じる
 
 @param sender <#sender description#>
 */
- (void)tapActionClose:(UITapGestureRecognizer *)sender {
    
    [self.presentedViewController dismissViewControllerAnimated:YES completion:^{
    }];
}

@end
