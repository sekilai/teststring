//
//  SCOverlayControllerAnimatedTransitioning.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCOverlayControllerAnimatedTransitioning : NSObject <UIViewControllerAnimatedTransitioning>

- (instancetype)initWithPresent:(BOOL)present;

// アニメーション方向
typedef NS_ENUM(NSInteger, SCAnimationDirection) {
    kOLAD_None = 0,    // アニメーションなし
    kOLAD_LeftToRight, // 左から右へアニメーション
    kOLAD_RightToLeft, // 右から左へアニメーション
    kOLAD_TopToBottom, // 上から下へアニメーション
    kOLAD_BottomToTop  // 下から上へアニメーション（未対応）
};
@property (nonatomic) SCAnimationDirection overlayAnimationDirection;

@end
