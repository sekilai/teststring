//
//  SCNotificationService.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/11/16.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCNotificationService : NSObject

// インスタンス生成
+ (instancetype)sharedInstance;

// 通知の送信
- (void)sendNotification:(NSString *)alertMsg info:(NSDictionary *)info;

@end


#pragma mark - Const

static NSString * const kSC_NS_Alert = @"Alert";
static NSString * const kSC_NS_SecurityLock = @"SecurityLock";
static NSString * const kSC_NS_SerialNo = @"SerialNo";
static NSString * const kSC_NS_NotifyType = @"NotifyType";

static NSString* const kSC_NS_Command_MainUnitLock   = @"lock";   // 本体ロックコマンド通知
static NSString* const kSC_NS_Command_MainUnitUnlock = @"unlock"; // 本体ロック解除コマンド通知
static NSString* const kSC_NS_Command_LogSend        = @"log";    // ログ送信コマンド通知
