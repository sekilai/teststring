//
//  SCScreenCaptureViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCScreenCaptureViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCScreenCaptureFlow.h"
#import "UIView+Border.h"
#import "SCLeftMenuViewController.h"

@interface SCScreenCaptureViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) SCScreenCaptureFlow* flow;
@property (nonatomic) NSMutableArray* listFunctionMenu;

@property (weak, nonatomic) IBOutlet UITableView *tblvwAction;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;
@property (weak, nonatomic) IBOutlet UILabel *lblMsgUp;

@end

@implementation SCScreenCaptureViewController

static NSString* const kSC_CAP_Title      = @"Title";      // メニュータイトル
static NSString* const kSC_CAP_SegueId    = @"SegueId";    // 画面遷移ID
static NSString* const kSC_CAP_CellId     = @"CellId";     // セルID
static NSString* const kSC_CAP_CellHeight = @"CellHeight"; // セルの高さ

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];

    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_CAPTURE", @"キャプチャ");
    
    // 機能メニュー
    self.listFunctionMenu = [NSMutableArray arrayWithCapacity:0];
    [self.listFunctionMenu addObject:@{
                                       // "シャッターボタン"
                                       kSC_CAP_Title : @"",
                                       kSC_CAP_SegueId : @"",
                                       kSC_CAP_CellId : @"cellCapture",
                                       kSC_CAP_CellHeight : [NSNumber numberWithFloat:72.0f]
                                       }];
    [self.listFunctionMenu addObject:@{
                                       // "キャプチャ一覧"
                                       kSC_CAP_Title : @"TITLE_CAPTURE_LIST",
                                       kSC_CAP_SegueId : @"toSelectImage",
                                       kSC_CAP_CellId : @"cell",
                                       kSC_CAP_CellHeight : [NSNumber numberWithFloat:48.0f]
                                       }];
    
    // スクロール禁止
    self.tblvwAction.scrollEnabled = NO;
    
    // 画面表示データの更新
    self.isSelectedSplicer = YES;
    [self refreshSelectedSerialNo];

    self.appData.manScreenCapture = [[SCScreenCaptureManager alloc] init];

    // メッセージ
    self.lblMsgUp.text = NSLocalizedString(@"MSG_10039", @"");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
}

#pragma mark - Segue

/**
 左メニュー遷移
 
 @param segue  <#segue description#>
 @param sender <#sender description#>
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    DDLogDebug(@"");
    
    if ([@"toLeftMenu" isEqualToString:segue.identifier]) {
        
        segue.destinationViewController.modalPresentationStyle = UIModalPresentationCustom;
        segue.destinationViewController.transitioningDelegate = self;
        SCLeftMenuViewController* leftVC = segue.destinationViewController;
        leftVC.preVC = self.parentViewController;
    }
}


#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

    NSDictionary* dic = self.listFunctionMenu[indexPath.row];
    return [dic[kSC_CAP_CellHeight] floatValue];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listFunctionMenu.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary* dic = self.listFunctionMenu[indexPath.row];

    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:dic[kSC_CAP_CellId]];
    
    if ([dic[kSC_CAP_CellId] isEqualToString:@"cell"]) {
        
        UILabel* label = [cell viewWithTag:1];
        label.text = NSLocalizedString(dic[kSC_CAP_Title], @"キャプチャ一覧");
    } else {

        // 色味の設定
        cell.backgroundColor = [SCSystemData colorWithRGB:0x52 green:0x58 blue:0x61 alpha:1.0f];
    }
    
    return cell;
}

/**
 シャッターボタン/キャプチャ一覧選択

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    NSDictionary* dic = self.listFunctionMenu[indexPath.row];

    if ([dic[kSC_CAP_SegueId] isEqualToString:@"toSelectImage"]) {

        // キャプチャ一覧選択
        dispatch_async(dispatch_get_main_queue(), ^{
            
            // 融着機が未選択の場合はエラーを表示する
            if ([self isUnselectSplicerAlert]) {
                
                return;
            }
            
            // 写真のアクセスが「許可する」以外の場合はアラートを表示し、遷移しない
            if ([self isPhotosAuthDeniedAlert]) {
                
                return;
            }
            
            [self performSegueWithIdentifier:@"toSelectImage" sender:self];
        });
    } else {
        
        // シャッターボタン選択
        dispatch_async(dispatch_get_main_queue(), ^{
            
            // アプリ使用期限の確認
            if ([self isPassedExpirationDateMsg]) {
                
                return;
            }
            
            // Wi-Fi切り替え確認
            if (![self isSplicerConnect:self.appData.selectedSerialNo]) {
                
                [self connectInternetAlert];
                
                return;
            }
            
            self.flow = [[SCScreenCaptureFlow alloc] init];
            [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中....") cancelHandler:^{
                
                DDLogDebug(@"プログレスのキャンセル");
                
                [self.flow cancelFlow];
            }];
            
            // ビジネスフロー
            DDLogInfo(@"4.スクリーンキャプチャ機能フロー:開始");
            [self.flow runFlow:self.appData.selectedSerialNo completion:^(NSError *error) {
                
                DDLogInfo(@"4.スクリーンキャプチャ機能フロー:完了");
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [self hideProgress];
                    
                    // ビジネスフロー結果メッセージ表示
                    [self messageBFResult:self.flow.resultFlow error:error actionHandler:nil];
                    
                    if (!error && (kBF_OK == self.flow.resultFlow)) {
                        
                        UIImage* image = [UIImage imageWithData:self.appData.manScreenCapture.captureImage];
                        if (image) {
                            
                            // 「キャプチャ撮影後画面」へ遷移
                            [self performSegueWithIdentifier:@"toPreview" sender:self];
                        }
                    }
                    
                    self.flow = nil;
                });
            }];
        });
    }
}

#pragma mark - Override Method

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

@end
