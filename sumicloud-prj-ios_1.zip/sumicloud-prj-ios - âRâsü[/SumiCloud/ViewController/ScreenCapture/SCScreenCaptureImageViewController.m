//
//  SCScreenCaptureImageViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCScreenCaptureImageViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"

#import "SCScreenCaptureFlow.h"
#import "SCCaptureData.h"

@interface SCScreenCaptureImageViewController () <UIScrollViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *navigationView;
@property (weak, nonatomic) IBOutlet UIButton *btnClose;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UIButton *btnAction;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UIScrollView *imageScrollView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageHeightConstraint;
@property (weak, nonatomic) IBOutlet UILabel *lblPage;
@property (weak, nonatomic) IBOutlet UIButton *btnPageBack;
@property (weak, nonatomic) IBOutlet UIButton *btnPageNext;

@property (nonatomic) NSInteger curPage;
@property (nonatomic) NSInteger maxPageCnt;
@property (nonatomic) NSArray *captureList;
@property (nonatomic) NSArray *captureImageList;

- (IBAction)btnCloseUpInside:(id)sender;
- (IBAction)btnActionUpInside:(id)sender;
- (IBAction)btnPageBackUpInside:(id)sender;
- (IBAction)btnPageNextUpInside:(id)sender;

@end

@implementation SCScreenCaptureImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // ナビゲーションバー設定
    self.navigationView.backgroundColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    self.lblTitle.font = [UIFont boldSystemFontOfSize:17.0];
    
    // タイトル
    self.lblTitle.text = [NSString stringWithFormat:@"%@ %@",self.appData.manScreenCapture.selectYYYYMMDD, self.appData.manScreenCapture.selectHHMMSS];
    
    // 画像表示データの更新
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    [self refreshOnlineSerialNo];
    
    // 選択中の日付のキャプチャ情報一覧を取得する
    self.captureList = [SCScreenCaptureFlow getWithDateCaptureList:self.appData.manScreenCapture.selectYYYYMMDD];
    
    // 「日付」のキャプチャ画像を取得する
    NSMutableArray *aryImage = [[NSMutableArray alloc] initWithCapacity:0];
    
    for (SCCaptureData *item in self.captureList) {
        
        UIImage *image = [[SCScreenCaptureFlow getImageWithIdentifier:@[item.path] thumbnail:NO] lastObject];
        [aryImage addObject:image];
    }
    self.captureImageList = aryImage;

    // 選択日付のページ件数
    self.maxPageCnt = self.captureList.count;
    
    // 選択している時刻のページ数
    for (int i = 0; i < self.maxPageCnt; i++) {
        
        SCCaptureData *data = self.captureList[i];
        if ([data.time isEqualToString:self.appData.manScreenCapture.selectHHMMSS]) {
            
            self.curPage = i;
        }
    }
    
    // ジェスチャー登録
    UITapGestureRecognizer *imageDoubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageDoubleTap:)];
    imageDoubleTap.numberOfTapsRequired = 2;
    self.imageView.userInteractionEnabled = YES;
    [self.imageView addGestureRecognizer:imageDoubleTap];
    
    self.imageScrollView.minimumZoomScale = 1.0;
    self.imageScrollView.maximumZoomScale = 5.0;
    self.imageScrollView.zoomScale = self.imageScrollView.minimumZoomScale;

    // Viewサイズの調整
    UIImage *obj = self.captureImageList.firstObject;
    CGSize imageSize = obj.size;
    float width = self.navigationView.frame.size.width;
    float height = width * imageSize.height / imageSize.width;
    self.imageHeightConstraint.constant = height;
    [self.imageView updateConstraints];
    
    [self showPage];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIButton Action

/**
 閉じるボタン

 */
- (IBAction)btnCloseUpInside:(id)sender {

    // 画面を閉じる
    [self dismissViewControllerAnimated:YES completion:nil];
}

/**
 アクションメニューボタン

 */
- (IBAction)btnActionUpInside:(id)sender {
    
    DDLogDebug(@"");
}

/**
 戻るボタン

 */
- (IBAction)btnPageBackUpInside:(id)sender {
    
    // 前ページに遷移
    self.curPage--;
    [self showPage];
}

/**
 進むボタン

 */
- (IBAction)btnPageNextUpInside:(id)sender {
    
    // 後ページに遷移
    self.curPage++;
    [self showPage];
}

#pragma mark - UIImageView Action

/**
 ダブルタップで拡大
 
 @param sender <#sender description#>
 */
- (void)imageDoubleTap:(UITapGestureRecognizer *)sender {
    
    CGPoint pos = [sender locationInView:self.imageScrollView];
    
    CGRect zoom;
    if (self.imageScrollView.zoomScale > self.imageScrollView.minimumZoomScale) {
        
        zoom = self.imageScrollView.bounds;
    } else {
        
        zoom = [self zoomRectForScrollView:self.imageScrollView withScale:self.imageScrollView.maximumZoomScale withCenter:pos];
    }
    [self.imageScrollView zoomToRect:zoom animated:YES];
}

#pragma mark - UIScrollViewDelegate

/**
 zoomRectForScrollView（Apple のガイド参照）
 
 @param scrollView <#scrollView description#>
 @param scale <#scale description#>
 @param center <#center description#>
 @return <#return value description#>
 */
- (CGRect)zoomRectForScrollView:(UIScrollView *)scrollView withScale:(float)scale withCenter:(CGPoint)center {
    
    CGRect zoom;
    
    zoom.size.height = scrollView.frame.size.height / scale;
    zoom.size.width = scrollView.frame.size.width / scale;
    
    zoom.origin.x = center.x - (zoom.size.width / 2.0);
    zoom.origin.y = center.y - (zoom.size.height / 2.0);
    
    return zoom;
}

/**
 ピンチインで縮小、ピンチアウトで拡大
 
 @param scrollView <#scrollView description#>
 @return <#return value description#>
 */
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    
    // イメージの操作
    return self.imageView;
}

#pragma mark - Private Methods

/**
 キャプチャ詳細のページ表示
 
 */
- (void)showPage {

    self.btnPageBack.hidden = YES;
    self.btnPageNext.hidden = YES;
    
    // ページの更新
    if (0 == self.maxPageCnt) {
        
        self.lblPage.text = @"-/-";
        return;
    }

    // タイトルの更新
    SCCaptureData *data = self.captureList[self.curPage];
    self.lblTitle.text = [NSString stringWithFormat:@"%@ %@", data.date, data.time];
    
    self.lblPage.text = [NSString stringWithFormat:NSLocalizedString(@"PAGE_FORMAT", @"%@ / %@"), @(self.curPage + 1), @(self.maxPageCnt)];
    
    // ページボタンの更新
    if (self.curPage > 0) {
        
        self.btnPageBack.hidden = NO;
    }
    if (self.curPage < self.maxPageCnt - 1) {

        self.btnPageNext.hidden = NO;
    }
    
    // キャプチャ画像の更新
    self.imageView.image = self.captureImageList[self.curPage];
}

#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}


@end
