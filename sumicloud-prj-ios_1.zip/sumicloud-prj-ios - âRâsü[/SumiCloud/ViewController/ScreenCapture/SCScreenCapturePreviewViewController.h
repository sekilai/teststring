//
//  SCScreenCapturePreviewViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_8 on 2016/11/17.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCScreenCapturePreviewViewController : SCBaseViewController

@end
