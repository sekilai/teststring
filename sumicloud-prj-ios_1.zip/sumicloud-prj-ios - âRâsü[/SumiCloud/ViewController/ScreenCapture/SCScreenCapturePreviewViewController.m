//
//  SCScreenCapturePreviewViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_8 on 2016/11/17.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCScreenCapturePreviewViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCScreenCaptureFlow.h"

@interface SCScreenCapturePreviewViewController () <UIScrollViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *navigationView;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UIScrollView *captureScrollView;
@property (weak, nonatomic) IBOutlet UIImageView *capturePrevImage;

@property (weak, nonatomic) IBOutlet UIButton *btnSave;

- (IBAction)btnSaveUpInside:(id)sender;
- (IBAction)btnCloseUpInside:(id)sender;

@end

@implementation SCScreenCapturePreviewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // ナビゲーションバー設定
    self.navigationView.backgroundColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    self.lblTitle.font = [UIFont boldSystemFontOfSize:18.0];
    self.lblTitle.text = NSLocalizedString(@"TITLE_CAPTURE_IMAGE", @"キャプチャ画像");
    
    // 保存ボタン設定
    [self.btnSave setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnSave setBackgroundImage:[self setButtonHilightBackColor:self.btnSave.bounds] forState:UIControlStateHighlighted];
    [self.btnSave setTitle:NSLocalizedString(@"BTN_SAVE", @"保存") forState:UIControlStateNormal];
    
    // ジェスチャー登録
    UITapGestureRecognizer *imageDoubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageDoubleTap:)];
    imageDoubleTap.numberOfTapsRequired = 2;
    self.capturePrevImage.userInteractionEnabled = YES;
    [self.capturePrevImage addGestureRecognizer:imageDoubleTap];

    self.captureScrollView.minimumZoomScale = 1.0;
    self.captureScrollView.maximumZoomScale = 5.0;
    self.captureScrollView.zoomScale = self.captureScrollView.minimumZoomScale;

    // 画像設定
    self.capturePrevImage.image = [UIImage imageWithData:self.appData.manScreenCapture.captureImage];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIButton Action

/**
 保存ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnSaveUpInside:(id)sender {

    // 保存ボタンの操作を抑止する
    UIButton *btn = (UIButton *)sender;
    btn.userInteractionEnabled = NO;
    
    [SCScreenCaptureFlow saveScreenCaptureCompletion:^(NSError *error) {

        if (!error) {
            
            DDLogDebug(@"スクリーンキャプチャ保存成功");
        } else {
            
            DDLogDebug(@"スクリーンキャプチャ保存失敗[%@]", error);
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            
            // 画面を閉じる
            self.appData.manScreenCapture.captureImage = nil;
            self.appData.manScreenCapture.captureData = nil;
            [self dismissViewControllerAnimated:YES completion:nil];
        });
    }];
    
}

/**
 閉じるボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCloseUpInside:(id)sender {
    
    // 画面を閉じる
    self.appData.manScreenCapture.captureImage = nil;
    self.appData.manScreenCapture.captureData = nil;
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UIImageView Action

/**
 ダブルタップで拡大
 
 @param sender <#sender description#>
 */
- (void)imageDoubleTap:(UITapGestureRecognizer *)sender {
    
    CGPoint pos = [sender locationInView:self.captureScrollView];
    
    CGRect zoom;
    if (self.captureScrollView.zoomScale > self.captureScrollView.minimumZoomScale) {
        
        zoom = self.captureScrollView.bounds;
    } else {
        
        zoom = [self zoomRectForScrollView:self.captureScrollView withScale:self.captureScrollView.maximumZoomScale withCenter:pos];
    }
    [self.captureScrollView zoomToRect:zoom animated:YES];
}

#pragma mark - UIScrollViewDelegate

/**
 zoomRectForScrollView（Apple のガイド参照）
 
 @param scrollView <#scrollView description#>
 @param scale <#scale description#>
 @param center <#center description#>
 @return <#return value description#>
 */
- (CGRect)zoomRectForScrollView:(UIScrollView *)scrollView withScale:(float)scale withCenter:(CGPoint)center {
    
    CGRect zoom;
    
    zoom.size.height = scrollView.frame.size.height / scale;
    zoom.size.width = scrollView.frame.size.width / scale;
    
    zoom.origin.x = center.x - (zoom.size.width / 2.0);
    zoom.origin.y = center.y - (zoom.size.height / 2.0);
    
    return zoom;
}

/**
 ピンチインで縮小、ピンチアウトで拡大
 
 @param scrollView <#scrollView description#>
 @return <#return value description#>
 */
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    
    // イメージの操作
    return self.capturePrevImage;
}

@end
