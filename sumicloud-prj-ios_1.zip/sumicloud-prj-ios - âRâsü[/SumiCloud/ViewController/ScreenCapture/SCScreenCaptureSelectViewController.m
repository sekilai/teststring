//
//  SCScreenCaptureSelectViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCScreenCaptureSelectViewController.h"
#import "SCLogUtil.h"

#import "SCScreenCaptureFlow.h"
#import "SCCaptureData.h"

@interface SCScreenCaptureSelectViewController () <UICollectionViewDelegate, UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UICollectionView *viewCollection;

@property (nonatomic) NSArray *dateList; // 日付一覧
@property (nonatomic) NSArray *dateCountList; // 日付ごとの件数一覧
@property (nonatomic) NSArray *captureList; // キャプチャデータ一覧

@end

@implementation SCScreenCaptureSelectViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_CAPTURE_LIST", @"キャプチャ一覧");
    
    // 画面表示データの更新
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    [self refreshOnlineSerialNo];
    
    // フォアグラウンド遷移通知の登録
    // カメラロールで画像削除した場合に、選択時にフレームワークのメソッドで配列の参照エラーが発生する対策用
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appWillEnterForeground) name:UIApplicationWillEnterForegroundNotification object:nil];
    
    if (![self.appData.selectedSerialNo isEqualToString:@"---"]) {

        // カメラロールで削除されたデータはDBから削除する
        [SCScreenCaptureFlow updateCaptureData];
        
        // 日付一覧を取得する
        self.dateList = [SCScreenCaptureFlow getWithDateList];
        
        // 日付ごとの件数一覧を取得する
        self.dateCountList = [SCScreenCaptureFlow getWithDateTotalList:self.dateList];
        
        // キャプチャデータを取得する
        self.captureList = [SCScreenCaptureFlow getWithCaptureList:self.dateList];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)appWillEnterForeground {
    
    if (![self.appData.selectedSerialNo isEqualToString:@"---"]) {
        
        // カメラロールで削除されたデータはDBから削除する
        [SCScreenCaptureFlow updateCaptureData];
        
        // 日付一覧を取得する
        self.dateList = [SCScreenCaptureFlow getWithDateList];
        
        // 日付ごとの件数一覧を取得する
        self.dateCountList = [SCScreenCaptureFlow getWithDateTotalList:self.dateList];
        
        // キャプチャデータを取得する
        self.captureList = [SCScreenCaptureFlow getWithCaptureList:self.dateList];
    }
    [self.viewCollection reloadData];
}

#pragma mark - UICollectionViewDelegate

/**
 CollectionViewのセクション数

 @param collectionView <#collectionView description#>
 
 @return <#return value description#>
 */
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return self.dateList.count;
}

/**
 CollectionViewの列数

 @param collectionView <#collectionView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return [self.dateCountList[section] integerValue];
}

/**
 CollectionViewのヘッダーを生成

 @param collectionView <#collectionView description#>
 @param kind <#kind description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *header =  [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"dateHeader" forIndexPath:indexPath];
    
    // 日付を取得
    UILabel *lblDate = (UILabel*)[header viewWithTag:1];
    lblDate.text = [self.dateList objectAtIndex:indexPath.section];
    
    return header;
}

/**
 CollectionViewのセルを生成

 @param collectionView <#collectionView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    UICollectionViewCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"captureCell" forIndexPath:indexPath];
    
    // キャプチャ画像のIDを取得
    SCCaptureData* data = self.captureList[indexPath.section][indexPath.row];
    NSString* imageId = data.path;
    
    // サムネイルを取得
    NSArray* aryThumbnail = [SCScreenCaptureFlow getImageWithIdentifier:@[imageId] thumbnail:YES];
    if (aryThumbnail.count != 0) {
        UIImage* thumbnail = aryThumbnail.lastObject;
        UIImageView* viewImage = (UIImageView*)[cell viewWithTag:1];
        viewImage.image = thumbnail;
    }
    
    return cell;
}

/**
 キャプチャ一覧の選択

 @param collectionView <#collectionView description#>
 @param indexPath <#indexPath description#>
 */
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSLog(@"キャプチャ選択");
    
    // 選択したキャプチャ画像のIDを取得
    SCCaptureData* data = self.captureList[indexPath.section][indexPath.row];
    
    // 日付、時刻を保持
    self.appData.manScreenCapture.selectYYYYMMDD = data.date;
    self.appData.manScreenCapture.selectHHMMSS = data.time;
    
    // 「キャプチャ詳細画面」へ遷移
    [self performSegueWithIdentifier:@"toCaptureImage" sender:self];
}


/**
 Backボタン
 
 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {
    
    DDLogDebug(@"");
    
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 アクションメニューボタン
 
 @param sender <#sender description#>
 */
- (IBAction)actionMenu:(UIBarButtonItem *)sender {
    
    DDLogDebug(@"");
}

#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

@end
