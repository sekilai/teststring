//
//  SCSpliceDataReferenceImageViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/13.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataReferenceImageViewController.h"
#import "SCLogUtil.h"
#import "SCSystemData.h"

@interface SCSpliceDataReferenceImageViewController () <UIScrollViewDelegate>

@property (nonatomic) NSInteger currentPageNo;
@property (nonatomic) NSInteger maxPageNo;

@property (weak, nonatomic) IBOutlet UIScrollView *viewScrollX;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwX;
@property (weak, nonatomic) IBOutlet UIScrollView *viewScrollY;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwY;
@property (weak, nonatomic) IBOutlet UIButton *btnPrevImage;
@property (weak, nonatomic) IBOutlet UILabel *lblPage;
@property (weak, nonatomic) IBOutlet UIButton *btnNextImage;
@property (weak, nonatomic) IBOutlet UIView *detail_72MView;
@property (weak, nonatomic) IBOutlet UIImageView *img_72MX;
@property (weak, nonatomic) IBOutlet UIImageView *img_72MY;
@property (weak, nonatomic) IBOutlet UIScrollView *view72MScrollX;
@property (weak, nonatomic) IBOutlet UIScrollView *view72MScrollY;


- (IBAction)btnPrevImageTouchUpInside:(UIButton *)sender;
- (IBAction)btnNextImageTouchUpInside:(UIButton *)sender;

@end

@implementation SCSpliceDataReferenceImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 多言語対応
    self.title = NSLocalizedString(@"BTN_SPLICEDATA_IMAGE", @"画像");
    
    self.detail_72MView.hidden = ![SCSystemData isModelType72M:self.appData.selectedSerialNo];
    
    UITapGestureRecognizer *imageDoubleTapX = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageDoubleTapX:)];
    imageDoubleTapX.numberOfTapsRequired = 2;
    self.imgvwX.userInteractionEnabled = YES;
    [self.imgvwX addGestureRecognizer:imageDoubleTapX];
    
    UITapGestureRecognizer *imageDoubleTapY = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageDoubleTapY:)];
    imageDoubleTapY.numberOfTapsRequired = 2;
    self.imgvwY.userInteractionEnabled = YES;
    [self.imgvwY addGestureRecognizer:imageDoubleTapY];

    self.viewScrollX.minimumZoomScale = 1.0;
    self.viewScrollX.maximumZoomScale = 5.0;
    self.viewScrollX.zoomScale = self.viewScrollX.minimumZoomScale;

    self.viewScrollY.minimumZoomScale = 1.0;
    self.viewScrollY.maximumZoomScale = 5.0;
    self.viewScrollY.zoomScale = self.viewScrollY.minimumZoomScale;
    
    if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
        self.view72MScrollX.minimumZoomScale = 1.0;
        self.view72MScrollX.maximumZoomScale = 5.0;
        self.view72MScrollX.zoomScale = self.view72MScrollX.minimumZoomScale;
        
        self.view72MScrollY.minimumZoomScale = 1.0;
        self.view72MScrollY.maximumZoomScale = 5.0;
        self.view72MScrollY.zoomScale = self.view72MScrollY.minimumZoomScale;
        
        UITapGestureRecognizer *doubleTapX = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageDoubleTapX:)];
        doubleTapX.numberOfTapsRequired = 2;
        self.img_72MX.userInteractionEnabled = YES;
        [self.img_72MX addGestureRecognizer:doubleTapX];
        
        UITapGestureRecognizer *doubleTapY = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageDoubleTapY:)];
        doubleTapY.numberOfTapsRequired = 2;
        self.img_72MY.userInteractionEnabled = YES;
        [self.img_72MY addGestureRecognizer:doubleTapY];
    }

    self.currentPageNo = 0;
    self.maxPageNo = [self.appData.detailSpliceData.image_download_flg integerValue];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    [self showPageNo];
}


#pragma mark - Button Action

/**
 前イメージボタン

 @param sender <#sender description#>
 */
- (IBAction)btnPrevImageTouchUpInside:(UIButton *)sender {

    self.currentPageNo = self.currentPageNo - 1;
    
    [self showPageNo];
}

/**
 後イメージボタン

 @param sender <#sender description#>
 */
- (IBAction)btnNextImageTouchUpInside:(UIButton *)sender {

    self.currentPageNo = self.currentPageNo + 1;
    
    [self showPageNo];
}

#pragma maek - Action

/**
 ダブルタップで拡大（X画像）

 @param sender <#sender description#>
 */
- (void)imageDoubleTapX:(UITapGestureRecognizer *)sender {
    
    CGPoint pos = [sender locationInView:self.viewScrollX];
    
    if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
        CGRect zoom;
        if (self.view72MScrollX.zoomScale > self.viewScrollX.minimumZoomScale) {
            
            zoom = self.view72MScrollX.bounds;
        } else {
            
            zoom = [self zoomRectForScrollView:self.view72MScrollX withScale:self.view72MScrollX.maximumZoomScale withCenter:pos];
        }
        [self.view72MScrollX zoomToRect:zoom animated:YES];
    } else {
        CGRect zoom;
        if (self.viewScrollX.zoomScale > self.viewScrollX.minimumZoomScale) {
            
            zoom = self.viewScrollX.bounds;
        } else {
            
            zoom = [self zoomRectForScrollView:self.viewScrollX withScale:self.viewScrollX.maximumZoomScale withCenter:pos];
        }
        [self.viewScrollX zoomToRect:zoom animated:YES];
    }
}

/**
 ダブルタップで拡大（Y画像）

 @param sender <#sender description#>
 */
- (void)imageDoubleTapY:(UITapGestureRecognizer *)sender {
    
    CGPoint pos = [sender locationInView:self.viewScrollY];
    
    if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
        CGRect zoom;
        if (self.view72MScrollY.zoomScale > self.view72MScrollY.minimumZoomScale) {
            
            zoom = self.view72MScrollY.bounds;
        } else {
            
            zoom = [self zoomRectForScrollView:self.view72MScrollY withScale:self.view72MScrollY.maximumZoomScale withCenter:pos];
        }
        [self.view72MScrollY zoomToRect:zoom animated:YES];
    } else {
        CGRect zoom;
        if (self.viewScrollY.zoomScale > self.viewScrollY.minimumZoomScale) {
            
            zoom = self.viewScrollY.bounds;
        } else {
            
            zoom = [self zoomRectForScrollView:self.viewScrollY withScale:self.viewScrollY.maximumZoomScale withCenter:pos];
        }
        [self.viewScrollY zoomToRect:zoom animated:YES];
    }
    
}


#pragma mark - UIScrollViewDelegate

/**
 zoomRectForScrollView（Apple のガイド参照）
 
 @param scrollView <#scrollView description#>
 @param scale <#scale description#>
 @param center <#center description#>
 @return <#return value description#>
 */
- (CGRect)zoomRectForScrollView:(UIScrollView *)scrollView withScale:(float)scale withCenter:(CGPoint)center {
    
    CGRect zoom;
    
    zoom.size.height = scrollView.frame.size.height / scale;
    zoom.size.width = scrollView.frame.size.width / scale;
    
    zoom.origin.x = center.x - (zoom.size.width / 2.0);
    zoom.origin.y = center.y - (zoom.size.height / 2.0);
    
    return zoom;
}

/**
 ピンチインで縮小、ピンチアウトで拡大

 @param scrollView <#scrollView description#>
 @return <#return value description#>
 */
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {

    if (self.viewScrollX == scrollView) {
        
        // X イメージの操作
        return self.imgvwX;
    } else if ( self.viewScrollY == scrollView ){
        
        // Y イメージの操作
        return self.imgvwY;
    } else if ( self.view72MScrollX == scrollView ) {
        return self.img_72MX;
    } else {
        return self.img_72MY;
    }
}


#pragma mark - Private Method

/**
 ページ番号の表示
 */
- (void)showPageNo {
    
    self.btnPrevImage.enabled = NO;
    self.btnPrevImage.hidden = YES;
    self.btnNextImage.enabled = NO;
    self.btnNextImage.hidden = YES;

    // XY画像の表示ページ
    if (0 == self.maxPageNo) {
        
        self.lblPage.text = @"-/-";
        return;
    }
    self.lblPage.text = [NSString stringWithFormat:NSLocalizedString(@"PAGE_FORMAT", @"%@ / %@"), @(self.currentPageNo + 1), @(self.maxPageNo)];

    // XY画像表示
    switch (self.currentPageNo) {
        case 0:
            [self splitImage:self.appData.detailSpliceData.img_data1];
            break;
        case 1:
            [self splitImage:self.appData.detailSpliceData.img_data2];
            break;
        case 2:
            [self splitImage:self.appData.detailSpliceData.img_data3];
            break;
        case 3:
            [self splitImage:self.appData.detailSpliceData.img_data4];
            break;
        case 4:
            [self splitImage:self.appData.detailSpliceData.img_data5];
            break;
            
        default:
            break;
    }
    
    // ページ替えボタンの表示制御
    if (0 < self.maxPageNo) {
        
        if (0 < self.currentPageNo) {
            
            self.btnPrevImage.enabled = YES;
            self.btnPrevImage.hidden = NO;
        }
        
        if ((self.currentPageNo+1) < self.maxPageNo) {
            
            self.btnNextImage.enabled = YES;
            self.btnNextImage.hidden = NO;
        }
    }
}

/**
 X,Y 画像に分割して表示
 
 @param spliceDataImage <#spliceDataImage description#>
 */
- (void)splitImage:(NSData *)spliceDataImage {
    
    if (spliceDataImage) {
        
        UIImage* image = [[UIImage alloc] initWithData:spliceDataImage];
        if (image) {
            
            CGRect xRect = CGRectMake(image.size.width / 2, 0, image.size.width / 2, image.size.height);
            CGRect yRect = CGRectMake(0, 0, image.size.width / 2, image.size.height);
            
            CGImageRef imageRef = [image CGImage];
            CGImageRef xImageRef = CGImageCreateWithImageInRect(imageRef, xRect);
            self.imgvwX.image = [UIImage imageWithCGImage:xImageRef];
            if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
                self.img_72MX.image = [UIImage imageWithCGImage:xImageRef];
            }
            CGImageRelease(xImageRef);
            CGImageRef yImageRef = CGImageCreateWithImageInRect(imageRef, yRect);
            self.imgvwY.image = [UIImage imageWithCGImage:yImageRef];
            if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
                self.img_72MY.image = [UIImage imageWithCGImage:yImageRef];
            }
            CGImageRelease(yImageRef);
            
            self.viewScrollX.zoomScale = 1;
            self.viewScrollX.contentSize = self.viewScrollX.bounds.size;
            self.imgvwX.frame = self.viewScrollX.bounds;
            
            self.viewScrollY.zoomScale = 1;
            self.viewScrollY.contentSize = self.viewScrollY.bounds.size;
            self.imgvwY.frame = self.viewScrollY.bounds;
        } else {
            
            self.imgvwX.image = nil;
            if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
                self.img_72MX.image = nil;
            }
            self.imgvwY.image = nil;
            if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
                self.img_72MY.image = nil;
            }
        }
    } else {
        
        self.imgvwX.image = nil;
        if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
            self.img_72MX.image = nil;
        }
        self.imgvwY.image = nil;
        if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
            self.img_72MY.image = nil;
        }
    }
}

@end
