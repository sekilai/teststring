//
//  SCPreventiveSettingViewController.h
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2020/01/06.
//  Copyright © 2020 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

typedef void(^SettingStatusBlock)(NSString *status);

@interface SCPreventiveSettingViewController : SCBaseViewController

@property (assign, nonatomic) BOOL pushRunNoti;

@end

