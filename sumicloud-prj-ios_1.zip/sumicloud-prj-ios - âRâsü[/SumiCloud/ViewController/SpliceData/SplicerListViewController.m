//
//  SplicerListViewController.m
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/09/06.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import "SplicerListViewController.h"
//#import "SideMenuController.h"
#import "DbAccessControllDao.h"
#import "Constants.h"
#import "SplicerListCell.h"
#import "SplicerListAdminCell.h"
#import "SplicerInfoEntity.h"
#import "SCApplicationData.h"
#import "SCLogUtil.h"
#import "Utility.h"
#import "SCWebService.h"
#import "SortInfo.h"
#import "SortButton.h"
#import "GetUnitInfoFlow.h"
#import "FunctionControlFlow.h"
#import "SCSystemData.h"
#import "UIAlertController+Window.h"
#import "SCLocationService.h"
#import "LoginViewController.h"
#import "SCWiFiStateManager.h"

typedef enum {
    SORT_TYPE_CONNECT_UP,
    SORT_TYPE_CONNECT_DOWN,
    SORT_TYPE_SERIAL_UP,
    SORT_TYPE_SERIAL_DOWN,
    SORT_TYPE_REMAIN_DAYS_UP,
    SORT_TYPE_REMAIN_DAYS_DOWN,
    SORT_TYPE_START_UP,
    SORT_TYPE_START_DOWN,
    SORT_TYPE_END_UP,
    SORT_TYPE_END_DOWN,
} SORT_TYPE;

@interface SplicerListViewController ()
<UITableViewDelegate, UITableViewDataSource,
UICollectionViewDelegateFlowLayout, UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UIView *listHeader;
@property (weak, nonatomic) IBOutlet UIView *listHeaderAdmin;
@property (weak, nonatomic) IBOutlet UIImageView *sortIconSerial;
@property (weak, nonatomic) IBOutlet UIImageView *sortIconRemaindays;
@property (weak, nonatomic) IBOutlet UIImageView *sortIconStartday;
@property (weak, nonatomic) IBOutlet UIImageView *sortIconEndday;
@property (weak, nonatomic) IBOutlet UIImageView *sortIconAdminSerial;
@property (weak, nonatomic) IBOutlet UIImageView *sortIconAdminStartday;
@property (weak, nonatomic) IBOutlet UILabel * sortLabelStartday;
@property (weak, nonatomic) IBOutlet UILabel * lockMessage;
@property (weak, nonatomic) IBOutlet UITableView *splicerListView;
@property (weak, nonatomic) IBOutlet UIButton *sortButton;
@property (weak, nonatomic) IBOutlet UIView *sortView;
@property (weak, nonatomic) IBOutlet UIView *sortBackgroundView;


@property (nonatomic) NSMutableArray * splicerList;
@property (nonatomic) NSString * account;
@property (nonatomic) NSString * role;
@property (nonatomic) BOOL isReturnList;
@property (nonatomic) DbAccessControllDao * dbController;
@property (nonatomic) FunctionControlFlow *flow;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *listTopConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *listTopAdminConstraint;

@property (nonatomic) NSMutableArray * sortInfoList;
@property (nonatomic) SORT_TYPE sortType;
@property (weak, nonatomic) IBOutlet UICollectionView * sortArea;

@property (weak, nonatomic) IBOutlet UILabel *serialNoLabelAdmin;
@property (weak, nonatomic) IBOutlet UILabel *remainingDaysLabelAdmin;
@property (weak, nonatomic) IBOutlet UILabel *startDaysLabelAdmin;
@property (weak, nonatomic) IBOutlet UILabel *endDaysLabelAdmin;
@property (weak, nonatomic) IBOutlet UILabel *lockMessageUser;


@property (weak, nonatomic) IBOutlet UILabel *serialNoLabel;
@property (weak, nonatomic) IBOutlet UILabel *reSortLabel;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControl;

@property (assign, nonatomic) BOOL isShowedUnlockAlert;
@property (nonatomic,strong) UIColor *onlineColor;
@property (nonatomic,strong) UIColor *outlineColor;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *sortViewConstraint;
@property (strong,nonatomic) GetUnitInfoFlow* refreshFlow;

@end

@implementation SplicerListViewController

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[SCApplicationData sharedInstance] removeObserver:self forKeyPath:kSC_ADP_OnlineSerialNo];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    
    [[SCApplicationData sharedInstance] addObserver:self forKeyPath:kSC_ADP_OnlineSerialNo options:NSKeyValueObservingOptionNew context:nil];
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    self.refreshFlow = [[GetUnitInfoFlow alloc] init];
    _onlineColor = [UIColor colorWithRed:20.0/255.0 green:160.0/255.0 blue:175.0/255.0 alpha:1];
    _outlineColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1];
    // シリアル番号
    self.serialNoLabelAdmin.text = NSLocalizedString(@"list_header_serno", @"");
    // 残日数
//    self.remainingDaysLabelAdmin.text = NSLocalizedString(@"list_header_remaindays", @"");
    self.remainingDaysLabelAdmin.text = NSLocalizedString(@"status_title", @"");;
    // 開始日
//    self.startDaysLabelAdmin.text = NSLocalizedString(@"list_header_startday", @"");
    self.startDaysLabelAdmin.text = @"";
    // 終了日
//    self.endDaysLabelAdmin.text = NSLocalizedString(@"list_header_endday", @"");
    self.endDaysLabelAdmin.text = @"";
    // シリアル番号
    self.serialNoLabel.text = NSLocalizedString(@"list_header_serno", @"");

    
//    self.sortLabelStartday.text = !self.isReturnList ?
//    NSLocalizedString(@"list_header_admin_startday", @"") : // 開始日
//    NSLocalizedString(@"list_header_admin_endday", @"");  // 終了日
    self.sortLabelStartday.text = @"";
    self.lockMessage.text = !self.isReturnList ?
    NSLocalizedString(@"list_message_lock", @"") : // ロックをしたい融着機をタップしてください
    NSLocalizedString(@"list_message_unlock", @"");// ロックを解除したい融着機をタップしてください
    // 並び替え
    self.reSortLabel.text = NSLocalizedString(@"sort_message", @"");
    // ロックを解除したい融着機をタップしてください
    self.lockMessageUser.text = NSLocalizedString(@"list_message_unlock", @"");
    
    // 出荷待ちリスト
    [self.segmentedControl setTitle:NSLocalizedString(@"list_switch_loan", @"") forSegmentAtIndex:0];
    // 返却リスト
     [self.segmentedControl setTitle:NSLocalizedString(@"list_switch_return", @"") forSegmentAtIndex:1];
    
    
    if (@available(iOS 13.0, *)) {
//        self.segmentedControl.selectedSegmentTintColor = [UIColor colorWithRed:0.08f green:0.59f blue:0.65f alpha:1];
        self.segmentedControl.layer.borderColor = [UIColor colorWithRed:0.08f green:0.59f blue:0.65f alpha:1].CGColor;
        self.segmentedControl.layer.borderWidth = 1;
        self.segmentedControl.layer.cornerRadius = 4;
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],NSForegroundColorAttributeName,nil];
        [self.segmentedControl setTitleTextAttributes:dic forState:UIControlStateSelected];
        dic = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor colorWithRed:0.08f green:0.59f blue:0.65f alpha:1],NSForegroundColorAttributeName,nil];
        [self.segmentedControl setTitleTextAttributes:dic forState:UIControlStateNormal];
        [self.segmentedControl setBackgroundImage:[Utility imageWithColor:[UIColor clearColor]] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        [self.segmentedControl setBackgroundImage:[Utility imageWithColor:[UIColor colorWithRed:0.08f green:0.59f blue:0.65f alpha:1]] forState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
    }
  
    
    self.splicerListView.bounces = NO;
    self.splicerListView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.sortButton.layer.shadowOpacity = 0.5;
    self.sortButton.layer.shadowOffset = CGSizeMake(2, 2);

    self.dbController = [[DbAccessControllDao alloc] init];
    self.splicerList = [NSMutableArray array];
    self.account = [[NSUserDefaults standardUserDefaults] stringForKey:PRE_ACCOUNT];
    self.role = [self.dbController getAccountRole:self.account];
    // 管理者
    if([self.role isEqualToString:@"1"]){
        self.listHeader.hidden = YES;;
        // 貸出融着機リスト
        self.title = NSLocalizedString(@"label_splicer_list", @"");
    }else{
        // 作業者
        self.listHeaderAdmin.hidden = YES;
        // 借用中融着機一覧
        self.title = NSLocalizedString(@"borrowed_splicers_list_title", @"");
    }
    [self refreshSplicerList:false];
    self.sortInfoList = [NSMutableArray array];
    [self.sortBackgroundView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideSortView:)]];
    [self refreshSortInfoList];
    self.sortType = SORT_TYPE_CONNECT_UP;
    [self refreshSplicerList:false];
    if(self.isLoginFailed){
//        long long lastLogin = [self.dbController getLastestLogin:self.account];
//        NSDate * date = [NSDate dateWithTimeIntervalSince1970:lastLogin / 1000.0];
//        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//        dateFormatter.dateFormat = @"yyyy/MM/dd HH:mm";
//        dateFormatter.calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
//        NSString * timeString = [dateFormatter stringFromDate:date];
        UIAlertController *alert = [UIAlertController
                                    alertControllerWithTitle:NSLocalizedString(@"adlg_title_connection_error", @"")
                                    message:NSLocalizedString(@"adlg_network_error_message", @"")
                                    preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"")
                                                  style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [alert dismissViewControllerAnimated:YES completion:nil];
        }]];
        [alert show];
    }
}

/**
   画面表示制御

 @param animated <#animated description#>
 */



/**
    画面表示制御

 @param animated <#animated description#>
 */
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

/**
 プロパティ監視
 
 @param keyPath keyPath description
 @param object object description
 @param change change description
 @param context context description
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    
    DDLogInfo(@"プロパティ監視【%@】", keyPath);
    if(object == [SCApplicationData sharedInstance] && [keyPath isEqualToString:kSC_ADP_OnlineSerialNo]){
        [self refreshSplicerList:true];
    }
}



- (void)viewDidLayoutSubviews{
    
    if([self.role isEqualToString:@"1"]){
        [NSLayoutConstraint activateConstraints:@[self.listTopAdminConstraint]];
        [NSLayoutConstraint deactivateConstraints:@[self.listTopConstraint]];
    }else{
        [NSLayoutConstraint deactivateConstraints:@[self.listTopAdminConstraint]];
        [NSLayoutConstraint activateConstraints:@[self.listTopConstraint]];
    }
    self.sortButton.layer.cornerRadius = self.sortButton.frame.size.width / 2;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}


/**
 リフレッシュ

 @param sender <#sender description#>
 */
- (IBAction)doRefresh:(id)sender {
    
    // Wi-Fi切り替え確認
    if ([self isSplicerConnect]) {
        [self connectInternetAlert];
    }else {
        NSString * password = [self.dbController getAccountPassword:self.account];
        [self showProgress:NSLocalizedString(@"adlg_connecting", @"") cancelHandler:^{
            [self hideProgress];
            [self.refreshFlow cancelFlow];
        }];
        // データ取得機能フロー
        [self.refreshFlow runRefreshFlow:self.account password:password isFirst:NO completion:^(RESULT_CODE result) {
            [self hideProgress];
            if(result == SUCCESS){
                [self refreshSplicerList:false];
            }else if (result == CANCELED){
                return;;
            }else{
                if(result == NET_JSON_RESULT_ERROR){
                    UIAlertController *alert = [UIAlertController
                                                alertControllerWithTitle:NSLocalizedString(@"adlg_loginerror_title", @"")
                                                message:NSLocalizedString(@"adlg_login_failed", @"")
                                                preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"")
                                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                  [alert dismissViewControllerAnimated:YES completion:nil];
                                                              }]];
                    [alert show];
                }else{
                    
                    UIAlertController *alert = [UIAlertController
                                                alertControllerWithTitle:NSLocalizedString(@"adlg_title_connection_error", @"")
                                                message:NSLocalizedString(@"adlg_network_error_message", @"")
                                                preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"")
                                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                  [alert dismissViewControllerAnimated:YES completion:nil];
                                                              }]];
                    [alert show];
                    
                }
            }
        }];
        // #10943
        self.sortType = SORT_TYPE_CONNECT_UP;
        [self refreshSortInfoList];
    }

}

/**
 <#Description#>

 @param sender <#sender description#>
 */
- (IBAction)switchList:(UISegmentedControl *)sender {
    self.isReturnList = sender.selectedSegmentIndex != 0;
//    self.sortLabelStartday.text = !self.isReturnList ?
//        NSLocalizedString(@"list_header_admin_startday", @"") :
//        NSLocalizedString(@"list_header_admin_endday", @"");
    self.lockMessage.text = !self.isReturnList ?
        NSLocalizedString(@"list_message_lock", @"") :
        NSLocalizedString(@"list_message_unlock", @"");
    [self refreshSortInfoList];
    self.sortType = SORT_TYPE_CONNECT_UP;
    [self refreshSplicerList:false];
}


/**
 <#Description#>

 @param sender <#sender description#>
 */
- (IBAction)showSortView:(id)sender {
    self.sortBackgroundView.hidden = NO;
    self.sortBackgroundView.alpha = 0;
    self.sortViewConstraint.constant = -216;
    [UIView animateWithDuration:0.5 animations:^{
        self.sortBackgroundView.alpha = 0.4;
        [self.view layoutIfNeeded];
    }];
}

/**
 <#Description#>

 @param sender <#sender description#>
 */
- (IBAction)hideSortView:(id)sender {
    self.sortViewConstraint.constant = 0;
    [UIView animateWithDuration:0.5 animations:^{
        self.sortBackgroundView.alpha = 0;
        [self.view layoutIfNeeded];
    } completion:^(BOOL finished) {
        self.sortBackgroundView.hidden = YES;
    }];
}

/**
 <#Description#>
 */
- (void)refreshSortInfoList {
    [self.sortInfoList removeAllObjects];
    // 接続状況
    SortInfo * info = [SortInfo infoWithName:NSLocalizedString(@"sort_btn_connect", nil)];
    info.checkStatus = CHECK_STATUS_UP;
    
    if([self.role isEqualToString:@"1"]){
        [self.sortInfoList addObject:[SortInfo infoWithName:NSLocalizedString(@"sort_btn_serial", nil)]];
    }else{
        [self.sortInfoList addObject:info];
        [self.sortInfoList addObject:[SortInfo infoWithName:NSLocalizedString(@"sort_btn_serial", nil)]];
        [self.sortInfoList addObject:[SortInfo infoWithName:NSLocalizedString(@"sort_btn_remainday", nil)]];
    }
    [self.sortArea reloadData];
}

/**
 <#Description#>

 @param sortType <#sortType description#>
 */
- (void)setSortType:(SORT_TYPE)sortType {
    _sortType = sortType;
    self.sortIconSerial.image = nil;
    self.sortIconRemaindays.image = nil;
    self.sortIconStartday.image = nil;
    self.sortIconEndday.image = nil;
    self.sortIconAdminSerial.image = nil;
    self.sortIconAdminStartday.image = nil;
    for(SortInfo * info in self.sortInfoList){
        info.checkStatus = CHECK_STATUS_NONE;
        switch (sortType) {
            case SORT_TYPE_SERIAL_UP:
                self.sortIconSerial.image = [UIImage imageNamed:@"icon_sort_up"];
                self.sortIconAdminSerial.image = [UIImage imageNamed:@"icon_sort_up"];
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_serial", nil)]) {
                    info.checkStatus = CHECK_STATUS_UP;
                }
                break;
            case SORT_TYPE_SERIAL_DOWN:
                self.sortIconSerial.image = [UIImage imageNamed:@"icon_sort_down"];
                self.sortIconAdminSerial.image = [UIImage imageNamed:@"icon_sort_down"];
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_serial", nil)]) {
                    info.checkStatus = CHECK_STATUS_DOWN;
                }
                break;
            case SORT_TYPE_CONNECT_UP:
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_connect", nil)]) {
                    info.checkStatus = CHECK_STATUS_UP;
                }
                break;
            case SORT_TYPE_CONNECT_DOWN:
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_connect", nil)]) {
                    info.checkStatus = CHECK_STATUS_DOWN;
                }
                break;
            case SORT_TYPE_REMAIN_DAYS_UP:
                self.sortIconRemaindays.image = [UIImage imageNamed:@"icon_sort_up"];
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_remainday", nil)]) {
                    info.checkStatus = CHECK_STATUS_UP;
                }
                break;
            case SORT_TYPE_REMAIN_DAYS_DOWN:
                self.sortIconRemaindays.image = [UIImage imageNamed:@"icon_sort_down"];
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_remainday", nil)]) {
                    info.checkStatus = CHECK_STATUS_DOWN;
                }
                break;
            case SORT_TYPE_START_UP:
                self.sortIconStartday.image = [UIImage imageNamed:@"icon_sort_up"];
                if(!self.isReturnList){
                    self.sortIconAdminStartday.image = [UIImage imageNamed:@"icon_sort_up"];
                }
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_startday", nil)]) {
                    info.checkStatus = CHECK_STATUS_UP;
                }
                break;
            case SORT_TYPE_START_DOWN:
                self.sortIconStartday.image = [UIImage imageNamed:@"icon_sort_down"];
                if(!self.isReturnList){
                    self.sortIconAdminStartday.image = [UIImage imageNamed:@"icon_sort_down"];
                }
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_startday", nil)]) {
                    info.checkStatus = CHECK_STATUS_DOWN;
                }
                break;
            case SORT_TYPE_END_UP:
                self.sortIconEndday.image = [UIImage imageNamed:@"icon_sort_up"];
                if(self.isReturnList){
                    self.sortIconAdminStartday.image = [UIImage imageNamed:@"icon_sort_up"];
                }
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_endday", nil)]) {
                    info.checkStatus = CHECK_STATUS_UP;
                }
                break;
            case SORT_TYPE_END_DOWN:
                self.sortIconEndday.image = [UIImage imageNamed:@"icon_sort_down"];
                if(self.isReturnList){
                    self.sortIconAdminStartday.image = [UIImage imageNamed:@"icon_sort_down"];
                }
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_endday", nil)]) {
                    info.checkStatus = CHECK_STATUS_DOWN;
                }
                break;
            default:
                if([info.name isEqualToString:NSLocalizedString(@"sort_btn_connect", nil)]) {
                    info.checkStatus = CHECK_STATUS_UP;
                }
                break;
        }
    }
    [self.sortArea reloadData];
    [self refreshSplicerList:false];
}

/**
 <#Description#>
 */
- (void)refreshSplicerList:(BOOL)showUnlockAlert {
    [self.splicerList removeAllObjects];
    NSArray * splicerList = [self.dbController getUnitInfoList:self.account];
    
    for(SplicerInfoEntity * info in splicerList){
        if([self.role isEqualToString:@"0"] &&
           [info.unitInfo.requestType isEqualToString:@"1"]
           ){
            // 作業者の場合 #10152
                if([info.unitInfo.serialNo isEqualToString:[SCApplicationData sharedInstance].onlineSerialNo]){
                    info.isOnline = YES;
                    NSString * now = [SCSystemData stringFromDate:[NSDate date] format:@"yyyy/MM/dd"];
                    if (![now isEqualToString:info.lastunlockdate]
                        && [info.unitInfo.remainDays integerValue] > 0
                        && showUnlockAlert
                        && [info expirationCount] > 0) {
                        [self runUnlockFlowWithUniteInfo:info];
                    }
                }
                [self.splicerList addObject:info];
        }else{
            // 管理者の場合 #10152
            if(self.isReturnList){
                if([info.unitInfo.requestType isEqualToString:@"0"] &&
                   ([info.unitInfo.passcodeStatus isEqualToString:@"1"] ||
                    [info.unitInfo.passcodeStatus isEqualToString:@"2"]
                    )
                   ){
                    // 要求状態 = 0：UnLock and 融着機状態 = 1：Lock or 2：Use
                    if([info.unitInfo.serialNo isEqualToString:[SCApplicationData sharedInstance].onlineSerialNo]){
                        info.isOnline = YES;
                    }else{
                        info.isOnline = NO;
                    }
                    [self.splicerList addObject:info];
                }
            }else{
                if([info.unitInfo.requestType isEqualToString:@"1"] &&
                  [info.unitInfo.passcodeStatus isEqualToString:@"0"]
                   ){
                    // 要求状態 = 1：Lock  and 融着機状態 = 0：UnLock
                    if([info.unitInfo.serialNo isEqualToString:[SCApplicationData sharedInstance].onlineSerialNo]){
                        info.isOnline = YES;
                    }else{
                        info.isOnline = NO;
                    }
                    [self.splicerList addObject:info];
                }
            }
        }
    }
     
    [self.splicerList sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        SplicerInfoEntity * info1 = (SplicerInfoEntity *)obj1;
        SplicerInfoEntity * info2 = (SplicerInfoEntity *)obj2;
        
        int remainDays1 =  [info1.unitInfo.remainDays intValue];
        int remainDays2 =  [info2.unitInfo.remainDays intValue];
        
        switch (self.sortType) {
            case SORT_TYPE_SERIAL_UP:
                return [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
            case SORT_TYPE_SERIAL_DOWN:
                return -1 * [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
            case SORT_TYPE_CONNECT_UP:
                if((info1.isOnline && info2.isOnline) || (!info1.isOnline && !info2.isOnline)) {
                    return [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
                }else if(info1.isOnline && !info2.isOnline) {
                    return -1;
                }else{
                    return 1;
                }
            case SORT_TYPE_CONNECT_DOWN:
                if((info1.isOnline && info2.isOnline) || (!info1.isOnline && !info2.isOnline)) {
                    return [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
                }else if(info1.isOnline && !info2.isOnline) {
                    return 1;
                }else{
                    return -1;
                }
            case SORT_TYPE_REMAIN_DAYS_UP:
                if (remainDays1 > remainDays2) {
                    return 1;
                }else if(remainDays1 < remainDays2) {
                    return -1;
                }else {
                    return [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
                }
            case SORT_TYPE_REMAIN_DAYS_DOWN:
                if (remainDays1 > remainDays2) {
                    return -1;
                } else if(remainDays1 < remainDays2) {
                    return 1;
                } else {
                    return [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
                }
            case SORT_TYPE_START_UP:
                return [info1.unitInfo.startDate compare:info2.unitInfo.startDate] != 0 ?
                [info1.unitInfo.startDate compare:info2.unitInfo.startDate] :
                [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
            case SORT_TYPE_START_DOWN:
                return -1 * [info1.unitInfo.startDate compare:info2.unitInfo.startDate] != 0 ?
                -1 * [info1.unitInfo.startDate compare:info2.unitInfo.startDate] :
                [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
            case SORT_TYPE_END_UP:
                return [info1.unitInfo.endDate compare:info2.unitInfo.endDate] != 0 ?
                [info1.unitInfo.endDate compare:info2.unitInfo.endDate] :
                [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
            case SORT_TYPE_END_DOWN:
                return -1 * [info1.unitInfo.endDate compare:info2.unitInfo.endDate] != 0 ?
                -1 * [info1.unitInfo.endDate compare:info2.unitInfo.endDate] :
                [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
            default:
                return [info1.unitInfo.serialNo compare:info2.unitInfo.serialNo];
        }
    }];
    
    self.splicerListView.contentOffset = CGPointZero;
    
    
    [self.splicerListView reloadData];
}



/**
 機能フロー

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DDLogDebug(@"indexPath.row = %ld",(long)indexPath.row);
    __weak typeof(self) wself = self;
    [[SCLocationService sharedInstance] getAuthorizationStatusWithCompletion:^(BOOL canUseLocation) {
        if(!canUseLocation){
            UIAlertController *alert = [UIAlertController
                                        alertControllerWithTitle:NSLocalizedString(@"adlg_init_title", @"")
                                        message:NSLocalizedString(@"adlg_init_message", @"")
                                        preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"")
                                                      style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                          [alert dismissViewControllerAnimated:YES completion:nil];
                                                      }]];
            [alert show];
            
        }else {
            
            wself.flow = [[FunctionControlFlow alloc] init];
            
            SplicerInfoEntity *selectEntity = wself.splicerList[indexPath.row];
            
            if ([self.role isEqualToString:@"0"]) {
                
                NSString *remainDayStr =  selectEntity.unitInfo.remainDays;
                
                if (!remainDayStr || !remainDayStr.length || [remainDayStr intValue] <= 0) {
                    
                    DDLogError(@"[SpliceUnLock error]");
                    
                    [wself alertMessage:NSLocalizedString(@"adlg_3th_message_text", @"")];
                    
                    return;
                }else if ([selectEntity expirationCount] <= 0 ) {
                    
                    DDLogError(@"[SpliceUnLock error]");
                    
                    [wself alertMessage:NSLocalizedString(@"adlg_unlock_count_message", @"")];
                    
                    return;
                }else {
                   
                    [self runUnlockFlowWithUniteInfo:selectEntity];
                }
            }else {
                
                if(!selectEntity.isOnline){
                    [self messageBFAction:SCBFAction_WIFIERROR result:WIFI_ERROR error:nil];
                    return;
                }
            
                
                NSString *requestTypeStr =  selectEntity.unitInfo.requestType;
                
                if (requestTypeStr && [requestTypeStr isEqualToString:@"1"]) {
                    
                    UIAlertController *alert = [UIAlertController
                                                alertControllerWithTitle:NSLocalizedString(@"adlg_title_lock", @"")
                                                message:[NSString stringWithFormat:@"%@%@",selectEntity.unitInfo.serialNo,NSLocalizedString(@"adlg_message_lock", @"")]
                                                preferredStyle:UIAlertControllerStyleAlert];
                    
                    
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"")
                                      
                                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                  
                                                                  if(![selectEntity.unitInfo.serialNo isEqualToString:[SCApplicationData sharedInstance].onlineSerialNo]) {
                                                            
                                                                      [wself messageBFAction:SCBFAction_LOCK result:WIFI_ERROR error:nil];
                                                                      return;
                                                                  }
                                                                  

                                                                  
                                                                  [wself showProgress:NSLocalizedString(@"adlg_please_wait", @"") cancelHandler:nil];
                                                                  DDLogInfo(@"ロック要求実施機能フロー:開始");
                                                                  [wself.flow setSpliceLock:selectEntity completion:^(NSError *error) {
                                                                      
                                                                      DDLogInfo(@"ロック要求実施機能フロー:完了");
                                                                      
                                                                      dispatch_async(dispatch_get_main_queue(), ^{
                                                                          
                                                                          [wself hideProgress];
                                                                          
                                                                          //TODO: - version
                                                                          if (wself.flow.isCheckVersion) {
                                                                               [self alertShowWithTitle:NSLocalizedString(@"dlg_alert", @"通知") andMessage:NSLocalizedString(@"adlg_version_message", @"確認メッセージ")];
                                                                              return;
                                                                          }
                                                                          

                                                                          [wself messageBFAction:SCBFAction_LOCK result:wself.flow.resultFlow error:error];

                                                                          // アラート表示
                                                                          if (!error) {

                                                                              if (kBF_MU_LOCK == wself.flow.resultFlow) {
                                                                                  
                                                                                  DDLogInfo(@"[SpliceLock success]");
                                                                                  [[NSUserDefaults standardUserDefaults] setValue:@"Locked" forKey:[NSString stringWithFormat:@"%@_lockState", selectEntity.unitInfo.serialNo]];
                                                                                  [[NSUserDefaults standardUserDefaults] synchronize];
                                                                                  
                                                                              }
                                                                          }
                                                                      });
                                                                      
                                                                  }];
                                                              }]];
                    
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_negative", @"") style:UIAlertActionStyleCancel handler:nil]];
                    [alert show];
                }else {
                    UIAlertController *alert = [UIAlertController
                                                alertControllerWithTitle:NSLocalizedString(@"adlg_title_unlock", @"")
                                                message:[NSString stringWithFormat:@"%@%@",selectEntity.unitInfo.serialNo,NSLocalizedString(@"adlg_message_unlock", @"")]
                                                preferredStyle:UIAlertControllerStyleAlert];
                    
                    
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"")
                                      
                                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                  
                                                                  if (![selectEntity.unitInfo.serialNo isEqualToString:[SCApplicationData sharedInstance].onlineSerialNo]) {
                                                                      [wself messageBFAction:SCBFAction_LOCKCLEAR result:WIFI_ERROR error:nil];
                                                                      return;
                                                                  }
                                                                  
                                                                  [wself showProgress:NSLocalizedString(@"adlg_please_wait", @"") cancelHandler:nil];

                                                                  DDLogInfo(@"本体ロックClear実施機能フロー:開始");
                                                                  
                                                                  [wself.flow setSpliceLockClear:selectEntity completion:^(NSError *error) {
                                                                      
                                                                      DDLogInfo(@"本体ロックClear実施機能フロー:完了");
                                                                      
                                                                      dispatch_async(dispatch_get_main_queue(), ^{
                                                                          
                                                                          [wself hideProgress];
                                                                          
                                                                          
                                                                          [wself messageBFAction:SCBFAction_LOCKCLEAR result:wself.flow.resultFlow error:error];
                                                                          if (!error) {
                                                                              
                                                                              if (kBF_MU_LOCK_CLEAR == wself.flow.resultFlow) {
                                                                                  [[NSUserDefaults standardUserDefaults] setValue:@"unLock" forKey:[NSString stringWithFormat:@"%@_lockState", selectEntity.unitInfo.serialNo]];
                                                                                  [[NSUserDefaults standardUserDefaults] synchronize];
                                                                                  
                                                                                  DDLogInfo(@"[SpliceLockClear success]");
                                                                              }
                                                                          }
                                                                      });
                                                                  }];
                                                              }]];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_negative", @"") style:UIAlertActionStyleCancel handler:nil]];
                    [alert show];
                    
                }
            }
        }
    }];
  }

/**
  TableView初期化

 @param tableView <#tableView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.splicerList.count;
}

/**
  TableView初期化

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell * cell = nil;
    SplicerInfoEntity * info = self.splicerList[indexPath.row];
    if([self.role isEqualToString:@"1"]){
        SplicerListAdminCell * slCell = (SplicerListAdminCell *)[tableView dequeueReusableCellWithIdentifier:@"celladmin" forIndexPath:indexPath];
        cell = slCell;
        slCell.serialNo.text = info.unitInfo.serialNo;
        if(!self.isReturnList){
            slCell.startday.text = @"";
        }else{
            slCell.startday.text = @"";
        }
        slCell.connectedLbl.text = NSLocalizedString(@"connect_label_text", @"Connected");
        // シリアルNo
        // 未接続:グレー 接続:黒
        if(info.isOnline){
            slCell.serialNo.textColor = _onlineColor;
            slCell.connectedIcon.hidden = false;
            slCell.unConnectIcon.hidden = true;
            slCell.connectedLbl.hidden = false;
        }else{
            slCell.serialNo.textColor = _outlineColor;
            slCell.connectedIcon.hidden = true;
            slCell.unConnectIcon.hidden = false;
            slCell.connectedLbl.hidden = true;
        }
        
        // 開始日/終了日
        // 変更あり:青 未接続:グレー 接続:黒
        if(![[info.changeFlag substringWithRange:NSMakeRange(1, 1)] isEqualToString:@"0"]
           || ![[info.changeFlag substringWithRange:NSMakeRange(2, 1)] isEqualToString:@"0"]){
            slCell.startday.textColor = self.onlineColor;
        }else{
            if(info.isOnline){
                slCell.startday.textColor = self.onlineColor;
                slCell.connectedIcon.hidden = FALSE;
                slCell.unConnectIcon.hidden = true;
                slCell.connectedLbl.hidden = false;
            }else{
                slCell.startday.textColor = self.outlineColor;
                slCell.connectedIcon.hidden = true;
                slCell.unConnectIcon.hidden = false;
                slCell.connectedLbl.hidden = true;
            }
        }
    }else{
        SplicerListCell * slCell = (SplicerListCell *)[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
        cell = slCell;
        slCell.serialNo.text = info.unitInfo.serialNo;
        slCell.remaindays.text = [info.unitInfo.remainDays integerValue] > 0 ? NSLocalizedString(@"status_avaliable", @"") : NSLocalizedString(@"status_unavaliable", @"");
        slCell.startday.text = @"";
        slCell.endday.text = @"";
        slCell.connectedLbl.text = NSLocalizedString(@"connect_label_text", @"Connected");
        // シリアルNo
        // 未接続:グレー 接続:黒
        if(info.isOnline){
            slCell.serialNo.textColor = self.onlineColor;
            slCell.startday.textColor = self.onlineColor;
            slCell.connectedIcon.hidden = false;
            slCell.unConnectIcon.hidden = true;
            slCell.connectedLbl.hidden = false;
        }else{
            slCell.serialNo.textColor = self.outlineColor;
            slCell.startday.textColor = self.outlineColor;
            slCell.connectedIcon.hidden = true;
            slCell.unConnectIcon.hidden = false;
            slCell.connectedLbl.hidden = true;
        }
        
        // 残日数、開始日、終了日
        // 開始日、終了日変更があった場合、どれが変更したのに関わらず、青で表示する
        // 残日数の変更が無視する
        // 変更あり:青 未接続:グレー 接続:黒
        if(![[info.changeFlag substringWithRange:NSMakeRange(1, 1)] isEqualToString:@"0"]
           || ![[info.changeFlag substringWithRange:NSMakeRange(2, 1)] isEqualToString:@"0"]){
            slCell.remaindays.textColor = self.onlineColor;
            slCell.startday.textColor = self.onlineColor;
            slCell.endday.textColor = self.onlineColor;
        }else{
            if(info.isOnline){
                slCell.serialNo.textColor = self.onlineColor;
                slCell.remaindays.textColor = self.onlineColor;
                slCell.startday.textColor = self.onlineColor;
                slCell.endday.textColor = self.onlineColor;
                
                slCell.connectedIcon.hidden = false;
                slCell.unConnectIcon.hidden = true;
                slCell.connectedLbl.hidden = false;
            }else{
                slCell.serialNo.textColor = self.outlineColor;
                slCell.remaindays.textColor = self.outlineColor;
                slCell.startday.textColor = self.outlineColor;
                slCell.endday.textColor = self.outlineColor;
                
                slCell.connectedIcon.hidden = true;
                slCell.unConnectIcon.hidden = false;
                slCell.connectedLbl.hidden = true;
            }
        }
    }
    return cell;
}

/**
  CollectionViewの列数

 @param collectionView <#collectionView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.sortInfoList.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:

/**
  CollectionViewのセルを生成

 @param collectionView <#collectionView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"SortCell" forIndexPath:indexPath];
    SortButton * sortButton = (SortButton *)[cell viewWithTag:1];
    sortButton.sortInfo = self.sortInfoList[indexPath.row];
    return cell;
}

/**
 CollectionViewCellのサイズ

 @param collectionView <#collectionView description#>
 @param collectionViewLayout <#collectionViewLayout description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return CGSizeMake(collectionView.frame.size.width / 2 - 20, collectionView.frame.size.height / 3 - 20) ;
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10, 10, 10, 10);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 20.0;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 20.0;
}

/**
  リストの選択

 @param collectionView <#collectionView description#>
 @param indexPath <#indexPath description#>
 */
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    SortInfo * info = self.sortInfoList[indexPath.row];
    if([info.name isEqualToString:NSLocalizedString(@"sort_btn_serial", nil)]){
        if(self.sortType == SORT_TYPE_SERIAL_UP){
            self.sortType = SORT_TYPE_SERIAL_DOWN;
        }else{
            self.sortType = SORT_TYPE_SERIAL_UP;
        }
    }else if([info.name isEqualToString:NSLocalizedString(@"sort_btn_connect", nil)]) {
        if(self.sortType == SORT_TYPE_CONNECT_UP){
            self.sortType = SORT_TYPE_CONNECT_DOWN;
        }else{
            self.sortType = SORT_TYPE_CONNECT_UP;
        }
    }else if([info.name isEqualToString:NSLocalizedString(@"sort_btn_remainday", nil)]) {
        if(self.sortType == SORT_TYPE_REMAIN_DAYS_UP){
            self.sortType = SORT_TYPE_REMAIN_DAYS_DOWN;
        }else{
            self.sortType = SORT_TYPE_REMAIN_DAYS_UP;
        }
    }else if([info.name isEqualToString:NSLocalizedString(@"sort_btn_startday", nil)]) {
        if(self.sortType == SORT_TYPE_START_UP){
            self.sortType = SORT_TYPE_START_DOWN;
        }else{
            self.sortType = SORT_TYPE_START_UP;
        }
    }else if([info.name isEqualToString:NSLocalizedString(@"sort_btn_endday", nil)]) {
        if(self.sortType == SORT_TYPE_END_UP){
            self.sortType = SORT_TYPE_END_DOWN;
        }else{
            self.sortType = SORT_TYPE_END_UP;
        }
    }
}


-(void)runUnlockFlowWithUniteInfo:(SplicerInfoEntity *)selectEntity{
    
    if (self.flow == nil) {
        self.flow = [[FunctionControlFlow alloc] init];
    }

    __weak typeof(self) wself = self;
    DDLogInfo(@"本体ロック解除実施機能フロー:開始");
    if(!selectEntity.isOnline){
        [self messageBFAction:SCBFAction_WIFIERROR result:WIFI_ERROR error:nil];
        return;
    }
                       
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"adlg_title_unlock", @"")
                                                                   message:[NSString
    stringWithFormat:@"%@%@",selectEntity.unitInfo.serialNo,NSLocalizedString(@"adlg_message_unlock", @"")]
                                                   preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"")
                                         style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        self.isShowedUnlockAlert = false;
                                                                        
        if (![selectEntity.unitInfo.serialNo isEqualToString:[SCApplicationData sharedInstance].onlineSerialNo]) {
            [wself messageBFAction:SCBFAction_UNLOCK result:WIFI_ERROR error:nil];
            return;
        }
                                                                     
        [self showProgress:NSLocalizedString(@"adlg_please_wait", @"") cancelHandler:nil];
                                                                     
        [self.flow setSpliceUnLock:selectEntity completion:^(NSError *error) {
            DDLogInfo(@"本体ロック解除実施機能フロー:完了");
                                                                         
            dispatch_async(dispatch_get_main_queue(), ^{
                                                                    
                [wself hideProgress];
                // フロー結果メッセージ表示
                [wself messageBFAction:SCBFAction_UNLOCK result:wself.flow.resultFlow error:error];
                                                                             
                if (!error) {
                    if (kBF_MU_UNLOCK == self.flow.resultFlow) {
                        DDLogInfo(@"[SpliceUnLock success]");
                        [[NSUserDefaults standardUserDefaults] setValue:@"unLock" forKey:[NSString stringWithFormat:@"%@_lockState", selectEntity.unitInfo.serialNo]];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                        int count = selectEntity.expirationCount - 1;
                        [selectEntity setExpirationCount:count];
                        selectEntity.lastunlockdate = [SCSystemData stringFromDate:[NSDate date] format:@"yyyy/MM/dd"];
                        [wself.dbController updateUnitInfo:selectEntity];
                    }
                }
            });
        }];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_negative", @"") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        _isShowedUnlockAlert = false;
    }]];
    if (!_isShowedUnlockAlert){
        [self presentViewController:alert animated:YES completion:nil];
        _isShowedUnlockAlert = true;
    }
}

@end
