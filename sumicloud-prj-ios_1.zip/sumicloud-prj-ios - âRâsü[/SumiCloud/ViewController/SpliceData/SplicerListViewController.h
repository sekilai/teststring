//
//  SplicerListViewController.h
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/09/06.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SCBaseViewController.h"

@interface SplicerListViewController : SCBaseViewController
@property (nonatomic) BOOL isLoginFailed;
@end
