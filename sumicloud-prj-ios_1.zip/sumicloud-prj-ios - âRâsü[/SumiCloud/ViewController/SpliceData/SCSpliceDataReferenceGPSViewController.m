//
//  SCSpliceDataReferenceGPSViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/13.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataReferenceGPSViewController.h"
#import "SCLogUtil.h"

#import <MapKit/MapKit.h>

@interface SCSpliceDataReferenceGPSViewController ()

@property (weak, nonatomic) IBOutlet MKMapView *vwMap;

@end

@implementation SCSpliceDataReferenceGPSViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 多言語対応
    self.title = NSLocalizedString(@"BTN_SPLICEDATA_GPS", @"GPS");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 画面表示
 */
- (void)show {

    DDLogDebug(@"GPS = <%@, %@>",
               self.appData.detailSpliceData.lat,
               self.appData.detailSpliceData.lon);
    
    // MapViewの位置情報起動
    self.vwMap.showsUserLocation = YES;
    
    // 接続データの位置情報をセンタリング
    CLLocationCoordinate2D coordinate;
    coordinate.latitude = [self.appData.detailSpliceData.lat doubleValue];
    coordinate.longitude = [self.appData.detailSpliceData.lon doubleValue];
    [self.vwMap setCenterCoordinate:coordinate animated:YES];
    
    // 接続データの位置情報にピンを立てる
    [self.vwMap removeAnnotations:self.vwMap.annotations];
    
    MKPointAnnotation* posAnno = [[MKPointAnnotation alloc] init];
    posAnno.coordinate = coordinate;
    [self.vwMap addAnnotation:posAnno];
    
    // 縮尺の指定
    MKCoordinateRegion scale;
    scale.center = coordinate;
    scale.span.latitudeDelta = 0.01f;
    scale.span.longitudeDelta = 0.01f;
    [self.vwMap setRegion:scale animated:YES];
}

/**
 画面非表示
 */
- (void)hide {
    
    DDLogDebug(@"");
    
    // MapViewの位置情報停止
    self.vwMap.showsUserLocation = NO;
}

@end
