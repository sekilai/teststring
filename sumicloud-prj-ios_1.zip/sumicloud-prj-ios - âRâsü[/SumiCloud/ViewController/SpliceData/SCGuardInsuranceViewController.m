//
//  SCGuardInsuranceViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2019/12/23.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//




#import "SCGuardInsuranceViewController.h"
#import "SCLogUtil.h"
#import "SCSystemData.h"
#import "SCSpliceDataDao.h"
#import "SCSpliceDataFlow.h"
#import "SCConnectSpliceDao.h"
#import "SCHelpVideoFlow.h"
#import "SCAutoDiagnosisVideoButton.h"

@import MessageUI;

@interface PreventiveCheckModel : NSObject

@property (copy,nonatomic) NSString *checkName;//Cleaver Electrode Protection glass
@property (copy,nonatomic) NSString *checkStatus; //good caution warning
@property (assign,nonatomic) NSInteger checkLevel;// 0 1 2
@property (strong,nonatomic) UIColor *signalColor;
@property (copy,nonatomic) NSString *solutDescription;
@property (assign,nonatomic)BOOL showCleaverView;
@property (assign,nonatomic)BOOL showVideoView;

@end

@implementation PreventiveCheckModel

- (instancetype)initWithCheckName:(NSString *)checkName
{
    self = [super init];
    if (self) {
        self.checkLevel = 0;
        self.checkName = checkName;
        self.showCleaverView = false;
        self.showVideoView = false;
    }
    return self;
    
}

- (void)setCheckLevel:(NSInteger)checkLevel{
    _checkLevel = checkLevel;
    if (checkLevel == 0) {
        _signalColor = [UIColor colorWithRed:92/255.0 green:198/255.0 blue:102/255.0 alpha:1];
        _checkStatus = @"Good";
    } else if (checkLevel == 1) {
        _signalColor = [UIColor colorWithRed:246/255.0 green:172/255.0 blue:0 alpha:1];
        _checkStatus = @"Caution";
    } else if (checkLevel == 2) {
        _signalColor = [UIColor redColor];
        _checkStatus = @"Warning";
    }
}

@end

@interface SCGuardInsuranceViewController () <MFMailComposeViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *modalTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *modalLabel;
@property (weak, nonatomic) IBOutlet UILabel *snNumTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *snNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *checkDateTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *checkDateLabel;

@property (weak, nonatomic) IBOutlet UILabel *mainTitleLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *mainTitleViewHeight;


@property (weak, nonatomic) IBOutlet UIView *firstTitleView;
@property (weak, nonatomic) IBOutlet UIView *secondTitleView;
@property (weak, nonatomic) IBOutlet UIView *thirdTitleView;
@property (weak, nonatomic) IBOutlet UIView *fouthTitleView;

@property (weak, nonatomic) IBOutlet UIView *firstInfoView;
@property (weak, nonatomic) IBOutlet UIView *secondInfoView;
@property (weak, nonatomic) IBOutlet UIView *thirdInfoView;
@property (weak, nonatomic) IBOutlet UIView *fouthInfoView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *firstTitleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *secondTitleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *thirdTitleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *fouthTitleHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *firstInfoHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *secondInfoHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *thirdInfoHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *fouthInfoHeight;

@property (weak, nonatomic) IBOutlet UILabel *firstInfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *secondInfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *thirdInfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *fouthInfoLabel;


@property (weak, nonatomic) IBOutlet NSLayoutConstraint *totalContentHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *firstCleaverInfoViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *secondCleaverInfoViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *thirdCleaverInfoViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *fouthCleaverInfoViewHeight;

@property (weak, nonatomic) IBOutlet UIButton * firstTitleBtn;
@property (weak, nonatomic) IBOutlet UILabel * firstTitleSignalLabel;
@property (weak, nonatomic) IBOutlet UILabel * firstTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView * firstTitleIcon;

@property (weak, nonatomic) IBOutlet UIButton * secondTitleBtn;
@property (weak, nonatomic) IBOutlet UILabel * secondTitleSignalLabel;
@property (weak, nonatomic) IBOutlet UILabel * secondTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView * secondTitleIcon;

@property (weak, nonatomic) IBOutlet UIButton * thirdTitleBtn;
@property (weak, nonatomic) IBOutlet UILabel * thirdTitleSignalLabel;
@property (weak, nonatomic) IBOutlet UILabel * thirdTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView * thirdTitleIcon;

@property (weak, nonatomic) IBOutlet UIButton *fouthTitleBtn;
@property (weak, nonatomic) IBOutlet UILabel *fouthTitleSignalLabel;
@property (weak, nonatomic) IBOutlet UILabel *fouthTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *fouthTitleIcon;


@property (weak, nonatomic) IBOutlet UIButton *reportBtn;

@property (weak, nonatomic) IBOutlet UILabel *firstCleaverChangeTitle;
@property (weak, nonatomic) IBOutlet UILabel *secondCleaverChangeTitle;
@property (weak, nonatomic) IBOutlet UILabel *thirdCleaverChangeTitle;
@property (weak, nonatomic) IBOutlet UILabel *fouthCleaverChangeTitle;
@property (weak, nonatomic) IBOutlet UIButton *firstCleaverChangeBtn;
@property (weak, nonatomic) IBOutlet UIButton *secondCleaverChangeBtn;
@property (weak, nonatomic) IBOutlet UIButton *thirdCleaverChangeBtn;
@property (weak, nonatomic) IBOutlet UIButton *fouthCleaverChangeBtn;

@property (weak, nonatomic) IBOutlet UIView *firstVideoView;
@property (weak, nonatomic) IBOutlet UIView *secondVideoView;
@property (weak, nonatomic) IBOutlet UIView *thirdVideoView;
@property (weak, nonatomic) IBOutlet UIView *fouthVideoView;

@property (nonatomic) SCHelpVideoFlow * helpVideoFlow;
@property (nonatomic) NSMutableDictionary *helpVideoList;

@property (strong, nonatomic)NSMutableArray *checkDataArray;
@end

@implementation SCGuardInsuranceViewController

{
    BOOL _showFirstInfo;
    BOOL _showSecondInfo;
    BOOL _showThirdInfo;
    BOOL _showFouthInfo;
    
    NSInteger _titleBtnTag;
    NSInteger _titleSignalViewTag;
    NSInteger _titleLabelViewTag;
    NSInteger _titleIconTag;
    
    CGFloat _cleaverInfoTotalHeight;
    CGFloat _contentOriginalHeight;
    
    NSInteger _cleaverViewIndex;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = NSLocalizedString(@"RES_30001", @"Fusion splicers and tools condition");
    _mailTitle = NSLocalizedString(@"RES_30039", @"Fusion splicers and tools condition");
    self.modalTitleLabel.text = NSLocalizedString(@"RES_20031", @"モデル:");
    self.snNumTitleLabel.text = NSLocalizedString(@"RES_20032", @"S/N:");
    self.snNumLabel.text = self.appData.selectedSerialNo;
    self.modalLabel.text = [SCSystemData getSpliceModelName:self.appData.selectedSerialNo];
    NSDictionary *statusInfo = [[[SCSpliceDataDao alloc] init] getPreventiveTotalResult:self.appData.selectedSerialNo];
    NSDate *checkDate = [SCSystemData dateFromString:statusInfo[@"checkdate"] format:@"yyyy/MM/dd HH:mm:ss"];
    self.checkDateTitleLabel.text = NSLocalizedString(@"RES_30002", @"最終検査日");
    self.checkDateLabel.text = [SCSystemData stringFromDate:checkDate format:@"yyyy/MM/dd HH:mm"];
    self.mainTitleLabel.text = NSLocalizedString(@"RES_30003", @"");
    [self.reportBtn setTitle:NSLocalizedString(@"RES_30005", @"報告") forState:UIControlStateNormal];
    
    [self initData];
    [self initHelpVideos];
    [self initView];
}
-(void)initHelpVideos{
    self.helpVideoList = [[NSMutableDictionary alloc] init];
    self.helpVideoFlow = [[SCHelpVideoFlow alloc] init];
    self.appData.manHelpVideo = [[SCHelpVideoManager alloc] init];
    self.appData.manHelpVideo.selectLanguage = @"";
    
    // 選択可能言語を取得する
    NSArray *langList = [self.helpVideoFlow getSelectableLaunguageList:self.appData.selectedSerialNo];
    // 言語コードを昇順に並び替える
    NSArray *sortList = [SCHelpVideoFlow sortAscending:langList key:kSC_HVL_No];
    
    // デフォルト言語取得
    self.appData.manHelpVideo.defaultLanguage = sortList.firstObject[kSC_HVL_Code];
    // 選択可能言語の取得
    if (self.appData.selectedSerialNo) {
        
        if ([self.appData.manHelpVideo.selectLanguage isEqualToString:@""]) {
            
            self.appData.manHelpVideo.selectLanguage = self.appData.manHelpVideo.defaultLanguage;
        }
        
        // 選択言語のヘルプリストを取得する
        NSArray *list = [self.helpVideoFlow getHelpMoviesInfo:self.appData.selectedSerialNo];
        
        // IDを昇順に並び替える
        NSArray *movieList = [SCHelpVideoFlow sortAscending:list key:@"id_no"];
        
        for (SCHelpMovie *helpMovie in movieList) {
            if ([helpMovie.id_no hasSuffix:@"0104"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"Microscope_Video"];
            } else if ([helpMovie.id_no hasSuffix:@"0401"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"V_Video"];
            } else if ([helpMovie.id_no hasSuffix:@"0403"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"Clamp_Video"];
            } else if ([helpMovie.id_no hasSuffix:@"0406"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"Electrodes_Video"];
            } else if ([helpMovie.id_no hasSuffix:@"0202"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"Battery_Video"];
            }
        }
        
    }
}

-(void)initData{
    NSDictionary* cleaverInfo = [[[SCSpliceDataDao alloc] init] getRotatesettingInfo:self.appData.selectedSerialNo];
    NSInteger rotatesetting = [[cleaverInfo objectForKey:@"rotatesetting"] integerValue];
    NSInteger thresholdid = [[cleaverInfo objectForKey:@"rotatesetting"] integerValue];
    NSInteger cleaverType = [[cleaverInfo objectForKey:@"type"] integerValue];
    NSDictionary* temp = @{@"serialno":self.appData.selectedSerialNo,
                           @"checktype":[NSNumber numberWithInteger:3],
                           @"thresholdid":[NSNumber numberWithInteger:5]};
    NSDictionary* detailResult = [[[SCSpliceDataDao alloc] init] getPreventiveResultDetailInfo:temp];
    NSInteger alignmentunitstatus = [[detailResult objectForKey:@"status"] integerValue];
    temp = @{@"serialno":self.appData.selectedSerialNo,
             @"checktype":[NSNumber numberWithInteger:2],
             @"thresholdid":[NSNumber numberWithInteger:3]};
    detailResult = [[[SCSpliceDataDao alloc] init] getPreventiveResultDetailInfo:temp];
    NSInteger arcCountStatus = [[detailResult objectForKey:@"status"] integerValue];
    temp = @{@"serialno":self.self.appData.selectedSerialNo,
             @"checktype":[NSNumber numberWithInteger:1],
             @"thresholdid":[NSNumber numberWithInteger:1]};
    detailResult = [[[SCSpliceDataDao alloc] init] getPreventiveResultDetailInfo:temp];
    NSInteger autoCleaverStatus = [[detailResult objectForKey:@"status"] integerValue];
    temp = @{@"serialno":self.self.appData.selectedSerialNo,
             @"checktype":[NSNumber numberWithInteger:1],
             @"thresholdid":[NSNumber numberWithInteger:2]};
    detailResult = [[[SCSpliceDataDao alloc] init] getPreventiveResultDetailInfo:temp];
    NSInteger fixedCleaverStatus = [[detailResult objectForKey:@"status"] integerValue];
    temp = @{@"serialno":self.appData.selectedSerialNo,
             @"checktype":[NSNumber numberWithInteger:2],
             @"thresholdid":[NSNumber numberWithInteger:4]};
    detailResult = [[[SCSpliceDataDao alloc] init] getPreventiveResultDetailInfo:temp];
    NSInteger errorLogCodeStatus = [[detailResult objectForKey:@"status"] integerValue];
    
    NSInteger batteryInfoStatus = 0;
    temp = @{@"serialno":self.appData.selectedSerialNo,
             @"checktype":[NSNumber numberWithInteger:4],
             @"thresholdid":[NSNumber numberWithInteger:6]};
    NSDictionary* batteryDetailResult = [[[SCSpliceDataDao alloc] init] getPreventiveResultDetailInfo:temp];
    batteryInfoStatus = [[batteryDetailResult objectForKey:@"status"] integerValue];
    NSString* batterySN = [batteryDetailResult objectForKey:@"batterysn"];
    
    NSInteger cleaverstatus = fixedCleaverStatus >= autoCleaverStatus ? fixedCleaverStatus : autoCleaverStatus;
    if (cleaverType == 0) {
        cleaverstatus = 0;
    } else if (autoCleaverStatus == 0) {
        cleaverstatus = fixedCleaverStatus;
    } else if (fixedCleaverStatus == 1 && autoCleaverStatus == 2) {
        cleaverstatus = rotatesetting == 1 ? autoCleaverStatus : fixedCleaverStatus;
    } else if (fixedCleaverStatus == 0 && autoCleaverStatus == 1) {
        cleaverstatus = rotatesetting == 1 ? autoCleaverStatus : fixedCleaverStatus;
    } else if (fixedCleaverStatus == 2 && autoCleaverStatus == 1) {
        cleaverstatus = rotatesetting == 1 ? autoCleaverStatus : fixedCleaverStatus;
    } else if (fixedCleaverStatus == 0 && autoCleaverStatus == 2) {
        cleaverstatus = rotatesetting == 1 ? autoCleaverStatus : fixedCleaverStatus;
    }

    self.checkDataArray = [[NSMutableArray alloc] init];
    
    PreventiveCheckModel *checkCleaverModel = [[PreventiveCheckModel alloc] initWithCheckName:NSLocalizedString(@"RES_30006", @"ファイバカッタ")];
    PreventiveCheckModel *checkProtectionGlassModel = [[PreventiveCheckModel alloc] initWithCheckName:NSLocalizedString(@"RES_30007", @"調心ユニット")];
    PreventiveCheckModel *checkElectrodeModel = [[PreventiveCheckModel alloc] initWithCheckName:NSLocalizedString(@"RES_30008", @"電極棒")];
    PreventiveCheckModel *checkBatteryModel;
    if (batterySN.length) {
        checkBatteryModel = [[PreventiveCheckModel alloc] initWithCheckName:[NSString stringWithFormat:NSLocalizedString(@"BT_MSG_1", @"バッテリ(S/N：%@)"),batterySN]];
    } else {
        checkBatteryModel = [[PreventiveCheckModel alloc] initWithCheckName:NSLocalizedString(@"BT_MSG_2", @"バッテリ")];
    }
    checkBatteryModel.checkLevel = batteryInfoStatus;
    
    if (batteryInfoStatus == 1) {
        checkBatteryModel.solutDescription = NSLocalizedString(@"BT_MSG_CAUTION", @"");
    } else if (batteryInfoStatus == 2) {
        checkBatteryModel.solutDescription = NSLocalizedString(@"BT_MSG_WARNING", @"");
    }
    
    checkCleaverModel.checkLevel = cleaverstatus;
    if (checkCleaverModel.checkLevel > 0) {checkCleaverModel.showCleaverView = true;}
    checkProtectionGlassModel.checkLevel = alignmentunitstatus;
    checkElectrodeModel.checkLevel = arcCountStatus > errorLogCodeStatus ? arcCountStatus : errorLogCodeStatus;
    
    if (thresholdid == 1) {
        //自動
        if (cleaverstatus == 1) {checkCleaverModel.solutDescription = NSLocalizedString(@"RES_30012", @"");}
        if (cleaverstatus == 2) {checkCleaverModel.solutDescription = NSLocalizedString(@"RES_30014", @"");}
    } else if (thresholdid == 2) {
        //手動
        if (cleaverstatus == 1) {checkCleaverModel.solutDescription = NSLocalizedString(@"RES_30011", @"");}
        if (cleaverstatus == 2) {checkCleaverModel.solutDescription = NSLocalizedString(@"RES_30013", @"");}
    }
    if (arcCountStatus >= errorLogCodeStatus) {
        if (arcCountStatus == 1) {checkElectrodeModel.solutDescription = NSLocalizedString(@"RES_30033", @"");}
        if (arcCountStatus == 2) {checkElectrodeModel.solutDescription = NSLocalizedString(@"RES_30034", @"");}
    } else {
        checkElectrodeModel.solutDescription = NSLocalizedString(@"RES_30035", @"");
    }
    
    if (checkElectrodeModel.checkLevel > 0) {checkProtectionGlassModel.showVideoView = true;}
    
    if (checkProtectionGlassModel.checkLevel == 1) {
        checkProtectionGlassModel.solutDescription = NSLocalizedString(@"RES_30031", @"");
        checkProtectionGlassModel.showVideoView = true;
    } else if (checkProtectionGlassModel.checkLevel == 2) {
        checkProtectionGlassModel.solutDescription = NSLocalizedString(@"RES_30032", @"");
        checkProtectionGlassModel.showVideoView = true;
    }
    
    [self.checkDataArray addObject:checkCleaverModel];
    [self.checkDataArray addObject:checkProtectionGlassModel];
    [self.checkDataArray addObject:checkElectrodeModel];
    [self.checkDataArray addObject:checkBatteryModel];
    
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"checkLevel" ascending:NO];
    [self.checkDataArray sortUsingDescriptors:[NSArray arrayWithObject:sort]];
    
    NSInteger cleaverIndex = [self.checkDataArray indexOfObject:checkCleaverModel];
    while (cleaverIndex > 0) {
        PreventiveCheckModel *tempModel = [self.checkDataArray objectAtIndex:cleaverIndex-1];
        if (tempModel.checkLevel == checkCleaverModel.checkLevel) { [self.checkDataArray exchangeObjectAtIndex:cleaverIndex withObjectAtIndex:cleaverIndex-1]; }
        cleaverIndex--;
    }
    if (checkProtectionGlassModel.checkLevel == checkElectrodeModel.checkLevel) {
        NSInteger argumentUnitIndex = [self.checkDataArray indexOfObject:checkProtectionGlassModel];
        NSInteger electrodeIndex = [self.checkDataArray indexOfObject:checkElectrodeModel];
        if (argumentUnitIndex > electrodeIndex) {
            [self.checkDataArray exchangeObjectAtIndex:argumentUnitIndex withObjectAtIndex:electrodeIndex];
        }
    }
    
    self.firstCleaverChangeTitle.text = thresholdid == 1 ? NSLocalizedString(@"RES_30021", @"") : NSLocalizedString(@"RES_30022", @"");
    self.secondCleaverChangeTitle.text = thresholdid == 1 ? NSLocalizedString(@"RES_30021", @"") : NSLocalizedString(@"RES_30022", @"");
    self.thirdCleaverChangeTitle.text = thresholdid == 1 ? NSLocalizedString(@"RES_30021", @"") : NSLocalizedString(@"RES_30022", @"");
    self.fouthCleaverChangeTitle.text = thresholdid == 1 ? NSLocalizedString(@"RES_30021", @"") : NSLocalizedString(@"RES_30022", @"");
    [self.firstCleaverChangeBtn setTitle:@"Done" forState:UIControlStateNormal];
    [self.secondCleaverChangeBtn setTitle:@"Done" forState:UIControlStateNormal];
    [self.thirdCleaverChangeBtn setTitle:@"Done" forState:UIControlStateNormal];
    [self.fouthCleaverChangeBtn setTitle:@"Done" forState:UIControlStateNormal];
}

-(void)initView{
    
//    if(![SCSystemData isModelType72C:self.appData.selectedSerialNo]) {
//        self.reportBtn.hidden = true;
//    }
    
    NSDictionary *statusInfo = [[[SCSpliceDataDao alloc] init] getPreventiveTotalResult:self.appData.selectedSerialNo];
    NSDate *checkDate = [SCSystemData dateFromString:statusInfo[@"checkdate"] format:@"yyyy/MM/dd HH:mm:ss"];
    self.checkDateLabel.text = [SCSystemData stringFromDate:checkDate format:@"yyyy/MM/dd HH:mm"];
    
    self.mainTitleViewHeight.constant = 60;
    _showFirstInfo = false;
    _showSecondInfo = false;
    _showThirdInfo = false;
    _showFouthInfo = false;
    _cleaverViewIndex = 0;
    
    NSArray *titleHeightArray = @[self.firstTitleHeight,self.secondTitleHeight,self.thirdTitleHeight,self.fouthTitleHeight];
    NSArray *signalLabelArray = @[self.firstTitleSignalLabel,self.secondTitleSignalLabel,self.thirdTitleSignalLabel,self.fouthTitleSignalLabel];
    NSArray *titleLabelArray = @[self.firstTitleLabel,self.secondTitleLabel,self.thirdTitleLabel,self.fouthTitleLabel];
    NSArray *infoLabelArray  = @[self.firstInfoLabel,self.secondInfoLabel,self.thirdInfoLabel,self.fouthInfoLabel];
    NSArray *videoArray = @[self.firstVideoView,self.secondVideoView,self.thirdVideoView,self.fouthVideoView];
    
    for (NSInteger i = 0; i < self.checkDataArray.count; i++) {
        UIView* videoView = videoArray[i];
        PreventiveCheckModel *checkModel = self.checkDataArray[i];
        UILabel *titleLabel = titleLabelArray[i];
        titleLabel.text = checkModel.checkName;
        UILabel *signalLabel = signalLabelArray[i];
        signalLabel.text = checkModel.checkStatus;
        signalLabel.backgroundColor = checkModel.signalColor;
        UILabel *infoLabel = infoLabelArray[i];
        infoLabel.text = checkModel.solutDescription;
        if (checkModel.checkLevel == 0 || checkModel.checkLevel == -1) {
            NSLayoutConstraint *titleHeight = titleHeightArray[i];
            titleHeight.constant = 0;
        } else {
            if ([checkModel.checkName isEqualToString:NSLocalizedString(@"RES_30006", @"ファイバカッタ")] && checkModel.showCleaverView){
                _cleaverViewIndex = i+1;
                videoView.hidden = true;
            } else if ([checkModel.checkName isEqualToString:NSLocalizedString(@"RES_30007", @"調心ユニット")]) {
                videoView.hidden = false;
                [self makeVideoViewWithTitle:NSLocalizedString(@"RES_30007", @"調心ユニット") andVideoView:videoView];
            } else if ([checkModel.checkName isEqualToString:NSLocalizedString(@"RES_30008", @"電極棒")]) {
                videoView.hidden = false;
                [self makeVideoViewWithTitle:NSLocalizedString(@"RES_30008", @"電極棒") andVideoView:videoView];
            } else if ([checkModel.checkName hasPrefix:@"Battery"] || [checkModel.checkName hasPrefix:@"バッテリ"]) {
                [self makeVideoViewWithTitle:checkModel.checkName andVideoView:videoView];
            }
            self.mainTitleViewHeight.constant = 0;
        }
    }
    
    _cleaverInfoTotalHeight = 100;
    _contentOriginalHeight = 196;
    
    self.firstInfoHeight.constant = 0;
    self.secondInfoHeight.constant = 0;
    self.thirdInfoHeight.constant = 0;
    self.fouthInfoHeight.constant = 0;
    self.totalContentHeight.constant = _contentOriginalHeight;
    
    
    self.firstCleaverInfoViewHeight.constant = _cleaverViewIndex == 1 ? _cleaverInfoTotalHeight : 50;
    self.secondCleaverInfoViewHeight.constant = _cleaverViewIndex == 2 ? _cleaverInfoTotalHeight : 50;
    self.thirdCleaverInfoViewHeight.constant = _cleaverViewIndex == 3 ? _cleaverInfoTotalHeight : 50;
    self.fouthCleaverInfoViewHeight.constant = _cleaverViewIndex == 4 ? _cleaverInfoTotalHeight : 50;

    
    [self refeshTitleView];
}

-(void)makeVideoViewWithTitle:(NSString *)title andVideoView:(UIView *)videoView{
    NSArray* views = [videoView subviews];
    BOOL isTypeSE = false;
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        isTypeSE = true;
    }
    CGFloat movieWidth = isTypeSE ? 72 : 90;
    CGFloat movieHeight = isTypeSE ? 40 : 50;
    CGFloat HelpMovieInterval = 10;
    for (UIView * temp in views) {
        [temp removeFromSuperview];
    }
    if ([title isEqualToString:NSLocalizedString(@"RES_30007", @"調心ユニット")]){
        NSMutableArray * videoList = [[NSMutableArray alloc] init];
        if ([self.helpVideoList objectForKey:@"V_Video"] != nil) {
            [videoList addObject:[self.helpVideoList objectForKey:@"V_Video"]];
        } else {
            DDLogDebug(@"--> Have no V_Video <--");
        }
        if ([self.helpVideoList objectForKey:@"Clamp_Video"] != nil) {
            [videoList addObject:[self.helpVideoList objectForKey:@"Clamp_Video"]];
        } else {
            DDLogDebug(@"--> Have no Clamp_Video <--");
        }
        if ([self.helpVideoList objectForKey:@"Microscope_Video"] != nil) {
            [videoList addObject:[self.helpVideoList objectForKey:@"Microscope_Video"]];
        } else {
            DDLogDebug(@"--> Have no Microscope_Video <--");
        }
        for (int i = 0 ; i < [videoList count]; i++) {
            SCHelpMovie *helpMovie = [videoList objectAtIndex:i];
            NSString *thumbnailFile = [self.helpVideoFlow.rootHelpVideoFolder stringByAppendingPathComponent:helpMovie.thumbnailfile];
            UIImage *thumbnail = [self getThumbnailImage:thumbnailFile];
            SCAutoDiagnosisVideoButton *videoButton = [SCAutoDiagnosisVideoButton buttonWithType:UIButtonTypeCustom];
            videoButton.helpMovie = helpMovie;
            videoButton.frame = CGRectMake((i % 3) * (movieWidth + HelpMovieInterval), (i/3) * (movieHeight + HelpMovieInterval), movieWidth, movieHeight);
            [videoButton setBackgroundImage:thumbnail forState:UIControlStateNormal];
            [videoButton setImage:[UIImage imageNamed:@"Video_play"] forState:UIControlStateNormal];
            [videoButton addTarget:self action:@selector(showHelpMovie:) forControlEvents:UIControlEventTouchUpInside];
            [videoView addSubview:videoButton];
        }
    } else if ([title isEqualToString:NSLocalizedString(@"RES_30008", @"電極棒")]) {
        SCHelpMovie *fiberResetMovie = [self.helpVideoList objectForKey:@"Electrodes_Video"];
        NSString *thumbnailFile = [self.helpVideoFlow.rootHelpVideoFolder stringByAppendingPathComponent:fiberResetMovie.thumbnailfile];
        UIImage *thumbnail = [self getThumbnailImage:thumbnailFile];
        SCAutoDiagnosisVideoButton *videoButton = [SCAutoDiagnosisVideoButton buttonWithType:UIButtonTypeCustom];
        videoButton.helpMovie = fiberResetMovie;
        videoButton.frame = CGRectMake(0, 0, movieWidth, movieHeight);
        [videoButton setBackgroundImage:thumbnail forState:UIControlStateNormal];
        [videoButton setImage:[UIImage imageNamed:@"Video_play"] forState:UIControlStateNormal];
        [videoButton addTarget:self action:@selector(showHelpMovie:) forControlEvents:UIControlEventTouchUpInside];
        [videoView addSubview:videoButton];
    } else if ([title hasPrefix:@"Battery"] || [title hasPrefix:@"バッテリ"]) {
        SCHelpMovie *batteryMovie = [self.helpVideoList objectForKey:@"Battery_Video"];
        NSString *thumbnailFile = [self.helpVideoFlow.rootHelpVideoFolder stringByAppendingPathComponent:batteryMovie.thumbnailfile];
        UIImage *thumbnail = [self getThumbnailImage:thumbnailFile];
        SCAutoDiagnosisVideoButton *videoButton = [SCAutoDiagnosisVideoButton buttonWithType:UIButtonTypeCustom];
        videoButton.helpMovie = batteryMovie;
        videoButton.frame = CGRectMake(0, 0, movieWidth, movieHeight);
        [videoButton setBackgroundImage:thumbnail forState:UIControlStateNormal];
        [videoButton setImage:[UIImage imageNamed:@"Video_play"] forState:UIControlStateNormal];
        [videoButton addTarget:self action:@selector(showHelpMovie:) forControlEvents:UIControlEventTouchUpInside];
        [videoView addSubview:videoButton];
    }
}

-(void)refeshTitleView{
    [_firstTitleBtn setBackgroundColor:_showFirstInfo ? [UIColor colorWithRed:243/255.0f green:243/255.0f blue:243/255.0f alpha:1]:[UIColor whiteColor]];
    [_secondTitleBtn setBackgroundColor:_showSecondInfo ? [UIColor colorWithRed:243/255.0f green:243/255.0f blue:243/255.0f alpha:1]:[UIColor whiteColor]];
    [_thirdTitleBtn setBackgroundColor:_showThirdInfo ? [UIColor colorWithRed:243/255.0f green:243/255.0f blue:243/255.0f alpha:1]:[UIColor whiteColor]];
    [_fouthTitleBtn setBackgroundColor:_showFouthInfo ? [UIColor colorWithRed:243/255.0f green:243/255.0f blue:243/255.0f alpha:1]:[UIColor whiteColor]];
    
    _firstTitleIcon.image = _showFirstInfo ? [UIImage imageNamed:@"icon_Arrow"] : [UIImage imageNamed:@"triangle"];
    _secondTitleIcon.image = _showSecondInfo ? [UIImage imageNamed:@"icon_Arrow"] : [UIImage imageNamed:@"triangle"];
    _thirdTitleIcon.image = _showThirdInfo ? [UIImage imageNamed:@"icon_Arrow"] : [UIImage imageNamed:@"triangle"];
    _fouthTitleIcon.image = _showFouthInfo ? [UIImage imageNamed:@"icon_Arrow"] : [UIImage imageNamed:@"triangle"];
}

-(void)refreshInfoView{

    self.firstInfoHeight.constant = _showFirstInfo ? (self.firstInfoLabel.frame.size.height + 30 + (_cleaverViewIndex == 1 ? 100 : 50)) : 0;
    self.secondInfoHeight.constant = _showSecondInfo ?  (self.secondInfoLabel.frame.size.height + 30 + (_cleaverViewIndex == 2 ? 100 : 50)) : 0;
    self.thirdInfoHeight.constant = _showThirdInfo ? (self.thirdInfoLabel.frame.size.height + 30 + (_cleaverViewIndex == 3 ? 100 : 50)) : 0;
    self.fouthInfoHeight.constant = _showFouthInfo ? (self.fouthInfoLabel.frame.size.height + 30 + (_cleaverViewIndex == 4 ? 100 : 50)) : 0;
    self.totalContentHeight.constant = _contentOriginalHeight + (self.firstInfoHeight.constant
                                                                 + self.secondInfoHeight.constant
                                                                 + self.thirdInfoHeight.constant
                                                                 + self.fouthInfoHeight.constant);
     
    
    [UIView animateWithDuration:0.5 animations:^{
        
        [self.view layoutIfNeeded];
        
    }];
}

- (void)showHelpMovie:(SCAutoDiagnosisVideoButton *)button {
    self.appData.manHelpVideo.selectHelpID = button.helpMovie.id_no;
    [self performSegueWithIdentifier:@"toHelpVideoPlay" sender:self];
}

- (UIImage *)getThumbnailImage:(NSString *)fileName {
    
    UIImage *ret;
    if (fileName) {
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        BOOL isExist = [fileManager fileExistsAtPath:fileName];
        if(isExist) {
            NSData *data = [[NSData alloc] initWithContentsOfFile:fileName];
            if (data) {
                ret = [UIImage imageWithData:data];
            }
        }
    }
    
    return ret;
}
#pragma mark - 实现 MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    if (result == MFMailComposeResultFailed) {
        DDLogDebug(@"Sendmail Failed.");
    } else if (result == MFMailComposeResultSent) {
        DDLogDebug(@"Sendmail Success.");
    }
    //关闭邮件发送窗口
    
    [controller dismissViewControllerAnimated:YES completion:^{
        
    }];
    
}

#pragma mark - BtnMethod

-(IBAction)titleBtnClicked:(id)sender{
    
    if (sender == _firstTitleBtn) {
        
        _showFirstInfo = !_showFirstInfo;
        
    } else if (sender == _secondTitleBtn) {
        
        _showSecondInfo = !_showSecondInfo;
        
    } else if (sender == _thirdTitleBtn) {
        
        _showThirdInfo = !_showThirdInfo;
        
    } else if (sender == _fouthTitleBtn) {
        
        _showFouthInfo = !_showFouthInfo;
        
    }
    
    [self refeshTitleView];
    [self refreshInfoView];
}

- (IBAction)exchangeCleaverBtnClicked:(id)sender {
    
    NSInteger thresholdid = [[[SCSpliceDataDao alloc] init] getRotatesettingID:self.appData.selectedSerialNo];//1:自動　2:手動
    NSString *alertTitle = thresholdid == 1 ? NSLocalizedString(@"RES_30029", @"") : NSLocalizedString(@"RES_30030", @"");
    
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:alertTitle
                                                                   message:@"" preferredStyle:UIAlertControllerStyleAlert];

     [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
         
         NSDictionary *detailInfo = @{@"serialno":self.appData.selectedSerialNo,
                                      @"checktype":[NSNumber numberWithInt:1],
                                      @"thresholdid" : [NSNumber numberWithInteger:1],
                                      @"status" : [NSNumber numberWithInteger:0]};
         [[[SCSpliceDataDao alloc] init] changePreventiveDetailInfoStatus:detailInfo];
         
         detailInfo = @{@"serialno":self.appData.selectedSerialNo,
                                      @"checktype":[NSNumber numberWithInt:1],
                                      @"thresholdid" : [NSNumber numberWithInteger:2],
                                      @"status" : [NSNumber numberWithInteger:0]};
         [[[SCSpliceDataDao alloc] init] changePreventiveDetailInfoStatus:detailInfo];
         
         [SCSystemData changeTotalCheckResult:self.appData.selectedSerialNo updateCheckTime:false];
         
         [self runGetCheckArcCountFlow];
         [self initData];
         [self initView];
     }]];
    
     [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
     }]];
     
     [self presentViewController:alert animated:YES completion:^{
     }];
}

-(void)runGetCheckArcCountFlow{
    SCSpliceDataFlow *flow = [[SCSpliceDataFlow alloc] init];
    [self showProgress:NSLocalizedString(@"RES_20057", @"実行中...") cancelHandler:^{
            DDLogDebug(@"プログレスのキャンセル");
    }];
    
    [flow getArcAccountWithCompletion:^(NSInteger checkCount, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideProgress];
        
            NSDictionary *rotatesInfo = [[[SCSpliceDataDao alloc] init] getRotatesettingInfo:self.appData.selectedSerialNo];
            NSMutableDictionary *exchangeInfoDic = [[NSMutableDictionary alloc] initWithDictionary:rotatesInfo];
            NSInteger exchangeCount = [[rotatesInfo objectForKey:@"exchangecount"] integerValue];
            NSDate* now = [NSDate date];
            [exchangeInfoDic setObject:[SCSystemData stringFromDate:now format:@"yyyy/MM/dd HH:mm:ss"]
                                       forKey:@"exchangedate"];
            if (error) {
                [exchangeInfoDic setObject:[NSNumber numberWithInteger:exchangeCount] forKey:@"exchangecount"];
            } else {
                [exchangeInfoDic setObject:[NSNumber numberWithInteger:checkCount] forKey:@"exchangecount"];
            }

            [[[SCSpliceDataDao alloc] init] updateRotatesettingInfo:exchangeInfoDic];
            
            NSDictionary* uploadInfo = [[[SCSpliceDataDao alloc] init] getPreventiveTotalUploadInfo:rotatesInfo];

            NSInteger status = 0;
            NSMutableDictionary* alignmentUnitDetailResult = [[NSMutableDictionary alloc] initWithDictionary:[[[SCSpliceDataDao alloc] init] getPreventiveDetailResultWith:[uploadInfo objectForKey:@"serialno"] andChecktype:3 andThresholdid:5 andCheckDate:[uploadInfo objectForKey:@"checkdate"]]];
            NSMutableDictionary* arcDetailResult = [[NSMutableDictionary alloc] initWithDictionary:[[[SCSpliceDataDao alloc] init] getPreventiveDetailResultWith:[uploadInfo objectForKey:@"serialno"] andChecktype:2 andThresholdid:3 andCheckDate:[uploadInfo objectForKey:@"checkdate"]]];
            NSMutableDictionary* autoCleaverDetailResult = [[NSMutableDictionary alloc] initWithDictionary:[[[SCSpliceDataDao alloc] init] getPreventiveDetailResultWith:[uploadInfo objectForKey:@"serialno"] andChecktype:1 andThresholdid:1 andCheckDate:[uploadInfo objectForKey:@"checkdate"]]];
            NSMutableDictionary* fixedCleaverDetailResult = [[NSMutableDictionary alloc] initWithDictionary:[[[SCSpliceDataDao alloc] init] getPreventiveDetailResultWith:[uploadInfo objectForKey:@"serialno"] andChecktype:1 andThresholdid:2 andCheckDate:[uploadInfo objectForKey:@"checkdate"]]];
            NSMutableDictionary* errorLogDetailResult = [[NSMutableDictionary alloc] initWithDictionary:[[[SCSpliceDataDao alloc] init] getPreventiveDetailResultWith:[uploadInfo objectForKey:@"serialno"] andChecktype:2 andThresholdid:4 andCheckDate:[uploadInfo objectForKey:@"checkdate"]]];
            [alignmentUnitDetailResult setObject:[SCSystemData stringFromDate:now format:@"yyyyMMddHHmmss"] forKey:@"checkdate"];
            [arcDetailResult setObject:[SCSystemData stringFromDate:now format:@"yyyyMMddHHmmss"] forKey:@"checkdate"];
            [autoCleaverDetailResult setObject:[NSNumber numberWithInteger:0] forKey:@"status"];
            [autoCleaverDetailResult setObject:[SCSystemData stringFromDate:now format:@"yyyyMMddHHmmss"] forKey:@"checkdate"];
            [fixedCleaverDetailResult setObject:[NSNumber numberWithInteger:0] forKey:@"status"];
            [fixedCleaverDetailResult setObject:[SCSystemData stringFromDate:now format:@"yyyyMMddHHmmss"] forKey:@"checkdate"];
            [errorLogDetailResult setObject:[SCSystemData stringFromDate:now format:@"yyyyMMddHHmmss"] forKey:@"checkdate"];

            [[[SCSpliceDataDao alloc] init] insertPreventiveDetailResult:alignmentUnitDetailResult];
            [[[SCSpliceDataDao alloc] init] insertPreventiveDetailResult:arcDetailResult];
            [[[SCSpliceDataDao alloc] init] insertPreventiveDetailResult:autoCleaverDetailResult];
            [[[SCSpliceDataDao alloc] init] insertPreventiveDetailResult:fixedCleaverDetailResult];
            [[[SCSpliceDataDao alloc] init] insertPreventiveDetailResult:errorLogDetailResult];
            
            if ([[alignmentUnitDetailResult objectForKey:@"status"] integerValue] > status) {
                status = [[alignmentUnitDetailResult objectForKey:@"status"] integerValue];
            }

            if ([[arcDetailResult objectForKey:@"status"] integerValue] > status) {
                status = [[arcDetailResult objectForKey:@"status"] integerValue];
            }
            
            NSMutableDictionary *tempDic = [[NSMutableDictionary alloc] initWithDictionary:uploadInfo];
            [tempDic setValue:[SCSystemData stringFromDate:now format:@"yyyyMMddHHmmss"] forKey:@"checkdate"];
            [tempDic setValue:[exchangeInfoDic objectForKey:@"exchangedate"] forKey:@"exchangedate"];
            [tempDic setValue:[NSNumber numberWithInteger:0] forKey:@"exchangecount"];
            [tempDic setValue:[exchangeInfoDic objectForKey:@"exchangecount"] forKey:@"prejudgecount"];
            [tempDic setValue:[exchangeInfoDic objectForKey:@"type"] forKey:@"type"];
            [tempDic setValue:[exchangeInfoDic objectForKey:@"rotatesetting"] forKey:@"rotatesetting"];
            [tempDic setValue:[NSNumber numberWithInteger:0] forKey:@"uploadedflag"];
            [tempDic setValue:[NSNumber numberWithInteger:status] forKey:@"status"];
            [tempDic setValue:[NSNumber numberWithInteger:0] forKey:@"cleaverstatus"];
            [[[SCSpliceDataDao alloc] init] setPreventiveTotalUploadInfo:tempDic];

        });
    }];
}

- (IBAction)sendEmail:(id)sender {
    
    MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init];
    mailViewController.modalPresentationStyle = UIModalPresentationFullScreen;
    
    if (!mailViewController) {
        DDLogDebug(@"Email Account また設定しません。");
        return;
    }
       
    mailViewController.mailComposeDelegate = self;
       
    // 2.设置邮件主题
    if (_mailTitle) {
        [mailViewController setSubject:_mailTitle];
    }
    
    NSMutableArray *questionModelArray = [[NSMutableArray alloc] init];
    
    for (PreventiveCheckModel *temp in self.checkDataArray) {
        if (temp.checkLevel > 0) {
            [questionModelArray addObject:temp];
        }
    }
    
    NSMutableString *mailText = [NSMutableString stringWithCapacity:0];
    [mailText appendFormat:@"%@ %@ \n",NSLocalizedString(@"RES_20031", @"モデル:"),[SCSystemData getSpliceModelName:self.appData.selectedSerialNo]];
    [mailText appendFormat:@"S/N: %@ \n",self.appData.selectedSerialNo];
    [mailText appendFormat:@"%@: %@ \n\n",NSLocalizedString(@"RES_30002", @"最終検査日"),self.checkDateLabel.text];
    
    if (questionModelArray.count) {

        for (PreventiveCheckModel *temp in questionModelArray) {
            [mailText appendFormat:@"- %@:%@ \n",temp.checkName,temp.checkStatus];
            [mailText appendFormat:@"%@ \n\n",temp.solutDescription];
        }
           
        [mailViewController setMessageBody:mailText isHTML:NO];
    } else {
        
        [mailText appendFormat:@"%@ \n\n",self.mainTitleLabel.text];
        [mailViewController setMessageBody:mailText isHTML:NO];
        
    }
       
       // 5.呼出发送视图
    [self presentViewController:mailViewController animated:YES completion:nil];
}

- (IBAction)actionBack:(UIBarButtonItem *)sender {

    DDLogDebug(@"");

    [self.navigationController popViewControllerAnimated:YES];
}

@end
