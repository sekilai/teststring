//
//  SplicerListAdminCell.h
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/03.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplicerListAdminCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *serialNo;
@property (weak, nonatomic) IBOutlet UILabel *startday;
@property (weak, nonatomic) IBOutlet UIImageView *unConnectIcon;
@property (weak, nonatomic) IBOutlet UIImageView *connectedIcon;
@property (weak, nonatomic) IBOutlet UILabel *connectedLbl;

@end
