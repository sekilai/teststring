//
//  SCSpliceDataSelectDateTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/17.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCSpliceDataSelectDateTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblDate;
@property (weak, nonatomic) IBOutlet UILabel *lblTotal;

@end
