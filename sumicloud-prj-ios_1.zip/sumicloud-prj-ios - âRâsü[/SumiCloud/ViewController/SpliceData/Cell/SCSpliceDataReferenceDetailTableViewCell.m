//
//  SCSpliceDataReferenceDetailTableViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/18.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataReferenceDetailTableViewCell.h"

#import "SCSystemData.h"

@implementation SCSpliceDataReferenceDetailTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


/**
 緯度・経度

 @param latitude <#latitude description#>
 @param longitude <#longitude description#>
 */
- (void)makeLatLon:(NSString *)latitude lon:(NSString *)longitude {
    
    if (latitude.length == 0 || longitude.length == 0) {
        
        self.lblValue.text = NSLocalizedString(@"NO_DATA", @"---");
        
        self.lblSubTitle.text = @"";
    } else {

        self.lblValue.text = [NSString stringWithFormat:@"%@\n%@",
                              [self getGeoTage60:latitude],
                              [self getGeoTage60:longitude]];
        
        self.lblSubTitle.text = [NSString stringWithFormat:@"%@\n%@",
                                 NSLocalizedString(@"UNIT_12",@"緯度"),
                                 NSLocalizedString(@"UNIT_13", @"経度")];
    }
}

-(void)makeT502Loss:(NSString *)cladLossStr hca:(NSString *)hcaLossStr estLossLimit:(NSString *)estLossLimit{
    
    self.lblValue1.text = [NSString stringWithFormat:@"Clad:%@ dB",cladLossStr];
    self.lblValue2.text = [NSString stringWithFormat:@"HCA:%@ dB",hcaLossStr];
    
    if (cladLossStr.length && estLossLimit.length) {
        
        if ([cladLossStr doubleValue] >= [estLossLimit doubleValue]) {
            
            self.lblValue1.textColor = [UIColor redColor];
        }
    }
    
    if (hcaLossStr.length && estLossLimit.length) {
        if ([hcaLossStr doubleValue] >= [estLossLimit doubleValue]) {
            self.lblValue2.textColor = [UIColor redColor];
        }
    }
}

/**
 エラー情報

 @param errinfo <#errinfo description#>
 */
- (void)makeErrInfo:(NSString *)errinfo {
    
    NSString* msg = NSLocalizedString(@"SP_ERRINFO_NO_ERROR", @"エラーメッセージ");
    
    if (errinfo.length && ![errinfo isEqualToString:@"0"]) {
        
        NSString* errID = [[NSString alloc] initWithFormat:@"SP_ERRINFO_%@", errinfo];
        msg = NSLocalizedString(errID, @"エラーメッセージ");

        if ([msg isEqualToString:errID]) {
            
            NSString *fmt = NSLocalizedString(@"SP_ERRINFO_XXXX", @"エラーメッセージ");
            msg = [[NSString alloc] initWithFormat:fmt, errinfo];
        }
    }
    
    self.lblValue.text = msg;
}

/**
 推定ロス値

 @param estimatedLoss <#estimatedLoss description#>
 @param estLossLimit <#estLossLimit description#>
 */
- (void)makeEstimatedLoss:(NSString *)estimatedLoss estLossLimit:(NSString *)estLossLimit {
    
    self.lblValue.text = [NSString stringWithFormat:@"%@ %@",
                          [SCSystemData stringFromDoubleString:estimatedLoss decimalLength:2],
                          NSLocalizedString(@"UNIT_01", @"dB")];

    self.lblValue.textColor = [UIColor blackColor];

    if (estimatedLoss.length && estLossLimit.length) {
        
        if ([estimatedLoss doubleValue] >= [estLossLimit doubleValue]) {
            
            self.lblValue.textColor = [UIColor redColor];
        }
    }
}

/**
 端面角度

 @param left <#left description#>
 @param right <#right description#>
 */
- (void)makeCleaveAngle:(NSString *)left right:(NSString *)right {
    
    NSString *fmt = NSLocalizedString(@"UNIT_03", @"左右");
    NSString *txt = [NSString stringWithFormat:fmt,
                     [SCSystemData stringFromDoubleString:left decimalLength:1],
                     [SCSystemData stringFromDoubleString:right decimalLength:1]];
    
    self.lblValue.text = [NSString stringWithFormat:@"%@ %@",
                          txt,
                          NSLocalizedString(@"UNIT_04", @"度")];
}

/**
 軸ずれ量

 @param before <#before description#>
 @param after <#after description#>
 */
- (void)makeFiberOffset:(NSString *)before after:(NSString *)after {
    
    NSString *fmt = NSLocalizedString(@"UNIT_05", @"前後");
    NSString *txt = [NSString stringWithFormat:fmt,
                     [SCSystemData stringFromDoubleString:before decimalLength:1],
                     [SCSystemData stringFromDoubleString:after decimalLength:1]];
    
    self.lblValue.text = [NSString stringWithFormat:@"%@ %@",
                          txt,
                          NSLocalizedString(@"UNIT_06", @"um")];
}

/**
 コアずれ量

 @param coreOffset <#coreOffset description#>
 */
- (void)makeCoreOffset:(NSString *)coreOffset {
    if ([coreOffset isEqualToString:@"---"]) {
        self.lblValue.text = @"--- um";
    } else {
        self.lblValue.text = [NSString stringWithFormat:@"%@ %@",
                              [SCSystemData stringFromDoubleString:coreOffset decimalLength:1],
                              NSLocalizedString(@"UNIT_06", @"um")];
    }
}

/**
 軸ずれ角度（放電前）

 @param before <#before description#>
 @param after <#after description#>
 */
- (void)makeCoreAngle:(NSString *)before after:(NSString *)after {
    
    NSString *fmt = NSLocalizedString(@"UNIT_05", @"前後");
    NSString *txt = [NSString stringWithFormat:fmt,
                     [SCSystemData stringFromDoubleString:before decimalLength:1],
                     [SCSystemData stringFromDoubleString:after decimalLength:1]];
    
    self.lblValue.text = [NSString stringWithFormat:@"%@ %@",
                          txt,
                          NSLocalizedString(@"UNIT_04", @"度")];
}

/**
 偏心量

 @param left <#left description#>
 @param right <#right description#>
 */
- (void)makeConcentricity:(NSString *)left right:(NSString *)right {
    
    NSString *fmt = NSLocalizedString(@"UNIT_03", @"左右");
    NSString *txt = [NSString stringWithFormat:fmt,
                     [SCSystemData stringFromDoubleString:left decimalLength:1],
                     [SCSystemData stringFromDoubleString:right decimalLength:1]];
    
    self.lblValue.text = [NSString stringWithFormat:@"%@ %@",
                          txt,
                          NSLocalizedString(@"UNIT_06", @"um")];
}

/**
 気温

 @param temperature <#temperature description#>
 @param isDegF <#isDegF description#>
 */
- (void)makeTemperature:(NSString *)temperature isDegF:(BOOL)isDegF {
    
    // 華氏ー＞摂氏変換判定
    if (isDegF) {
        
        // 華氏
        self.lblValue.text = [NSString stringWithFormat:@"%@ %@",
                              temperature,
                              NSLocalizedString(@"UNIT_07", @"F")];
    } else {
        
        // 摂氏
        self.lblValue.text = [NSString stringWithFormat:@"%d %@",
                              (int)round(([temperature doubleValue] - 32) / 1.8f),
                              NSLocalizedString(@"UNIT_08", @"C")];
    }
}

/**
 気圧

 @param airPressure <#airPressure description#>
 */
- (void)makeAirPressure:(NSString *)airPressure {
    
    self.lblValue.text = [NSString stringWithFormat:@"%@ %@",
                          airPressure,
                          NSLocalizedString(@"UNIT_09", @"hP")];
}

/**
 放電回数
 
 @param arcCount <#arcCount description#>
 */
- (void)makeArcCount:(NSString *)arcCount {
    
    self.lblValue.text = [NSString stringWithFormat:@"%@ %@",
                          arcCount,
                          NSLocalizedString(@"UNIT_10", @"回")];
}

/**
 心線識別
 
 @param detectLeft <#detectLeft description#>
 @param detectRight <#detectRight description#>
 */
- (void)makeDetectLeft:(NSString *)detectLeft right:(NSString *)detectRight {
    NSString *fmt = NSLocalizedString(@"UNIT_03", @"左右");
    self.lblValue.text = [NSString stringWithFormat:fmt,
                          [self detectString:detectLeft],
                          [self detectString:detectRight]];
}


#pragma mark - Private Method

/**
 *  getGeoTage60
 *  緯度・経度表示変換（１０進法度単位 >> 度分秒）
 */
- (NSString *)getGeoTage60:(NSString *)latlon {
    
    NSString *ret = @"";
    
    if (latlon.length) {
        
        double val = [latlon floatValue];
        double valAbs = fabs(val);
        NSInteger deg = floor(valAbs);
        NSInteger min = floor((valAbs - deg) * 60);
        NSInteger sec = floor((((valAbs - deg) * 60 - min) * 60));
        
        NSString* msg = NSLocalizedString(@"UNIT_11", @"緯度・経度（度分秒フォーマット）");
        if (0.0f < val) {
            
            ret = [NSString stringWithFormat:msg,
                   [NSString stringWithFormat:@"%4zd", deg],
                   [NSString stringWithFormat:@"%.2zd", min],
                   [NSString stringWithFormat:@"%.2zd", sec]];
        } else {
            
            ret = [NSString stringWithFormat:msg,
                   [NSString stringWithFormat:@"%4zd", (-1 * deg)],
                   [NSString stringWithFormat:@"%.2zd", min],
                   [NSString stringWithFormat:@"%.2zd", sec]];
        }
    }
    
    return ret;
}

/**
 心線識別
 
 @param detect <#detect description#>
 */
- (NSString *)detectString:(NSString *)detect {
    if([detect isEqualToString:@"0"]){
        return NSLocalizedString(@"DETECT_0", @"-");
    }else if([detect isEqualToString:@"1"]){
        return NSLocalizedString(@"DETECT_1", @"SMF");
    }else if([detect isEqualToString:@"2"]){
        return NSLocalizedString(@"DETECT_2", @"MMF");
    }else if([detect isEqualToString:@"3"]){
        return NSLocalizedString(@"DETECT_3", @"DSF");
    }else if([detect isEqualToString:@"4"]){
        return NSLocalizedString(@"DETECT_4", @"NZDS");
    }else if([detect isEqualToString:@"5"]){
        return NSLocalizedString(@"DETECT_5", @"BIF");
    }else{
        return NSLocalizedString(@"DETECT_-1", @"Other");
    }
}
@end
