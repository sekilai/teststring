//
//  SCSpliceDataInformationTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/18.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCSpliceDataInformationTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgvwInfomation;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@end
