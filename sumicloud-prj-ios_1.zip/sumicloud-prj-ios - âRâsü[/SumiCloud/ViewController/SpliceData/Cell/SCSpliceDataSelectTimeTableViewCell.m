//
//  SCSpliceDataSelectTimeTableViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/17.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataSelectTimeTableViewCell.h"

#import "SCSystemData.h"

@implementation SCSpliceDataSelectTimeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    if (selected) {
        
        self.backgroundColor = [SCSystemData colorWithRGB:0xEC green:0xEE blue:0xF0 alpha:1.0f];
    } else {
        
        self.backgroundColor = [UIColor clearColor];
    }
}


/**
 推定ロス値判定

 @param estimatedLoss <#estimatedLoss description#>
 @param estLossLimit <#estLossLimit description#>
 */
- (void)getColorEstimatedLoss:(NSString *)estimatedLoss estLossLimit:(NSString *)estLossLimit {
    
    self.lblDB.textColor = [UIColor blackColor];
    
    if (estimatedLoss.length && estLossLimit.length) {
        
        if ([estimatedLoss doubleValue] >= [estLossLimit doubleValue]) {
            
            self.lblDB.textColor = [UIColor redColor];
        }
    }
}

@end
