//
//  SCSpliceDataSelectTimeTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/17.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCSpliceDataSelectTimeTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblTime;
@property (weak, nonatomic) IBOutlet UILabel *lblDB;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwGPS;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwPhoto;

// 推定ロス値判定
- (void)getColorEstimatedLoss:(NSString *)estimatedLoss estLossLimit:(NSString *)estLossLimit;

@end
