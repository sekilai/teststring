//
//  SplicerListCell.m
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/03.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import "SplicerListCell.h"

@implementation SplicerListCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
