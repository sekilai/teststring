//
//  SCSpliceDataReferenceDetailTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/18.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCSpliceDataReferenceDetailTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblValue;
@property (weak, nonatomic) IBOutlet UILabel *lblSubTitle;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwArrow;
@property (weak, nonatomic) IBOutlet UILabel *lblValue1;
@property (weak, nonatomic) IBOutlet UILabel *lblValue2;

// 緯度・経度
- (void)makeLatLon:(NSString *)latitude lon:(NSString *)longitude;

// エラー情報
- (void)makeErrInfo:(NSString *)errinfo;

// 推定ロス値
- (void)makeEstimatedLoss:(NSString *)estimatedLoss estLossLimit:(NSString *)estLossLimit;

// 推定ロス値T502
-(void)makeT502Loss:(NSString *)cladLossStr hca:(NSString *)hcaLossStr estLossLimit:(NSString *)estLossLimit;

// 端面角度
- (void)makeCleaveAngle:(NSString *)left right:(NSString *)right;

// 軸ずれ量
- (void)makeFiberOffset:(NSString *)before after:(NSString *)after;

// コアずれ量
- (void)makeCoreOffset:(NSString *)coreOffset;

// 軸ずれ角度（放電前）
- (void)makeCoreAngle:(NSString *)before after:(NSString *)after;

// 偏心量
- (void)makeConcentricity:(NSString *)left right:(NSString *)right;

// 気温
- (void)makeTemperature:(NSString *)temperature isDegF:(BOOL)isDegF;

// 気圧
- (void)makeAirPressure:(NSString *)airPressure;

// 放電回数
- (void)makeArcCount:(NSString *)arcCount;

// 心線識別
- (void)makeDetectLeft:(NSString *)detectLeft right:(NSString *)detectRight;
@end
