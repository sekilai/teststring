//
//  SCGuardInsuranceViewController.h
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2019/12/23.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SCGuardInsuranceViewController : SCBaseViewController

@property(strong,nonatomic)NSString * mailTitle;

@property(strong,nonatomic)NSString * mailText;

@end

NS_ASSUME_NONNULL_END
