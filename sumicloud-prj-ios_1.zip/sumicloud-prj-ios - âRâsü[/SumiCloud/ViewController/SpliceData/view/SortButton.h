//
//  SortButton.h
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/12.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SortInfo.h"

IB_DESIGNABLE
@interface SortButton : UIView
@property (nonatomic) SortInfo * sortInfo;

@end
