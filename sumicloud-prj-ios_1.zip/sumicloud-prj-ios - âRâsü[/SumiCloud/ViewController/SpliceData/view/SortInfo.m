//
//  SortInfo.m
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/18.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import "SortInfo.h"

@implementation SortInfo

/**
 初期化

 @param name <#name description#>
 @return <#return value description#>
 */
+ (instancetype)infoWithName:(NSString *)name {
    SortInfo * info = [[SortInfo alloc] init];
    info.name = name;
    info.checkStatus = CHECK_STATUS_NONE;
    return info;
}

@end
