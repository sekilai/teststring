//
//  SortButton.m
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/12.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import "SortButton.h"
@interface SortButton ()
@property (weak, nonatomic) IBOutlet UIImageView * checkIcon;
@property (weak, nonatomic) IBOutlet UIImageView * sortIcon;
@property (weak, nonatomic) IBOutlet UILabel * nameText;
@property (weak, nonatomic) IBOutlet UIView * contentView;

@end

@implementation SortButton

/**
    xibファイル名を指定
 */
- (void)commonInit {
    NSString* className = NSStringFromClass([self class]);
    [[NSBundle bundleForClass:[self class]] loadNibNamed:className owner:self options:nil];
    
    self.contentView.frame = self.bounds;
    [self addSubview:self.contentView];
}

/**
 interface builder(storyboardやnibファイルなど)からobjectを作るときに呼ばれる

 @param aDecoder <#aDecoder description#>
 @return <#return value description#>
 */
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    
    if (self) {
        [self commonInit];
    }
    
    return self;
}

/**
 code上でobjectを作る時に呼ばれる

 @param frame <#frame description#>
 @return <#return value description#>
 */
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        [self commonInit];
    }
    
    return self;
}

/**
 checkIcon状態

 @param sortInfo <#sortInfo description#>
 */
- (void)setSortInfo:(SortInfo *)sortInfo {
    _sortInfo = sortInfo;
    self.nameText.text = sortInfo.name;
    if(sortInfo.checkStatus == CHECK_STATUS_NONE){
        self.checkIcon.image = nil;
        self.sortIcon.image = nil;
    }else{
        self.checkIcon.image = [UIImage imageNamed:@"icon_check"];
        if(sortInfo.checkStatus == CHECK_STATUS_UP){
            self.sortIcon.image = [UIImage imageNamed:@"icon_sort_up"];
        }else{
            self.sortIcon.image = [UIImage imageNamed:@"icon_sort_down"];
        }
    }
}
@end
