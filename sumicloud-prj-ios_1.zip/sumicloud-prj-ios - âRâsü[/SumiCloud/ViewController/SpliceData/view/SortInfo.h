//
//  SortInfo.h
//  RentalApp
//
//  Created by fsi_mac5d_2 on 2017/10/18.
//  Copyright © 2017年 fsi_mac5d_2. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    CHECK_STATUS_NONE,
    CHECK_STATUS_UP,
    CHECK_STATUS_DOWN,
} CHECK_STATUS;

@interface SortInfo : NSObject
@property (nonatomic) IBInspectable NSString * name;
@property (nonatomic) CHECK_STATUS checkStatus;
+ (instancetype)infoWithName:(NSString *)name;
@end
