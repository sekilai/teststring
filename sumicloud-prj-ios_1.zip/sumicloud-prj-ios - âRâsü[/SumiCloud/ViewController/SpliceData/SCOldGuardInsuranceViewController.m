//
//  SCGuardInsuranceViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2019/12/23.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//




#import "SCOldGuardInsuranceViewController.h"
#import "SCLogUtil.h"
#import "SCSystemData.h"
#import "SCSpliceDataDao.h"
#import "SCSpliceDataFlow.h"
#import "SCConnectSpliceDao.h"

@import MessageUI;

@interface OldPreventiveCheckModel : NSObject

@property (copy,nonatomic) NSString *checkName;//Cleaver Electrode Protection glass
@property (copy,nonatomic) NSString *checkStatus; //good caution warning
@property (assign,nonatomic) NSInteger checkLevel;// 0 1 2
@property (strong,nonatomic) UIColor *signalColor;
@property (copy,nonatomic) NSString *solutDescription;
@property (assign,nonatomic)BOOL showCleaverView;

@end

@implementation OldPreventiveCheckModel

- (instancetype)initWithCheckName:(NSString *)checkName
{
    self = [super init];
    if (self) {
        self.checkLevel = 0;
        self.checkName = checkName;
        self.showCleaverView = false;
    }
    return self;
    
}

- (void)setCheckLevel:(NSInteger)checkLevel{
    _checkLevel = checkLevel;
    if (checkLevel == 0) {
        _signalColor = [UIColor colorWithRed:92/255.0 green:198/255.0 blue:102/255.0 alpha:1];
        _checkStatus = @"Good";
    } else if (checkLevel == 1) {
        _signalColor = [UIColor colorWithRed:246/255.0 green:172/255.0 blue:0 alpha:1];
        _checkStatus = @"Caution";
    } else if (checkLevel == 2) {
        _signalColor = [UIColor redColor];
        _checkStatus = @"Warning";
    }
}

@end

@interface SCOldGuardInsuranceViewController () <MFMailComposeViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *modalTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *modalLabel;
@property (weak, nonatomic) IBOutlet UILabel *snNumTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *snNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *checkDateTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *checkDateLabel;

@property (weak, nonatomic) IBOutlet UILabel *mainTitleLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *mainTitleViewHeight;


@property (weak, nonatomic) IBOutlet UIView *firstTitleView;
@property (weak, nonatomic) IBOutlet UIView *secondTitleView;
@property (weak, nonatomic) IBOutlet UIView *thirdTitleView;

@property (weak, nonatomic) IBOutlet UIView *firstInfoView;
@property (weak, nonatomic) IBOutlet UIView *secondInfoView;
@property (weak, nonatomic) IBOutlet UIView *thirdInfoView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *firstTitleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *secondTitleHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *thirdTitleHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *firstInfoHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *secondInfoHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *thirdInfoHeight;

@property (weak, nonatomic) IBOutlet UILabel *firstInfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *secondInfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *thirdInfoLabel;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *totalContentHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *firstCleaverInfoViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *secondCleaverInfoViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *thirdCleaverInfoViewHeight;

@property (weak, nonatomic) IBOutlet UIButton * firstTitleBtn;
@property (weak, nonatomic) IBOutlet UILabel * firstTitleSignalLabel;
@property (weak, nonatomic) IBOutlet UILabel * firstTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView * firstTitleIcon;

@property (weak, nonatomic) IBOutlet UIButton * secondTitleBtn;
@property (weak, nonatomic) IBOutlet UILabel * secondTitleSignalLabel;
@property (weak, nonatomic) IBOutlet UILabel * secondTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView * secondTitleIcon;

@property (weak, nonatomic) IBOutlet UIButton * thirdTitleBtn;
@property (weak, nonatomic) IBOutlet UILabel * thirdTitleSignalLabel;
@property (weak, nonatomic) IBOutlet UILabel * thirdTitleLabel;
@property (weak, nonatomic) IBOutlet UIImageView * thirdTitleIcon;
@property (weak, nonatomic) IBOutlet UIButton *reportBtn;

@property (weak, nonatomic) IBOutlet UILabel *firstCleaverChangeTitle;
@property (weak, nonatomic) IBOutlet UILabel *secondCleaverChangeTitle;
@property (weak, nonatomic) IBOutlet UILabel *thirdCleaverChangeTitle;
@property (weak, nonatomic) IBOutlet UIButton *firstCleaverChangeBtn;
@property (weak, nonatomic) IBOutlet UIButton *secondCleaverChangeBtn;
@property (weak, nonatomic) IBOutlet UIButton *thirdCleaverChangeBtn;


@property (strong, nonatomic)NSMutableArray *checkDataArray;
@end

@implementation SCOldGuardInsuranceViewController

{
    BOOL _showFirstInfo;
    BOOL _showSecondInfo;
    BOOL _showThirdInfo;
    
    NSInteger _titleBtnTag;
    NSInteger _titleSignalViewTag;
    NSInteger _titleLabelViewTag;
    NSInteger _titleIconTag;
    
    CGFloat _cleaverInfoTotalHeight;
    CGFloat _contentOriginalHeight;
    
    NSInteger _cleaverViewIndex;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = NSLocalizedString(@"RES_30000", @"Fusion splicers and tools condition");
    _mailTitle = NSLocalizedString(@"RES_30040", @"Fusion splicers and tools condition");;
    self.modalTitleLabel.text = NSLocalizedString(@"RES_20031", @"モデル:");
    self.snNumTitleLabel.text = NSLocalizedString(@"RES_20032", @"S/N:");
    self.snNumLabel.text = self.appData.selectedSerialNo;
    self.modalLabel.text = [SCSystemData getSpliceModelName:self.appData.selectedSerialNo];
    NSDictionary *statusInfo = [[[SCSpliceDataDao alloc] init] getPreventiveTotalResult:self.appData.selectedSerialNo];
    NSDate *checkDate = [SCSystemData dateFromString:statusInfo[@"checkdate"] format:@"yyyy/MM/dd HH:mm:ss"];
    self.checkDateTitleLabel.text = NSLocalizedString(@"RES_30002", @"最終検査日");
    self.checkDateLabel.text = [SCSystemData stringFromDate:checkDate format:@"yyyy/MM/dd HH:mm"];
    self.mainTitleLabel.text = NSLocalizedString(@"RES_30041", @"");
    [self.reportBtn setTitle:NSLocalizedString(@"RES_30005", @"報告") forState:UIControlStateNormal];
    
    [self initData];
    [self initView];
}

-(void)initData{
    self.checkDataArray = [[NSMutableArray alloc] init];
    
    OldPreventiveCheckModel *checkCleaverModel = [[OldPreventiveCheckModel alloc] initWithCheckName:NSLocalizedString(@"RES_30006", @"ファイバカッタ")];
    OldPreventiveCheckModel *checkProtectionGlassModel = [[OldPreventiveCheckModel alloc] initWithCheckName:NSLocalizedString(@"RES_30007", @"調心ユニット")];
    OldPreventiveCheckModel *checkElectrodeModel = [[OldPreventiveCheckModel alloc] initWithCheckName:NSLocalizedString(@"RES_30008", @"電極棒")];
    
    checkElectrodeModel.solutDescription = NSLocalizedString(@"RES_30009", @"");
    checkProtectionGlassModel.solutDescription = NSLocalizedString(@"RES_30010", @"");
    
    BOOL isCheckSpliceErrorLog = false;
    NSInteger spliceErrorLogStatus = 0;
    NSDictionary *preventiveInfo = @{@"serialno":self.appData.selectedSerialNo,
                                 @"checktype":[NSNumber numberWithInt:1],
                                 @"thresholdid" : [NSNumber numberWithInteger:[[[SCSpliceDataDao alloc] init] getRotatesettingID:self.appData.selectedSerialNo]],
                                 @"status" : [NSNumber numberWithInteger:0]};
    if (preventiveInfo.count) {
        isCheckSpliceErrorLog = true;
        spliceErrorLogStatus = [(NSNumber *)[preventiveInfo objectForKey:@"status"] integerValue];
        if (spliceErrorLogStatus > 0) { checkCleaverModel.showCleaverView = true; }
    }
    
    BOOL isHealthMonitorStatus = [[[NSUserDefaults standardUserDefaults] stringForKey:kSC_ThresholdKey_HealthMonitorStatus] boolValue];
    NSInteger healthCleaverStatus = 0;
    
    SCConnectSplice* connectSplice = [SCSpliceDataFlow getConnectSpliceState:self.appData.selectedSerialNo];
     if ((0x00 < connectSplice.result_auto_diagnosis) && isHealthMonitorStatus) {
             
         if (0x01 & connectSplice.result_auto_diagnosis) {
             // @"電極棒が消耗",
             checkElectrodeModel.checkLevel = 1;
         }
         if (0x02 & connectSplice.result_auto_diagnosis) {
             // @"ファイバ端面角度が大きくなっています"
             healthCleaverStatus = 1;
         }
         if (0x04 & connectSplice.result_auto_diagnosis) {
             // @"融着接続機の状態がよくありません。",
             checkProtectionGlassModel.checkLevel = 2;
         }
     }
    
    if ( !isCheckSpliceErrorLog && !isHealthMonitorStatus ) {
        checkCleaverModel.checkLevel = 0;
    } else if ( isCheckSpliceErrorLog && !isHealthMonitorStatus) {
        checkCleaverModel.checkLevel = spliceErrorLogStatus;
    } else if ( !isCheckSpliceErrorLog && isHealthMonitorStatus) {
        checkCleaverModel.checkLevel = healthCleaverStatus;
    } else if ( isCheckSpliceErrorLog && isHealthMonitorStatus ) {
        checkCleaverModel.checkLevel = (spliceErrorLogStatus > healthCleaverStatus ? spliceErrorLogStatus : healthCleaverStatus);
    }
    
    NSInteger thresholdid = [[[SCSpliceDataDao alloc] init] getRotatesettingID:self.appData.selectedSerialNo];//1:自動　2:手動
    
    if (spliceErrorLogStatus == 0 && healthCleaverStatus == 0) {
        checkCleaverModel.solutDescription = @"";
    } else if (spliceErrorLogStatus == 1 && healthCleaverStatus == 0) {
        checkCleaverModel.solutDescription = (thresholdid == 1 ?
                                              NSLocalizedString(@"RES_30012", @""):
                                              NSLocalizedString(@"RES_30011", @""));
    } else if (spliceErrorLogStatus == 2 && healthCleaverStatus == 0) {
        checkCleaverModel.solutDescription = (thresholdid == 1 ?
        NSLocalizedString(@"RES_30014", @""):
        NSLocalizedString(@"RES_30013", @""));
    } else if (spliceErrorLogStatus == 0 && healthCleaverStatus == 1) {
        checkCleaverModel.solutDescription = (thresholdid == 1 ?
        NSLocalizedString(@"RES_30016", @""):
        NSLocalizedString(@"RES_30015", @""));
    } else if (spliceErrorLogStatus == 1 && healthCleaverStatus == 1) {
        checkCleaverModel.solutDescription = (thresholdid == 1 ?
        NSLocalizedString(@"RES_30018", @""):
        NSLocalizedString(@"RES_30017", @""));
    } else if (spliceErrorLogStatus == 2 && healthCleaverStatus == 1) {
        checkCleaverModel.solutDescription = (thresholdid == 1 ?
        NSLocalizedString(@"RES_30020", @""):
        NSLocalizedString(@"RES_30019", @""));
    }
    
    [self.checkDataArray addObject:checkElectrodeModel];
    [self.checkDataArray addObject:checkProtectionGlassModel];
    [self.checkDataArray addObject:checkCleaverModel];
    
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"checkLevel" ascending:NO];
    [self.checkDataArray sortUsingDescriptors:[NSArray arrayWithObject:sort]];
    
    NSInteger cleaverIndex = [self.checkDataArray indexOfObject:checkCleaverModel];
    while (cleaverIndex > 0) {
        OldPreventiveCheckModel *tempModel = [self.checkDataArray objectAtIndex:cleaverIndex-1];
        if (tempModel.checkLevel == checkCleaverModel.checkLevel) { [self.checkDataArray exchangeObjectAtIndex:cleaverIndex withObjectAtIndex:cleaverIndex-1]; }
        cleaverIndex--;
    }
    
    self.firstCleaverChangeTitle.text = thresholdid == 1 ? NSLocalizedString(@"RES_30021", @"") : NSLocalizedString(@"RES_30022", @"");
    self.secondCleaverChangeTitle.text = thresholdid == 1 ? NSLocalizedString(@"RES_30021", @"") : NSLocalizedString(@"RES_30022", @"");
    self.thirdCleaverChangeTitle.text = thresholdid == 1 ? NSLocalizedString(@"RES_30021", @"") : NSLocalizedString(@"RES_30022", @"");
    [self.firstCleaverChangeBtn setTitle:@"Done" forState:UIControlStateNormal];
    [self.secondCleaverChangeBtn setTitle:@"Done" forState:UIControlStateNormal];
    [self.thirdCleaverChangeBtn setTitle:@"Done" forState:UIControlStateNormal];
}

-(void)initView{
    
    if(![SCSystemData isModelType72C:self.appData.selectedSerialNo]) {
        self.reportBtn.hidden = true;
    }
    
    self.mainTitleViewHeight.constant = 60;
    _showFirstInfo = false;
    _showSecondInfo = false;
    _showThirdInfo = false;
    _cleaverViewIndex = 0;
    
    NSArray *titleHeightArray = @[self.firstTitleHeight,self.secondTitleHeight,self.thirdTitleHeight];
    NSArray *signalLabelArray = @[self.firstTitleSignalLabel,self.secondTitleSignalLabel,self.thirdTitleSignalLabel];
    NSArray *titleLabelArray = @[self.firstTitleLabel,self.secondTitleLabel,self.thirdTitleLabel];
    NSArray *infoLabelArray  = @[self.firstInfoLabel,self.secondInfoLabel,self.thirdInfoLabel];
    
    for (NSInteger i = 0; i < self.checkDataArray.count; i++) {
        OldPreventiveCheckModel *checkModel = self.checkDataArray[i];
        UILabel *titleLabel = titleLabelArray[i];
        titleLabel.text = checkModel.checkName;
        UILabel *signalLabel = signalLabelArray[i];
        signalLabel.text = checkModel.checkStatus;
        signalLabel.backgroundColor = checkModel.signalColor;
        UILabel *infoLabel = infoLabelArray[i];
        infoLabel.text = checkModel.solutDescription;
        if (checkModel.checkLevel == 0) {
            NSLayoutConstraint *titleHeight = titleHeightArray[i];
            titleHeight.constant = 0;
        } else {
            if ([checkModel.checkName isEqualToString:NSLocalizedString(@"RES_30006", @"ファイバカッタ")] && checkModel.showCleaverView){
                _cleaverViewIndex = i+1;
            }
            self.mainTitleViewHeight.constant = 0;
        }
    }
    
    _cleaverInfoTotalHeight = 100;
    _contentOriginalHeight = 152;
    
    self.firstInfoHeight.constant = 0;
    self.secondInfoHeight.constant = 0;
    self.thirdInfoHeight.constant = 0;
    self.totalContentHeight.constant = _contentOriginalHeight;
    
    self.firstCleaverInfoViewHeight.constant = _cleaverViewIndex == 1 ? _cleaverInfoTotalHeight : 0;
    self.secondCleaverInfoViewHeight.constant = _cleaverViewIndex == 2 ? _cleaverInfoTotalHeight : 0;
    self.thirdCleaverInfoViewHeight.constant = _cleaverViewIndex == 3 ? _cleaverInfoTotalHeight : 0 ;
    
    [self refeshTitleView];
}

-(void)refeshTitleView{
    [_firstTitleBtn setBackgroundColor:_showFirstInfo ? [UIColor colorWithRed:243/255.0f green:243/255.0f blue:243/255.0f alpha:1]:[UIColor whiteColor]];
    [_secondTitleBtn setBackgroundColor:_showSecondInfo ? [UIColor colorWithRed:243/255.0f green:243/255.0f blue:243/255.0f alpha:1]:[UIColor whiteColor]];
    [_thirdTitleBtn setBackgroundColor:_showThirdInfo ? [UIColor colorWithRed:243/255.0f green:243/255.0f blue:243/255.0f alpha:1]:[UIColor whiteColor]];
    
    _firstTitleIcon.image = _showFirstInfo ? [UIImage imageNamed:@"icon_Arrow"] : [UIImage imageNamed:@"triangle"];
    _secondTitleIcon.image = _showSecondInfo ? [UIImage imageNamed:@"icon_Arrow"] : [UIImage imageNamed:@"triangle"];
    _thirdTitleIcon.image = _showThirdInfo ? [UIImage imageNamed:@"icon_Arrow"] : [UIImage imageNamed:@"triangle"];
}

-(void)refreshInfoView{

    self.firstInfoHeight.constant = _showFirstInfo ? (self.firstInfoLabel.frame.size.height + 30 + (_cleaverViewIndex == 1 ? 100 : 0)) : 0;
    self.secondInfoHeight.constant = _showSecondInfo ?  (self.secondInfoLabel.frame.size.height + 30 + (_cleaverViewIndex == 2 ? 100 : 0)) : 0;
    self.thirdInfoHeight.constant = _showThirdInfo ? (self.thirdInfoLabel.frame.size.height + 30 + (_cleaverViewIndex == 3 ? 100 : 0)) : 0;
    self.totalContentHeight.constant = _contentOriginalHeight + (self.firstInfoHeight.constant
                                         + self.secondInfoHeight.constant
                                         + self.thirdInfoHeight.constant);
     
    
    [UIView animateWithDuration:0.5 animations:^{
        
        [self.view layoutIfNeeded];
        
    }];
}

#pragma mark - 实现 MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    if (result == MFMailComposeResultFailed) {
        DDLogDebug(@"Sendmail Failed.");
    } else if (result == MFMailComposeResultSent) {
        DDLogDebug(@"Sendmail Success.");
    }
    //关闭邮件发送窗口
    
    [controller dismissViewControllerAnimated:YES completion:^{
        
    }];
    
}

#pragma mark - BtnMethod

-(IBAction)titleBtnClicked:(id)sender{
    
    if (sender == _firstTitleBtn) {
        
        _showFirstInfo = !_showFirstInfo;
        
    } else if (sender == _secondTitleBtn) {
        
        _showSecondInfo = !_showSecondInfo;
        
    } else if (sender == _thirdTitleBtn) {
        
        _showThirdInfo = !_showThirdInfo;
        
    }
    
    [self refeshTitleView];
    [self refreshInfoView];
}

- (IBAction)exchangeCleaverBtnClicked:(id)sender {
    
    NSInteger thresholdid = [[[SCSpliceDataDao alloc] init] getRotatesettingID:self.appData.selectedSerialNo];//1:自動　2:手動
    NSString *alertTitle = thresholdid == 1 ? NSLocalizedString(@"RES_30029", @"") : NSLocalizedString(@"RES_30030", @"");
    
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:alertTitle
                                                                   message:@"" preferredStyle:UIAlertControllerStyleAlert];

     [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
         
         NSMutableDictionary *exchangeInfoDic = [[NSMutableDictionary alloc] init];
         
         [exchangeInfoDic setValue:self.appData.selectedSerialNo forKey:@"serialno"];
         [exchangeInfoDic setValue:[NSNumber numberWithInteger:thresholdid] forKey:@"rotatesetting"];
         [exchangeInfoDic setValue:[SCSystemData stringFromDate:[NSDate date] format:@"yyyy/MM/dd HH:mm:ss"]
                            forKey:@"exchangedate"];
         [[[SCSpliceDataDao alloc] init] updateRotatesettingInfo:exchangeInfoDic];
         
         NSDictionary *detailInfo = @{@"serialno":self.appData.selectedSerialNo,
                                      @"checktype":[NSNumber numberWithInt:1],
                                      @"thresholdid" : [NSNumber numberWithInteger:thresholdid],
                                      @"status" : [NSNumber numberWithInteger:0]};
         [[[SCSpliceDataDao alloc] init] changePreventiveDetailInfoStatus:detailInfo];
         
         SCConnectSplice* connectSplice = [[[SCConnectSpliceDao alloc] init] getSplicerState:self.appData.selectedSerialNo];
         if (0x00 < connectSplice.result_auto_diagnosis) {
             connectSplice.result_auto_diagnosis = connectSplice.result_auto_diagnosis ^ 0x02;
             [[[SCConnectSpliceDao alloc] init] setSplicerState:connectSplice];
         }
         [SCSystemData changeTotalCheckResult:self.appData.selectedSerialNo updateCheckTime:false];
         [self initData];
         [self initView];
     }]];
    
     [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
     }]];
     
     [self presentViewController:alert animated:YES completion:^{
     }];
}

- (IBAction)sendEmail:(id)sender {
    
    MFMailComposeViewController *mailViewController = [[MFMailComposeViewController alloc] init];
    mailViewController.modalPresentationStyle = UIModalPresentationFullScreen;
    
    if (!mailViewController) {
        DDLogDebug(@"Email Account また設定しません。");
        return;
    }
       
    mailViewController.mailComposeDelegate = self;
       
    // 2.设置邮件主题
    if (_mailTitle) {
        [mailViewController setSubject:_mailTitle];
    }
    
    NSMutableArray *questionModelArray = [[NSMutableArray alloc] init];
    
    for (OldPreventiveCheckModel *temp in self.checkDataArray) {
        if (temp.checkLevel > 0) {
            [questionModelArray addObject:temp];
        }
    }
    
    NSMutableString *mailText = [NSMutableString stringWithCapacity:0];
    [mailText appendFormat:@"%@ %@ \n",NSLocalizedString(@"RES_20031", @"モデル:"),[SCSystemData getSpliceModelName:self.appData.selectedSerialNo]];
    [mailText appendFormat:@"S/N: %@ \n",self.appData.selectedSerialNo];
    [mailText appendFormat:@"%@: %@ \n\n",NSLocalizedString(@"RES_30002", @"最終検査日"),self.checkDateLabel.text];
    
    if (questionModelArray.count) {

        for (OldPreventiveCheckModel *temp in questionModelArray) {
            [mailText appendFormat:@"- %@:%@ \n",temp.checkName,temp.checkStatus];
            [mailText appendFormat:@"%@ \n\n",temp.solutDescription];
        }
           
        [mailViewController setMessageBody:mailText isHTML:NO];
    } else {
        
        [mailText appendFormat:@"%@ \n\n",self.mainTitleLabel.text];
        [mailViewController setMessageBody:mailText isHTML:NO];
        
    }
       
       // 5.呼出发送视图
    [self presentViewController:mailViewController animated:YES completion:nil];
}

- (IBAction)actionBack:(UIBarButtonItem *)sender {

    DDLogDebug(@"");

    [self.navigationController popViewControllerAnimated:YES];
}

@end
