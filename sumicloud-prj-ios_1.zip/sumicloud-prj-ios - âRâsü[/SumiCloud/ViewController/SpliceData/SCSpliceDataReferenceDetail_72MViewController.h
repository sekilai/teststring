//
//  SCSpliceDataReferenceDetail_72MViewController.h
//  SumiCloud
//
//  Created by fsi_mac_6 on 2019/04/01.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCSpliceDataReferenceDetail_72MViewController : SCBaseViewController

@end

