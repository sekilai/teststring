//
//  SCSpliceDataSelectDateViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataSelectDateViewController.h"
#import "SCSpliceDataSelectDateTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCSpliceDataFlow.h"
#import "SCSpliceData.h"

@interface SCSpliceDataSelectDateViewController () <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource>

@property (nonatomic) NSArray* listData;
@property (nonatomic) NSArray* listSelectableYearMonth;

@property (weak, nonatomic) IBOutlet UITextField *txtYYYYMM;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UIView *vwDate;
@property (weak, nonatomic) IBOutlet UILabel *lblYYYYMM;
@property (weak, nonatomic) IBOutlet UIView *vwHeading;
@property (weak, nonatomic) IBOutlet UILabel *lblDate;
@property (weak, nonatomic) IBOutlet UILabel *lblTotal;
@property (weak, nonatomic) IBOutlet UITableView *tblvwList;

- (IBAction)actionBack:(UIBarButtonItem *)sender;
- (IBAction)actionCalender:(UIBarButtonItem *)sender;
- (IBAction)actionMenu:(UIBarButtonItem *)sender;

@end

@implementation SCSpliceDataSelectDateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.vwDate.backgroundColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    self.lblYYYYMM.textColor = [UIColor whiteColor];
    self.vwHeading.backgroundColor = [SCSystemData colorWithRGB:0xDB green:0xDB blue:0xDB alpha:1.0f];
    self.lblDate.textColor = [UIColor blackColor];
    self.lblTotal.textColor = [UIColor blackColor];

    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_SPLICEDATA_DATE", @"接続データ");
    self.lblYYYYMM.text = self.appData.manSpliceData.selectYYYYMM;
    self.txtYYYYMM.text = self.lblYYYYMM.text;
    self.lblDate.text = NSLocalizedString(@"RES_20008", @"Date");
    self.lblTotal.text = NSLocalizedString(@"RES_20009", @"Total");
    
    // 画面表示データの更新
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.listData = [SCSpliceDataFlow selectDateSpliceDataList];
    [self refreshOnlineSerialNo];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];

    [self.view endEditing:YES];
}


#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {

    DDLogDebug(@"");

    [self.navigationController popViewControllerAnimated:YES];
}

/**
 期間設定ボタン

 @param sender <#sender description#>
 */
- (IBAction)actionCalender:(UIBarButtonItem *)sender {

    DDLogDebug(@"");
    
    [self.txtYYYYMM becomeFirstResponder];
}

/**
 アクションメニューボタン

 @param sender <#sender description#>
 */
- (IBAction)actionMenu:(UIBarButtonItem *)sender {

    DDLogDebug(@"");
}


#pragma mark - UITextFieldDelegate

/**
 入力項目編集開始
 
 @param textField <#textField description#>
 
 @return <#return value description#>
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    // Cancelボタン
    UIBarButtonItem *btnEditCancel = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_CANCEL", @"キャンセル") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditCancelTouchUpInside:)];
    
    // フレキシブルスペース
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    
    // 設定ボタン
    UIBarButtonItem *btnEditOk = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_DONE", @"完了") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditOkTouchUpInside:)];
    
    // ツールバー
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    toolbar.barStyle = UIBarStyleDefault;
    [toolbar sizeToFit];
    [toolbar setItems:@[btnEditCancel, spacer, btnEditOk] animated:YES];
    textField.inputAccessoryView = toolbar;
    
    self.listSelectableYearMonth = [SCSpliceDataFlow selectableYearMonth];
    UIPickerView *vwPicker = [[UIPickerView alloc] init];
    textField.inputView = vwPicker;
    vwPicker.delegate = self;
    vwPicker.dataSource = self;
    [vwPicker sizeToFit];
    
    // 選択項目位置初期化
    for (NSInteger posPicker=0; posPicker < self.listSelectableYearMonth.count; posPicker++) {
        
        if ([textField.text isEqualToString:self.listSelectableYearMonth[posPicker]]) {
            
            [vwPicker selectRow:posPicker inComponent:0 animated:NO];
            break;
        }
    }
    
    return YES;
}

/**
 入力項目編集終了
 
 @param textField <#textField description#>
 */
- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    [self.view endEditing:YES];
}

/**
 入力項目のOK
 
 @param sender <#sender description#>
 */
- (void)btnEditOkTouchUpInside:(UIButton *)sender {
    
    [self.view endEditing:YES];
    
    UIPickerView* vwPicker = (UIPickerView *)self.txtYYYYMM.inputView;
    self.txtYYYYMM.text = [self.listSelectableYearMonth objectAtIndex:[vwPicker selectedRowInComponent:0]];
    self.lblYYYYMM.text = self.txtYYYYMM.text;
    
    // 画面表示データの更新
    self.appData.manSpliceData.selectYYYYMM = self.lblYYYYMM.text;
    self.listData = [SCSpliceDataFlow selectDateSpliceDataList];
    [self.tblvwList reloadData];
}

/**
 入力項目のCancel
 
 @param sender <#sender description#>
 */
- (void)btnEditCancelTouchUpInside:(UIButton *)sender {
    
    [self.view endEditing:YES];
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param section   <#section description#>

 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listData.count;
}

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>

 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    SCSpliceDataSelectDateTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    NSDictionary* dicItem = [self.listData objectAtIndex:indexPath.row];
    cell.lblDate.text = dicItem[kSC_SDM_Date];
    cell.lblTotal.text = dicItem[kSC_SDM_Total];
    
    return cell;
}

/**
 日付選択

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    DDLogDebug(@"");
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    SCSpliceDataSelectDateTableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
    self.appData.manSpliceData.selectYYYYMMDD = cell.lblDate.text;
    
    [self performSegueWithIdentifier:@"toSelectTime" sender:self];
}


#pragma mark - UIPickerViewDelegate

/**
 選択表示
 
 @param pickerView <#pickerView description#>
 @param row        <#row description#>
 @param component  <#component description#>
 */
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    
    self.txtYYYYMM.text = self.listSelectableYearMonth[row];
}

/**
 選択表示
 
 @param pickerView <#pickerView description#>
 @param row        <#row description#>
 @param component  <#component description#>
 
 @return <#return value description#>
 */
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    
    return self.listSelectableYearMonth[row];
}


#pragma mark - UIPickerViewDataSource

/**
 選択表示
 
 @param pickerView <#pickerView description#>
 
 @return <#return value description#>
 */
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
    return 1;
}

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param component <#component description#>
 @return <#return value description#>
 */
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    return self.listSelectableYearMonth.count;
}


#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

@end
