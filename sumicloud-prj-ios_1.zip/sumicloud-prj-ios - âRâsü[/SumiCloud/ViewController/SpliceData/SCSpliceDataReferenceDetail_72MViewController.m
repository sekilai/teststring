//
//  SCSpliceDataReferenceDetail_72MViewController.m
//  SumiCloud
//
//  Created by fsi_mac_6 on 2019/04/01.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataReferenceDetail_72MViewController.h"
#import "SCSystemData.h"
#import "SCSpliceDataFlow.h"


@interface DataModal_72M : NSObject

@property (nonatomic, copy) NSString * dataType;
@property (nonatomic, retain) NSMutableArray * signalArray;
@property (nonatomic, retain) NSMutableArray * dataArray;

@end

@implementation DataModal_72M

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.dataType = @"";
        self.dataArray = [[NSMutableArray alloc] init];
        self.signalArray = [[NSMutableArray alloc] init];
    }
    return self;
}

- (instancetype)initTitleData {
    self = [super init];
    if (self) {
        self.dataType = @"titleType";
    }
    return self;
}

- (instancetype)initWithNo:(NSString *)no
                        OffsetBefore:(NSString *)offsetBefore
                         OffsetAfter:(NSString *)offsetAfter
                           AngleLeft:(NSString *)angleLeft
                          AngleRight:(NSString *)angleRight
                                 Gap:(NSString *)gap
                                Loss:(NSString *)loss
                  OffsetBeforeSignal:(NSString *)offsetBeforeSignal
                   OffsetAfterSignal:(NSString *)offsetAfterSignal
                     AngleLeftSignal:(NSString *)angleLeftSignal
                    AngleRightSignal:(NSString *)angleRightSignal
                           GapSignal:(NSString *)gapSignal
                          LossSignal:(NSString *)lossSignal
                               Error:(NSString *)error{
    self = [super init];
    if (self) {
        self.dataType = @"dataType_1";
        self.dataArray = [[NSMutableArray alloc] init];
        [self.dataArray addObject:no];
        [self.dataArray addObject:offsetBefore];
        [self.dataArray addObject:offsetAfter];
        [self.dataArray addObject:angleLeft];
        [self.dataArray addObject:angleRight];
        [self.dataArray addObject:gap];
        [self.dataArray addObject:loss];
        
        self.signalArray = [[NSMutableArray alloc] init];
        [self.signalArray addObject:error];
        [self.signalArray addObject:offsetBeforeSignal];
        [self.signalArray addObject:offsetAfterSignal];
        [self.signalArray addObject:angleLeftSignal];
        [self.signalArray addObject:angleRightSignal];
        [self.signalArray addObject:gapSignal];
        [self.signalArray addObject:lossSignal];
        
    
    }
    return self;
}

- (instancetype)initWithTitle:(NSString *)title Value:(NSString *)value {
    self = [super init];
    if (self) {
        self.dataType = @"dataType_2";
        self.dataArray = [[NSMutableArray alloc] init];
        [self.dataArray addObject:title];
        [self.dataArray addObject:value];
    }
    return self;
}

- (instancetype)initWithGPS:(NSString *)loc Value1:(NSString *)value1 Value2:(NSString *)value2 {
    self = [super init];
    if (self) {
        self.dataType = @"dataType_3";
        self.dataArray = [[NSMutableArray alloc] init];
        [self.dataArray addObject:loc];
        [self.dataArray addObject:value1];
        [self.dataArray addObject:value2];
    }
    return self;
}

- (instancetype)initWithIrregular:(NSString *)title
                   Irregular_left:(NSString *)irregular_left
                  Irregular_right:(NSString *)irregular_right
                  Limit_Irregular:(NSString *)limitIrregular{
    self = [super init];
    if (self) {
        self.dataType = @"dataType_Irregular";
        self.dataArray = [[NSMutableArray alloc] init];
        [self.dataArray addObject:title];
        [self.dataArray addObject:irregular_left];
        [self.dataArray addObject:irregular_right];
        [self.dataArray addObject:limitIrregular];
    }
    return self;
}

- (instancetype)initWithNo:(NSString *)no ErrorCode:(NSString *)errorCode {
    self = [super init];
    if (self) {
        self.dataType = @"errorType";
        self.dataArray = [[NSMutableArray alloc] init];
        [self.dataArray addObject:no];
        [self.dataArray addObject:errorCode];
    }
    return self;
}


@end

@interface SCSpliceDataReferenceDetail_72MViewController () <UITextFieldDelegate,UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSMutableArray * dataList;
@property (nonatomic) NSString* editMemo;

@end

@implementation SCSpliceDataReferenceDetail_72MViewController

static NSInteger const kSC_MAXLEN_MEMO = 48;     // 「メモ」入力文字数

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (![SCSystemData isModelType72M:self.appData.detailSpliceData.serialno]) {
        return;
    }
    self.dataList = [[NSMutableArray alloc] init];
    [self makeData];
}

- (void)makeData {
    
    [self.dataList removeAllObjects];
    [self.dataList addObject:[[DataModal_72M alloc] initTitleData]];
    
    NSArray * detailList = self.appData.T72M_SpliceDataDetailList;
    NSMutableArray * errorList = [[NSMutableArray alloc] init];
    for (int i = 0; i < detailList.count; i++) {
       
        NSDictionary * tempDic = [detailList objectAtIndex:i];
        NSInteger errorCode = [(NSString *)[tempDic objectForKey:@"error"] integerValue];
        if (errorCode >= 115 && errorCode <= 118) {
            DataModal_72M * errorData = [[DataModal_72M alloc] initWithNo:[NSString stringWithFormat:@"%d", i+1] ErrorCode:[tempDic objectForKey:@"error"]];
            [errorList addObject:errorData];
        }
        DataModal_72M * tempData = [[DataModal_72M alloc] initWithNo:[NSString stringWithFormat:@"%d", i+1]
                                                        OffsetBefore:[SCSystemData stringFromDoubleString:[tempDic objectForKey:@"align"] decimalLength:1]
                                                         OffsetAfter:[SCSystemData stringFromDoubleString:[tempDic objectForKey:@"align_aft"] decimalLength:1]
                                                           AngleLeft:[SCSystemData stringFromDoubleString:[tempDic objectForKey:@"angle_left"] decimalLength:1]
                                                          AngleRight:[SCSystemData stringFromDoubleString:[tempDic objectForKey:@"angle_right"] decimalLength:1]
                                                                 Gap:[SCSystemData stringFromDoubleString:[tempDic objectForKey:@"interval"] decimalLength:1]
                                                                Loss:[SCSystemData stringFromDoubleString:[tempDic objectForKey:@"estimate"] decimalLength:2]
                                                  OffsetBeforeSignal:[tempDic objectForKey:@"align_err_flg"]
                                                   OffsetAfterSignal:[tempDic objectForKey:@"align_aft_err_flg"]
                                                     AngleLeftSignal:[tempDic objectForKey:@"angle_left_err_flg"]
                                                    AngleRightSignal:[tempDic objectForKey:@"angle_right_err_flg"]
                                                           GapSignal:[tempDic objectForKey:@"interval_err_flg"]
                                                          LossSignal:[tempDic objectForKey:@"estimate_err_flg"]
                                                               Error:[tempDic objectForKey:@"error"]];
        [self.dataList addObject:tempData];
    }
    

    
    
    NSString * irregularLeftStr = [self judgementIrregularWithIrregular_X:self.appData.detailSpliceData.irregular_left_x andIrregular_Y:self.appData.detailSpliceData.irregular_left_y];
    NSString * irregularRightStr = [self judgementIrregularWithIrregular_X:self.appData.detailSpliceData.irregular_right_x andIrregular_Y:self.appData.detailSpliceData.irregular_right_y];
    [self.dataList addObject:[[DataModal_72M alloc] initWithIrregular:NSLocalizedString(@"SP_DETAIL_22", @"不揃い量") Irregular_left:irregularLeftStr Irregular_right:irregularRightStr Limit_Irregular:self.appData.detailSpliceData.limit_err_irregular]];
    //SP_72M_ERRINFO_0
    NSInteger errorCode = [self.appData.detailSpliceData.error_info integerValue];
    if (errorCode >= 115 && errorCode <= 118) {
        [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_05", @"エラー") Value:NSLocalizedString(@"SP_72M_ERRINFO_Postfusion", @"Postfusion Check Error")]];
    } else {
        [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_05", @"エラー") Value:[self makeErrInfo:self.appData.detailSpliceData.error_info]]];
    }
    
    if (errorList.count > 0) {
        DataModal_72M * errorTitle = [[DataModal_72M alloc] initWithNo:@"No." ErrorCode:@""];
        [self.dataList addObject:errorTitle];
        for (DataModal_72M * errorData in errorList) {
            [self.dataList addObject:errorData];
        }
    }
    [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_12", @"メモ") Value:[NSString stringWithFormat:@"%@ >", self.appData.detailSpliceData.memo]]];
    [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_13", @"気温") Value:[self makeTemperature:self.appData.detailSpliceData.temperature isDegF:NO]]];
    [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_14", @"気圧") Value:[NSString stringWithFormat:@" %@ hPa",self.appData.detailSpliceData.air_pressure]]];
    [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_15", @"電源供給") Value:self.appData.detailSpliceData.power_supply]];
    [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_16", @"放電回数") Value:[NSString stringWithFormat:@"%@ %@",self.appData.detailSpliceData.arc_count,NSLocalizedString(@"UNIT_10", @"回")]]];
    [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_04", @"融着プログラム") Value:self.appData.detailSpliceData.name.length == 0 ? @"--" : self.appData.detailSpliceData.name]];
    [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_01", @"モデル") Value:[SCSystemData getSpliceModelName:self.appData.detailSpliceData.serialno]]];
    [self.dataList addObject:[[DataModal_72M alloc] initWithTitle:NSLocalizedString(@"SP_DETAIL_02", @"シリアル番号") Value:self.appData.detailSpliceData.serialno]];
    
    NSString * gps_lat = self.appData.detailSpliceData.lat;
    NSString * gps_lon = self.appData.detailSpliceData.lon;
    
    [self.dataList addObject:[[DataModal_72M alloc] initWithGPS:NSLocalizedString(@"SP_DETAIL_03", @"GPS位置")
                                                         Value1: gps_lat.length == 0 ? @"--" : [NSString stringWithFormat:@"  %@",self.appData.detailSpliceData.lat]
                                                         Value2: gps_lon.length == 0 ? @"--" : [NSString stringWithFormat:@"  %@",self.appData.detailSpliceData.lon]]];
    
    [self.tableView reloadData];
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    DataModal_72M * temp = [self.dataList objectAtIndex:indexPath.row];
    
    if ( [temp.dataType isEqualToString:@"titleType"] ) {
        return 40.0f;
    } else if ( [temp.dataType isEqualToString:@"dataType_1"] ) {
        return 28.0f;
    } else if ( [temp.dataType isEqualToString:@"dataType_2"] ) {
        return 30.0f;
    } else if ( [temp.dataType isEqualToString:@"dataType_3"] ) {
        return 60.0f;
    }
    
    return 40.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.dataList.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    DataModal_72M * temp = [self.dataList objectAtIndex:indexPath.row];
    
    UITableViewCell * cell;
    
    if ( [temp.dataType isEqualToString:@"titleType"] ) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"titleCell"];
        if ([UIScreen mainScreen].bounds.size.width == 320) {
            UIStackView * tempStackView = (UIStackView *)[cell.contentView viewWithTag:1000];
            UIView * gapView = (UIView *)[tempStackView viewWithTag:1100];
            UILabel * gapLabel = (UILabel *)[gapView viewWithTag:1110];
            gapLabel.text = @"Gap\n(um)";
            UIView * lossView = (UIView *)[tempStackView viewWithTag:1200];
            UILabel * lossLabel = (UILabel *)[lossView viewWithTag:1210];
            lossLabel.text = @"Loss\n(dB)";
            
        }
    }
    
    if ( [temp.dataType isEqualToString:@"dataType_1"] ) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"dataCell_1"];
        UIStackView * skView = (UIStackView *)[cell.contentView viewWithTag:1000];
        for (int i = 0 ; i < temp.dataArray.count ; i++) {
            UILabel * lbl = (UILabel *)[skView viewWithTag: i+100];
            NSString * dataStr = [temp.dataArray objectAtIndex:i];
            lbl.text = dataStr;
            NSString * signal = [temp.signalArray objectAtIndex:i];
            if ( i == 0 ) {
                NSInteger errorCode = [signal integerValue];
                if (errorCode >= 115 && errorCode <= 118) {
                    lbl.backgroundColor = [UIColor colorWithRed:1.0 green:80.0/255.0 blue:80.0/255.0 alpha:1];
                } else {
                    lbl.backgroundColor = [UIColor whiteColor];
                }
            } else if (i == 2) {
                continue;
            } else if (i == 6) {
                
                if ([dataStr isEqualToString:@"99.99"]) {
                    lbl.text = @"--";
                } else {
                    lbl.text = dataStr;
                }
                NSInteger errorCode = [(NSString *)[temp.signalArray objectAtIndex:0] integerValue];
                if ((errorCode != 0) && (errorCode != 13) && (errorCode != 119)){
                    if (!(errorCode >= 103 && errorCode <= 113)) {
                        lbl.text = @"--";
                    }
                }
                
                BOOL redWarning = true;
                if (errorCode == 0 || errorCode == 13 || errorCode == 119) {
                    redWarning = false;
                } else if (errorCode >= 103 && errorCode <= 113) {
                    redWarning = false;
                } else {
                    redWarning = true;
                }
                
                if ([dataStr floatValue] > [self.appData.detailSpliceData.est_loss_limit floatValue] &&
                    ![dataStr isEqualToString:@"--"]) {
                    redWarning = true;
                }
                
                if (redWarning) {
                    lbl.backgroundColor = [UIColor colorWithRed:1.0 green:80.0/255.0 blue:80.0/255.0 alpha:1];
                } else {
                    lbl.backgroundColor = [UIColor whiteColor];
                }
                
            } else {
                lbl.backgroundColor = [signal isEqualToString:@"1"] ? [UIColor colorWithRed:1.0 green:80.0/255.0 blue:80.0/255.0 alpha:1] : [UIColor whiteColor];
            }
        }
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    
    if ( [temp.dataType isEqualToString:@"dataType_2"] ) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"dataCell_2"];
        for (int i = 0 ; i < temp.dataArray.count ; i++) {
            UILabel * lbl = (UILabel *)[cell.contentView viewWithTag: i+200];
            lbl.text = (NSString *)[temp.dataArray objectAtIndex:i];
        }
    }
    
    if ( [temp.dataType isEqualToString:@"dataType_3"] ) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"dataCell_2"];
        UILabel * titleLabel = (UILabel *)[cell.contentView viewWithTag: 200];
        titleLabel.text = [temp.dataArray objectAtIndex:0];
        
        UILabel * gpsLabel = (UILabel *)[cell.contentView viewWithTag: 201];
        NSString * gps_Lat = [self getGeoTage60:[temp.dataArray objectAtIndex:1]];
        NSString * gps_Lon = [self getGeoTage60:[temp.dataArray objectAtIndex:2]];
        
        if ([gps_Lat isEqualToString:@"--"] || [gps_Lon isEqualToString:@"--"]) {
            gpsLabel.text = NSLocalizedString(@"NO_DATA", @"---");
        } else {
            gpsLabel.text = [NSString stringWithFormat:@"%@: %@\n%@: %@",
                             NSLocalizedString(@"UNIT_12",@"緯度"),
                             gps_Lat,
                             NSLocalizedString(@"UNIT_13", @"経度"),
                             gps_Lon];
        }
    }
    
    if ( [temp.dataType isEqualToString:@"errorType"] ) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"errorType"];
        
        UILabel * nolbl = (UILabel *)[cell.contentView viewWithTag:210];
        NSString * noStr = [temp.dataArray objectAtIndex:0];
        nolbl.text = [NSString stringWithFormat:@" %@", noStr];
        
        UILabel * errorLbl = (UILabel *)[cell.contentView viewWithTag:211];
        if ([noStr isEqualToString:@"No."]) {
            errorLbl.text = @"";
        } else {
            errorLbl.text = [self makeErrInfo:[temp.dataArray objectAtIndex:1]];
        }
    }
    
    if ([temp.dataType isEqualToString:@"dataType_Irregular"]) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"IrregularType"];
        UILabel * titleLabel = (UILabel *)[cell.contentView viewWithTag: 400];
        UILabel * irregularLeftLabel = (UILabel *)[cell.contentView viewWithTag: 401];
        UILabel * irregularRightLabel = (UILabel *)[cell.contentView viewWithTag: 402];
        titleLabel.text = [temp.dataArray objectAtIndex:0];
        NSString * irregularLeftData = [temp.dataArray objectAtIndex:1];
        NSString * irregularRightData = [temp.dataArray objectAtIndex:2];
        NSString * limitIrregularData = [temp.dataArray objectAtIndex:3];
        irregularLeftLabel.text = [NSString stringWithFormat:@"L:%@",irregularLeftData];
        irregularRightLabel.text = [NSString stringWithFormat:@"R:%@",irregularRightData];
        
        irregularLeftLabel.backgroundColor = ![irregularLeftData isEqualToString:@"--"] &&
        ([irregularLeftData integerValue] > [limitIrregularData integerValue]) ?
        [UIColor colorWithRed:1.0 green:80.0/255.0 blue:80.0/255.0 alpha:1] : [UIColor whiteColor];
        
        irregularRightLabel.backgroundColor = ![irregularRightData isEqualToString:@"--"] &&
        ([irregularRightData integerValue] > [limitIrregularData integerValue]) ?
        [UIColor colorWithRed:1.0 green:80.0/255.0 blue:80.0/255.0 alpha:1] : [UIColor whiteColor];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:true];
    
    DataModal_72M * temp = [self.dataList objectAtIndex:indexPath.row];
    if ([temp.dataType isEqualToString:@"dataType_2"] && [[temp.dataArray objectAtIndex:0] isEqualToString:NSLocalizedString(@"SP_DETAIL_12", @"メモ")]) {
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"SP_DETAIL_12", @"ラベル") message:@"" preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            
            self.editMemo = self.appData.detailSpliceData.memo;
            textField.delegate = self;
            textField.text = self.editMemo;
            textField.keyboardType = UIKeyboardTypeASCIICapable;
        }];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            // メモ更新
            self.appData.detailSpliceData.memo = self.editMemo;
            [SCSpliceDataFlow saveMemo];
            
            [self.view endEditing:YES];
            [self makeData];
            [self.tableView reloadData];
        }]];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            [self.view endEditing:YES];
        }]];
        
        [self presentViewController:alert animated:YES completion:^{
        }];
    }
}

#pragma mark - UITextFieldDelegate

/**
 入力項目編集中
 
 @param textField <#textField description#>
 @param range     <#range description#>
 @param string    <#string description#>
 
 @return <#return value description#>
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSMutableString *val = [textField.text mutableCopy];
    [val replaceCharactersInRange:range withString:string];
    
    // TODO:禁則文字チェック(ASCII)
    NSCharacterSet *checkStr = [NSCharacterSet characterSetWithCharactersInString:val];
    NSMutableCharacterSet *isAlphaNumCharSet = [[NSMutableCharacterSet alloc] init];
    [isAlphaNumCharSet addCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZ"];
    [isAlphaNumCharSet addCharactersInString:@"abcdefghijklmnopqrstuvwxyz"];
    [isAlphaNumCharSet addCharactersInString:@"0123456789"];
    [isAlphaNumCharSet addCharactersInString:@"!\"#$%&'()*+,-./:;<=>?@[]^_{} "];
    if (![isAlphaNumCharSet isSupersetOfSet:checkStr]) {
        
        return NO;
    }
    
    // 入力文字数チェック
    if (kSC_MAXLEN_MEMO < val.length) {
        
        return NO;
    }
    
    return YES;
}

/**
 入力項目編集終了
 
 @param textField <#textField description#>
 */
- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    [self.view endEditing:YES];
    
    self.editMemo = textField.text;
}

- (NSString *)makeErrInfo:(NSString *)errinfo {
    
    NSString* msg;
    
    if ([errinfo isEqualToString:@"0"]) {
        return NSLocalizedString(@"SP_72M_ERRINFO_0", @"エラーなし");
    }
    
    if (errinfo.length) {
        
        NSString* errID = [[NSString alloc] initWithFormat:@"SP_72M_ERRINFO_%@", errinfo];
        msg = NSLocalizedString(errID, @"エラーメッセージ");
        
        if ([msg isEqualToString:errID]) {
            msg = NSLocalizedString(@"SP_72M_ERRINFO_OTHER", @"その他のエラー(%@)");
            return [NSString stringWithFormat:msg,errinfo];
        }
    }
    return msg;
}

- (NSString *)makeTemperature:(NSString *)temperature isDegF:(BOOL)isDegF {
    NSString * resultStr;
    // 華氏ー＞摂氏変換判定
    if (isDegF) {
        
        // 華氏
        resultStr = [NSString stringWithFormat:@"%@ %@",
                              temperature,
                              NSLocalizedString(@"UNIT_07", @"F")];
    } else {
        
        // 摂氏
        resultStr = [NSString stringWithFormat:@"%d %@",
                              (int)round(([temperature doubleValue] - 32) / 1.8f),
                              NSLocalizedString(@"UNIT_08", @"C")];
    }
    
    return resultStr;
}

-(NSString *)judgementIrregularWithIrregular_X:(NSString *)irregular_X
                                andIrregular_Y:(NSString *)irregular_Y{
    
    NSInteger irregularX = [irregular_X integerValue];
    NSInteger irregularY = [irregular_Y integerValue];
    
    
    if (![irregular_X isEqualToString:@"0xFFFF"] &&
        ![irregular_Y isEqualToString:@"0xFFFF"] &&
        irregularX != 65535 &&
        irregularY != 65535 &&
        ![irregular_X isEqualToString:@"65535"] &&
        ![irregular_Y isEqualToString:@"65535"]) {
        return [NSString stringWithFormat:@"%03ld", irregularX > irregularY ? irregularX : irregularY];
    }
    
    if (([irregular_X isEqualToString:@"0xFFFF"] || irregularX == 65535 || [irregular_X isEqualToString:@"65535"]) &&
        (![irregular_Y isEqualToString:@"0xFFFF"] && irregularY != 65535 &&  ![irregular_Y isEqualToString:@"65535"])) {
        return [NSString stringWithFormat:@"%03ld", irregularY];
    }
    
    if (([irregular_Y isEqualToString:@"0xFFFF"] || irregularY == 65535 || [irregular_Y isEqualToString:@"65535"]) &&
        (![irregular_X isEqualToString:@"0xFFFF"] && irregularX != 65535 && ![irregular_X isEqualToString:@"65535"])) {
        return [NSString stringWithFormat:@"%03ld", irregularX];
    }
    
    return @"--";
}

/**
 *  getGeoTage60
 *  緯度・経度表示変換（１０進法度単位 >> 度分秒）
 */
- (NSString *)getGeoTage60:(NSString *)latlon {
    
    NSString *ret = @"";
    
    if (latlon.length && ![latlon isEqualToString:@"--"]) {
        
        double val = [latlon floatValue];
        double valAbs = fabs(val);
        NSInteger deg = floor(valAbs);
        NSInteger min = floor((valAbs - deg) * 60);
        NSInteger sec = floor((((valAbs - deg) * 60 - min) * 60));
        
        NSString* msg = NSLocalizedString(@"UNIT_11", @"緯度・経度（度分秒フォーマット）");
        if (0.0f < val) {
            
            ret = [NSString stringWithFormat:msg,
                   [NSString stringWithFormat:@"%4zd", deg],
                   [NSString stringWithFormat:@"%.2zd", min],
                   [NSString stringWithFormat:@"%.2zd", sec]];
        } else {
            
            ret = [NSString stringWithFormat:msg,
                   [NSString stringWithFormat:@"%4zd", (-1 * deg)],
                   [NSString stringWithFormat:@"%.2zd", min],
                   [NSString stringWithFormat:@"%.2zd", sec]];
        }
    } else {
        ret = @"--";
    }
    
    return ret;
}

@end
