//
//  SCSpliceDataSelectTimeViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataSelectTimeViewController.h"
#import "SCSpliceDataSelectTimeTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCSpliceDataFlow.h"
#import "SCSpliceData.h"

@interface SCSpliceDataSelectTimeViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) NSArray* listData;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UIView *vwHeading;
@property (weak, nonatomic) IBOutlet UILabel *lblTime;
@property (weak, nonatomic) IBOutlet UILabel *lblDB;
@property (weak, nonatomic) IBOutlet UILabel *lblGPS;
@property (weak, nonatomic) IBOutlet UILabel *lblPhoto;

- (IBAction)actionBack:(UIBarButtonItem *)sender;
- (IBAction)actionMenu:(UIBarButtonItem *)sender;

@end

@implementation SCSpliceDataSelectTimeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.vwHeading.backgroundColor = [SCSystemData colorWithRGB:0xDB green:0xDB blue:0xDB alpha:1.0f];
    self.lblTime.textColor = [UIColor blackColor];
    self.lblDB.textColor = [UIColor blackColor];
    self.lblGPS.textColor = [UIColor blackColor];
    self.lblPhoto.textColor = [UIColor blackColor];

    // 多言語対応
    self.title = self.appData.manSpliceData.selectYYYYMMDD;
    self.lblTime.text = NSLocalizedString(@"RES_20010", @"Time");
    self.lblDB.text = [SCSystemData isModelType72M:self.appData.selectedSerialNo] ? NSLocalizedString(@"UNIT_01_MAX", @"dB(Max)") : NSLocalizedString(@"UNIT_01", @"dB");
    self.lblGPS.text = NSLocalizedString(@"RES_20011", @"GPS");
    self.lblPhoto.text = NSLocalizedString(@"RES_20012", @"Photo");
    
    // 画面表示データの更新
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.listData = [SCSpliceDataFlow selectTimeSpliceDataList];
    [self refreshOnlineSerialNo];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {
    
    DDLogDebug(@"");
    
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 アクションメニューボタン

 @param sender <#sender description#>
 */
- (IBAction)actionMenu:(UIBarButtonItem *)sender {

    DDLogDebug(@"");
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param section   <#section description#>
 
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listData.count;
}

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SCSpliceDataSelectTimeTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    SCSpliceData* item = [self.listData objectAtIndex:indexPath.row];
    cell.lblTime.text = item.datetime;
    
    cell.lblDB.text = [SCSystemData stringFromDoubleString:item.estimated_loss decimalLength:2];
    
    if ([SCSystemData isModelType72M:item.serialno]) {
        cell.lblDB.text = [item.estimate_display_flag isEqualToString:@"1"] ? [SCSystemData stringFromDoubleString:item.estimated_loss decimalLength:2] : @"--";
    } else if ([SCSystemData isModelTypeT502:item.serialno]) {
        
        [cell getColorEstimatedLoss:item.estimated_loss estLossLimit:item.est_loss_limit];
        
        if ([item.estimation_mode isEqualToString:@"High(HCA)"]) {
            cell.lblDB.text = [SCSystemData stringFromDoubleString:item.core_left decimalLength:2];
            [cell getColorEstimatedLoss:item.core_left estLossLimit:item.est_loss_limit];
        }
        
        if ([item.estimation_mode isEqualToString:@"Clad+HCA"]) {
            NSString* hcaLoss = [SCSystemData stringFromDoubleString:item.core_left decimalLength:2];
            if (![hcaLoss isEqualToString:@"---"]) {
                cell.lblDB.text = hcaLoss;
                [cell getColorEstimatedLoss:item.core_left estLossLimit:item.est_loss_limit];
            } else {
                cell.lblDB.text = [SCSystemData stringFromDoubleString:item.estimated_loss decimalLength:2];
                [cell getColorEstimatedLoss:item.estimated_loss estLossLimit:item.est_loss_limit];
            }
        }
    }
    
    if (![SCSystemData isModelType72M:item.serialno] && ![SCSystemData isModelTypeT502:item.serialno]) {
        [cell getColorEstimatedLoss:item.estimated_loss estLossLimit:item.est_loss_limit];
    }
    
    if ([@"0" isEqualToString:item.image_flg]) {
        
        cell.imgvwPhoto.hidden = YES;
    } else {
        
        cell.imgvwPhoto.hidden = NO;
    }
    if (0 == item.lat.length || 0 == item.lon.length) {
        
        cell.imgvwGPS.hidden = YES;
    } else {
        
        cell.imgvwGPS.hidden = NO;
    }
    
    return cell;
}

/**
 時刻選択
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    DDLogDebug(@"");
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    SCSpliceDataSelectTimeTableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
    self.appData.manSpliceData.selectHHMMDD = cell.lblTime.text;
    [SCSpliceDataFlow selectDetail];

    [self performSegueWithIdentifier:@"toReference" sender:self];
}


#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

@end
