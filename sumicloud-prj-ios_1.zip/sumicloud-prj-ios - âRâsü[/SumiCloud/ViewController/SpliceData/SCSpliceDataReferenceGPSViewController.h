//
//  SCSpliceDataReferenceGPSViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/13.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCSpliceDataReferenceGPSViewController : SCBaseViewController

// 画面表示
- (void)show;

// 画面非表示
- (void)hide;

@end
