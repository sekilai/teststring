//
//  SCSpliceDataViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseLeftMenuViewController.h"

@interface SCSpliceDataViewController : SCBaseLeftMenuViewController

@end
