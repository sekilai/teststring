//
//  SCSpliceDataViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataViewController.h"
#import "SCSpliceDataInformationTableViewCell.h"
#import "SCFirmwareUpdateRootControllerViewController.h"
#import "SCLogUtil.h"
#import "SCSpliceDataDao.h"

#import "SCSystemData.h"
#import "SCSpliceDataFlow.h"
#import "SCFirmwareUpdateFlow.h"
#import "SCReportFlow.h"
#import <CoreLocation/CoreLocation.h>
#import "SCPreventiveSettingViewController.h"
#import "SCConnectSpliceDao.h"
#import "SCMainUnitLockFlow.h"
#import "SCLeftMenuViewController.h"
#import "SCAutoDiagnosisFlow.h"
#import "SCWebService.h"
#import "DbAccessControllDao.h"



@interface SCSpliceDataViewController () <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource>

@property (nonatomic) NSMutableArray* aryInformation;
@property (nonatomic) NSArray* listSelectableYearMonth;

@property (nonatomic) SCSpliceDataFlow* flow;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwOnlineState;
@property (weak, nonatomic) IBOutlet UILabel *lblOnlineState;

@property (weak, nonatomic) IBOutlet UIButton *btnYYYYMM;
@property (weak, nonatomic) IBOutlet UITextField *txtYYYYMM;
@property (weak, nonatomic) IBOutlet UITextField *txtYYYYMMdd;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwDropdown;

@property (weak, nonatomic) IBOutlet UILabel *lblAveregeTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblAverege;
@property (weak, nonatomic) IBOutlet UILabel *lblAveregeUnit;

@property (weak, nonatomic) IBOutlet UILabel *lblTotalTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblTotal;
@property (weak, nonatomic) IBOutlet UILabel *lblTotalUnit;

@property (weak, nonatomic) IBOutlet UIButton *btnGetSpliceData;

@property (weak, nonatomic) IBOutlet UIView *vwInformation;
@property (weak, nonatomic) IBOutlet UILabel *lblInformation;
@property (weak, nonatomic) IBOutlet UILabel *lblInformationMessage;
@property (weak, nonatomic) IBOutlet UITableView *tblvwInformation;

@property (weak, nonatomic) IBOutlet UIButton *btnSpliceDataReference;
@property (weak, nonatomic) IBOutlet UILabel *lblSpliceDataReference;
@property (weak, nonatomic) IBOutlet UIButton *btnTodayReport;
@property (weak, nonatomic) IBOutlet UILabel *lblTodayReport;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwTodayReport;
@property (weak, nonatomic) IBOutlet UIButton *btnAntiThefLock;
@property (weak, nonatomic) IBOutlet UILabel *lblAntiThefLock;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwSecurityLock;
@property (strong, nonatomic) UIButton *uploadBtn;

@property (weak, nonatomic) IBOutlet UIView *vwSplit1;
@property (weak, nonatomic) IBOutlet UIView *vwSplit2;
@property (assign, nonatomic) BOOL updatePreventiveStatusAndFWVersion;
@property (nonatomic) SCBusinessFlowResult updateFlow;
@property (nonatomic) NSError* lockUnlockError;

- (IBAction)btnWiFiTouchUpInside:(UIButton *)sender;
- (IBAction)btnYYYYMMTouchUpInside:(UIButton *)sender;
- (IBAction)btnGetSpliceDataTouchUpInside:(UIButton *)sender;
- (IBAction)btnSpliceDataListTouchUpInside:(UIButton *)sender;
- (IBAction)btnTodayReportTouchUpInside:(UIButton *)sender;
- (IBAction)btnSecurityLockTouchUpInside:(UIButton *)sender;

@end

typedef NS_ENUM(NSInteger, PickerButtonTag) {
    TagYYYYMM = 1000,
    TagYYYYMMdd
};

@implementation SCSpliceDataViewController

static NSString* const kSD_Title = @"Title";            // お知らせタイトル
static NSString* const kSD_SegueId = @"SegueId";        // 画面遷移ID
static NSString* const kSD_Infomation = @"Information"; // お知らせイメージ
static NSString* const kSD_StatusLevel = @"StatusLevel"; // good caution warning
static NSString* const kSD_Checkdate = @"Checkdate";

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    [self.btnGetSpliceData setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.btnGetSpliceData setBackgroundImage:[UIImage imageNamed:@"btn_bg_normal"] forState:UIControlStateNormal];
    [self.btnGetSpliceData setBackgroundImage:[UIImage imageNamed:@"btn_bg_press"] forState:UIControlStateHighlighted];
    self.vwInformation.backgroundColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    self.lblInformation.textColor = [UIColor whiteColor];
    self.lblSpliceDataReference.textColor = [SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f];
    self.lblTodayReport.textColor = [SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f];
    self.lblAntiThefLock.textColor = [SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f];
    
    UIImage* image= [UIImage imageNamed:@"ic_UploadDownload.png"];
    CGRect frame= CGRectMake(0, 0, 27, 18);
    self.uploadBtn = [[UIButton alloc] initWithFrame:frame];
    [self.uploadBtn addTarget: self action:@selector(uploadData) forControlEvents:UIControlEventTouchUpInside];
    [self.uploadBtn setBackgroundImage:image forState:UIControlStateNormal];
    UIBarButtonItem* rightBarButtonItem= [[UIBarButtonItem alloc] initWithCustomView:self.uploadBtn];
    [self.navigationItem setRightBarButtonItem:rightBarButtonItem];
  
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_TOP", @"TOP");
    [self.btnGetSpliceData setTitle:NSLocalizedString(@"BTN_GET_SPLICEDATA", @"接続データを取得する") forState:UIControlStateNormal];
    self.lblInformation.text = NSLocalizedString(@"RES_20007", @"Information");
    self.lblInformationMessage.text = NSLocalizedString(@"MSG_10006", @"お知らせはありません");
    self.lblAveregeTitle.text = NSLocalizedString(@"RES_20005", @"Average");
    self.lblAveregeUnit.text = NSLocalizedString(@"UNIT_01", @"dB");
    self.lblTotalTitle.text = NSLocalizedString(@"RES_20006", @"Total");
    self.lblTotalUnit.text = NSLocalizedString(@"UNIT_02", @"本");
    self.lblSpliceDataReference.text = NSLocalizedString(@"BTN_SPLICEDATA", @"接続データ");
    self.lblTodayReport.text = NSLocalizedString(@"BTN_TODAY_REPORT", @"今日のレポート");
    self.lblAntiThefLock.text = NSLocalizedString(@"BTN_ANTI_THEFT_LOCK", @"盗難防止ロック");

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(counterSpliceData:) name:kSC_SDM_SpliceDataCount object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(delayMethod) name:@"runGetSpliceFlow" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshLockState) name:@"refreshLockState" object:nil];
    // 画面表示データの更新
    self.tblvwInformation.estimatedRowHeight = 44.0f;
    self.tblvwInformation.rowHeight = UITableViewAutomaticDimension;
    self.isSelectedSplicer = YES;
    self.txtYYYYMM.text = [SCSystemData stringFromDate:[NSDate date] format:@"yyyy/MM"];
    self.txtYYYYMMdd.text = [SCSystemData stringFromDate:[NSDate date] format:@"yyyy/MM/dd"];
    [self.btnYYYYMM setTitle:self.txtYYYYMM.text forState:UIControlStateNormal];
    [self refreshOnlineSerialNo];
    
    // 余白セルを表示しない
    self.tblvwInformation.tableFooterView = [[UIView alloc] init];
    
    // 年月選択のドロップダウンイメージを回転する(右向きの画像を回転して使用)
    self.imgvwDropdown.transform = CGAffineTransformMakeRotation((90 * M_PI) / 180.0f);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSC_SDM_SpliceDataCount object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"runGetSpliceFlow" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"refreshLockState" object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];

    [self refreshViewController];
}


#pragma mark - Button Action

/**
 Wi-Fi切り替え（設定アプリ起動）

 @param sender <#sender description#>
 */
- (IBAction)btnWiFiTouchUpInside:(UIButton *)sender {

    DDLogInfo(@"Wi-Fi切り替え（設定アプリ起動）");
    
    // Wi-Fi切り替え確認
    [self connectInternetAlert];
}

/**
 年月選択

 @param sender <#sender description#>
 */
- (IBAction)btnYYYYMMTouchUpInside:(UIButton *)sender {

    [self.txtYYYYMM becomeFirstResponder];
}

/**
 接続データを取得するボタン

 @param sender <#sender description#>
 */
- (IBAction)btnGetSpliceDataTouchUpInside:(UIButton *)sender {
    
    NSDictionary *preventiveStatusDic = [[[SCSpliceDataDao alloc] init] getPreventiveSplicerInfoStatus:self.appData.selectedSerialNo];
    NSInteger checkStatus = [[preventiveStatusDic objectForKey:@"status"] integerValue];
    NSDictionary *getSetting = [[[SCSpliceDataDao alloc] init] getRotatesettingInfo:self.appData.selectedSerialNo];
    if (([SCSystemData isModelType72C:self.appData.selectedSerialNo] ||
         [SCSystemData isModelTypeT502:self.appData.selectedSerialNo])) {
//        if ([preventiveStatusDic count] == 0 || [getSetting count] == 0) {
//            [self updatePreventiveStatusAndFWVersionFlow];
//            return;
//        }
        [self updatePreventiveStatusAndFWVersionFlow];
        return;
    }
    
    
    if ([preventiveStatusDic count]) {
        if (checkStatus == 1 && [getSetting count] == 0){
            [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"SettedPreventive"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            SCPreventiveSettingViewController * settingVC = [[UIStoryboard storyboardWithName:@"Settings" bundle:nil] instantiateViewControllerWithIdentifier:@"PreventiveSetting"];
            settingVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
            settingVC.pushRunNoti = true;
            [self.navigationController pushViewController:settingVC animated:true];
            return;
        }
    }


    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }

    // Wi-Fi切り替え確認
    if (![self isSplicerConnect:self.appData.selectedSerialNo]) {
        
        [self connectInternetAlert];
        
        return;
    }
    
    // 接続データ取得確認
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_11000", @"接続データを取得しますか？") preferredStyle:UIAlertControllerStyleAlert];
              
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OPTION", @"オプション") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self.txtYYYYMMdd becomeFirstResponder];
    }]];

    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_GETNEW", @"新データ取得") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self runGetSpliceFlow];
    }]];
             
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self refreshViewController];
    }]];
              
    [self presentViewController:alert animated:YES completion:^{
    }];
}


-(void)updatePreventiveStatusAndFWVersionFlow{
    
    if (![self isSplicerConnect:self.appData.selectedSerialNo]) {
        
        [self showAlert:NSLocalizedString(@"MSG_13079", @"融着機の情報取得が必要です。融着機を接続してください.")];
        
        return;
    }
    
    [self showProgress:NSLocalizedString(@"MSG_10011", @"接続データを取得しています") cancelHandler:^{

    }];
    
    [self checkUpdateDataFlowWithComplete:^(bool status) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideProgress];
            if (status) {
                NSDictionary *getSetting = [[[SCSpliceDataDao alloc] init] getRotatesettingInfo:self.appData.selectedSerialNo];
                if ([getSetting count] == 0) {
                    [[NSUserDefaults standardUserDefaults] setBool:false forKey:@"SettedPreventive"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    SCPreventiveSettingViewController * settingVC = [[UIStoryboard storyboardWithName:@"Settings" bundle:nil] instantiateViewControllerWithIdentifier:@"PreventiveSetting"];
                    settingVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
                    settingVC.pushRunNoti = true;
                    [self.navigationController pushViewController:settingVC animated:true];
                } else {
                    if (self.updateFlow == kBF_MU_LOCK || self.updateFlow == kBF_MU_UNLOCK){
                        [self messageBFResult:self.updateFlow error:self.lockUnlockError actionHandler:nil];
                        return;
                    }
                    
                    if ([self isPassedExpirationDateMsg]) {
                        return;
                    }

                    // Wi-Fi切り替え確認
                    if (![self isSplicerConnect:self.appData.selectedSerialNo]) {
                        
                        [self connectInternetAlert];
                        
                        return;
                    }
                    
                    // 接続データ取得確認
                    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_11000", @"接続データを取得しますか？") preferredStyle:UIAlertControllerStyleAlert];
                              
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OPTION", @"オプション") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        [self.txtYYYYMMdd becomeFirstResponder];
                    }]];

                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_GETNEW", @"新データ取得") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        [self runGetSpliceFlow];
                    }]];
                             
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                        [self refreshViewController];
                    }]];
                              
                    [self presentViewController:alert animated:YES completion:^{
                    }];
                }
            } else {
//                [self showAlert:NSLocalizedString(@"MSG_13078", @"この融着機は予防保全の対象ではありません.")];
                // アプリ使用期限の確認
                
                if (self.updateFlow == kBF_MU_LOCK || self.updateFlow == kBF_MU_UNLOCK){
                    [self messageBFResult:self.updateFlow error:self.lockUnlockError actionHandler:nil];
                    return;
                }
                
                if ([self isPassedExpirationDateMsg]) {
                    return;
                }

                // Wi-Fi切り替え確認
                if (![self isSplicerConnect:self.appData.selectedSerialNo]) {
                    
                    [self connectInternetAlert];
                    
                    return;
                }
                
                // 接続データ取得確認
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_11000", @"接続データを取得しますか？") preferredStyle:UIAlertControllerStyleAlert];
                          
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OPTION", @"オプション") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self.txtYYYYMMdd becomeFirstResponder];
                }]];

                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_GETNEW", @"新データ取得") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self runGetSpliceFlow];
                }]];
                         
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                }]];
                          
                [self presentViewController:alert animated:YES completion:^{
                }];
            }
        });
    }];
}

-(void)checkUpdateDataFlowWithComplete:(void (^)(bool status))complete{
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        SCFlashAirService* serviceFlashAir = [[SCFlashAirService alloc] init];
        NSError* err = nil;
        NSDictionary* listCommandResult = nil;
        NSString *serialNo = self.appData.selectedSerialNo;
        serviceFlashAir.serialNo = serialNo;
        self.updateFlow = kBF_OK;
        self.lockUnlockError = nil;
        // ファイル削除
        [serviceFlashAir removeFile:kSC_RET_TXT];
        
#if defined(DEBUG) || defined(DEMO) // DEBUG版、DEBUG_DEMO版、RELEASE_DEMO版
//        // 本体ロック実施判定
//        if ([SCMainUnitLockFlow isMainUnitLock:serialNo]) {
//            DDLogInfo(@"本体ロック");
//            SCMainUnitLockFlow* flowLockUnlock = [[SCMainUnitLockFlow alloc] init];
//            err = [flowLockUnlock flowMainUnitLock:serviceFlashAir serialNo:serialNo];
//            self.updateFlow = flowLockUnlock.resultFlow;
//            self.lockUnlockError = err;
//            complete(false);
//            return;
//        }
//               
//               // 本体ロック解除実施判定
//        if ([SCMainUnitLockFlow isMainUnitUnlock:serialNo]) {
//            DDLogInfo(@"本体ロック解除");
//            SCMainUnitLockFlow* flowLockUnlock = [[SCMainUnitLockFlow alloc] init];
//            err = [flowLockUnlock flowMainUnitUnlock:serviceFlashAir serialNo:serialNo];
//            self.updateFlow = flowLockUnlock.resultFlow;
//            complete(false);
//            self.lockUnlockError = err;
//            return;
//        }
#endif
        // シリアル番号の融着接続機の状況を取得
        SCConnectSpliceDao* daoConnectSplice = [[SCConnectSpliceDao alloc] init];
        SCConnectSplice* connectSplice = [daoConnectSplice getSplicerState:self.appData.selectedSerialNo];
        
        // 6.ソフトバージョン情報取得
        NSArray* listVersionCmd = @[@"MM888"];
        if ([SCSystemData isModelType72C:serialNo] ||
            [SCSystemData isModelTypeZ2C:serialNo] ||
            [SCSystemData isModelType72M:serialNo] ||
            [SCSystemData isModelTypeT502:serialNo]) {

            listVersionCmd = @[@"MM888",@"MM881",@"MM882",@"MM883",@"MM884",@"MM886"];
            
            err = [serviceFlashAir getVersionMulti:listVersionCmd];
            [serviceFlashAir removeFile:kSC_RET_TXT];
            listCommandResult = [serviceFlashAir getVersionResult:listVersionCmd];
            connectSplice.current_version = listCommandResult[kSC_GETVERSION];
            [daoConnectSplice setSplicerState:connectSplice];
            NSNumber* currentVersion = [NSNumber numberWithFloat:[connectSplice.current_version floatValue]];
            NSNumber* supportVersion = [NSNumber numberWithFloat:1.14];
            if ([currentVersion compare:supportVersion] == kCFCompareLessThan && ![SCSystemData isModelTypeT502:serialNo]) {
                complete(false);
                return;
            }
        }
        
        SCPreventiveSplicerInfo* splicerInfo = [[[SCSpliceDataDao alloc] init] getPreventiveSplicerInfo:self.appData.selectedSerialNo];
        BOOL isCheckPreventive = [serviceFlashAir getPreventiveStatus];
        if (serviceFlashAir.resultService == kFASR_AD_OP08_COMMEND_FAIL) {
            isCheckPreventive = splicerInfo.status == 1 ? true : false;
        } else {
            SCPreventiveSplicerInfo *spliceInfo = [[SCPreventiveSplicerInfo alloc] init];
            spliceInfo.serialNo = self.appData.selectedSerialNo;
            spliceInfo.status = isCheckPreventive ? 1 : 0;
            [[[SCSpliceDataDao alloc] init] updatePreventiveSplicerInfoStatus:spliceInfo];
        }
        
        if (!isCheckPreventive) {
            complete(false);
            return;
        }
        
        complete(true);
    });
}
-(void)showAlert:(NSString *)alertString{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:alertString preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }]];
    [self showDetailViewController:alert sender:nil];
}
/**
 接続データボタン

 @param sender <#sender description#>
 */
- (IBAction)btnSpliceDataListTouchUpInside:(UIButton *)sender {

    DDLogInfo(@"接続データボタン");

    // 融着接続機選択確認
    if ([self isUnselectSplicerAlert]) {
        
        return;
    }
    
    [self performSegueWithIdentifier:@"toSelectDate" sender:self];
}

/**
 今日のレポートボタン

 @param sender <#sender description#>
 */
- (IBAction)btnTodayReportTouchUpInside:(UIButton *)sender {
    
    DDLogInfo(@"今日のレポートボタン");
    
    // 融着接続機選択確認
    if ([self isUnselectSplicerAlert]) {
        
        return;
    }
    
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"Report" bundle:nil];
    [self.navigationController pushViewController:[storyBoard instantiateInitialViewController] animated:true];
}

/**
 盗難防止ロックボタン

 @param sender <#sender description#>
 */
- (IBAction)btnSecurityLockTouchUpInside:(UIButton *)sender {

//    DDLogInfo(@"盗難防止ロックボタン");
//    // 融着接続機選択確認
//    if ([self isUnselectSplicerAlert]) {
//
//        return;
//    }
//
//    if (![SCSystemData isModelType72C:self.appData.selectedSerialNo] &&
//        ![SCSystemData isModelTypeZ2C:self.appData.selectedSerialNo] &&
//        ![SCSystemData isModelType72M:self.appData.selectedSerialNo] &&
//        ![SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
//        UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_13025", "この融着接続機は、ロック機能をサポートしてません。") preferredStyle:UIAlertControllerStyleAlert];
//        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
//        [self presentViewController:alert animated:YES completion:nil];
//
//    } else {
//        [self performSegueWithIdentifier:@"toSecurityLock" sender:self];
//    }
    
//    toSplicerList
    [self performSegueWithIdentifier:@"toSplicerList" sender:self];
}

- (void)uploadData{
    DDLogDebug(@"接続データ一括送信");
    
    // Wi-Fi切り替え確認
    if (![self isMobileConnect]) {
        
        [self connectSplicerAlert];
        
        return;
    }
    __block BOOL cancelFlag = false;
    [self showProgress:NSLocalizedString(@"adlg_connecting", @"接続中...") cancelHandler:^{
        cancelFlag = true;
    }];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSError* error = nil;
        
        NSArray* listSpliceData = [SCSpliceDataFlow unsentSpliceDataList];
        DDLogInfo(@"融着/自動診断データ送信（接続データ）:未送信件数<%@>", [NSNumber numberWithInteger:listSpliceData.count]);
        SCSpliceDataFlow* flow = [[SCSpliceDataFlow alloc] init];
        [flow runSentPreventingResultFlow];
        for (SCSpliceData* item in listSpliceData) {
            // 接続データ送信
            error = [flow uploadSpliceData:item];
            // 接続データ送信エラー判定
            if (error) {
                break;
            }
        }
        
        if (cancelFlag) {
            [self hideProgress];
            return;
        }
        
        NSArray* listAutoDiag = [SCAutoDiagnosisFlow unsentNoticeList];
        DDLogInfo(@"融着/自動診断データ送信（自動診断データ）:未送信件数<%@>", [NSNumber numberWithInteger:listAutoDiag.count]);
        SCAutoDiagnosisFlow* autoDiagFlow = [[SCAutoDiagnosisFlow alloc] init];
        for (SCAutoDiagnosisData* item in listAutoDiag) {
            error = [autoDiagFlow uploadAutoDiagnosisNotice:item];
            if (error) {
                break;
            }
        }
        
        if (cancelFlag) {
            [self hideProgress];
            return;
        }
        
        NSArray* listReportData = [SCReportFlow unsentReportList];
        DDLogInfo(@"レポート登録タスク:未送信件数<%@>", [NSNumber numberWithInteger:listReportData.count]);

        SCReportFlow* reportflow = [[SCReportFlow alloc] init];
        for (SCReportData* item in listReportData) {
            
            NSError* error = [reportflow uploadReport:item.serialno reportDate:item.report_date];
            if (error) {
                
                // レポート送信エラー判定
                DDLogError(@"レポート登録タスクエラー:<<%@>>", error.description);
                
                id errorResponse = error.userInfo[kSC_BF_ErrorResponse];
                if (!errorResponse) {
                    
                }
            }
        }
        
        if (cancelFlag) {
            [self hideProgress];
            return;
        }
        
        SCWebService * webService = [[SCWebService alloc] init];
        // GPSデータ通知
        [webService sendLocationInfo];
        
        if (cancelFlag) {
            [self hideProgress];
            return;
        }
        
        // 貸出情報取得
        NSString * account = [[NSUserDefaults standardUserDefaults] stringForKey:PRE_ACCOUNT];
        DbAccessControllDao * dbController = [[DbAccessControllDao alloc] init];
        NSString * password = [dbController getAccountPassword:account];
        [webService getUnitInfoWithAccount:account password:password];
        
        [self hideProgress];
        
        if (error) {
            
            DDLogError(@"融着/自動診断データ送信エラー:<<%@>>", error.description);
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10022", @"エラーメッセージ") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            
            [self presentViewController:alert animated:YES completion:^{
            }];
        }
        
        [self checkUploadNotifation];
    });
}



#pragma mark - Segue

/**
 画面遷移
 
 @param segue  <#segue description#>
 @param sender <#sender description#>
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    DDLogDebug(@"%@", segue.identifier);
    
    if ([@"toLeftMenu" isEqualToString:segue.identifier]) {
        
        segue.destinationViewController.modalPresentationStyle = UIModalPresentationCustom;
        segue.destinationViewController.transitioningDelegate = self;
        SCLeftMenuViewController* leftVC = segue.destinationViewController;
        leftVC.preVC = self.parentViewController;
    } else if ([@"toSelectDate" isEqualToString:segue.identifier]) {
        
        self.appData.manSpliceData = [[SCSpliceDataManager alloc] init];
        self.appData.manSpliceData.selectYYYYMM = self.txtYYYYMM.text;
    } else if ([@"toFirmwareUpdate" isEqualToString:segue.identifier]) {
        
        SCFirmwareUpdateRootControllerViewController * vc = ((UINavigationController *)segue.destinationViewController).viewControllers[0];
        vc.fromFlag = @"1";
    } else if ([@"toFirmwareUpdate1" isEqualToString:segue.identifier]) {
        
        SCFirmwareUpdateRootControllerViewController * vc = ((UINavigationController *)segue.destinationViewController).viewControllers[0];
        vc.fromFlag = @"0";
    } else if ([@"toSelectDate" isEqualToString:segue.identifier]) {
        
        self.appData.manSpliceData = [[SCSpliceDataManager alloc] init];
        self.appData.manSpliceData.selectYYYYMM = self.txtYYYYMM.text;
    }
}


#pragma mark - UITextFieldDelegate

/**
 入力項目編集開始

 @param textField <#textField description#>

 @return <#return value description#>
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {

    // Cancelボタン
    UIBarButtonItem *btnEditCancel = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_CANCEL", @"キャンセル") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditCancelTouchUpInside:)];
    
    // フレキシブルスペース
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    
    // 設定ボタン
    UIBarButtonItem *btnEditOk = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_DONE", @"完了") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditOkTouchUpInside:)];
    // ツールバー
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    toolbar.barStyle = UIBarStyleDefault;
    [toolbar sizeToFit];
    [toolbar setItems:@[btnEditCancel, spacer, btnEditOk] animated:YES];
    textField.inputAccessoryView = toolbar;
    
    if(textField == self.txtYYYYMM){
        btnEditOk.tag = TagYYYYMM;
        self.listSelectableYearMonth = [SCSpliceDataFlow selectableYearMonth];
        UIPickerView *vwPicker = [[UIPickerView alloc] init];
        textField.inputView = vwPicker;
        vwPicker.delegate = self;
        vwPicker.dataSource = self;
        [vwPicker sizeToFit];
        
        // 選択項目位置初期化
        for (NSInteger posPicker=0; posPicker < self.listSelectableYearMonth.count; posPicker++) {
            
            if ([textField.text isEqualToString:self.listSelectableYearMonth[posPicker]]) {
                
                [vwPicker selectRow:posPicker inComponent:0 animated:NO];
                break;
            }
        }
        
    }else if(textField == self.txtYYYYMMdd){
        btnEditOk.tag = TagYYYYMMdd;
        UIDatePicker *vwPicker = [[UIDatePicker alloc] init];
        if (@available(iOS 13.4, *)){
            vwPicker.preferredDatePickerStyle = UIDatePickerStyleWheels;
        }
        vwPicker.datePickerMode = UIDatePickerModeDate;
        vwPicker.calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
        vwPicker.date = [NSDate date];
        
        NSDate *minDate = [SCSystemData dateFromString:@"20010101000000" format:@"yyyyMMddHHmmss"];
        NSDate *maxDate = [SCSystemData dateFromString:@"20991231000000" format:@"yyyyMMddHHmmss"];
        [vwPicker setMaximumDate:maxDate];
        [vwPicker setMinimumDate:minDate];

        textField.inputView = vwPicker;
        [vwPicker sizeToFit];
    }
    return YES;
}

/**
 入力項目編集終了

 @param textField <#textField description#>
 */
- (void)textFieldDidEndEditing:(UITextField *)textField {

    [self.view endEditing:YES];
}

/**
 入力項目のOK

 @param sender <#sender description#>
 */
- (void)btnEditOkTouchUpInside:(UIBarButtonItem *)sender {
    
    [self.view endEditing:YES];
    if(sender.tag == TagYYYYMM){
        UIPickerView* vwPicker = (UIPickerView *)self.txtYYYYMM.inputView;
        self.txtYYYYMM.text = [self.listSelectableYearMonth objectAtIndex:[vwPicker selectedRowInComponent:0]];
        [self.btnYYYYMM setTitle:self.txtYYYYMM.text forState:UIControlStateNormal];
        
        // 画面表示データの更新
        [self refreshSelectedSerialNo];
    }else{
        UIDatePicker* vwPicker = (UIDatePicker *)self.txtYYYYMMdd.inputView;
        
        
        NSString * selectDay = [SCSystemData stringFromDate:vwPicker.date format:@"yyMMdd"];
        selectDay = [selectDay stringByAppendingString:@"0000"];
        NSDate *selectDayDate = [SCSystemData dateFromString:selectDay format:@"yyMMddHHmm"];
        NSDateComponents *dateComponents = [[NSDateComponents alloc] init];
        [dateComponents setMinute:-1];
        selectDayDate = [[NSCalendar currentCalendar] dateByAddingComponents:dateComponents toDate:selectDayDate options:0];
        selectDay = [SCSystemData stringFromDate:selectDayDate format:@"yyMMddHHmm"];
        
        
        DDLogInfo(@"接続データを取得するボタン");
        
        self.flow = [[SCSpliceDataFlow alloc] init];
        
        [self showProgress:NSLocalizedString(@"MSG_10011", @"接続データを取得しています") cancelHandler:^{
            
            DDLogDebug(@"プログレスのキャンセル");
            
            [self.flow cancelFlow];
        }];
        
        // ビジネスフロー
        DDLogInfo(@"3.接続データ機能フロー:開始");
        [self.flow runFlow:self.appData.selectedSerialNo startDate:selectDay completion:^(NSError *error) {
            
            DDLogInfo(@"3.接続データ機能フロー:完了");
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                // 画面表示データの更新
                [self refreshViewController];
                
                [self hideProgress];
                
                // ビジネスフロー結果メッセージ表示
                [self messageBFResult:self.flow.resultFlow error:error actionHandler:nil];
                
                self.flow = nil;
            });
        }];
    }
}

/**
 入力項目のCancel
 
 @param sender <#sender description#>
 */
- (void)btnEditCancelTouchUpInside:(UIButton *)sender {
    
    [self.view endEditing:YES];
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param section   <#section description#>
 
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.aryInformation.count;
}

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
//    SCSpliceDataInformationTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
//
    NSDictionary* dic = [self.aryInformation objectAtIndex:indexPath.row];
//    cell.imgvwInfomation.image = [UIImage imageNamed:dic[kSD_Infomation]];
//    cell.lblTitle.text = NSLocalizedString(dic[kSD_Title], @"ラベル");
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"newCell"];

    UILabel * signLabel = [cell.contentView viewWithTag:100];
    UILabel * dateLabel = [cell.contentView viewWithTag:101];
    UILabel * infoLabel = [cell.contentView viewWithTag:102];
    
    if ([dic[kSD_SegueId] isEqualToString:@"toGuardInsurance"] || [dic[kSD_SegueId] isEqualToString:@"toOldGuardInsurance"]) {
        
        NSInteger statusLevel = [dic[kSD_StatusLevel] integerValue];
        NSString *checkDate = dic[kSD_Checkdate];
        if (statusLevel == 1) {
            signLabel.text = @"Caution";
            signLabel.backgroundColor = [UIColor colorWithRed:246/255.0 green:172/255.0 blue:0 alpha:1];
        } else if (statusLevel == 2) {
            signLabel.text = @"Warning";
            signLabel.backgroundColor = [UIColor redColor];
        } else if (statusLevel  == 0) {
            signLabel.text = @"Good";
            signLabel.backgroundColor = [UIColor colorWithRed:92/255.0 green:198/255.0 blue:102/255.0 alpha:1];
        }
        dateLabel.text = checkDate;
    } else {
        signLabel.text = @"Information";
        signLabel.backgroundColor = [UIColor blueColor];
        dateLabel.text = @"";
    }
    
    infoLabel.text = NSLocalizedString(dic[kSD_Title], @"");
    
    if ([dic[kSD_SegueId] isEqualToString:@"toPreventiveSetting"]) {
        infoLabel.text = dic[kSD_Title];
        NSString *checkDate = dic[kSD_Checkdate];
        dateLabel.text = checkDate;
    }
    
    return cell;
}

/**
 Information選択
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary* dic = [self.aryInformation objectAtIndex:indexPath.row];
    NSString* segueId = dic[kSD_SegueId];
    if (segueId.length) {

//        NSString* title = dic[kSD_Title];
        [self performSegueWithIdentifier:dic[kSD_SegueId] sender:self];
        
    } else {
        
        // "自動診断閾値判定"
        NSString* title = dic[kSD_Title];
        
        if ([title isEqualToString:@"MSG_10064"] ||
            [title isEqualToString:@"MSG_10066"] ||
            [title isEqualToString:@"MSG_10067"] ||
            [title isEqualToString:@"MSG_10068"]) {
            NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if ([[UIApplication sharedApplication] canOpenURL:url])
            {
                [[UIApplication sharedApplication] openURL:url];
            }
            return;
        }
        
        NSString* msg = @"";
        if ([title isEqualToString:@"MSG_10046"]) {
            
            // 放電回数異常
            msg = NSLocalizedString(@"MSG_10047", @"放電回数異常");
        } else if ([title isEqualToString:@"MSG_10048"]) {

            // 端面角度異常
            msg = NSLocalizedString(@"MSG_10049", @"端面角度異常");
        } else if ([title isEqualToString:@"MSG_10050"]) {

            // 調心回数異常
            msg = NSLocalizedString(@"MSG_10051", @"調心回数異常");
        }
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        }]];
        
        [self presentViewController:alert animated:YES completion:^{
        }];
    }
}


#pragma mark - UIPickerViewDelegate

/**
 選択表示
 
 @param pickerView <#pickerView description#>
 @param row        <#row description#>
 @param component  <#component description#>
 */
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    
    self.txtYYYYMM.text = self.listSelectableYearMonth[row];
}

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param row        <#row description#>
 @param component  <#component description#>

 @return <#return value description#>
 */
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    
    return self.listSelectableYearMonth[row];
}


#pragma mark - UIPickerViewDataSource

/**
 選択表示
 
 @param pickerView <#pickerView description#>
 
 @return <#return value description#>
 */
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
    return 1;
}

/**
 選択表示
 
 @param pickerView <#pickerView description#>
 @param component  <#component description#>
 
 @return <#return value description#>
 */
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    return self.listSelectableYearMonth.count;
}


#pragma mark - Private Method

-(void)showPreventiveSettingAlertView{
    
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"RES_30023", @"") message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self showPreventiveSettingView];
    }]];
       
    [self presentViewController:alert animated:YES completion:^{
        
    }];
    
}

-(void)showPreventiveSettingView{
    __weak SCSpliceDataViewController * _weakSelf = self;
    SCPreventiveSettingViewController * settingVC = [[SCPreventiveSettingViewController alloc] init];
//    settingVC.settingStatus = ^(NSString *status) {
//        if ([status isEqualToString:@"automatic"]) {
//            DDLogDebug(@"Selected cleaver blade rotation mode:[R]Rotation");
//            [[[SCSpliceDataDao alloc] init] registRotatesetingID:1 withSerialno:self.appData.selectedSerialNo];
//        } else if ([status isEqualToString:@"manual"]) {
//            DDLogDebug(@"Selected cleaver blade rotation mode:[O]Fixed");
//            [[[SCSpliceDataDao alloc] init] registRotatesetingID:2 withSerialno:self.appData.selectedSerialNo];
//        }
//
//        // 接続データ取得確認
//        UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_11000", @"接続データを取得しますか？") preferredStyle:UIAlertControllerStyleAlert];
//
//        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OPTION", @"オプション") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//                      [_weakSelf.txtYYYYMMdd becomeFirstResponder];
//        }]];
//
//        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_GETNEW", @"新データ取得") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//
//            [_weakSelf runGetSpliceFlow];
//           
//        }]];
//
//        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
//        }]];
//
//        [_weakSelf presentViewController:alert animated:YES completion:^{
//        }];
//    };
    settingVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
    [self.parentViewController presentViewController:settingVC animated:false completion:nil];
}

-(void)delayMethod{
    [self performSelector:@selector(btnGetSpliceDataTouchUpInside:) withObject:nil afterDelay:0.5];
}

-(void)runGetSpliceFlow {
    
    DDLogInfo(@"接続データを取得するボタン");
    
    self.flow = [[SCSpliceDataFlow alloc] init];
    [self showProgress:NSLocalizedString(@"MSG_10011", @"接続データを取得しています") cancelHandler:^{

        DDLogDebug(@"プログレスのキャンセル");
        
        [self.flow cancelFlow];
    }];
    
    // ビジネスフロー
    DDLogInfo(@"3.接続データ機能フロー:開始");
    [self.flow runFlow:self.appData.selectedSerialNo completion:^(NSError *error) {
        
        DDLogInfo(@"3.接続データ機能フロー:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideProgress];
            
            // 画面表示データの更新
            [self refreshViewController];
            
            // ビジネスフロー結果メッセージ表示
            [self messageBFResult:self.flow.resultFlow error:error actionHandler:nil];
            
            if (self.flow.resultFlow == kBF_LOCK) {
                [[NSUserDefaults standardUserDefaults] setValue:@"Locked" forKey:[NSString stringWithFormat:@"%@_lockState", self.appData.selectedSerialNo]];
                [[NSUserDefaults standardUserDefaults] synchronize];
            } else {
                [[NSUserDefaults standardUserDefaults] setValue:@"unLock" forKey:[NSString stringWithFormat:@"%@_lockState", self.appData.selectedSerialNo]];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }
            
            self.flow = nil;
        });
    }];
    
}

/**
 画面表示更新
 */
- (void)refreshViewController {

    // Averege / Total 表示
    self.lblAverege.text = [SCSpliceDataFlow getMonthAverege:self.txtYYYYMM.text];
    self.lblTotal.text = [SCSpliceDataFlow getMonthTotal:self.txtYYYYMM.text];
    
    // お知らせ表示更新
    self.aryInformation = [NSMutableArray arrayWithCapacity:0];
    
    SCPreventiveSplicerInfo* preventiveInfo = [[[SCSpliceDataDao alloc] init] getPreventiveSplicerInfo:self.appData.selectedSerialNo];
    if (preventiveInfo.status) {
        NSDictionary *statusInfo = [[[SCSpliceDataDao alloc] init] getPreventiveTotalResult:self.appData.selectedSerialNo];
        NSInteger statusLevel = 0;
        NSString* checkdate = [statusInfo objectForKey:@"checkdate"];

        if (statusInfo.count) {
            statusLevel = [statusInfo[@"status"] integerValue];
            [self.aryInformation addObject:@{
                kSD_Title : @"RES_30001",
                kSD_SegueId : @"toGuardInsurance",
                kSD_Infomation : @"icon_info",
                kSD_StatusLevel : [statusInfo objectForKey:@"status"],
                kSD_Checkdate : [checkdate substringToIndex:checkdate.length-3]
            }];
        }
    } else {
        NSDictionary *statusInfo = [[[SCSpliceDataDao alloc] init] getPreventiveTotalResult:self.appData.selectedSerialNo];
        NSString* checkdate = [statusInfo objectForKey:@"checkdate"];
        if (statusInfo.count && ![SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
            [self.aryInformation addObject:@{
                kSD_Title : @"RES_30000",
                kSD_SegueId : @"toOldGuardInsurance",
                kSD_Infomation : @"icon_info",
                kSD_StatusLevel : [statusInfo objectForKey:@"status"],
                kSD_Checkdate : [checkdate substringToIndex:checkdate.length-3]
            }];
        }
    }
    
    if (@available(iOS 14.0, *)) {
        CLLocationManager* manager = [[CLLocationManager alloc] init];
        CLAccuracyAuthorization new_status = manager.accuracyAuthorization;
        CLAuthorizationStatus old_status = [CLLocationManager authorizationStatus];
        if (new_status == CLAccuracyAuthorizationFullAccuracy) {
            if (old_status != kCLAuthorizationStatusAuthorizedAlways) {
                [self.aryInformation addObject:@{
                                                kSD_Title : @"MSG_10066",
                                                kSD_SegueId : @"",
                                                kSD_Infomation : @"icon_info"
                                                }];
            }
        } else {
            if (old_status != kCLAuthorizationStatusAuthorizedAlways) {
                [self.aryInformation addObject:@{
                                                kSD_Title : @"MSG_10067",
                                                kSD_SegueId : @"",
                                                kSD_Infomation : @"icon_info"
                                                }];
            } else {
                [self.aryInformation addObject:@{
                                                kSD_Title : @"MSG_10068",
                                                kSD_SegueId : @"",
                                                kSD_Infomation : @"icon_info"
                                                }];
            }
        }
    } else {
        CLAuthorizationStatus status = [CLLocationManager authorizationStatus];
        if (status != kCLAuthorizationStatusAuthorizedAlways) {
            [self.aryInformation addObject:@{
                                            kSD_Title : @"MSG_10064",
                                            kSD_SegueId : @"",
                                            kSD_Infomation : @"icon_info"
                                            }];
        }
    }
    
//#if defined(DEBUG) || defined(DEMO) // DEBUG版、DEBUG_DEMO版、RELEASE_DEMO版
    // ファームウェアの最新バージョン有無判定
    BOOL isFirmwareNewVersion = [SCFirmwareUpdateFlow isFirmwareNewVersion:self.lblSerialNo.text];
    if (isFirmwareNewVersion) {
        
        // ファームウェア更新実施可否判定
        BOOL isFirmwareUpdate = [SCFirmwareUpdateFlow isFirmwareUpdate:self.lblSerialNo.text];
        if (isFirmwareUpdate) {
            
            [self.aryInformation addObject:@{
                                             kSD_Title : @"MSG_10008",
                                             kSD_SegueId : @"toFirmwareUpdate",
                                             kSD_Infomation : @"icon_caution"
                                             }];
        } else {
            
            [self.aryInformation addObject:@{
                                             kSD_Title : @"MSG_10007",
                                             kSD_SegueId : @"toFirmwareUpdate1",
                                             kSD_Infomation : @"icon_caution"
                                             }];
        }
    }
    
    NSDictionary *preventiveStatusDic = [[[SCSpliceDataDao alloc] init] getPreventiveSplicerInfoStatus:self.appData.selectedSerialNo];
    NSInteger checkStatus = 0;
    if ([preventiveStatusDic count]) {
        checkStatus = [[preventiveStatusDic objectForKey:@"status"] integerValue];
    }
    
    NSDictionary *rotateSettingDic = [[[SCSpliceDataDao alloc] init] getRotatesettingInfo:self.appData.selectedSerialNo];
    if ([rotateSettingDic count] && [[rotateSettingDic objectForKey:@"type"] integerValue] == 1 && checkStatus == 1) {
        NSMutableString* settingStr = [[NSMutableString alloc] initWithCapacity:0];
        NSString* typeStr = [[rotateSettingDic objectForKey:@"type"] integerValue] == 1 ? @"FC-8R":@"Other";
        NSString* rotateSettingStr;
        if ([[rotateSettingDic objectForKey:@"rotatesetting"] integerValue] == 1) {
            rotateSettingStr = @"Auto rotation";
        } else if ([[rotateSettingDic objectForKey:@"rotatesetting"] integerValue] == 2) {
            rotateSettingStr = @"Fixed";
        } else if ([[rotateSettingDic objectForKey:@"rotatesetting"] integerValue] == 0){
            rotateSettingStr = @"Other";
        }
        [settingStr appendFormat:@"Cleaver Setting:%@(%@)",typeStr,rotateSettingStr];
        [self.aryInformation addObject:@{
            kSD_Title : settingStr,
            kSD_SegueId : @"toPreventiveSetting",
            kSD_Infomation : @"icon_info",
        }];
    } else if ([rotateSettingDic count] == 0 && checkStatus == 1) {
        NSMutableString* settingStr = [[NSMutableString alloc] initWithCapacity:0];
        [settingStr appendFormat:@"Cleaver Setting:No settings"];
        [self.aryInformation addObject:@{
            kSD_Title : settingStr,
            kSD_SegueId : @"toPreventiveSetting",
            kSD_Infomation : @"icon_info",
        }];
    }
    
    if (self.aryInformation.count) {
        
        self.lblInformationMessage.hidden = YES;
        self.tblvwInformation.hidden = NO;
    } else {
        
        self.lblInformationMessage.hidden = NO;
        self.tblvwInformation.hidden = YES;
    }
    
    [self.tblvwInformation reloadData];
    [self refreshLockState];
    [self checkUploadNotifation];
}


#pragma mark - NotificationCenter

/**
 接続データ取得進捗

 @param notification <#notification description#>
 */
- (void)counterSpliceData:(NSNotification *)notification {

    NSDictionary* dicCount = notification.object;
    NSInteger maxCount = [dicCount[kSC_SDM_SpliceDataMaxCount] integerValue];
    NSInteger currentCount = [dicCount[kSC_SDM_SpliceDataCurrentCount] integerValue];
    
    [self updateProgressCounter:currentCount maxCount:maxCount];
}


#pragma mark - Override Method

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    // シリアル番号
    self.lblSerialNo.text = self.appData.selectedSerialNo;

    // 融着接続機の状態
    switch (self.appData.spliceStete) {
        case kSCS_OnlineUnlock:
            // オンライン ロックなし
            self.imgvwConnection.image = [UIImage imageNamed:@"image_top_connection-on"];
            
            self.imgvwOnlineState.image = [UIImage imageNamed:@"icon_online"];
            self.lblOnlineState.text = NSLocalizedString(@"ONLINE", @"オンライン");
            break;
        case kSCS_Onlinelock:
            // オンライン ロックあり
            self.imgvwConnection.image = [UIImage imageNamed:@"image_top_connection-on_keyon"];
            
            self.imgvwOnlineState.image = [UIImage imageNamed:@"icon_online"];
            self.lblOnlineState.text = NSLocalizedString(@"ONLINE", @"オンライン");
            break;
        case kSCS_Offlinelock:
            // オフライン ロックあり
            self.imgvwConnection.image = [UIImage imageNamed:@"image_top_connection-off_keyon"];
            
            self.imgvwOnlineState.image = [UIImage imageNamed:@"icon_offline"];
            self.lblOnlineState.text = NSLocalizedString(@"OFFLINE", @"オフライン");
            break;
        default:
            // オフライン ロックなし
            self.imgvwConnection.image = [UIImage imageNamed:@"image_top_connection-off"];
            
            self.imgvwOnlineState.image = [UIImage imageNamed:@"icon_offline"];
            self.lblOnlineState.text = NSLocalizedString(@"OFFLINE", @"オフライン");
            break;
    }

    // 画面表示更新
    [self refreshViewController];
}

-(void)refreshLockState{
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString* state = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"%@_lockState", self.appData.selectedSerialNo]];
        if ([self.appData.selectedSerialNo isEqualToString:@"---"]) {return;}
        if (self.appData.spliceStete == kSCS_OnlineUnlock || self.appData.spliceStete == kSCS_Onlinelock) {
            if ([state isEqualToString:@"Locked"]) {
                self.imgvwConnection.image = [UIImage imageNamed:@"image_top_connection-on_keyon"];
            } else {
                self.imgvwConnection.image = [UIImage imageNamed:@"image_top_connection-on"];
            }
        } else {
            if ([state isEqualToString:@"Locked"]) {
                self.imgvwConnection.image = [UIImage imageNamed:@"image_top_connection-off_keyon"];
            } else {
                self.imgvwConnection.image = [UIImage imageNamed:@"image_top_connection-off"];
            }
        }
    });
}

-(void)checkUploadNotifation{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSArray * entitys = [[[DbAccessControllDao alloc] init] getGpsDataList];
        
        NSInteger count = [SCSpliceDataFlow unsentSpliceDataCount] + [[SCAutoDiagnosisFlow unsentNoticeList] count] + [SCSpliceDataFlow unsentPreventiveDataCount] + [[SCReportFlow unsentReportList] count] + [entitys count];
        if (0 == count) {
            UIImage* image= [UIImage imageNamed:@"ic_UploadDownload.png"];
            [self.uploadBtn setBackgroundImage:image forState:UIControlStateNormal];
        } else {
            UIImage* image= [UIImage imageNamed:@"ic_UploadDownload_notification.png"];
            [self.uploadBtn setBackgroundImage:image forState:UIControlStateNormal];
        }
    });
}

@end
