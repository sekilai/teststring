//
//  SCPreventiveSettingViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2020/01/06.
//  Copyright © 2020 fsi_mac5d_5. All rights reserved.
//

#import "SCPreventiveSettingViewController.h"
#import "SCSystemData.h"
#import "SCSpliceDataDao.h"

static int tag_typeSelect1 = 101;
static int tag_typeSelect2 = 102;
static int tag_typeRotationSelect1 = 201;
static int tag_typeRotationSelect2 = 202;

@interface SCPreventiveSettingViewController ()

@property (weak, nonatomic) IBOutlet UILabel *modelLbl;
@property (weak, nonatomic) IBOutlet UILabel *serialNoLbl;
@property (weak, nonatomic) IBOutlet UILabel *mainTitle;
@property (weak, nonatomic) IBOutlet UILabel *subTitle;
@property (weak, nonatomic) IBOutlet UILabel *cleaverTypeLbl;
@property (weak, nonatomic) IBOutlet UILabel *rotationTypeLbl;
@property (weak, nonatomic) IBOutlet UIImageView *typeSelectIcon1;
@property (weak, nonatomic) IBOutlet UIImageView *typeSelectIcon2;
@property (weak, nonatomic) IBOutlet UIImageView *rotationSelectIcon1;
@property (weak, nonatomic) IBOutlet UIImageView *rotationSelectIcon2;
@property (weak, nonatomic) IBOutlet UILabel *modelTitleLbl;
@property (weak, nonatomic) IBOutlet UILabel *serialNoTItleLbl;

@property (weak, nonatomic) IBOutlet UILabel *rotationLabel;
@property (weak, nonatomic) IBOutlet UIView *rotationSelectView1;
@property (weak, nonatomic) IBOutlet UIView *rotationSelectView2;
@property (weak, nonatomic) IBOutlet UILabel *autoLabel;
@property (weak, nonatomic) IBOutlet UILabel *fixedLabel;
@property (weak, nonatomic) IBOutlet UILabel *autoTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *fixedTitleLabel;
@property (weak, nonatomic) IBOutlet UIButton *setBtn;
@property (weak, nonatomic) IBOutlet UIButton *cancelBtn;


@end

@implementation SCPreventiveSettingViewController

{
    NSInteger _cleaverType;//0:other、1:FC-8R
    NSInteger _rotationType;//1:自動、2:手動
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.tabBarController.tabBar.hidden = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _cleaverType = 99;
    _rotationType = 99;
    
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    self.title = NSLocalizedString(@"MSG_13077", @"予防保全設定");
    
    self.modelTitleLbl.text = NSLocalizedString(@"RES_20031", @"モデル:");
    self.serialNoTItleLbl.text = NSLocalizedString(@"RES_20032", @"S/N:");
    self.serialNoLbl.text = self.appData.selectedSerialNo;
    self.modelLbl.text = [SCSystemData getSpliceModelName:self.appData.selectedSerialNo];
    self.autoTitleLabel.text = NSLocalizedString(@"RES_30025", @"");
    self.fixedTitleLabel.text = NSLocalizedString(@"RES_30026", @"");
    self.mainTitle.text = NSLocalizedString(@"RES_30038", @"");
    self.subTitle.text = NSLocalizedString(@"RES_30024", @"");
    self.autoLabel.text = NSLocalizedString(@"RES_30036", @"Auto");
    self.fixedLabel.text = NSLocalizedString(@"RES_30037", @"Fixed");
    [self.setBtn setTitle:NSLocalizedString(@"BTN_SETTING", @"set") forState:UIControlStateNormal];
    [self.cancelBtn setTitle:NSLocalizedString(@"DLG_CANCEL", @"cancel") forState:UIControlStateNormal];
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"SettedPreventive"] == false) {
        self.cancelBtn.hidden = true;
    }
    [self updateView];
}

-(void)updateView{
    NSDictionary * settingInfo = [[[SCSpliceDataDao alloc] init] getRotatesettingInfo:self.appData.selectedSerialNo];
    if (![settingInfo objectForKey:@"type"]) {
        _cleaverType = 99;
        _rotationType = 0;
        self.typeSelectIcon1.image = [UIImage imageNamed:@"btn_radio_off"];
        self.typeSelectIcon2.image = [UIImage imageNamed:@"btn_radio_off"];
        self.rotationSelectIcon1.image = [UIImage imageNamed:@"btn_radio_off"];
        self.rotationSelectIcon2.image = [UIImage imageNamed:@"btn_radio_off"];
        [self changeRotationSelectForEnable:true];
    } else {
        _cleaverType = [(NSNumber *)[settingInfo objectForKey:@"type"] integerValue];
        _rotationType = [(NSNumber *)[settingInfo objectForKey:@"rotatesetting"] integerValue];
    }
    
    
    
    if (_cleaverType == 0){
        self.typeSelectIcon1.image = [UIImage imageNamed:@"btn_radio_off"];
        self.typeSelectIcon2.image = [UIImage imageNamed:@"btn_radio_on"];
        [self changeRotationSelectForEnable:false];
        _rotationType = 0;
    } else if (_cleaverType == 1) {
        self.typeSelectIcon1.image = [UIImage imageNamed:@"btn_radio_on"];
        self.typeSelectIcon2.image = [UIImage imageNamed:@"btn_radio_off"];
        [self changeRotationSelectForEnable:true];
    }
    
    if (_rotationType == 1) {
        self.rotationSelectIcon1.image = [UIImage imageNamed:@"btn_radio_on"];
        self.rotationSelectIcon2.image = [UIImage imageNamed:@"btn_radio_off"];
    } else if (_rotationType == 2) {
        self.rotationSelectIcon1.image = [UIImage imageNamed:@"btn_radio_off"];
        self.rotationSelectIcon2.image = [UIImage imageNamed:@"btn_radio_on"];
    }
    
}


- (IBAction)setBtnClicked:(id)sender {
    
    if (_cleaverType == 99) {
        _cleaverType = 0;
        _rotationType = 0;
    }
    if (_cleaverType == 0) {
        _rotationType = 0;
    }
    
    NSDictionary* cleaverInfo = [[[SCSpliceDataDao alloc] init] getRotatesettingInfo:self.appData.selectedSerialNo];
    NSMutableDictionary *resultDic;
    if ([cleaverInfo count] > 0) {
        resultDic = [[NSMutableDictionary alloc] initWithDictionary:cleaverInfo];
        [resultDic setObject:[NSNumber numberWithInteger:_cleaverType] forKey:@"type"];
        [resultDic setObject:[NSNumber numberWithInteger:_rotationType] forKey:@"rotatesetting"];
    } else {
        resultDic = [[NSMutableDictionary alloc] init];
        [resultDic setObject:self.appData.selectedSerialNo forKey:@"serialno"];
        [resultDic setObject:[NSNumber numberWithInteger:_cleaverType] forKey:@"type"];
        [resultDic setObject:[NSNumber numberWithInteger:_rotationType] forKey:@"rotatesetting"];
        [resultDic setObject:@"" forKey:@"exchangecount"];
        [resultDic setObject:@"" forKey:@"exchangedate"];
    }
    
    [[[SCSpliceDataDao alloc] init] updateRotatesettingInfo:resultDic];
    [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"SettedPreventive"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [SCSystemData changeTotalCheckResult:self.appData.selectedSerialNo updateCheckTime:false];
    [self.navigationController popViewControllerAnimated:true];
    if (self.pushRunNoti) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"runGetSpliceFlow" object:nil userInfo:nil];
    }
}

- (IBAction)cancelBtnClicked:(id)sender {
    
    [self.navigationController popViewControllerAnimated:true];
    
}

- (IBAction)cleaverTypeBtnClicked:(id)sender {
    UIButton * clickedBtn = (UIButton *)sender;
    if (clickedBtn.tag == tag_typeSelect1) {
        self.typeSelectIcon1.image = [UIImage imageNamed:@"btn_radio_on"];
        self.typeSelectIcon2.image = [UIImage imageNamed:@"btn_radio_off"];
        _cleaverType = 1;
        if (_rotationType == 0) {
            _rotationType = 1;
            self.rotationSelectIcon1.image = [UIImage imageNamed:@"btn_radio_on"];
        }
        [self changeRotationSelectForEnable:true];
    } else if (clickedBtn.tag == tag_typeSelect2) {
        self.typeSelectIcon1.image = [UIImage imageNamed:@"btn_radio_off"];
        self.typeSelectIcon2.image = [UIImage imageNamed:@"btn_radio_on"];
        _cleaverType = 0;
        [self changeRotationSelectForEnable:false];
    }
}

- (IBAction)rotationTypeBtnClicked:(id)sender {
    UIButton * clickedBtn = (UIButton *)sender;
    if (clickedBtn.tag == tag_typeRotationSelect1) {
        self.rotationSelectIcon1.image = [UIImage imageNamed:@"btn_radio_on"];
        self.rotationSelectIcon2.image = [UIImage imageNamed:@"btn_radio_off"];
        _rotationType = 1;
    } else if (clickedBtn.tag == tag_typeRotationSelect2) {
        self.rotationSelectIcon1.image = [UIImage imageNamed:@"btn_radio_off"];
        self.rotationSelectIcon2.image = [UIImage imageNamed:@"btn_radio_on"];
        _rotationType = 2;
    }
    if (_cleaverType == 99) {
        _cleaverType = 1;
        self.typeSelectIcon1.image = [UIImage imageNamed:@"btn_radio_on"];
    }
}

- (IBAction)actionBack:(id)sender {
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"SettedPreventive"] == false) {
        
    } else {
        [self.navigationController popViewControllerAnimated:true];
    }
}

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    // シリアル番号
    self.serialNoLbl.text = self.appData.selectedSerialNo;
    self.modelLbl.text = [SCSystemData getSpliceModelName:self.appData.selectedSerialNo];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    [super refreshOnlineSerialNo];
    
    if (![NSLocalizedString(@"NO_SERIAL", @"---") isEqualToString:self.appData.onlineSerialNo]) {
        
        self.appData.selectedSerialNo = self.appData.onlineSerialNo;
    }
}

-(void)changeRotationSelectForEnable:(BOOL)enable{
    UIButton * btn1 = [self.rotationSelectView1 viewWithTag:tag_typeRotationSelect1];
    UIButton * btn2 = [self.rotationSelectView2 viewWithTag:tag_typeRotationSelect2];
    if (enable) {
        self.rotationLabel.alpha = 1;
        self.rotationSelectView1.alpha = 1;
        self.rotationSelectView2.alpha = 1;
        btn1.enabled = true;
        btn2.enabled = true;
    } else {
        self.rotationLabel.alpha = 0.3;
        self.rotationSelectView1.alpha = 0.3;
        self.rotationSelectView2.alpha = 0.3;
//        self.rotationSelectIcon1.image = [UIImage imageNamed:@"btn_radio_off"];
//        self.rotationSelectIcon2.image = [UIImage imageNamed:@"btn_radio_off"];
        btn1.enabled = false;
        btn2.enabled = false;
    }
}

@end
