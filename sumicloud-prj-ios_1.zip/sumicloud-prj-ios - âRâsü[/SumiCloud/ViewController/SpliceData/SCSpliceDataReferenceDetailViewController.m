//
//  SCSpliceDataReferenceDetailViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/13.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSpliceDataReferenceDetailViewController.h"
#import "SCSpliceDataReferenceDetailTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCSpliceDataFlow.h"
#import "SCSpliceData.h"

@interface SCSpliceDataReferenceDetailViewController () <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) NSArray* itemList;
@property (nonatomic) NSString* editMemo;

@property (weak, nonatomic) IBOutlet UITableView *tblvwDetail;

@end

@implementation SCSpliceDataReferenceDetailViewController

static NSInteger const kSC_MAXLEN_MEMO = 48;     // 「メモ」入力文字数

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 多言語対応
    self.title = NSLocalizedString(@"BTN_SPLICEDATA_DETAIL", @"詳細データ");
    
    self.tblvwDetail.estimatedRowHeight = 44.0f;
    self.tblvwDetail.rowHeight = UITableViewAutomaticDimension;
    
    if ([SCSystemData isModelTypeZ2C:self.appData.detailSpliceData.serialno]) {
        self.itemList = @[
                          @"SP_DETAIL_01", // モデル
                          @"SP_DETAIL_02", // シリアル番号
                          @"SP_DETAIL_03", // GPS位置
                          @"SP_DETAIL_04", // 融着プログラム
                          //@"SP_DETAIL_21", // 心線識別 (左)
                          @"SP_DETAIL_05", // エラー
                          @"SP_DETAIL_06", // 推定ロス値
                          @"SP_DETAIL_07", // 端面角度
                          @"SP_DETAIL_08", // 軸ずれ量
                          //                          @"SP_DETAIL_09", // コアずれ量
                          //                         @"SP_DETAIL_10", // 軸ずれ角度（放電前）
                          //                         @"SP_DETAIL_11", // 偏心量
                          @"SP_DETAIL_12", // メモ
                          @"SP_DETAIL_13", // 気温
                          @"SP_DETAIL_14", // 気圧
                          @"SP_DETAIL_15", // 電源供給
                          @"SP_DETAIL_16"  // 放電回数
                          ];
    } else {
        self.itemList = @[
                          @"SP_DETAIL_01", // モデル
                          @"SP_DETAIL_02", // シリアル番号
                          @"SP_DETAIL_03", // GPS位置
                          @"SP_DETAIL_04", // 融着プログラム
                          //@"SP_DETAIL_21", // 心線識別 (左)
                          @"SP_DETAIL_05", // エラー
                          @"SP_DETAIL_06", // 推定ロス値
                          @"SP_DETAIL_07", // 端面角度
                          @"SP_DETAIL_08", // 軸ずれ量
                          @"SP_DETAIL_09", // コアずれ量
                          @"SP_DETAIL_10", // 軸ずれ角度（放電前）
                          @"SP_DETAIL_11", // 偏心量
                          @"SP_DETAIL_12", // メモ
                          @"SP_DETAIL_13", // 気温
                          @"SP_DETAIL_14", // 気圧
                          @"SP_DETAIL_15", // 電源供給
                          @"SP_DETAIL_16"  // 放電回数
                          ];
    }
    
    if ([[SCSystemData getSpliceModelName:self.appData.selectedSerialNo] isEqualToString:@"TYPE-72C+"] ||
        [[SCSystemData getSpliceModelName:self.appData.selectedSerialNo] isEqualToString:@"TYPE-82C+"] ||
        [[SCSystemData getSpliceModelName:self.appData.selectedSerialNo] isEqualToString:@"TYPE-Q102-CA+"] ||
        [[SCSystemData getSpliceModelName:self.appData.selectedSerialNo] isEqualToString:@"TYPE-72C-01+"] ||
        [[SCSystemData getSpliceModelName:self.appData.selectedSerialNo] isEqualToString:@"TYPE-82C+FA"] ||
        [[SCSystemData getSpliceModelName:self.appData.selectedSerialNo] isEqualToString:@"T-Q102-CA+CS"] ||
        [[SCSystemData getSpliceModelName:self.appData.selectedSerialNo] isEqualToString:@"TYPE-72C-01+MJ301"]) {
        self.itemList = @[
        @"SP_DETAIL_01", // モデル
        @"SP_DETAIL_02", // シリアル番号
        @"SP_DETAIL_03", // GPS位置
        @"SP_DETAIL_04", // 融着プログラム
        //@"SP_DETAIL_21", // 心線識別 (左)
        @"SP_DETAIL_05", // エラー
        @"SP_DETAIL_23", // NanoTune
        @"SP_DETAIL_06", // 推定ロス値
        @"SP_DETAIL_07", // 端面角度
        @"SP_DETAIL_08", // 軸ずれ量
        @"SP_DETAIL_09", // コアずれ量
        @"SP_DETAIL_10", // 軸ずれ角度（放電前）
        @"SP_DETAIL_11", // 偏心量
        @"SP_DETAIL_12", // メモ
        @"SP_DETAIL_13", // 気温
        @"SP_DETAIL_14", // 気圧
        @"SP_DETAIL_15", // 電源供給
        @"SP_DETAIL_16"  // 放電回数
        ];
    }
    
    if ([[SCSystemData getSpliceModelName:self.appData.selectedSerialNo] isEqualToString:@"T-502S"] ||
        [[SCSystemData getSpliceModelName:self.appData.selectedSerialNo] isEqualToString:@"TYPE-Q502S"]) {
        self.itemList = @[
        @"SP_DETAIL_01", // モデル
        @"SP_DETAIL_02", // シリアル番号
        @"SP_DETAIL_03", // GPS位置
        @"SP_DETAIL_04", // 融着プログラム
        //@"SP_DETAIL_21", // 心線識別 (左)
        @"SP_DETAIL_05", // エラー
        @"SP_DETAIL_23", // NanoTune
        @"SP_DETAIL_06", // 推定ロス値
        @"SP_DETAIL_07", // 端面角度
        @"SP_DETAIL_08", // 軸ずれ量
        @"SP_DETAIL_T502S_09", // コアずれ量
        @"SP_DETAIL_T502S_10", // 軸ずれ角度（放電前）
//        @"SP_DETAIL_11", // 偏心量
        @"SP_DETAIL_12", // メモ
        @"SP_DETAIL_13", // 気温
        @"SP_DETAIL_14", // 気圧
        @"SP_DETAIL_15", // 電源供給
        @"SP_DETAIL_16"  // 放電回数
        ];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - UITextFieldDelegate

/**
 入力項目編集中
 
 @param textField <#textField description#>
 @param range     <#range description#>
 @param string    <#string description#>
 
 @return <#return value description#>
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSMutableString *val = [textField.text mutableCopy];
    [val replaceCharactersInRange:range withString:string];
    
    // TODO:禁則文字チェック(ASCII)
    NSCharacterSet *checkStr = [NSCharacterSet characterSetWithCharactersInString:val];
    NSMutableCharacterSet *isAlphaNumCharSet = [[NSMutableCharacterSet alloc] init];
    [isAlphaNumCharSet addCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZ"];
    [isAlphaNumCharSet addCharactersInString:@"abcdefghijklmnopqrstuvwxyz"];
    [isAlphaNumCharSet addCharactersInString:@"0123456789"];
    [isAlphaNumCharSet addCharactersInString:@"!\"#$%&'()*+,-./:;<=>?@[]^_{} "];
    if (![isAlphaNumCharSet isSupersetOfSet:checkStr]) {
        
        return NO;
    }
    
    // 入力文字数チェック
    if (kSC_MAXLEN_MEMO < val.length) {
        
        return NO;
    }
    
    return YES;
}

/**
 入力項目編集終了
 
 @param textField <#textField description#>
 */
- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    [self.view endEditing:YES];
    
    self.editMemo = textField.text;
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param section   <#section description#>

 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.itemList.count;
}

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>

 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SCSpliceDataReferenceDetailTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];

    NSString* rowKey = [self.itemList objectAtIndex:indexPath.row];
    
    cell.lblTitle.text = NSLocalizedString(rowKey, @"ラベル");
    cell.lblValue.textColor = [UIColor blackColor];
    cell.imgvwArrow.hidden = YES;
    if ([rowKey isEqualToString:@"SP_DETAIL_01"]) {
        
        // モデル
        cell.lblValue.text = [SCSystemData getSpliceModelName:self.appData.detailSpliceData.serialno];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_02"]) {
        
        // シリアル番号
        cell.lblValue.text = self.appData.detailSpliceData.serialno;
    } else if ([rowKey isEqualToString:@"SP_DETAIL_03"]) {
        
        // GPS位置
        cell = [tableView dequeueReusableCellWithIdentifier:@"cellGPS"];
        cell.lblTitle.text = NSLocalizedString(rowKey, @"ラベル");
        cell.lblValue.textColor = [UIColor blackColor];
        [cell makeLatLon:self.appData.detailSpliceData.lat lon:self.appData.detailSpliceData.lon];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_04"]) {

        // 融着プログラム
        cell.lblValue.text = self.appData.detailSpliceData.name;
    } else if ([rowKey isEqualToString:@"SP_DETAIL_05"]) {

        // エラー
        [cell makeErrInfo:self.appData.detailSpliceData.error_info];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_06"]) {
        // 推定ロス値
        if ([SCSystemData isModelTypeT502:self.appData.detailSpliceData.serialno]) {
            cell = [tableView dequeueReusableCellWithIdentifier:@"cellT502Loss"];
            cell.lblTitle.text = NSLocalizedString(rowKey, @"ラベル");
            NSString* hdcmStr = self.appData.detailSpliceData.estimation_mode;
            NSString* cladStr = self.appData.detailSpliceData.estimated_loss;
            NSString* hcaStr = self.appData.detailSpliceData.core_left;
            NSString* limitLoss = self.appData.detailSpliceData.est_loss_limit;
            
            if ([cladStr isEqualToString:@"---"] || cladStr.length == 0){
                cladStr = @" ---";
            } else {
                cladStr = [SCSystemData stringFromDoubleString:cladStr decimalLength:2];
            }
            if ([hcaStr isEqualToString:@"---"] || hcaStr.length == 0) {
                hcaStr = @" ---";
            } else {
                hcaStr = [SCSystemData stringFromDoubleString:hcaStr decimalLength:2];
            }
            
            if ([hdcmStr isEqualToString:@"Standard"]) {
                [cell makeT502Loss:cladStr hca:@" ---" estLossLimit:limitLoss];
            } else if ([hdcmStr isEqualToString:@"Standard(Clad)"]) {
                [cell makeT502Loss:cladStr hca:@" ---" estLossLimit:limitLoss];
            } else if ([hdcmStr isEqualToString:@"High(HCA)"]) {
                [cell makeT502Loss:@" ---" hca:hcaStr estLossLimit:limitLoss];
            } else if ([hdcmStr isEqualToString:@"Clad+HCA"]) {
                [cell makeT502Loss:cladStr hca:hcaStr estLossLimit:limitLoss];
            } else {
                [cell makeT502Loss:cladStr hca:@" ---" estLossLimit:limitLoss];
            }
        } else {
            [cell makeEstimatedLoss:self.appData.detailSpliceData.estimated_loss estLossLimit:self.appData.detailSpliceData.est_loss_limit];
        }
    } else if ([rowKey isEqualToString:@"SP_DETAIL_07"]) {

        // 端面角度
        [cell makeCleaveAngle:self.appData.detailSpliceData.cleave_angle_left right:self.appData.detailSpliceData.cleave_angle_right];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_08"]) {
        
        // 軸ずれ量
        [cell makeFiberOffset:self.appData.detailSpliceData.fiber_offset_before after:self.appData.detailSpliceData.fiber_offset];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_09"] || [rowKey isEqualToString:@"SP_DETAIL_T502S_09"]) {

        // コアずれ量
        if ([SCSystemData isModelTypeT502:self.appData.detailSpliceData.serialno]) {
            if ([self.appData.detailSpliceData.estimation_mode isEqualToString:@"High(HCA)"] || [self.appData.detailSpliceData.estimation_mode isEqualToString:@"Clad+HCA"]) {
                [cell makeCoreOffset:self.appData.detailSpliceData.core_right];
            } else {
                [cell makeCoreOffset:@"---"];
            }
        } else {
            [cell makeCoreOffset:self.appData.detailSpliceData.core_offset];
        }
    } else if ([rowKey isEqualToString:@"SP_DETAIL_10"] || [rowKey isEqualToString:@"SP_DETAIL_T502S_10"]) {
        
        // 軸ずれ角度（放電前）
        [cell makeCoreAngle:self.appData.detailSpliceData.core_angle_before after:self.appData.detailSpliceData.core_angle];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_11"]) {

        // 偏心量
        [cell makeConcentricity:self.appData.detailSpliceData.concentricity_left right:self.appData.detailSpliceData.concentricity_right];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_12"]) {

        // メモ
        cell.lblValue.text = self.appData.detailSpliceData.memo;
        cell.imgvwArrow.hidden = NO;
    } else if ([rowKey isEqualToString:@"SP_DETAIL_13"]) {
        
        // 気温
        [cell makeTemperature:self.appData.detailSpliceData.temperature isDegF:NO];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_14"]) {
        
        // 気圧
        [cell makeAirPressure:self.appData.detailSpliceData.air_pressure];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_15"]) {
        
        // 電源供給
        cell.lblValue.text = self.appData.detailSpliceData.power_supply;
    } else if ([rowKey isEqualToString:@"SP_DETAIL_16"]) {
        
        // 放電回数
        [cell makeArcCount:self.appData.detailSpliceData.arc_count];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_21"]) {
        
        // 心線識別結果
        [cell makeDetectLeft:self.appData.detailSpliceData.detect_left right:self.appData.detailSpliceData.detect_right];
    } else if ([rowKey isEqualToString:@"SP_DETAIL_23"]) {
       //NanoTune
        NSString *nanoTuneStr = @"---";
        if ([self.appData.detailSpliceData.nanotune_method isEqualToString:@"1"] ||
            [self.appData.detailSpliceData.nanotune_method isEqualToString:@"2"]) {
            nanoTuneStr = @"Activated";
        }
        cell.lblValue.text = nanoTuneStr;
    } else {

        cell.lblValue.text = @"";
    }
    
    return cell;
}

/**
 メモ選択
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    DDLogDebug(@"");
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString* rowKey = [self.itemList objectAtIndex:indexPath.row];
    if ([rowKey isEqualToString:@"SP_DETAIL_12"]) {
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(rowKey, @"ラベル") message:@"" preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            
            self.editMemo = self.appData.detailSpliceData.memo;
            textField.delegate = self;
            textField.text = self.editMemo;
            textField.keyboardType = UIKeyboardTypeASCIICapable;
        }];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            // メモ更新
            self.appData.detailSpliceData.memo = self.editMemo;
            [SCSpliceDataFlow saveMemo];
            
            [self.view endEditing:YES];
            
            [self.tblvwDetail reloadData];
        }]];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            [self.view endEditing:YES];
        }]];

        [self presentViewController:alert animated:YES completion:^{
        }];
    }
}

@end
