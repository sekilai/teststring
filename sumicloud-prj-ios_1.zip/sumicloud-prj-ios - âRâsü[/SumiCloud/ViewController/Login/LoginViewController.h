//
//  LoginViewController.h
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2021/02/09.
//  Copyright © 2021 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LoginViewController : SCBaseViewController
@property (nonatomic) BOOL needClear;
@property (nonatomic) BOOL needChangePassword;
@end

NS_ASSUME_NONNULL_END
