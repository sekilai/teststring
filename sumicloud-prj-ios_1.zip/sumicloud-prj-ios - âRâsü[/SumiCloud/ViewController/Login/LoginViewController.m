//
//  LoginViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2021/02/09.
//  Copyright © 2021 fsi_mac5d_5. All rights reserved.
//

#import "LoginViewController.h"
#import "UIAlertController+Window.h"
#import "AESUtil.h"
#import "Constants.h"
#import "SCLocationService.h"
#import "DbAccessControllDao.h"
#import "SCLogUtil.h"
#import "GetUnitInfoFlow.h"
#import "SCCustomerRegistViewController.h"
#import "SCCustomerLicenceViewController.h"
#import "SCSystemData.h"

@interface LoginViewController ()

@property (weak, nonatomic) IBOutlet UITextField *accountTF;
@property (weak, nonatomic) IBOutlet UITextField *passwordTF;
@property (weak, nonatomic) IBOutlet UIButton *forgetPWBtn;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (strong, nonatomic) GetUnitInfoFlow* flow;

@end

@implementation LoginViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"showCustomerRegistView" object:nil];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    DDLogDebug(@"");
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [self.loginBtn setTitle:NSLocalizedString(@"BTN_LOGIN", @"Login") forState:UIControlStateNormal];
    if(self.needClear){
        self.needClear = NO;
    }
    if(self.needChangePassword) {
        NSString * account = [[NSUserDefaults standardUserDefaults] stringForKey:PRE_ACCOUNT];
        NSString * pre_password = [[NSUserDefaults standardUserDefaults] stringForKey:PRE_PASSWORD];
        self.accountTF.text = account;
        self.passwordTF.text = [AESUtil decrypt:PASSCODE_AES_KEY target:pre_password];
        self.needChangePassword = NO;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.flow = [[GetUnitInfoFlow alloc] init];
    [self configUI];
}

-(void)configUI{
    
    self.accountTF.leftViewMode = UITextFieldViewModeAlways;
    self.passwordTF.leftViewMode = UITextFieldViewModeAlways;
    UIView* usernameLeftview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 45, 45)];
    UIView* passwordLeftview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 45, 45)];
    UIImageView* usernameImg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ic_Account"]];
    usernameImg.center = CGPointMake(usernameLeftview.bounds.size.width/2, usernameLeftview.bounds.size.height/2);
    UIImageView* passwordImg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ic_Lock"]];
    passwordImg.center = CGPointMake(passwordLeftview.bounds.size.width/2, passwordLeftview.bounds.size.height/2);
    [usernameLeftview addSubview:usernameImg];
    [passwordLeftview addSubview:passwordImg];
    self.accountTF.leftView = usernameLeftview;
    self.passwordTF.leftView = passwordLeftview;
    self.accountTF.leftView.bounds = CGRectMake(0, 0, 45, 45);
    self.passwordTF.leftView.bounds = CGRectMake(0, 0, 45, 45);
    self.accountTF.leftView.contentMode = UIViewContentModeCenter;
    self.passwordTF.leftView.contentMode = UIViewContentModeCenter;
    self.accountTF.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"login_mailaddress", @"") attributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
    self.passwordTF.attributedPlaceholder = [[NSAttributedString alloc] initWithString:NSLocalizedString(@"login_password", @"") attributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
    self.accountTF.textColor = [UIColor whiteColor];
    self.passwordTF.textColor = [UIColor whiteColor];
    
    NSMutableAttributedString *title = [[NSMutableAttributedString alloc] initWithString:NSLocalizedString(@"password_forget_btn", @"")];
    NSRange titleRange = {0,[title length]};
    [title addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:titleRange];
    [title addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:titleRange];
    [self.forgetPWBtn setAttributedTitle:title
                          forState:UIControlStateNormal];
    
    // アカウントデータ格納
   NSString * account = [[NSUserDefaults standardUserDefaults] stringForKey:PRE_ACCOUNT];
   NSString * pre_password = [[NSUserDefaults standardUserDefaults] stringForKey:PRE_PASSWORD];
   self.accountTF.text = account;
   self.passwordTF.text = [AESUtil decrypt:PASSCODE_AES_KEY target:pre_password];
    
    self.navigationController.navigationBar.hidden = true;
    
        SCCustomerRegistState state = [SCSystemData getCustomerRegistState];
        if (kCRS_NONE == state) {
            // 初回起動
            UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"CustomerRegist" bundle:nil];
            SCCustomerLicenceViewController *licenceVC = [storyBoard instantiateViewControllerWithIdentifier:@"customerLicence"];
            licenceVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
            [self presentViewController:licenceVC animated:false completion:nil];
        }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showCustomerRegistView) name:@"showCustomerRegistView" object:nil];
}

-(void)showCustomerRegistView{
    UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"CustomerRegist" bundle:nil];
    SCCustomerRegistViewController *registVC = [storyBoard instantiateInitialViewController];
    registVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
    [self presentViewController:registVC animated:true completion:nil];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:true];
}

- (IBAction)doLogin:(id)sender {
    if(self.accountTF.text.length == 0){
        UIAlertController *alert = [UIAlertController
                                    alertControllerWithTitle:NSLocalizedString(@"adlg_loginerror_title", @"")
                                    message:NSLocalizedString(@"adlg_loginerror_message", @"")
                                    preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", @"")
                                                  style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                      [alert dismissViewControllerAnimated:YES completion:nil];
                                                  }]];
        [alert show];
        return;
    }
     // パスワードのチェック
    if(self.passwordTF.text.length == 0){
        UIAlertController *alert = [UIAlertController
                                    alertControllerWithTitle:NSLocalizedString(@"adlg_loginerror_title", @"")
                                    message:NSLocalizedString(@"adlg_loginerror_message", @"")
                                    preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", @"")
                                                  style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                      [alert dismissViewControllerAnimated:YES completion:nil];
                                                  }]];
        [alert show];
        return;
    }
    
    NSString * username = self.accountTF.text;
    NSString * password = [AESUtil encrypt:PASSWORD_AES_KEY target:self.passwordTF.text];
    
    [[SCLocationService sharedInstance] getAuthorizationStatusWithCompletion:^(BOOL canUseLocation) {
        if(!canUseLocation){
            UIAlertController *alert = [UIAlertController
                                        alertControllerWithTitle:NSLocalizedString(@"adlg_init_title", @"")
                                        message:NSLocalizedString(@"adlg_init_message", @"")
                                        preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", @"")
                                                      style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                          [alert dismissViewControllerAnimated:YES completion:nil];
                                                      }]];
            [alert show];
        }else{
            // アカウントデータ格納
            [[NSUserDefaults standardUserDefaults] setObject:username forKey:PRE_ACCOUNT];
            [[NSUserDefaults standardUserDefaults] synchronize];
            
            if ([self isSplicerConnect]) {
                NSString * dbPass = [[[DbAccessControllDao alloc] init] getAccountPassword:username];
                // 融着機と接続していた場合、スマホDBの情報をチェックする
                if([password isEqualToString:dbPass]) {
                    
                    UIAlertController *alert = [UIAlertController
                                                alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"")
                                                message:NSLocalizedString(@"adlg_login_message", @"")
                                                preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", @"")
                                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                  
                                                                  [[NSUserDefaults standardUserDefaults] setObject:@(YES) forKey:PRE_CEHCKBOX];
                                                                  [[NSUserDefaults standardUserDefaults] synchronize];
                                                                  
                        UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        UIViewController* mainVC = [storyBoard instantiateInitialViewController];
                        [self.navigationController pushViewController:mainVC animated:NO];
                                                              }]];
                    
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_CANCEL", @"")
                                                              style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                                                                  
                                                                  // Wi-Fi切り替え確認
                                                                  [self connectInternetAlert];
                                                              }]];
                    [alert show];
                }else {
                    
                    if (!dbPass || dbPass.length == 0) {
                        [self connectInternetAlert];
                    }else {
                        // アカウントまたはパスワードが間違た場合
                        UIAlertController *alert = [UIAlertController
                                                    alertControllerWithTitle:NSLocalizedString(@"adlg_loginerror_title", @"")
                                                    message:NSLocalizedString(@"adlg_login_failed", @"")
                                                    preferredStyle:UIAlertControllerStyleAlert];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", @"")
                                                                  style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                      [alert dismissViewControllerAnimated:YES completion:nil];
                                                                  }]];
                        [alert show];
                    }
                    
                }
            } else {
                
                if (![self isMobileConnect]) {
                    
                    NSString * dbPass = [[[DbAccessControllDao alloc] init] getAccountPassword:username];
                    if (!dbPass || dbPass.length == 0) {
                        [self connectInternetAlert];
                        return;
                    }
                    UIAlertController *alert = [UIAlertController
                                                alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"")
                                                message:NSLocalizedString(@"adlg_login_message", @"")
                                                preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", @"")
                                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                  
                                                                  [[NSUserDefaults standardUserDefaults] setObject:@(YES) forKey:PRE_CEHCKBOX];
                                                                  [[NSUserDefaults standardUserDefaults] synchronize];
                                                                  
                        UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        UIViewController* mainVC = [storyBoard instantiateInitialViewController];
                        [self.navigationController pushViewController:mainVC animated:NO];
                                                              }]];
                    
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_CANCEL", @"")
                                                              style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                                                                  
                                                                  // Wi-Fi切り替え確認
                                                                  [self connectInternetAlert];
                                                              }]];
                    [alert show];
                    return;
                }
            
                [self showProgress:NSLocalizedString(@"adlg_connecting", @"") cancelHandler:^{
                    [self.flow cancelFlow];
                    [self hideProgress];
                }];
                DDLogDebug(@"ログイン機能フロー");
                // ログイン機能フロー
                [self.flow runFlow:username password:password isFirst:YES completion:^(RESULT_CODE result) {
                    [self hideProgress];
                    if(result == SUCCESS || result == CANCELED_LOGIN){
                        [[NSUserDefaults standardUserDefaults] setObject:[AESUtil encrypt:PASSCODE_AES_KEY target:self.passwordTF.text] forKey:PRE_PASSWORD];
                        [[NSUserDefaults standardUserDefaults] setObject:@(YES) forKey:PRE_CEHCKBOX];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                        
                        
                        UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        UIViewController* mainVC = [storyBoard instantiateInitialViewController];
                        [self.navigationController pushViewController:mainVC animated:NO];
                    } else if (result == CANCELED) {
                        return;
                    } else {
                        
                        if(result == NET_JSON_RESULT_ERROR){
                            UIAlertController *alert = [UIAlertController
                                                        alertControllerWithTitle:NSLocalizedString(@"adlg_loginerror_title", @"")
                                                        message:NSLocalizedString(@"adlg_login_failed", @"")
                                                        preferredStyle:UIAlertControllerStyleAlert];
                            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", @"")
                                                                      style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                          [alert dismissViewControllerAnimated:YES completion:nil];
                                                                      }]];
                            [alert show];
                        }else{
                            // 指定のaccountPasswordを取得する
                            NSString * dbPass = [[[DbAccessControllDao alloc] init] getAccountPassword:username];
                            
                            if ([password isEqualToString:dbPass]) {
                                
                                [[NSUserDefaults standardUserDefaults] setObject:@(YES) forKey:PRE_CEHCKBOX];
                                [[NSUserDefaults standardUserDefaults] synchronize];
                                
                                UIStoryboard* storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                UIViewController* mainVC = [storyBoard instantiateInitialViewController];
                                [self.navigationController pushViewController:mainVC animated:NO];
                            }else {
                                if (!dbPass || dbPass.length == 0) {
                                    // SumiCloudサーバと接続できません
                                    UIAlertController *alert = [UIAlertController
                                                                alertControllerWithTitle:NSLocalizedString(@"adlg_title_connection_error", @"")
                                                                message:NSLocalizedString(@"adlg_network_error_message", @"")
                                                                preferredStyle:UIAlertControllerStyleAlert];
                                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", @"")
                                                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                                  [alert dismissViewControllerAnimated:YES completion:nil];
                                                                              }]];
                                    [alert show];
                                    
                                }else {
                                    //アカウントまたはパスワードが間違っています
                                    UIAlertController *alert = [UIAlertController
                                                                alertControllerWithTitle:NSLocalizedString(@"adlg_loginerror_title", @"")
                                                                message:NSLocalizedString(@"adlg_login_failed", @"")
                                                                preferredStyle:UIAlertControllerStyleAlert];
                                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", @"")
                                                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                                                  [alert dismissViewControllerAnimated:YES completion:nil];
                                                                              }]];
                                    [alert show];
                                }
                            }
                        }
                    }
                }];
                    
            }
        }
    }];
}

- (IBAction)doForgetPassword:(id)sender {
    UIAlertController *alert = [UIAlertController
                                alertControllerWithTitle:NSLocalizedString(@"adlg_password_forget_title", @"")
                                message:NSLocalizedString(@"adlg_password_forget_message", @"")
                                preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"")
                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                  [alert dismissViewControllerAnimated:YES completion:nil];
                                              }]];
    [alert show];
}

@end
