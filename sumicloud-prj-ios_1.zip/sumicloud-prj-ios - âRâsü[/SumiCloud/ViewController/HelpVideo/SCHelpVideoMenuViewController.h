//
//  SCHelpVideoMenuViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseLeftMenuViewController.h"

@interface SCHelpVideoMenuViewController : SCBaseLeftMenuViewController

@end
