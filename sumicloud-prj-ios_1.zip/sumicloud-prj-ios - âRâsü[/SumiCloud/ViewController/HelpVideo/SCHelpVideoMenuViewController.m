//
//  SCHelpVideoMenuViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCHelpVideoMenuViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCHelpVideoFlow.h"
#import "SCLeftMenuViewController.h"

@interface SCHelpVideoMenuViewController () <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UITableView *menuTable;

@property (nonatomic) NSMutableArray *menuList;

@end

@implementation SCHelpVideoMenuViewController

static NSString* const kSC_HVM_Title = @"Title";     // メニュータイトル
static NSString* const kSC_HVM_SegueId = @"SegueId"; // 画面遷移ID
static NSString* const kSC_HVM_CellId = @"CellId";   // セルID

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_HELP", @"ヘルプ");

    // 画面表示データの更新
    [self refreshSelectedSerialNo];
    
    // 余白セルを表示しない
    self.menuTable.estimatedRowHeight = 44.0f;
    self.menuTable.rowHeight = UITableViewAutomaticDimension;
    self.menuTable.tableFooterView = [[UIView alloc] init];
    
    self.menuList = [[NSMutableArray alloc] initWithCapacity:0];
    // 「お問い合わせ」は非表示にする
//    [self.menuList addObject:@{
//                               kSC_HVM_Title : NSLocalizedString(@"TITLE_HELP_CONTACT", @"お問い合わせ"),
//                               kSC_HVM_SegueId : @"toHelpContact",
//                               kSC_HVM_CellId : @"labelCell"
//                               }];
    [self.menuList addObject:@{
                               kSC_HVM_Title : NSLocalizedString(@"TITLE_HELP_LIST", @"ヘルプ動画"),
                               kSC_HVM_SegueId : @"toHelpVideoList",
                               kSC_HVM_CellId : @"arrowCell"
                               }];
//    [self.menuList addObject:@{
//                               kSC_HVM_Title : NSLocalizedString(@"MSG_10058", @"確認メッセージ"),
//                               kSC_HVM_SegueId : @"",
//                               kSC_HVM_CellId : @"labelCell"
//                               }];
    
    self.appData.manHelpVideo = [[SCHelpVideoManager alloc] init];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Segue

/**
 <#Description#>
 
 @param segue  <#segue description#>
 @param sender <#sender description#>
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    DDLogDebug(@"");
    
    if ([@"toLeftMenu" isEqualToString:segue.identifier]) {
        
        segue.destinationViewController.modalPresentationStyle = UIModalPresentationCustom;
        segue.destinationViewController.transitioningDelegate = self;
        SCLeftMenuViewController* leftVC = segue.destinationViewController;
        leftVC.preVC = self.parentViewController;
    }

}

#pragma mark - UITableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.menuList.count;
}

/**
 メニュー作成

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell* cell;
    
    NSDictionary* dic = self.menuList[indexPath.row];
    
    cell = [tableView dequeueReusableCellWithIdentifier:dic[kSC_HVM_CellId]];
    
    if ([dic[kSC_HVM_CellId] isEqualToString:@"labelCell"]) {

        cell.userInteractionEnabled = NO;
        
        cell.textLabel.text = NSLocalizedString(dic[kSC_HVM_Title], @"ラベル");
        cell.textLabel.enabled = YES;
        cell.textLabel.numberOfLines = 0;
    } else {
        
        UILabel* label = [cell viewWithTag:1];
        label.text = dic[kSC_HVM_Title];
    }
    
    return cell;
}

/**
 メニュー選択

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary* dic = self.menuList[indexPath.row];
    
    // ヘルプ動画選択の場合
    if ([dic[kSC_HVM_SegueId] isEqualToString:@"toHelpVideoList"]) {
        
        // シリアル未選択の場合はエラーを表示
        if ([self isUnselectSplicerAlert]) {
            
            return;
        }
        
        // ヘルプリスト、サムネイルをサーバから取得する
        SCHelpVideoFlow* flow = [[SCHelpVideoFlow alloc] init];
        
        // 選択可能言語を取得する
        NSArray *langList = [flow getSelectableLaunguageList:self.appData.selectedSerialNo];
        
        // 言語コードを昇順に並び替える
        NSArray *sortList = [SCHelpVideoFlow sortAscending:langList key:kSC_HVL_No];
        
        // デフォルト言語取得
        self.appData.manHelpVideo.defaultLanguage = sortList.firstObject[kSC_HVL_Code];
        
    }
    [self performSegueWithIdentifier:dic[kSC_HVM_SegueId] sender:self];
}

#pragma mark - Override Method

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

@end
