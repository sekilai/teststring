//
//  SCHelpVideoPlayViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCHelpVideoPlayViewController.h"
#import "SCLogUtil.h"

#import <AVFoundation/AVFoundation.h>

#import "SCSystemData.h"
#import "SCHelpMovie.h"
#import "SCHelpVideoFlow.h"
#import "NSString+Parser.h"

@interface SCHelpVideoPlayViewController ()
{
    AVPlayer *player;
    NSObject *periodicTimeObserver;
}
@property (weak, nonatomic) IBOutlet UIView *navigationView;
@property (weak, nonatomic) IBOutlet UIButton *btnClose;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@property (weak, nonatomic) IBOutlet UIView *playerBackgroundView;

@property (weak, nonatomic) IBOutlet UIView *controlBackgroundView;
@property (weak, nonatomic) IBOutlet UIImageView *imgPlayStop;
@property (weak, nonatomic) IBOutlet UIButton *btnPrev;
@property (weak, nonatomic) IBOutlet UIButton *btnNext;
@property (weak, nonatomic) IBOutlet UISlider *sldPlaytime;
@property (weak, nonatomic) IBOutlet UILabel *lblCurtime;
@property (weak, nonatomic) IBOutlet UILabel *lblPlaytime;
@property (weak, nonatomic) IBOutlet UILabel *lblTelop;
@property (weak, nonatomic) IBOutlet UIImageView *imgPrev;
@property (weak, nonatomic) IBOutlet UIImageView *imgNext;

@property (nonatomic) SCHelpVideoFlow *flow;

@property (nonatomic) NSMutableArray *movieList;
@property (nonatomic) NSInteger currentMovie;
@property (nonatomic) BOOL isLandScapeControlHidden;

@property (nonatomic) int seekStatus;
@property (nonatomic) AVPlayerLayer * playerLayer;

- (IBAction)btnCloseTouchUpInside:(UIButton *)sender;
- (IBAction)btnPlayStopAction:(id)sender;
- (IBAction)btnbackAction:(id)sender;
- (IBAction)btnNextAction:(id)sender;
- (IBAction)startSeeking:(id)sender;
- (IBAction)endSeeking:(id)sender;
- (IBAction)seek:(id)sender;

@end

@implementation SCHelpVideoPlayViewController

static float const MovieWidth = 640.0;
static float const MovieHeight = 480.0;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // ヘルプリスト情報を取得
    self.flow = [[SCHelpVideoFlow alloc] init];
    self.movieList = [[self.flow getHelpMoviesInfo:self.appData.selectedSerialNo] mutableCopy];
    // ナビゲーションバー設定
    self.navigationView.backgroundColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    self.lblTitle.font = [UIFont boldSystemFontOfSize:17.0];
    
    if (self.showPreAndNext == false) {
        self.imgNext.hidden = true;
        self.imgPrev.hidden = true;
        self.btnNext.hidden = true;
        self.btnPrev.hidden = true;
    }
    
    // ヘルプ動画画面では縦横回転を許容する
    self.appData.rotateMask = UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskLandscape;
    
    UITapGestureRecognizer *movieTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(movieTap:)];
    self.playerBackgroundView.userInteractionEnabled = YES;
    [self.playerBackgroundView addGestureRecognizer:movieTap];
    
    // 現在のヘルプ動画情報を取得
    for (int i = 0 ; i < self.movieList.count ; i++) {
        
        SCHelpMovie *movie = self.movieList[i];
        if ([movie.id_no isEqualToString:self.appData.manHelpVideo.selectHelpID]) {
            
            self.currentMovie = i;
            break;
        }
    }

    SCHelpMovie *movie = self.movieList[self.currentMovie];

    // テロップファイル情報の更新
    [self.flow updateParseTelopFile:movie];

    // タイトルの設定
    self.lblTitle.text = movie.title;

    // プレーヤー生成
    NSString *moviePath = [self.flow.rootHelpVideoFolder stringByAppendingPathComponent:movie.moviefile];
    NSURL *url = [NSURL fileURLWithPath:moviePath isDirectory:NO];
    
    // AVPlayer作成
    player = [[AVPlayer alloc] initWithURL:url];
    
    self.playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
    self.playerLayer.frame = self.playerBackgroundView.layer.bounds;
    self.playerLayer.videoGravity = AVLayerVideoGravityResize;
    
    [self.playerBackgroundView.layer addSublayer:self.playerLayer];
    
    // KVO監視メソッド登録
    // 再生準備完了の監視
    [player addObserver:self
             forKeyPath:@"status"
                options:NSKeyValueObservingOptionNew
                context:&player];
    
    // 再生状態を監視する、playとpauseボタンを変えるため
    [player addObserver:self
             forKeyPath:@"rate"
                options:NSKeyValueObservingOptionNew
                context:&player];
    
    // PlayerViewのサイズ変更の監視
    [self.playerBackgroundView.layer addObserver:self
                                      forKeyPath:@"bounds"
                                         options:NSKeyValueObservingOptionNew
                                         context:(void *)self.playerLayer];
    
    // テロップを最前面に表示
    [self.playerBackgroundView bringSubviewToFront:self.lblTelop];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    
    // 画面を閉じる時に縦固定に戻す
    self.appData.rotateMask = UIInterfaceOrientationMaskPortrait;
    
    // ヘルプリストに戻る時に横向きの場合は縦画面に回転する
    dispatch_async(dispatch_get_main_queue(), ^{
        
        UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
        if (orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight) {
            
            NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
            [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
        }
    });
}

- (void)dealloc {
    
    self.flow = nil;
    
    [self.playerLayer removeFromSuperlayer];
    self.playerLayer = nil;
    player = nil;
}

/**
 回転制御

 @param size <#size description#>
 @param coordinator <#coordinator description#>
 */
- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    
    NSLog(@"viewWillTransitionToSize");
    
    // 回転後はコントロールを表示に変更
    self.isLandScapeControlHidden = NO;
    [self showHiddenControl:NO];
}

#pragma mark - Button Action

/**
 閉じるボタン

 */
- (IBAction)btnCloseTouchUpInside:(UIButton *)sender {
    
    DDLogDebug(@"");
    
    [player pause];
    
    [player removeObserver:self forKeyPath:@"status"];
    [player removeObserver:self forKeyPath:@"rate"];
    [self.playerBackgroundView.layer removeObserver:self forKeyPath:@"bounds"];

    if(periodicTimeObserver){
        [player removeTimeObserver:periodicTimeObserver];
    }
    // dealloc前にnilで初期化しないとdeallocが呼ばれない
    periodicTimeObserver = nil;
    
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}

/**
 再生・停止ボタン

 */
- (IBAction)btnPlayStopAction:(id)sender {
    
    // 再生中は再生ボタンにして一時停止に変更
    if(player.rate > 0){
        
        [self.imgPlayStop setImage:[UIImage imageNamed:@"btn_video_play"]];
        [player pause];
    }else{
        
        // 最後まで再生した場合、先頭から再生する
        if(CMTimeCompare(player.currentTime,player.currentItem.asset.duration) == 0){

            [player seekToTime:CMTimeMakeWithSeconds(0, player.currentTime.timescale)
             completionHandler:^(BOOL finished) {
                 [player play];
             }];
        }else{
            
            [self.imgPlayStop setImage:[UIImage imageNamed:@"btn_video_stop"]];
            [player play];
        }
    }
}

/**
 前の動画へボタン

 */
- (IBAction)btnbackAction:(id)sender {

    [player pause];
    
    // 前の動画に遷移
    NSInteger movieNum = [self indexMoveHelpMovie:self.currentMovie forward:NO];
    [self playMovie:movieNum];
}

/**
 後の動画へボタン

 */
- (IBAction)btnNextAction:(id)sender {

    [player pause];
    
    // 後の動画に遷移
    NSInteger movieNum = [self indexMoveHelpMovie:self.currentMovie forward:YES];
    [self playMovie:movieNum];
}

/**
 スライダー操作開始

 */
- (IBAction)startSeeking:(id)sender {
    
    // ドラッグ前の再生状態を保持する
    // seekStatus 0:ドラッグしていない
    //            1:再生中
    //            2:停止中
    self.seekStatus = player.rate > 0?1:2;
    [player pause];
}

/**
 スライダーの操作終了

 */
- (IBAction)endSeeking:(id)sender {

    // ドラッグ前の再生状態で再開する
    if(self.seekStatus == 1){
        [player play];
    }else{
        [player pause];
    }
    self.seekStatus = 0;
}

/**
 スライダーの操作

 */
- (IBAction)seek:(id)sender {

    // スライド中は、現在時間表示にスライドしている時間を表示
    self.lblCurtime.text = [NSString stringWithFormat:@"%02d:%02d",
                         (int)self.sldPlaytime.value / 60,
                         (int)self.sldPlaytime.value % 60];
    [player seekToTime:CMTimeMake(self.sldPlaytime.value * 1000, 1000)
       toleranceBefore:CMTimeMake(1, 60)
        toleranceAfter:CMTimeMake(1, 60)
     completionHandler:^(BOOL finished) {
     }];
}

/**
 ヘルプ動画領域タップ処理（横画面のみ）

 @param sender <#sender description#>
 */
- (void)movieTap:(UITapGestureRecognizer *)sender {
    
    // 横画面の場合は、コントロールの表示/非表示を切替
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if (orientation == UIInterfaceOrientationLandscapeLeft || orientation == UIInterfaceOrientationLandscapeRight) {

        self.isLandScapeControlHidden = !self.isLandScapeControlHidden;
        
        [self showHiddenControl:self.isLandScapeControlHidden];
    }
}

/**
 コントロール表示切替

 @param isHidden <#isHidden description#>
 */
- (void)showHiddenControl:(BOOL)isHidden {
    
    self.controlBackgroundView.hidden = isHidden;
    self.navigationView.hidden = isHidden;
}

/**
 ヘルプ動画更新

 @param movieNum <#movieNum description#>
 */
- (void)playMovie:(NSInteger)movieNum {
    
    SCHelpMovie *movie = self.movieList[movieNum];

    // 動画ファイルのダウンロード
    if ([self.flow isDownloadMovie:movie]) {
        
        // Wi-Fi切り替え確認
        if (![self isMobileConnect]) {
            
            [self connectSplicerAlert];
            return;
        }
        
        [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
        
        // ダウンロードが必要な場合は、動画ファイルをダウンロードする
        NSError *error = [self.flow downloadHelpVideo:movie];
        
        [self hideProgress];
        
        if (error) {
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10055", @"") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
            
            return;
        }
    }
    
    // テロップのダウンロード
    if ([self.flow isDownloadTelop:movie]) {
        
        // モバイル接続中の場合は、テロップファイルをダウンロード
        if ([self isMobileConnect]) {
            
            [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
            
            [self.flow downloadTelop:movie];
            
            [self hideProgress];
        }
    }
    
    // ヘルプリスト情報の更新
    SCHelpMovie *downloadMovie = [self.flow getHelpMovie:movie.id_no];
    [self.movieList replaceObjectAtIndex:movieNum withObject:downloadMovie];
    
    self.currentMovie = movieNum;
    
    // 動画情報の設定
    SCHelpMovie *newMovie = self.movieList[movieNum];

    // テロップファイル情報の更新
    [self.flow updateParseTelopFile:newMovie];
    
    // タイトルの設定
    self.lblTitle.text = newMovie.title;
    
    // 再生する動画ファイルを更新する
    AVPlayerItem * item = [[AVPlayerItem alloc] initWithURL:[NSURL fileURLWithPath:[self.flow.rootHelpVideoFolder stringByAppendingPathComponent:newMovie.moviefile]]];
    [player replaceCurrentItemWithPlayerItem:item];
    [player play];
    CMTime cmTime = item.asset.duration;
    self.sldPlaytime.maximumValue = CMTimeGetSeconds(cmTime);
    self.sldPlaytime.value = 0;
    self.lblPlaytime.text = [NSString stringWithFormat:@"%02d:%02d",
                             (int)CMTimeGetSeconds(cmTime) / 60,
                             (int)CMTimeGetSeconds(cmTime) % 60];
}

/**
 遷移後のヘルプ動画インデックス取得

 @param movieNum <#movieNum description#>
 @param forward <#forward description#>
 @return <#return value description#>
 */
- (NSInteger)indexMoveHelpMovie:(NSInteger)movieNum forward:(BOOL)forward {

    NSInteger ret;
    if (forward) {
        
        if (movieNum < self.movieList.count - 1) {
            
            // 後のヘルプ動画へ移動
            ret = movieNum + 1;
        } else {
            
            // 最後の動画の場合は、先頭の動画へ移動する
            ret = 0;
        }
    } else {
        
        if (movieNum > 0) {
            
            // 前のヘルプ動画へ移動
            ret = movieNum - 1;
        } else {
            
            // 先頭の動画の場合は、最後の動画へ移動する
            ret = self.movieList.count - 1;
        }
    }
    return ret;
}


#pragma mark - Notification

/**
 プロパティ監視

 @param keyPath <#keyPath description#>
 @param object <#object description#>
 @param change <#change description#>
 @param context <#context description#>
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    
    DDLogInfo(@"プロパティ監視【%@】", keyPath);
    if(object == player){
        if([keyPath isEqualToString:@"status"]) {
            
            // 再生準備完了次第動画を再生
            if( [player status] == AVPlayerItemStatusReadyToPlay ) {
                
                // 現在の動画情報の設定
                AVPlayerItem * item = player.currentItem;
                CMTime cmTime = item.asset.duration;
                self.sldPlaytime.maximumValue = CMTimeGetSeconds(cmTime);
                self.sldPlaytime.value = 0;
                self.lblPlaytime.text = [NSString stringWithFormat:@"%02d:%02d",
                                          (int)CMTimeGetSeconds(cmTime) / 60,
                                          (int)CMTimeGetSeconds(cmTime) % 60];
                
                // 再生監視ブロックの登録
                if(periodicTimeObserver){
                    [player removeTimeObserver:periodicTimeObserver];
                }
                __block SCHelpVideoPlayViewController * bSelf = self;  // ループ参照を避けるため、__block変数用意
                periodicTimeObserver = [player
                                        addPeriodicTimeObserverForInterval:CMTimeMake(20, 1000)
                                        queue:dispatch_get_main_queue()  // メインスレッドが必要
                                        usingBlock:^(CMTime time) {
                                            // TODO:テロップ表示
                                            SCTelop * telop = [bSelf.flow telopWithTimeInterval:CMTimeGetSeconds(time)];
                                            if(telop){
                                                
                                                // テロップ情報設定
                                                bSelf.lblTelop.text = telop.text;
                                                bSelf.lblTelop.backgroundColor = [telop.backgroundColor colorValue];
                                                bSelf.lblTelop.textColor = [telop.textColor colorValue];
                                                
                                                // テロップ開始位置はムービのサイズ(640x480)で指定しているので
                                                // 本当の位置に変換する必要がある
                                                float x = telop.x / MovieWidth * bSelf.playerBackgroundView.frame.size.width;
                                                float y = telop.y / MovieHeight * bSelf.playerBackgroundView.frame.size.height;
                                                
                                                // テロップ大きさの計算
                                                // 以下のルールで計算する
                                                // 1.開始位置から、ムービの右側(10px間隔)までを横幅として、テロップラベルの高さを計算する
                                                // 2.テロップラベルに計算された高さを設定し、ラベルのメソッドを呼び出し、最小サイズを計算
                                                // 3.計算された最小サイズをラベルに設定する
                                                NSAttributedString *attributedText = [[NSAttributedString alloc]
                                                                                      initWithString:bSelf.lblTelop.text
                                                                                      attributes:@{
                                                                                                   NSFontAttributeName: bSelf.lblTelop.font
                                                                                                   }];
                                                CGRect rect = [attributedText boundingRectWithSize:
                                                               (CGSize){bSelf.playerBackgroundView.frame.size.width - x - 10, CGFLOAT_MAX}
                                                                                           options:NSStringDrawingUsesLineFragmentOrigin
                                                                                           context:nil];
                                                CGSize labelSize = [bSelf.lblTelop
                                                                    sizeThatFits:CGSizeMake(bSelf.playerBackgroundView.frame.size.width - x - 10,
                                                                                            rect.size.height)];
                                                bSelf.lblTelop.frame = CGRectMake(x,
                                                                                  y,
                                                                                  labelSize.width,
                                                                                  labelSize.height);
                                                bSelf.lblTelop.hidden = NO;
                                            }else{
                                                
                                                // テロップがない場合、テロップラベルが表示されない
                                                bSelf.lblTelop.hidden = YES;
                                            }
                                            
                                            // 再生している時間の設定
                                            if(bSelf.seekStatus == 0){
                                                bSelf.lblCurtime.text = [NSString stringWithFormat:@"%02d:%02d",
                                                                         (int)CMTimeGetSeconds(time) / 60,
                                                                         (int)CMTimeGetSeconds(time) % 60];
                                                bSelf.sldPlaytime.value = CMTimeGetSeconds(time);
                                            }
                                        }];
                
                // ムービの準備が完了すると、すぐ再生開始する
                [player play];
                return;
            }
        }else if([keyPath isEqualToString:@"rate"]){
            
            // 再生/停止ボタン更新
            if(player.rate == 0){
                
                [self.imgPlayStop setImage:[UIImage imageNamed:@"btn_video_play"]];

                // バックグラウンド遷移から復帰した時に現在時間が前後に数秒程度ずれる対策
                [player seekToTime:player.currentTime
                   toleranceBefore:CMTimeMake(1, 60)
                    toleranceAfter:CMTimeMake(1, 60)
                 completionHandler:^(BOOL finished) {
                 }];
            } else {
                
                [self.imgPlayStop setImage:[UIImage imageNamed:@"btn_video_stop"]];
            }
        }
    }else if(object == self.playerBackgroundView.layer){
        
        // 再生Viewサイズが変化された場合、layerのサイズも変更する
        AVPlayerLayer * playerLayer = (__bridge AVPlayerLayer *)context;
        playerLayer.frame = self.playerBackgroundView.layer.bounds;
    }
}
@end
