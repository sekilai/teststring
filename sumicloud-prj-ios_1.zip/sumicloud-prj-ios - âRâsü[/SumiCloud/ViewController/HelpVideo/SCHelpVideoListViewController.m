//
//  SCHelpVideoListViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCHelpVideoListViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCHelpVideoListCollectionViewCell.h"
#import "SCHelpVideoFlow.h"
#import "SCHelpVideoPlayViewController.h"

@interface SCHelpVideoListViewController () <UICollectionViewDelegate, UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UICollectionView *helpMovieCollectionView;

@property (nonatomic) SCHelpVideoFlow *flow;
@property (nonatomic) NSArray *languageList;
@property (nonatomic) NSArray *movieList;

@property (nonatomic) NSMutableArray *menuList;

- (IBAction)actionBack:(id)sender;
- (IBAction)actionMenu:(UIBarButtonItem *)sender;

@end

@implementation SCHelpVideoListViewController

static NSString* const kSC_HVLM_Title = @"Title";     // メニュータイトル

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_HELP_LIST", @"ヘルプ動画");
    
    self.flow = [[SCHelpVideoFlow alloc] init];
    
    self.appData.manHelpVideo.selectLanguage = @"";

    // メニュー項目
    self.menuList = [[NSMutableArray alloc] initWithCapacity:0];
// Phase2では非表示にする（サムネイル（小）、タイプ選択、選択、すべて選択）
//    [self.menuList addObject:@{
//                               kSC_HVLM_Title : @"サムネイル（小）"
//                               }];
//    [self.menuList addObject:@{
//                               kSC_HVLM_Title : @"タイプ選択"
//                               }];
    [self.menuList addObject:@{
                               kSC_HVLM_Title : NSLocalizedString(@"RES_20039", @"言語変更")
                               }];
//    [self.menuList addObject:@{
//                               kSC_HVLM_Title : @"選択"
//                               }];
//    [self.menuList addObject:@{
//                               kSC_HVLM_Title : @"すべて選択"
//                               }];
    
    // 画面表示データの更新
    [self refreshSelectedSerialNo];
    
    // ヘルプリスト表示
    [self showHelpVideoList];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    [self.helpMovieCollectionView reloadData];
}

#pragma mark - UICollectionViewDelegate

/**
 CollectionViewの列数
 
 @param collectionView <#collectionView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return self.movieList.count;
}

/**
 CollectionViewCellのサイズ

 @param collectionView <#collectionView description#>
 @param collectionViewLayout <#collectionViewLayout description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(nonnull UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(nonnull NSIndexPath *)indexPath {

    return CGSizeMake(collectionView.frame.size.width / 2 - 16, collectionView.frame.size.width / 2 - 16);
}

/**
 CollectionViewのセルを生成
 
 @param collectionView <#collectionView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    SCHelpVideoListCollectionViewCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"helpVideoCell" forIndexPath:indexPath];
    
    SCHelpMovie *movie = self.movieList[indexPath.row];
    
    // サムネイルを設定
    NSString *thumbnailFile = [self.flow.rootHelpVideoFolder stringByAppendingPathComponent:movie.thumbnailfile];
    cell.imgvwThumbnail.image = [self getThumbnailImage:thumbnailFile];
    
    // 再生時間を設定
    if (!movie.play_time || [movie.play_time isEqualToString:@""]) {

        // 再生時間が存在しない場合は表示しない
        cell.bgvwPlaytime.hidden = YES;
        cell.lblPlaytime.hidden = YES;
    } else {
        
        cell.lblPlaytime.text = movie.play_time;
    }

    // タイトルを設定
    cell.lblTitle.text = movie.title;

    // ヘルプ動画がローカルに保存されていない場合は、反転する
    cell.vwMask.hidden = [self.flow isExistsMovie:movie];

    return cell;
}

/**
 ヘルプリストの選択
 
 @param collectionView <#collectionView description#>
 @param indexPath <#indexPath description#>
 */
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSLog(@"ヘルプ動画選択");
    
    // 選択した動画IDを保持
    SCHelpMovie *movie = self.movieList[indexPath.row];
    self.appData.manHelpVideo.selectHelpID = movie.id_no;
    
    // 動画ファイルのダウンロード
    if ([self.flow isDownloadMovie:movie]) {
        
        // Wi-Fi切り替え確認
        if (![self isMobileConnect]) {
            
            [self connectSplicerAlert];
            return;
        }
        
        [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
        
        NSError *error = [self.flow downloadHelpVideo:movie];

        [self hideProgress];
        
        if (error) {
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10055", @"") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            [self presentViewController:alert animated:YES completion:nil];
            
            return;
        }
    }
    
    // テロップのダウンロード
    if ([self.flow isDownloadTelop:movie]) {

        // モバイル接続中の場合は、テロップファイルをダウンロード
        if ([self isMobileConnect]) {
            
            [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
            
            [self.flow downloadTelop:movie];
            
            [self hideProgress];
        }
    }
    
    // 「ヘルプ動画表示画面」へ遷移
    [self performSegueWithIdentifier:@"toHelpVideoPlay" sender:self];
}

#pragma mark - Segue

/**
 <#Description#>
 
 @param segue  <#segue description#>
 @param sender <#sender description#>
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    DDLogDebug(@"");
    if ([@"toHelpVideoPlay" isEqualToString:segue.identifier]) {
        SCHelpVideoPlayViewController* vwCon = segue.destinationViewController;
        vwCon.showPreAndNext = true;
    }
    
}

#pragma mark - UIButtonAction

/**
 戻るボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 アクションメニューボタン

 @param sender <#sender description#>
 */
- (IBAction)actionMenu:(UIBarButtonItem *)sender {
    
    // ActionSheetの作成
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];

    for (NSDictionary* item in self.menuList) {
        [alertController addAction:[UIAlertAction actionWithTitle:item[kSC_HVLM_Title] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            [self selectActionMenu:action];
        }]];
    }
    
    // キャンセル
    [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
    }]];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

#pragma mark - Override Method

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
    
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

#pragma mark - Private Method

/**
 サムネイル取得

 @param fileName <#fileName description#>
 @return <#return value description#>
 */
- (UIImage *)getThumbnailImage:(NSString *)fileName {
    
    UIImage *ret;
    if (fileName) {
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        BOOL isExist = [fileManager fileExistsAtPath:fileName];
        if(isExist) {
            NSData *data = [[NSData alloc] initWithContentsOfFile:fileName];
            if (data) {
                ret = [UIImage imageWithData:data];
            }
        }
    }
    
    return ret;
}

/**
 ヘルプリスト表示
 */
- (void)showHelpVideoList {
    
    // 選択可能言語の取得
    if (self.appData.selectedSerialNo) {
        // 選択可能言語を取得する
        NSArray *langList = [self.flow getSelectableLaunguageList:self.appData.selectedSerialNo];
        
        
        // 言語コードを昇順に並び替える
        self.languageList = [SCHelpVideoFlow sortAscending:langList key:kSC_HVL_No];
        
        if ([self.appData.manHelpVideo.selectLanguage isEqualToString:@""]) {
            
            self.appData.manHelpVideo.selectLanguage = self.appData.manHelpVideo.defaultLanguage;
        }
        
        // 選択言語のヘルプリストを取得する
        NSArray *list = [self.flow getHelpMoviesInfo:self.appData.selectedSerialNo];
        // IDを昇順に並び替える
        self.movieList = [SCHelpVideoFlow sortAscending:list key:@"id_no"];
        
        [self.helpMovieCollectionView reloadData];
    }
}

/**
 アクションメニュー選択

 @param action <#action description#>
 */
- (void)selectActionMenu:(UIAlertAction*)action {
    
    if ([action.title isEqualToString:NSLocalizedString(@"RES_20039", @"言語変更")]) {
        
        // 言語変更メニューを作成
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        for (NSDictionary* item in self.languageList) {
            
            [alertController addAction:[UIAlertAction actionWithTitle:item[kSC_HVL_Name] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                
                // 変更前の言語を保持する
                NSString *oldLanguage = self.appData.manHelpVideo.selectLanguage;
                
                // 選択言語を保持する
                self.appData.manHelpVideo.selectLanguage = item[kSC_HVL_Code];
                
                // ヘルプリスト情報を再取得する
                NSArray *list = [self.flow getHelpMoviesInfo:self.appData.selectedSerialNo];
                
                if (list.count > 0) {
                    
                    // IDを昇順に並び替える
                    self.movieList = [SCHelpVideoFlow sortAscending:list key:@"id_no"];
                    
                    // ヘルプリスト更新
                    [self.helpMovieCollectionView reloadData];
                } else {
                    
                    // 選択言語を変更前に戻す
                    self.appData.manHelpVideo.selectLanguage = oldLanguage;

                    // 確認メッセージ表示
                    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10060", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
                    
                    [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
                    }]];
                    
                    [self presentViewController:confirm animated:YES completion:nil];
                }
            }]];
        }
        
        // キャンセル
        [alertController addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        }]];
        
        [self presentViewController:alertController animated:YES completion:nil];
    }
}

@end
