//
//  SCHelpVideoListCollectionViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_8 on 2016/12/08.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCHelpVideoListCollectionViewCell.h"

@implementation SCHelpVideoListCollectionViewCell

@end
