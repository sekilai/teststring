//
//  SCHelpVideoListCollectionViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_8 on 2016/12/08.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCHelpVideoListCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgvwThumbnail;
@property (weak, nonatomic) IBOutlet UIView *bgvwPlaytime;
@property (weak, nonatomic) IBOutlet UILabel *lblPlaytime;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UIView *vwMask;

@end
