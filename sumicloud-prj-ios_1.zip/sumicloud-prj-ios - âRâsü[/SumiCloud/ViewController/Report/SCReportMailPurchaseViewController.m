//
//  SCReportMailPurchaseViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportMailPurchaseViewController.h"
#import "SCLogUtil.h"

@interface SCReportMailPurchaseViewController ()

- (IBAction)actionBack:(UIBarButtonItem *)sender;

@end

@implementation SCReportMailPurchaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_REPORT_MAIL_PURCHASE", @"レポートメール作成回数購入");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}

#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {

    DDLogDebug(@"");
    
    [self.navigationController popViewControllerAnimated:YES];
}

@end
