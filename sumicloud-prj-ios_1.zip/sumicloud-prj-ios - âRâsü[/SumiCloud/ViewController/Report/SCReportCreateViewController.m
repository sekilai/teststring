//
//  SCReportCreateViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportCreateViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCReportFlow.h"

#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

@interface SCReportCreateViewController () <UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, MFMailComposeViewControllerDelegate>

@property (nonatomic) NSInteger tagEditWorkImage; // 画像選択中の入力項目
@property (nonatomic) NSString* zipPassword;      // メール送信のZIPパスワード
@property (nonatomic) BOOL isWokerImage1;         // 工事写真１が選択済みか
@property (nonatomic) BOOL isWokerImage2;         // 工事写真２が選択済みか
@property (nonatomic) BOOL isWokerImage3;         // 工事写真３が選択済みか

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UIScrollView *vwScroll;
@property (weak, nonatomic) IBOutlet UIView *vwContents;

@property (weak, nonatomic) IBOutlet UILabel *lblTitleDateTime;
@property (weak, nonatomic) IBOutlet UILabel *lblValueDateTime;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleTimezone;
@property (weak, nonatomic) IBOutlet UILabel *lblValueTimezone;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleWorker;
@property (weak, nonatomic) IBOutlet UITextField *txtWorker;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwWorkImage1;
@property (weak, nonatomic) IBOutlet UILabel *lblAppendWorkImage1;
@property (weak, nonatomic) IBOutlet UIButton *btnRemoveWorkImage1;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwWorkImage2;
@property (weak, nonatomic) IBOutlet UILabel *lblAppendWorkImage2;
@property (weak, nonatomic) IBOutlet UIButton *btnRemoveWorkImage2;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwWorkImage3;
@property (weak, nonatomic) IBOutlet UILabel *lblAppendWorkImage3;
@property (weak, nonatomic) IBOutlet UIButton *btnRemoveWorkImage3;

@property (weak, nonatomic) IBOutlet UIButton *btnUserDefine;
@property (weak, nonatomic) IBOutlet UILabel *lblUserDefineCount;

@property (weak, nonatomic) IBOutlet UIButton *btnPeriodSetting;
@property (weak, nonatomic) IBOutlet UILabel *lblPeriodSettingCount;

@property (weak, nonatomic) IBOutlet UIButton *btnSendPDF;
@property (weak, nonatomic) IBOutlet UIButton *btnSendMail;
@property (weak, nonatomic) IBOutlet UIButton *btnSendServer;

- (IBAction)actionBack:(UIBarButtonItem *)sender;
- (IBAction)btnRemoveWorkImage:(UIButton *)sender;
- (IBAction)btnSendPDFTouchUpInside:(UIButton *)sender;
- (IBAction)btnSendMailTouchUpInside:(UIButton *)sender;
- (IBAction)btnSendServerTouchUpInside:(UIButton *)sender;

@end

@implementation SCReportCreateViewController

typedef NS_ENUM(NSInteger, ReportCreateEntryTag) {
    TagWorker = 1000,
    TagWorkImage1,
    TagWorkImage2,
    TagWorkImage3,
    TagZipPassword
};

static NSInteger const kSC_MAXLEN_WORKER       = 256; // 「作業者」入力文字数
static NSInteger const kSC_MAXLEN_ZIP_PASSWORD = 256; // 「ZIPファイルパスワード」入力文字数

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    [self creatTodayReport];
    // 色味の設定
    self.lblAppendWorkImage1.textColor = [SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f];
    self.lblAppendWorkImage2.textColor = [SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f];
    self.lblAppendWorkImage3.textColor = [SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f];
    [self.btnRemoveWorkImage1 setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnRemoveWorkImage1 setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:0.35f] forState:UIControlStateDisabled];
    [self.btnRemoveWorkImage2 setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnRemoveWorkImage2 setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:0.35f] forState:UIControlStateDisabled];
    [self.btnRemoveWorkImage3 setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnRemoveWorkImage3 setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:0.35f] forState:UIControlStateDisabled];
    [self.btnUserDefine setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    self.lblUserDefineCount.backgroundColor = [SCSystemData colorWithRGB:0xF4 green:0xF4 blue:0xF4 alpha:1.0f];
    [self.btnPeriodSetting setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    self.lblPeriodSettingCount.backgroundColor = [SCSystemData colorWithRGB:0xF4 green:0xF4 blue:0xF4 alpha:1.0f];
    [self.btnSendPDF setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnSendMail setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnSendServer setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];

    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_REPORT_CREATE", @"レポート作成");
    self.lblTitleDateTime.text = NSLocalizedString(@"RES_20018", @"日時:");
    self.lblTitleTimezone.text = NSLocalizedString(@"RES_20019", @"タイムゾーン:");
    self.lblTitleWorker.text = NSLocalizedString(@"RES_20020", @"作業者:");
    self.lblAppendWorkImage1.text = NSLocalizedString(@"BTN_APPEND_CAPTURE", @"写真追加");
    self.lblAppendWorkImage2.text = NSLocalizedString(@"BTN_APPEND_CAPTURE", @"写真追加");
    self.lblAppendWorkImage3.text = NSLocalizedString(@"BTN_APPEND_CAPTURE", @"写真追加");
    [self.btnRemoveWorkImage1 setTitle:NSLocalizedString(@"BTN_REMOVE_CAPTURE", @"削除") forState:UIControlStateNormal];
    [self.btnRemoveWorkImage2 setTitle:NSLocalizedString(@"BTN_REMOVE_CAPTURE", @"削除") forState:UIControlStateNormal];
    [self.btnRemoveWorkImage3 setTitle:NSLocalizedString(@"BTN_REMOVE_CAPTURE", @"削除") forState:UIControlStateNormal];
    [self.btnUserDefine setTitle:NSLocalizedString(@"TITLE_REPORT_USER_DEFINE", @"ユーザ定義設定") forState:UIControlStateNormal];
    [self.btnPeriodSetting setTitle:NSLocalizedString(@"TITLE_REPORT_PERIOD_SETTING", @"接続データ設定") forState:UIControlStateNormal];
    [self.btnSendPDF setTitle:NSLocalizedString(@"BTN_SEND_PDF", @"PDF送信") forState:UIControlStateNormal];
    [self.btnSendMail setTitle:NSLocalizedString(@"BTN_SEND_MAIL", @"XML送信") forState:UIControlStateNormal];
    [self.btnSendServer setTitle:NSLocalizedString(@"BTN_SEND_SERVER", @"サーバ送信") forState:UIControlStateNormal];
    
    // タップジェスチャー
    UITapGestureRecognizer* tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapGestureAction:)];
    [self.view addGestureRecognizer:tapGesture];

    // 画像１タップ
    UITapGestureRecognizer* imageSingleTap01 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureActionWorkImage:)];
    imageSingleTap01.numberOfTapsRequired = 1;
    self.imgvwWorkImage1.tag = TagWorkImage1;
    self.imgvwWorkImage1.userInteractionEnabled = YES;
    [self.imgvwWorkImage1 addGestureRecognizer:imageSingleTap01];
    
    // 画像２タップ
    UITapGestureRecognizer* imageSingleTap02 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureActionWorkImage:)];
    imageSingleTap02.numberOfTapsRequired = 1;
    self.imgvwWorkImage2.tag = TagWorkImage2;
    self.imgvwWorkImage2.userInteractionEnabled = YES;
    [self.imgvwWorkImage2 addGestureRecognizer:imageSingleTap02];
    
    // 画像３タップ
    UITapGestureRecognizer* imageSingleTap03 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureActionWorkImage:)];
    imageSingleTap03.numberOfTapsRequired = 1;
    self.imgvwWorkImage3.tag = TagWorkImage3;
    self.imgvwWorkImage3.userInteractionEnabled = YES;
    [self.imgvwWorkImage3 addGestureRecognizer:imageSingleTap03];
    
    // 画面表示データの更新
    self.txtWorker.tag = TagWorker;
    self.isWokerImage1 = NO;
    self.btnRemoveWorkImage1.tag = TagWorkImage1;
    self.btnRemoveWorkImage1.enabled = NO;
    self.isWokerImage2 = NO;
    self.btnRemoveWorkImage2.tag = TagWorkImage2;
    self.btnRemoveWorkImage2.enabled = NO;
    self.isWokerImage3 = NO;
    self.btnRemoveWorkImage3.tag = TagWorkImage3;
    self.btnRemoveWorkImage3.enabled = NO;
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.txtWorker.text = self.appData.manReport.operatorId;
    self.lblValueDateTime.text = [SCSystemData stringFromDate:[NSDate date] format:@"yyyy/MM/dd HH:mm"];
    self.lblValueTimezone.text = [NSTimeZone systemTimeZone].name;
    [self refreshOnlineSerialNo];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    
    self.appData.manReport = nil;
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    // ユーザ定義設定の表示
    NSInteger cntUserDefine = [SCReportFlow countSelectUserDefine];
    if (0 == cntUserDefine) {
        
        self.lblUserDefineCount.text = NSLocalizedString(@"RES_20021", @"未設定");
    } else {
        
        self.lblUserDefineCount.text = [NSString stringWithFormat:NSLocalizedString(@"RES_20022", @"合計"), [NSNumber numberWithInteger:cntUserDefine]];
    }
    
    // 接続データ設定の表示
    [SCReportFlow beginEditingSelectSpliceData];
    NSInteger cntSpliceData = [SCReportFlow countSelectSpliceDataWithCheckOn];
    [SCReportFlow endEditingSelectSpliceData:NO];
    if (0 == cntSpliceData) {
        
        self.lblPeriodSettingCount.text = NSLocalizedString(@"RES_20021", @"未設定");
    } else {
        
        self.lblPeriodSettingCount.text = [NSString stringWithFormat:NSLocalizedString(@"RES_20022", @"合計"), [NSNumber numberWithInteger:cntSpliceData]];
    }
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];

    // 色味の設定（レイアウト確定後）
    [self.btnRemoveWorkImage1 setBackgroundImage:[self setButtonHilightBackColor:self.btnRemoveWorkImage1.bounds] forState:UIControlStateHighlighted];
    [self.btnRemoveWorkImage2 setBackgroundImage:[self setButtonHilightBackColor:self.btnRemoveWorkImage2.bounds] forState:UIControlStateHighlighted];
    [self.btnRemoveWorkImage3 setBackgroundImage:[self setButtonHilightBackColor:self.btnRemoveWorkImage3.bounds] forState:UIControlStateHighlighted];
    [self.btnUserDefine setBackgroundImage:[self setButtonHilightBackColor:self.btnUserDefine.bounds] forState:UIControlStateHighlighted];
    [self.btnPeriodSetting setBackgroundImage:[self setButtonHilightBackColor:self.btnPeriodSetting.bounds] forState:UIControlStateHighlighted];
    [self.btnSendPDF setBackgroundImage:[self setButtonHilightBackColor:self.btnSendPDF.bounds] forState:UIControlStateHighlighted];
    [self.btnSendMail setBackgroundImage:[self setButtonHilightBackColor:self.btnSendMail.bounds] forState:UIControlStateHighlighted];
    [self.btnSendServer setBackgroundImage:[self setButtonHilightBackColor:self.btnSendServer.bounds] forState:UIControlStateHighlighted];
}

- (void)viewDidLayoutSubviews {
    
    [super viewDidLayoutSubviews];
    
    self.vwScroll.contentSize = self.vwContents.bounds.size;
}

#pragma mark - Action

/**
 画面タップでキーボード非表示

 @param sender <#sender description#>
 */
- (void)viewTapGestureAction:(UITapGestureRecognizer *)sender {
    
    [self.view endEditing:YES];
}

/**
 タップで画像選択（３つの画像の選択を制御する）

 @param sender <#sender description#>
 */
- (void)tapGestureActionWorkImage:(UITapGestureRecognizer *)sender {
    
    // 写真アクセスが「許可する」以外の場合は、メッセージを表示する
    if ([self isPhotosAuthDeniedAlert]) {

        return;
    }
    
    self.tagEditWorkImage = [sender view].tag;
    DDLogDebug(@"タップで画像選択（画像%@）", [NSNumber numberWithInteger:self.tagEditWorkImage]);
    
    UIImagePickerControllerSourceType photoSourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    if ([UIImagePickerController isSourceTypeAvailable:photoSourceType]) {
        
        UIImagePickerController *imgpickerCon = [[UIImagePickerController alloc] init];
        imgpickerCon.sourceType = photoSourceType;
        imgpickerCon.delegate = self;
        [self presentViewController:imgpickerCon animated:YES completion:nil];
    }
}


#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {

    DDLogDebug(@"");
    
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 削除ボタン（３つの画像の削除を制御する）

 @param sender <#sender description#>
 */
- (IBAction)btnRemoveWorkImage:(UIButton *)sender {

    DDLogDebug(@"画像削除（画像%@）", [NSNumber numberWithInteger:sender.tag]);
    
    if (sender.tag == self.btnRemoveWorkImage1.tag) {
        
        self.imgvwWorkImage1.image = [UIImage imageNamed:@"btn_photo_add"];
        self.lblAppendWorkImage1.hidden = NO;
        self.isWokerImage1 = NO;
        self.btnRemoveWorkImage1.enabled = NO;
    } else if (sender.tag == self.btnRemoveWorkImage2.tag) {
        
        self.imgvwWorkImage2.image = [UIImage imageNamed:@"btn_photo_add"];
        self.lblAppendWorkImage2.hidden = NO;
        self.isWokerImage2 = NO;
        self.btnRemoveWorkImage2.enabled = NO;
    } else if (sender.tag == self.btnRemoveWorkImage3.tag) {
        
        self.imgvwWorkImage3.image = [UIImage imageNamed:@"btn_photo_add"];
        self.lblAppendWorkImage3.hidden = NO;
        self.isWokerImage3 = NO;
        self.btnRemoveWorkImage3.enabled = NO;
    }
}

/**
 メール送信ボタン
 
 @param sender <#sender description#>
 */
- (IBAction)btnSendPDFTouchUpInside:(UIButton *)sender {
    
    // メール設定確認
    if (![MFMailComposeViewController canSendMail]) {
        
        DDLogError(@"メール設定異常");
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10018", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:nil];
        
        return;
    }
    
    // ZIPパスワード入力確認
    UIAlertController* alertZipPassword = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"RES_20038", @"ZIPパスワード入力") message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    [alertZipPassword addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        
        self.zipPassword = @"";
        textField.delegate = self;
        textField.text = self.zipPassword;
        textField.tag = TagZipPassword;
        textField.keyboardType = UIKeyboardTypeASCIICapable;
    }];
    
    [alertZipPassword addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        DDLogInfo(@"メール送信ボタン -> レポート作成");
        
        self.appData.manReport.zipPassword = self.zipPassword;
        self.appData.manReport.timeZone = self.lblValueTimezone.text;
        if (self.isWokerImage1) {
            
            self.appData.manReport.wokerImg1 = [[NSData alloc] initWithData:UIImageJPEGRepresentation(self.imgvwWorkImage1.image, 1.0)];
        } else {
            
            self.appData.manReport.wokerImg1 = nil;
        }
        if (self.isWokerImage2) {
            
            self.appData.manReport.wokerImg2 = [[NSData alloc] initWithData:UIImageJPEGRepresentation(self.imgvwWorkImage2.image, 1.0)];
        } else {
            
            self.appData.manReport.wokerImg2 = nil;
        }
        if (self.isWokerImage3) {
            
            self.appData.manReport.wokerImg3 = [[NSData alloc] initWithData:UIImageJPEGRepresentation(self.imgvwWorkImage3.image, 1.0)];
        } else {
            
            self.appData.manReport.wokerImg3 = nil;
        }
        
        [self showProgress:NSLocalizedString(@"PDF_00021", @"PDFデータを作成しています") cancelHandler:nil];
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            
            // レポートファイル作成
            [SCReportFlow createPDFReportFile:self.appData.selectedSerialNo];
            NSData* reportData = [NSData dataWithContentsOfFile:self.appData.manReport.zipFileName];
            DDLogDebug(@"メール送信添付レポートファイル名 >> <<%@>>", self.appData.manReport.zipFileName);
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [self hideProgress];
                // メーラー起動
                MFMailComposeViewController *vwConMail = [[MFMailComposeViewController alloc] init];
                vwConMail.mailComposeDelegate = self;
                [vwConMail setSubject:NSLocalizedString(@"RES_20040", @"サブジェクト")];
                [vwConMail addAttachmentData:reportData mimeType:@"application/octet-stream" fileName:[self.appData.manReport.zipFileName lastPathComponent]];
                [self presentViewController:vwConMail animated:YES completion:nil];
                
                // レポートファイル削除
                [[NSFileManager defaultManager] removeItemAtPath:self.appData.manReport.zipFileName error:nil];
            });
            
        });
        

    }]];
    
    [alertZipPassword addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }]];
    
    [self presentViewController:alertZipPassword animated:YES completion:^{
    }];
}

/**
 メール送信ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnSendMailTouchUpInside:(UIButton *)sender {
    
    // メール設定確認
    if (![MFMailComposeViewController canSendMail]) {
        
        DDLogError(@"メール設定異常");
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10018", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:nil];
        
        return;
    }
    
    // ZIPパスワード入力確認
    UIAlertController* alertZipPassword = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"RES_20038", @"ZIPパスワード入力") message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    [alertZipPassword addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        
        self.zipPassword = @"";
        textField.delegate = self;
        textField.text = self.zipPassword;
        textField.tag = TagZipPassword;
        textField.keyboardType = UIKeyboardTypeASCIICapable;
    }];

    [alertZipPassword addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {

        DDLogInfo(@"メール送信ボタン -> レポート作成");
        
        self.appData.manReport.zipPassword = self.zipPassword;
        self.appData.manReport.timeZone = self.lblValueTimezone.text;
        if (self.isWokerImage1) {
            
            self.appData.manReport.wokerImg1 = [[NSData alloc] initWithData:UIImageJPEGRepresentation(self.imgvwWorkImage1.image, 1.0)];
        } else {
            
            self.appData.manReport.wokerImg1 = nil;
        }
        if (self.isWokerImage2) {
            
            self.appData.manReport.wokerImg2 = [[NSData alloc] initWithData:UIImageJPEGRepresentation(self.imgvwWorkImage2.image, 1.0)];
        } else {
            
            self.appData.manReport.wokerImg2 = nil;
        }
        if (self.isWokerImage3) {
            
            self.appData.manReport.wokerImg3 = [[NSData alloc] initWithData:UIImageJPEGRepresentation(self.imgvwWorkImage3.image, 1.0)];
        } else {
            
            self.appData.manReport.wokerImg3 = nil;
        }
        
        // レポートファイル作成
        [SCReportFlow createReportFile:self.appData.selectedSerialNo];
        NSData* reportData = [NSData dataWithContentsOfFile:self.appData.manReport.zipFileName];
        DDLogDebug(@"メール送信添付レポートファイル名 >> <<%@>>", self.appData.manReport.zipFileName);
        
        // メーラー起動
        MFMailComposeViewController *vwConMail = [[MFMailComposeViewController alloc] init];
        vwConMail.mailComposeDelegate = self;
        [vwConMail setSubject:NSLocalizedString(@"RES_20040", @"サブジェクト")];
        [vwConMail addAttachmentData:reportData mimeType:@"application/octet-stream" fileName:[self.appData.manReport.zipFileName lastPathComponent]];
        
        [self presentViewController:vwConMail animated:YES completion:nil];
        
        // レポートファイル削除
        [[NSFileManager defaultManager] removeItemAtPath:self.appData.manReport.zipFileName error:nil];
    }]];

    [alertZipPassword addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }]];

    [self presentViewController:alertZipPassword animated:YES completion:^{
    }];
}


/**
 サーバ送信ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnSendServerTouchUpInside:(UIButton *)sender {

    DDLogInfo(@"サーバ送信ボタン -> レポート作成");

    // サーバ送信レポートの作成
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
    
    self.appData.manReport.timeZone = self.lblValueTimezone.text;
    if (self.isWokerImage1) {
        
        self.appData.manReport.wokerImg1 = [[NSData alloc] initWithData:UIImageJPEGRepresentation(self.imgvwWorkImage1.image, 1.0)];
    } else {
        
        self.appData.manReport.wokerImg1 = nil;
    }
    if (self.isWokerImage2) {
        
        self.appData.manReport.wokerImg2 = [[NSData alloc] initWithData:UIImageJPEGRepresentation(self.imgvwWorkImage2.image, 1.0)];
    } else {
        
        self.appData.manReport.wokerImg2 = nil;
    }
    if (self.isWokerImage3) {
        
        self.appData.manReport.wokerImg3 = [[NSData alloc] initWithData:UIImageJPEGRepresentation(self.imgvwWorkImage3.image, 1.0)];
    } else {
        
        self.appData.manReport.wokerImg3 = nil;
    }
    NSString* reportDate = [SCReportFlow createReportSendData:self.appData.selectedSerialNo];
    
    SCReportFlow* flow = [[SCReportFlow alloc] init];
    [flow runFlowSendServer:self.appData.selectedSerialNo reportDate:reportDate completion:^(NSError *error) {

        [self hideProgress];
        
        if (error) {
            
            DDLogError(@"サーバ送信エラー:<<%@>>", error.description);

            // エラーメッセージ
            NSString *msg = [NSString stringWithFormat:@"%@\n%@",
                             NSLocalizedString(@"MSG_10022", @"エラーメッセージ"),
                             NSLocalizedString(@"MSG_10023", @"エラーメッセージ")];
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            
            [self presentViewController:alert animated:YES completion:^{
            }];
        } else {
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:NSLocalizedString(@"MSG_10021", @"完了メッセージ") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            
            [self presentViewController:alert animated:YES completion:^{
            }];
        }
    }];
}


#pragma mark - UITextFieldDelegate

/**
 入力項目編集中

 @param textField <#textField description#>
 @param range <#range description#>
 @param string <#string description#>
 
 @return <#return value description#>
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSMutableString *val = [textField.text mutableCopy];
    [val replaceCharactersInRange:range withString:string];
    
    if (textField.tag == self.txtWorker.tag) {
        
        // 入力文字数チェック
        if (kSC_MAXLEN_WORKER < val.length) {
            
            return NO;
        }
        
        return YES;
    } else if (TagZipPassword == textField.tag) {
        
        // 禁則文字チェック(英数字(ASCII))
        NSCharacterSet *checkStr = [NSCharacterSet characterSetWithCharactersInString:val];
        NSMutableCharacterSet *isAlphaNumCharSet = [[NSMutableCharacterSet alloc] init];
        [isAlphaNumCharSet addCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZ"];
        [isAlphaNumCharSet addCharactersInString:@"abcdefghijklmnopqrstuvwxyz"];
        [isAlphaNumCharSet addCharactersInString:@"0123456789"];
        if (![isAlphaNumCharSet isSupersetOfSet:checkStr]) {
            
            return NO;
        }
        
        // 入力文字数チェック
        if (kSC_MAXLEN_ZIP_PASSWORD < val.length) {
            
            return NO;
        }
        
        return YES;
    }

    return NO;
}

/**
 入力項目編集終了

 @param textField <#textField description#>
 */
- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    // 作業者保存
    if (self.txtWorker.tag == textField.tag) {
        
        [SCSystemData setOperatorId:textField.text];
        self.appData.manReport.operatorId = textField.text;
    } else if (TagZipPassword == textField.tag) {
        
        self.zipPassword = textField.text;
    }
}


#pragma mark - UIImagePickerControllerDelegate

/**
 画像選択イベント

 @param picker <#picker description#>
 @param info <#info description#>
 */
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage* selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    [self dismissViewControllerAnimated:YES completion:^{
        
        DDLogDebug(@"画像選択");
        
        if (self.tagEditWorkImage == self.imgvwWorkImage1.tag) {
            
            self.imgvwWorkImage1.image = selectedImage;
            self.lblAppendWorkImage1.hidden = YES;
            self.isWokerImage1 = YES;
            self.btnRemoveWorkImage1.enabled = YES;
        } else if (self.tagEditWorkImage == self.imgvwWorkImage2.tag) {
            
            self.imgvwWorkImage2.image = selectedImage;
            self.lblAppendWorkImage2.hidden = YES;
            self.isWokerImage2 = YES;
            self.btnRemoveWorkImage2.enabled = YES;
        } else if (self.tagEditWorkImage == self.imgvwWorkImage3.tag) {
            
            self.imgvwWorkImage3.image = selectedImage;
            self.lblAppendWorkImage3.hidden = YES;
            self.isWokerImage3 = YES;
            self.btnRemoveWorkImage3.enabled = YES;
        }
    }];
}


#pragma mark - MFMailComposeViewControllerDelegate

/**
 メール送信後アクション

 @param controller <#controller description#>
 @param result <#result description#>
 @param error <#error description#>
 */
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    
    switch (result) {
        case MFMailComposeResultSaved:
        case MFMailComposeResultSent:
            DDLogDebug(@"メール送信操作（保存）または（送信）");
            break;
        case MFMailComposeResultFailed:
            DDLogError(@"メール送信操作（失敗）");
            break;
        case MFMailComposeResultCancelled:
        default:
            DDLogDebug(@"メール送信操作（キャンセル）");
            break;
    }
    
    [controller dismissViewControllerAnimated:YES completion:^{
    }];
}


#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

-(void)creatTodayReport{
    self.appData.manReport = [[SCReportManager alloc] init];
    self.appData.manReport.today = [SCSystemData stringFromDate:[NSDate date] format:@"yyyy/MM/dd"];
    self.appData.manReport.fromDate = self.appData.manReport.today;
    self.appData.manReport.toDate = self.appData.manReport.today;
    // レポート情報の初期化
    [SCReportFlow initializeReportEdit];
}

@end
