//
//  SCReportViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportViewController.h"
#import "SCReportTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCReportFlow.h"
#import "SCReportData.h"

@interface SCReportViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) NSMutableArray* listFunctionMenu;

@property (weak, nonatomic) IBOutlet UITableView *tblvwFunctionMenu;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@end

@implementation SCReportViewController

static NSString* const kRE_Title = @"Title";       // メニュータイトル
static NSString* const kRE_SegueId = @"SegueId";   // 画面遷移ID
static NSString* const kRE_CellType = @"CellType"; // 表示タイプ

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_REPORT", @"レポート");

    // 機能メニュー
    self.listFunctionMenu = [NSMutableArray arrayWithCapacity:0];
    [self.listFunctionMenu addObject:@{
                                       // "レポート作成"
                                       kRE_Title : @"TITLE_REPORT_CREATE",
                                       kRE_SegueId : @"toReportCreate",
                                       kRE_CellType : @"cell"
                                       }];
    [self.listFunctionMenu addObject:@{
                                       // "レポート一括送信"
                                       kRE_Title : @"RES_20017",
                                       kRE_SegueId : @"",
                                       kRE_CellType : @"cell"
                                       }];
    [self.listFunctionMenu addObject:@{
                                       // "フッターメッセージ"
                                       kRE_Title : @"MSG_10013",
                                       kRE_SegueId : @"",
                                       kRE_CellType : @"cellMsg"
                                       }];
    // TODO:一旦、対象外
    //[self.listFunctionMenu addObject:@{
    //                                   // "レポートメール作成回数購入"
    //                                   kRE_Title : @"TITLE_REPORT_MAIL_PURCHASE",
    //                                   kRE_SegueId : @"toMailPurchase"
    //                                   }];
    // TODO:一旦、対象外

    // 画面表示データの更新
    self.tblvwFunctionMenu.estimatedRowHeight = 44.0f;
    self.tblvwFunctionMenu.rowHeight = UITableViewAutomaticDimension;
    self.tblvwFunctionMenu.tableFooterView = [[UIView alloc] init];
    [self refreshSelectedSerialNo];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    // メニュー更新
    [self.tblvwFunctionMenu reloadData];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}


#pragma mark - Segue

/**
 <#Description#>
 
 @param segue  <#segue description#>
 @param sender <#sender description#>
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    DDLogDebug(@"");
    
    if ([@"toLeftMenu" isEqualToString:segue.identifier]) {
        
        segue.destinationViewController.modalPresentationStyle = UIModalPresentationCustom;
        segue.destinationViewController.transitioningDelegate = self;
    } else if ([@"toReportCreate" isEqualToString:segue.identifier]) {
        
        self.appData.manReport = [[SCReportManager alloc] init];

        // レポート情報の初期化
        [SCReportFlow initializeReportEdit];
    }
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param section   <#section description#>
 
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listFunctionMenu.count;
}

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary* dic = [self.listFunctionMenu objectAtIndex:indexPath.row];
    NSString* cellType = dic[kRE_CellType];
    
    SCReportTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellType];

    if ([cellType isEqualToString:@"cell"]) {
        
        cell.userInteractionEnabled = YES;
        
        cell.lblTitle.text = NSLocalizedString(dic[kRE_Title], @"ラベル");
        cell.lblTitle.enabled = YES;
        cell.lblDetail.text = @"";
        cell.lblDetail.enabled = YES;
        
        if ([@"RES_20017" isEqualToString:dic[kRE_Title]]) {
            
            NSInteger count = [SCReportFlow unsentReportCount];
            if (0 == count) {
                
                cell.lblDetail.text = NSLocalizedString(@"MSG_10009", @"未送信データなし");
                cell.lblTitle.enabled = NO;
                cell.lblDetail.enabled = NO;
            } else {
                
                cell.lblDetail.text = NSLocalizedString(@"MSG_10010", @"未送信データあり");
            }
        }
    } else {
        
        cell.userInteractionEnabled = NO;
        
        cell.textLabel.text = NSLocalizedString(dic[kRE_Title], @"ラベル");
        cell.textLabel.enabled = YES;
        cell.textLabel.numberOfLines = 0;
    }
    
    return cell;
}

/**
 メニュー選択
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary* dic = [self.listFunctionMenu objectAtIndex:indexPath.row];
    
    NSString* segueId = dic[kRE_SegueId];
    if (segueId.length) {
        
        // "レポート作成"
        // "レポートメール作成回数"
        DDLogDebug(@"画面遷移 -->> %@", segueId);
        
        // レポート作成の場合は融着機未選択か判定
        if ([segueId isEqualToString:@"toReportCreate"]) {
            
            if ([self isUnselectSplicerAlert]) {

                return;
            }
        }
        
        [self performSegueWithIdentifier:segueId sender:self];
    } else if ([@"RES_20017" isEqualToString:dic[kRE_Title]]) {
        
        // "レポート一括送信"
        SCReportTableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
        if (cell.lblTitle.enabled) {
            
            // Wi-Fi切り替え確認
            if (![self isMobileConnect]) {
                
                [self connectSplicerAlert];
                
                return;
            }
            
            // 活性のメニューの場合、レポート一括送信を実施する
            [self sendReport];
        }
    }
}


#pragma mark - Private Method

/**
 レポート一括送信
 */
- (void)sendReport {
    
    DDLogDebug(@"レポート一括送信");
    
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSArray* listReportData = [SCReportFlow unsentReportList];
        DDLogInfo(@"レポート一括送信:未送信件数<%@>", [NSNumber numberWithInteger:listReportData.count]);
        
        NSError* error = nil;
        
        SCReportFlow* flow = [[SCReportFlow alloc] init];
        for (SCReportData* item in listReportData) {
            
            // レポート送信
            error = [flow uploadReport:item.serialno reportDate:item.report_date];
            
            // レポート送信エラー判定
            if (error) {
                
                break;
            }
        }
        
        [self hideProgress];
        
        if (error) {
            
            DDLogError(@"レポート一括送信エラー:<<%@>>", error.description);
            
            // エラーメッセージ
            NSString *msg = [NSString stringWithFormat:@"%@\n%@",
                             NSLocalizedString(@"MSG_10022", @"エラーメッセージ"),
                             NSLocalizedString(@"MSG_10023", @"エラーメッセージ")];
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            
            [self presentViewController:alert animated:YES completion:^{
            }];
        } else {
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:NSLocalizedString(@"MSG_10021", @"完了メッセージ") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            
            [self presentViewController:alert animated:YES completion:^{
            }];
        }
        
        // メニュー更新
        [self.tblvwFunctionMenu reloadData];
    });
}


#pragma mark - Override Method

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");

    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
    
    // メニュー更新
    [self.tblvwFunctionMenu reloadData];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

@end
