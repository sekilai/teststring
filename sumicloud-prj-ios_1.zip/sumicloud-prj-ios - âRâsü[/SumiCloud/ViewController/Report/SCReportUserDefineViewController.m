//
//  SCReportUserDefineViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportUserDefineViewController.h"
#import "SCReportUserDefineTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCReportFlow.h"
#import "SCSelectUserDefine.h"

@interface SCReportUserDefineViewController () <UITableViewDelegate, UITableViewDataSource,  SCReportUserDefineTableViewCellDelegate>

@property (nonatomic) NSMutableArray* listReportData;
@property (nonatomic) NSIndexPath* editRow;
@property (nonatomic) CGSize vwTableOffset;
@property (nonatomic) CGPoint vwTableOrignalOffsetOSize;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UITableView *tblvwUserDefine;

@property (weak, nonatomic) IBOutlet UIButton *btnCancel;
@property (weak, nonatomic) IBOutlet UIButton *btnCommit;

- (IBAction)actionBack:(UIBarButtonItem *)sender;
- (IBAction)btnCancelTouchUpInside:(UIButton *)sender;
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender;

@end

@implementation SCReportUserDefineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    [self.btnCancel setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnCommit setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];

    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_REPORT_USER_DEFINE", @"ユーザ定義設定");
    [self.btnCancel setTitle:NSLocalizedString(@"BTN_CLEAR", @"クリア") forState:UIControlStateNormal];
    [self.btnCommit setTitle:NSLocalizedString(@"BTN_SETTING", @"設定") forState:UIControlStateNormal];

    // 画面表示データの更新
    self.tblvwUserDefine.estimatedRowHeight = 78.0f;
    self.tblvwUserDefine.rowHeight = UITableViewAutomaticDimension;
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    [self refreshOnlineSerialNo];

    // タップジェスチャー
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapGestureAction:)];
    [self.view addGestureRecognizer:tapGesture];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];

    // キーボード表示制御
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    // 編集リストの更新
    [SCReportFlow beginEditingSelectUserDefine];
    [self refreshEditingList];
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    // 色味の設定（レイアウト確定後）
    [self.btnCancel setBackgroundImage:[self setButtonHilightBackColor:self.btnCancel.bounds] forState:UIControlStateHighlighted];
    [self.btnCommit setBackgroundImage:[self setButtonHilightBackColor:self.btnCommit.bounds] forState:UIControlStateHighlighted];
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];

    [self.view endEditing:YES];
    // キーボード表示制御
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


#pragma mark - Action

/**
 *  画面タップでキーボード非表示
 *
 *  @param sender <#sender description#>
 */
- (void)viewTapGestureAction:(UITapGestureRecognizer *)sender {
    
    [self.view endEditing:YES];
}

/**
 キーボード表示制御
 
 @param notification <#notification description#>
 */
- (void)keyboardWillShow:(NSNotification *)notification {
    
    // 高さ変更(キーボードの分縮める)
    CGRect keyboardRect = [[notification userInfo][UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    // オフセットから表示サイズを求める
    self.vwTableOrignalOffsetOSize = self.tblvwUserDefine.contentOffset;
    
    // セル位置（画面上の絶対位置）
    UITableViewCell* cell = [self.tblvwUserDefine cellForRowAtIndexPath:self.editRow];
    CGFloat cellBottom = cell.frame.origin.y + cell.frame.size.height - self.tblvwUserDefine.contentOffset.y + self.tblvwUserDefine.frame.origin.y + self.navigationController.navigationBar.frame.size.height + [UIApplication sharedApplication].statusBarFrame.size.height;
    
    // 位置判定
    if (keyboardRect.origin.y < cellBottom) {
        
        // 表示中のをキーボードの上に移動
        CGPoint newPos = CGPointMake(self.tblvwUserDefine.contentOffset.x, self.tblvwUserDefine.contentOffset.y + cellBottom - keyboardRect.origin.y);
        [self.tblvwUserDefine setContentOffset:newPos animated:YES];
    }
    
    self.tblvwUserDefine.scrollEnabled = NO;
}

/**
 キーボード非表示制御
 
 @param notification <#notification description#>
 */
- (void)keyboardWillHide:(NSNotification *)notification {

    self.tblvwUserDefine.scrollEnabled = YES;
    
    // オフセットに戻す
    [self.tblvwUserDefine setContentOffset:self.vwTableOrignalOffsetOSize];
}


#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {

    DDLogDebug(@"");
    
    // 編集中のユーザ定義設定を破棄する
    [SCReportFlow endEditingSelectUserDefine:NO];

    // レポート作成画面へ戻る
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 キャンセルボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCancelTouchUpInside:(UIButton *)sender {

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_11003", @"ユーザ定義設定クリア") preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        DDLogInfo(@"キャンセルボタン -> ユーザ定義設定");

        // 作成中のユーザ定義設定をクリアする
        [SCReportFlow setSelectUserDefineList:self.appData.manReport.defaultUserDefineList];
        [SCReportFlow endEditingSelectUserDefine:YES];
        
        // レポート作成画面へ戻る
        [self.navigationController popViewControllerAnimated:YES];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

/**
 設定ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender {

    DDLogInfo(@"設定ボタン -> ユーザ定義設定");

    // 作成中のユーザ定義設定を保存する
    [SCReportFlow setSelectUserDefineList:self.listReportData];
    [SCReportFlow endEditingSelectUserDefine:YES];
    
    // レポート作成画面へ戻る
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listReportData.count;
}

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SCReportUserDefineTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    // 多言語対応
    cell.lblTitleItem.text = NSLocalizedString(@"RES_20023", @"アイテムの入力");
    cell.lblTitleValue.text = NSLocalizedString(@"RES_20024", @"値の入力");
    
    cell.delegate = self;
    SCSelectUserDefine* item = [self.listReportData objectAtIndex:indexPath.row];
    cell.isCheckBoxON = item.check_state;
    cell.txtItem.text = item.user_define_item;
    cell.txtValue.text = item.user_define_value;
    
    [cell refreshCell];
    
    return cell;
}


#pragma mark - SCReportUserDefineTableViewCellDelegate

/**
 チェックボックスの状態更新

 @param cell <#cell description#>
 */
- (void)changeCBState:(UITableViewCell *)cell {
    
    [self.view endEditing:YES];
    
    NSIndexPath* indexPath = [self.tblvwUserDefine indexPathForCell:cell];
    SCSelectUserDefine* item = [self.listReportData objectAtIndex:indexPath.row];
    
    if (item.check_state) {
        
        item.check_state = NO;
    } else {
        
        item.check_state = YES;
    }
    
    // 編集対象のユーザ定義設定を更新
    [SCReportFlow editingSelectUserDefineList:self.listReportData];
    
    // 編集リストの更新
    [self refreshEditingList];
}

/**
 編集開始

 @param cell <#cell description#>
 */
- (void)shouldBeginEdit:(UITableViewCell *)cell {
    
    self.editRow = [self.tblvwUserDefine indexPathForCell:cell];
}

/**
 編集終了

 @param cell <#cell description#>
 */
- (void)didEndEdit:(UITableViewCell *)cell {
    
    NSIndexPath* indexPath = [self.tblvwUserDefine indexPathForCell:cell];
    
    SCSelectUserDefine* item = [self.listReportData objectAtIndex:indexPath.row];
    item.user_define_item = ((SCReportUserDefineTableViewCell *)cell).txtItem.text;
    item.user_define_value = ((SCReportUserDefineTableViewCell *)cell).txtValue.text;
}


#pragma mark - Private Method

/**
 編集リストの更新
 */
- (void)refreshEditingList {
    
    // ユーザ定義設定の入力行更新
    self.listReportData = [NSMutableArray arrayWithArray:[SCReportFlow getSelectUserDefineList]];
    if (self.listReportData.count < kSC_MAX_SELECTED_USER_DEFINE) {
        
        // 最大件数未設定の場合は、空行を追加
        SCSelectUserDefine* entry = [[SCSelectUserDefine alloc] init];
        [self.listReportData addObject:entry];
    }
    
    [self.tblvwUserDefine reloadData];
    
    // オフセットを更新
    self.vwTableOffset = CGSizeMake(self.tblvwUserDefine.contentSize.width, self.tblvwUserDefine.contentSize.height);
}


#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

@end
