//
//  SCBaseReportViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/12/27.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseReportViewController.h"
#import "SCLogUtil.h"

#import "SCReportFlow.h"

@interface SCBaseReportViewController ()

@end

@implementation SCBaseReportViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/**
 接続データ設定編集破棄
 */
- (void)cancelSpliceDataEdit {

    // 編集中の接続データ設定を破棄
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_11002", @"接続データクリア") preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        DDLogWarn(@"接続データ設定編集破棄");
        
        // 作成中のレポート情報をクリアする
        [SCReportFlow endEditingSelectSpliceData:NO];
        
        // レポート情報の初期化
        [SCReportFlow initializeReportEdit];
        
        // レポート作成画面へ戻る
        [self.navigationController popToViewController:self.navigationController.viewControllers[1] animated:YES];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

@end
