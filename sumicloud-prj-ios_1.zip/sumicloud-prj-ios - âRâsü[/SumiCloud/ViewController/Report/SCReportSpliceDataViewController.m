//
//  SCReportSpliceDataViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportSpliceDataViewController.h"
#import "SCReportSpliceDataTableViewCell.h"
#import "SCReportSpliceDataReferenceViewController.h"
#import "SCReportSpliceDataJudgementViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCReportFlow.h"
#import "SCSelectSpliceData.h"
#import "SCSpliceDataDao.h"

@interface SCReportSpliceDataViewController () <UITableViewDelegate, UITableViewDataSource, SCReportSpliceDataTableViewCellDelegate, SCReportSpliceDataReferenceViewControllerDelegate>

@property (nonatomic) NSArray* listReportData;
@property (nonatomic) NSMutableArray* checkedDataList;
@property (nonatomic) NSIndexPath* editRow;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UIView *vwMessage;
@property (weak, nonatomic) IBOutlet UILabel *lblMessage;

@property (weak, nonatomic) IBOutlet UITableView *tblvwSpliceDataList;

@property (weak, nonatomic) IBOutlet UIView *vwHeading;
@property (weak, nonatomic) IBOutlet UILabel *lblTime;
@property (weak, nonatomic) IBOutlet UILabel *lblDB;
@property (weak, nonatomic) IBOutlet UILabel *lblGPS;
@property (weak, nonatomic) IBOutlet UILabel *lblPhoto;

@property (weak, nonatomic) IBOutlet UIButton *btnCancel;
@property (weak, nonatomic) IBOutlet UIButton *btnCommit;
@property (weak, nonatomic) IBOutlet UIButton *btnSelect;

- (IBAction)actionBack:(UIBarButtonItem *)sender;
- (IBAction)btnCancelTouchUpInside:(UIButton *)sender;
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender;
- (IBAction)btnSelectTouchUpInside:(UIButton *)sender;

@end

@implementation SCReportSpliceDataViewController

static NSString* const kRSD_CB_STATE = @"cb_state";      // チェックボックス状態
static NSString* const kRSD_SPLICE_DATA = @"spliceData"; // 接続データ

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    self.checkedDataList = [[NSMutableArray alloc] init];
    // 色味の設定
    self.vwMessage.backgroundColor = [SCSystemData colorWithRGB:0xF4 green:0xF4 blue:0xF4 alpha:1.0f];
    self.vwHeading.backgroundColor = [SCSystemData colorWithRGB:0xDB green:0xDB blue:0xDB alpha:1.0f];
    [self.btnCancel setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnCommit setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnSelect setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];

    // 多言語対応
    self.lblMessage.text = NSLocalizedString(@"MSG_10015", @"レポートを作成する接続データを選択してください");
    self.lblTime.text = NSLocalizedString(@"RES_20010", @"Time");
    self.lblDB.text = [SCSystemData isModelType72M:self.appData.selectedSerialNo] ? NSLocalizedString(@"UNIT_01_MAX", @"dB(Max)") : NSLocalizedString(@"UNIT_01", @"dB");
    self.lblGPS.text = NSLocalizedString(@"RES_20011", @"GPS");
    self.lblPhoto.text = NSLocalizedString(@"RES_20012", @"Photo");
    [self.btnCancel setTitle:NSLocalizedString(@"BTN_CLEAR", @"クリア") forState:UIControlStateNormal];
    [self.btnCommit setTitle:NSLocalizedString(@"BTN_APPEND_REPORT", @"レポートに添付") forState:UIControlStateNormal];
    [self.btnSelect setTitle:NSLocalizedString(@"BTN_SELECT_ALL", @"全選択") forState:UIControlStateNormal];
    
    // 画面表示データの更新
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    [self refreshOnlineSerialNo];
    
    // 編集対象の接続データ設定一覧を取得
    [SCReportFlow beginEditingSelectSpliceData];
    self.listReportData = [SCReportFlow makeEditingSelectSpliceDataList];
    
    // 期間を表示
    NSString* titleFormat = NSLocalizedString(@"TITLE_REPORT_SPLICE_DATA", @"期間表示");
    self.title = [NSString stringWithFormat:titleFormat, self.appData.manReport.fromDate, self.appData.manReport.toDate];
    
    [self.tblvwSpliceDataList reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    // 色味の設定（レイアウト確定後）
    [self.btnCancel setBackgroundImage:[self setButtonHilightBackColor:self.btnCancel.bounds] forState:UIControlStateHighlighted];
    [self.btnCommit setBackgroundImage:[self setButtonHilightBackColor:self.btnCommit.bounds] forState:UIControlStateHighlighted];
    [self.btnSelect setBackgroundImage:[self setButtonHilightBackColor:self.btnSelect.bounds] forState:UIControlStateHighlighted];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}


#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {

    DDLogDebug(@"");
    
    // 接続データ編集破棄
    [SCReportFlow endEditingSelectSpliceData:NO];
    
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 キャンセルボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCancelTouchUpInside:(UIButton *)sender {

    DDLogDebug(@"キャンセルボタン -> 接続データ設定");

    [self cancelSpliceDataEdit];
}

/**
 レポートに添付ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender {

    // 接続データ設定件数チェック
    NSInteger count = [SCReportFlow countSelectSpliceDataWithCheckOn];
    if (kSC_MAX_SELECTED_SPLICE_DATA < count) {
        
        NSString* errorMsg = [NSString stringWithFormat:NSLocalizedString(@"MSG_12007", @"接続データ最大"), [NSNumber numberWithInteger:kSC_MAX_SELECTED_SPLICE_DATA], [NSNumber numberWithInteger:count]];
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:errorMsg preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        }]];
        
        [self presentViewController:alert animated:YES completion:^{
        }];
        
        return;
    }

    DDLogInfo(@"レポートに添付ボタン -> 接続データ設定");
    
    // 接続データ編集確定
    [SCReportFlow endEditingSelectSpliceData:YES];
    
    [self performSegueWithIdentifier:@"toReportJudgement" sender:self];
}

/**
 「Select All」ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnSelectTouchUpInside:(UIButton *)sender {
    
    int listReportDataCount = 0;
    int checkStateCount = 0;
    
    for (NSArray* list in self.listReportData) {
        
        for (SCSelectSpliceData* item in  list) {
            
            listReportDataCount++;
            
            if (!item.check_state) {
                item.check_state = YES;
            }else {
                checkStateCount++;
            }
           
        }
    }
    
    for (NSArray* list in self.listReportData) {
        
        for (SCSelectSpliceData* item in  list) {
            
            if (checkStateCount != 0 && (checkStateCount == listReportDataCount)) {
                item.check_state = NO;
                 [self.btnSelect setTitle:NSLocalizedString(@"BTN_SELECT_ALL", @"全選択") forState:UIControlStateNormal];
                
            }else {
                
                [self.btnSelect setTitle:NSLocalizedString(@"BTN_REMOVE_ALL", @"全解除") forState:UIControlStateNormal];
            }
        }
    }
    
    DDLogInfo(@"「Select All」ボタン -> 接続データ設定");
    
    [self.tblvwSpliceDataList reloadData];
}


#pragma mark - Segue

/**
 画面遷移

 @param segue <#segue description#>
 @param sender <#sender description#>
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    DDLogDebug(@"%@", segue.identifier);
    
    if ([@"toSpliceDataReference" isEqualToString:segue.identifier]) {
        
        NSArray* list = [self.listReportData objectAtIndex:self.editRow.section];
        SCSelectSpliceData* item = [list objectAtIndex:self.editRow.row];
        
        self.appData.manReport.selectDateTime = item.datetime;
        
        // 接続データ詳細取得
        self.appData.detailSpliceData = [SCReportFlow getSpliceData:self.appData.selectedSerialNo datetime:self.appData.manReport.selectDateTime];
        NSArray* split = [self.appData.manReport.selectDateTime componentsSeparatedByString:@" "];
        NSString* date = split[0];
        NSString* time = [split[1] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        self.appData.T72M_SpliceDataDetailList = [[[SCSpliceDataDao alloc] init] getWith72MDetailDateList:self.appData.selectedSerialNo date:date time:time];
        
        SCReportSpliceDataReferenceViewController* vwCon = segue.destinationViewController;
        vwCon.delegate = self;
    } else if ([@"toReportJudgement" isEqualToString:segue.identifier]) {
        [self.checkedDataList removeAllObjects];
        for (NSArray* list in self.listReportData) {
            for (SCSelectSpliceData* item in list) {
                if (item.check_state == YES) {
                    [self.checkedDataList addObject:item];
                }
            }
        }
        
        SCReportSpliceDataJudgementViewController* vc = segue.destinationViewController;
        vc.listReportData = [NSArray arrayWithArray:self.checkedDataList];
    }
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化

 @param tableView <#tableView description#>
 @return <#return value description#>
 */
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.listReportData.count;
}

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {

    NSArray* list = [self.listReportData objectAtIndex:section];
    SCSelectSpliceData* selectSplice = [list firstObject];
    
    NSArray* datetimeSplit = [selectSplice.datetime componentsSeparatedByString:@" "];
    
    return datetimeSplit[0];
}

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSArray* list = [self.listReportData objectAtIndex:section];
    return list.count;
}

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    SCReportSpliceDataTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.delegate = self;

    NSArray* list = [self.listReportData objectAtIndex:indexPath.section];
    SCSelectSpliceData* item = [list objectAtIndex:indexPath.row];
    NSArray* datetimeSplit = [item.datetime componentsSeparatedByString:@" "];
    
    cell.isCheckBoxON = item.check_state;
    cell.lblTime.text = datetimeSplit[1];
    cell.lblDB.text = [SCSystemData stringFromDoubleString:item.estimated_loss decimalLength:2];
    if ([SCSystemData isModelTypeT502:item.serialno]) {
        cell.lblDB.text = item.estimated_loss.length ? [SCSystemData stringFromDoubleString:item.estimated_loss decimalLength:2] : @"---";
    }
    if ([SCSystemData isModelType72M:item.serialno]) {
        cell.lblDB.text = [item.estimate_display_flag isEqualToString:@"1"] ? [SCSystemData stringFromDoubleString:item.estimated_loss decimalLength:2] : @"--";
    }
    if (![SCSystemData isModelType72M:item.serialno]) {
        [cell getColorEstimatedLoss:item.estimated_loss estLossLimit:item.est_loss_limit];
    }
    if ([@"0" isEqualToString:item.image_flg]) {
        
        cell.imgvwPhoto.hidden = YES;
    } else {
        
        cell.imgvwPhoto.hidden = NO;
    }
    if ((0 == item.lat.length) || (0 == item.lon.length)) {
        
        cell.imgvwGPS.hidden = YES;
    } else {
        
        cell.imgvwGPS.hidden = NO;
    }
    
    [cell refreshCell];

    return cell;
}

/**
 接続データ選択

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    DDLogDebug(@"");
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    self.editRow = indexPath;
    
    [self performSegueWithIdentifier:@"toSpliceDataReference" sender:self];
}


#pragma mark - SCReportSpliceDataTableViewCellDelegate

/**
 チェックボックスの状態更新

 @param cell <#cell description#>
 */
- (void)changeCBState:(UITableViewCell *)cell {
    
    NSIndexPath* indexPath = [self.tblvwSpliceDataList indexPathForCell:cell];
    NSArray* list = [self.listReportData objectAtIndex:indexPath.section];
    SCSelectSpliceData* item = [list objectAtIndex:indexPath.row];
    
    if (item.check_state) {
        item.check_state = NO;
    } else {
        item.check_state = YES;
    }
    
    //
    [self selectSpliceData:item];
    
    [self.tblvwSpliceDataList reloadData];
}

/**
 <#Description#>

 @param item <#item description#>
 */
-(void)selectSpliceData:(SCSelectSpliceData*)item {
    
    int listReportDataCount = 0;
    int checkStateCount = 0;
    
    for (NSArray* list in self.listReportData) {
        
        for (SCSelectSpliceData* item in  list) {
            
            listReportDataCount++;
            
            if (item.check_state) {
                
                checkStateCount++;
                
            }else {
                
                checkStateCount--;
                
                if (checkStateCount <= 0) {
                    
                    checkStateCount = 0;
                    
                }
            }
            
        }
    }
    if (checkStateCount >= listReportDataCount) {
        
        checkStateCount = listReportDataCount;
        
    }
    
    if (!item.check_state) {
        [self.btnSelect setTitle:NSLocalizedString(@"BTN_SELECT_ALL", @"全選択") forState:UIControlStateNormal];
    }else if ((checkStateCount != 0) &&(checkStateCount == listReportDataCount)) {
        [self.btnSelect setTitle:NSLocalizedString(@"BTN_REMOVE_ALL", @"全解除") forState:UIControlStateNormal];
    }
}


#pragma mark - SCReportSpliceDataReferenceViewControllerDelegate

/**
 接続データ選択
 */
- (void)selectedSpliceData {
    
    DDLogDebug(@"");
    
    NSArray* list = [self.listReportData objectAtIndex:self.editRow.section];
    SCSelectSpliceData* item = [list objectAtIndex:self.editRow.row];
    item.check_state = YES;
  
    [self selectSpliceData:item];
    
    [self.tblvwSpliceDataList reloadData];
}


#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

@end
