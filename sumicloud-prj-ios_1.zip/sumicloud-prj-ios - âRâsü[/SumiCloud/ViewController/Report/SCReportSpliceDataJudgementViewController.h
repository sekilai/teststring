//
//  SCReportSpliceDataJudgementViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/12/09.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseReportViewController.h"

@interface SCReportSpliceDataJudgementViewController : SCBaseReportViewController
@property (nonatomic) NSArray* listReportData;

@end
