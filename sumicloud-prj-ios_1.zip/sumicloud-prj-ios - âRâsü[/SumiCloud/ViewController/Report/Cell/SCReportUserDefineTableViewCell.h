//
//  SCReportUserDefineTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/11/21.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SCReportUserDefineTableViewCellDelegate <NSObject>

// チェックボックスの状態更新
- (void)changeCBState:(UITableViewCell *)cell;

- (void)shouldBeginEdit:(UITableViewCell *)cell;
- (void)didEndEdit:(UITableViewCell *)cell;

@end

@interface SCReportUserDefineTableViewCell : UITableViewCell

@property (nonatomic) id<SCReportUserDefineTableViewCellDelegate> delegate;

@property (nonatomic) BOOL isCheckBoxON;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwCheckBox;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleItem;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleValue;
@property (weak, nonatomic) IBOutlet UITextField *txtItem;
@property (weak, nonatomic) IBOutlet UITextField *txtValue;

// セル更新
- (void)refreshCell;

@end
