//
//  SCReportSplice72MDataJudgementCell.m
//  SumiCloud
//
//  Created by fsi_mac_6 on 2019/04/02.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCReportSplice72MDataJudgementCell.h"
#import "DigestTool.h"


#define plusBtnTag 103
#define lossTfTag 102
#define minusBtnTag 101
#define lossLabelTag 104
#define maxViewTag 1017

@implementation SCReportSplice72MDataJudgementCell 

{
    DataChangedCallBack _tempCallBack;
    SCSelectSpliceData * _tempSpliceData;
    JudgementChangedCallBack _judgementCallBack;
    BOOL firstShow;
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self initAllInfoViews];
    
}

-(void)initAllInfoViews{
    
//    NSLocalizedString(@"MSG_10022", @"エラーメッセージ")
    self.dateTitle.text = NSLocalizedString(@"RES_20018", @"日時：");
    self.measurementTitle.text = NSLocalizedString(@"RES_20055", @"測定値");
    self.lossTitle.text = NSLocalizedString(@"SP_DETAIL_06", @"推定ロス値");
    [self.allWriteBtn setTitle:NSLocalizedString(@"RES_20056", @"すべてに設定") forState:UIControlStateNormal];
    self.judgementLbl.text = NSLocalizedString(@"RES_20029", @"判定:");
    [self.judgementBtn setTitle:NSLocalizedString(@"REP_JUDGE_NOT", @"未選択") forState:UIControlStateNormal];
    self.maxLossLabel.text = NSLocalizedString(@"PDF_00033", @"max");
    
    self.allInfoViews = [[NSMutableArray alloc] init];
    
    for (NSInteger i = 1001; i <= 1016; i++) {
        UIView * infoView = (UIView *)[self.listStackView viewWithTag:i];
        [self.allInfoViews addObject:infoView];
    }
    
    for (UIView * tempView in self.allInfoViews) {
        UIButton * plusBtn = (UIButton *)[tempView viewWithTag:plusBtnTag];
        UIButton * minusBtn = (UIButton *)[tempView viewWithTag:minusBtnTag];
        [plusBtn addTarget:self action:@selector(plusBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [minusBtn addTarget:self action:@selector(minusBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        [plusBtn setImage:[UIImage imageNamed:@"icon_plus.png"] forState:UIControlStateNormal];
        [minusBtn setImage:[UIImage imageNamed:@"icon_minus.png"] forState:UIControlStateNormal];
        plusBtn.tintColor = [UIColor blackColor];
        plusBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [plusBtn setImageEdgeInsets:UIEdgeInsetsMake(4, 0, 4, 0)];
        minusBtn.tintColor = [UIColor blackColor];
        minusBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [minusBtn setImageEdgeInsets:UIEdgeInsetsMake(4, 0, 4, 0)];
        
        UITextField * tf = (UITextField *)[tempView viewWithTag:lossTfTag];
        tf.delegate = self;
    }
    
    _allWriteTf.delegate = self;
    
    [self.allWriteBtn addTarget:self action:@selector(allWriteBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.judgementBtn addTarget:self action:@selector(judgementBtnClicked) forControlEvents:UIControlEventTouchUpInside];
}

-(void)plusBtnClicked:(UIButton *)btn {
    UIView * btn_super_view = btn.superview;
    UITextField * lossTF = (UITextField *)[btn_super_view viewWithTag:lossTfTag];
    float value = [lossTF.text floatValue] + 0.01;
    if (value > 99.99) {
        value = 99.99;
    }
    lossTF.text = [NSString stringWithFormat:@"%0.2f", value];
    
    if (_tempCallBack != nil && _tempSpliceData != nil) {
        
        NSInteger index = [self.allInfoViews indexOfObject:btn_super_view];
        [_tempSpliceData.measurementList replaceObjectAtIndex:index withObject:[NSString stringWithFormat:@"%0.2f", value]];
        
        _tempCallBack(_tempSpliceData);
    }
    [self calculateMax];
}

-(void)minusBtnClicked:(UIButton *)btn {
    UIView * btn_super_view = btn.superview;
    UITextField * lossTF = (UITextField *)[btn_super_view viewWithTag:lossTfTag];
    float value = [lossTF.text floatValue] - 0.01;
    if (value < 0) {
        value = 0.00;
    }
    lossTF.text = [NSString stringWithFormat:@"%0.2f", value];
    if (_tempCallBack != nil && _tempSpliceData != nil) {
        
        NSInteger index = [self.allInfoViews indexOfObject:btn_super_view];
        [_tempSpliceData.measurementList replaceObjectAtIndex:index withObject:[NSString stringWithFormat:@"%0.2f", value]];
        
        _tempCallBack(_tempSpliceData);
    }
    [self calculateMax];
}

-(void)allWriteBtnClicked{
    
    NSString * writeText = [self.allWriteTf.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString * resultString;
    if ([writeText length] == 0) {
        for (UIView * tempView in self.allInfoViews) {
            UITextField * lossTF = (UITextField *)[tempView viewWithTag:lossTfTag];
            lossTF.text = @"";
            resultString = @"";
        }
        
    } else {
        float value = [self.allWriteTf.text floatValue];
        if (value < 0) {
            value = 0.00;
        }
        
        for (UIView * tempView in self.allInfoViews) {
            UITextField * lossTF = (UITextField *)[tempView viewWithTag:lossTfTag];
            lossTF.text = [NSString stringWithFormat:@"%0.2f",value];
        }
        resultString = [NSString stringWithFormat:@"%0.2f",value];
    }
    
    if (_tempCallBack != nil && _tempSpliceData != nil) {
        
        for (NSInteger i = 0; i < _tempSpliceData.measurementList.count; i++) {
            [_tempSpliceData.measurementList replaceObjectAtIndex:i withObject:resultString];
        }
        _tempCallBack(_tempSpliceData);
    }
    [self calculateMax];
}

-(void)setSCSelectSpliceDataInfo:(SCSelectSpliceData *)dataInfo andDataChangedCallBack:(DataChangedCallBack)callBack{
    _tempSpliceData = dataInfo;
    _tempCallBack = callBack;
    
    for (UIView * tempView in self.allInfoViews) {
        tempView.hidden = false;
    }
    
    for (NSInteger i = 0; i < dataInfo.estimateList.count; i++) {
        UIView * tempView = (UIView *)[self.allInfoViews objectAtIndex:i];
        UITextField * lossTF = (UITextField *)[tempView viewWithTag:lossTfTag];
        UILabel * lossLbl = (UILabel *)[tempView viewWithTag:lossLabelTag];
        
        
        NSString * str_estimate = [dataInfo.estimateList objectAtIndex:i];
        NSInteger errorCode = [(NSString *)[dataInfo.errorCodeList objectAtIndex:i] integerValue];
        if ((errorCode != 0) &&
            (errorCode != 13) &&
            (errorCode != 119) &&
            (!(errorCode >= 103 && errorCode <= 113))){
            lossLbl.text = @"--";
        } else if ([str_estimate isEqualToString:@"--"] ||
            [str_estimate floatValue] * 100 == 0xFFFF ||
            [str_estimate floatValue] * 100 == -1 ||
            [str_estimate isEqualToString:@"99.99"] ||
            str_estimate.length == 0) {
            lossLbl.text = @"--";
        } else {
            float estimate = [(NSString *)[dataInfo.estimateList objectAtIndex:i] floatValue];
            lossLbl.text = [NSString stringWithFormat:@"%0.2f", estimate];
        }
        
        NSString * str_measurement = [dataInfo.measurementList objectAtIndex:i];
        if ([str_measurement isEqualToString:@""]) {
            lossTF.text = @"";
        } else {
            float measurement = [(NSString *)[dataInfo.measurementList objectAtIndex:i] floatValue];
            if (measurement > 99.99 ||
                measurement < 0) {
                lossTF.text = @"";
            } else {
                lossTF.text = [NSString stringWithFormat:@"%0.2f", measurement];
            }
        }
    }
    
    if (self.allInfoViews.count > dataInfo.estimateList.count) {
        for (NSInteger i = dataInfo.estimateList.count; i < self.allInfoViews.count; i++) {
            UIView * tempView = (UIView *)[self.allInfoViews objectAtIndex:i];
            tempView.hidden = true;
        }
    }
    
    self.allWriteTf.text = dataInfo.allwriteStr.length == 0 ? @"" : dataInfo.allwriteStr;
    
    [self calculateMax];
}

-(void)calculateMax{
    
    BOOL max_display_flag = true;
    
    UIView * maxView = (UIView *)[self.listStackView viewWithTag:maxViewTag];
    UITextField * maxTF = (UITextField *)[maxView viewWithTag:lossTfTag];
    UILabel * maxLbl = (UILabel *)[maxView viewWithTag:lossLabelTag];
    
    
    if ([_tempSpliceData.estimate_display_flag isEqualToString:@"0"]) {
        maxLbl.text = @"--";
    } else {
        maxLbl.text = [NSString stringWithFormat:@"%0.2f", [_tempSpliceData.estimated_loss doubleValue]];
    }
    
    float max_measurement = 0.00;
    
    for (NSInteger i = 0; i < _tempSpliceData.estimateList.count; i++) {
        UIView * infoView = [self.allInfoViews objectAtIndex:i];
        UITextField * tempTf = (UITextField *)[infoView viewWithTag:lossTfTag];
        
        NSString * measurementStr = tempTf.text;
        if (![measurementStr isEqualToString:@"--"] &&
            ![measurementStr isEqualToString:@""] ) {
            float measurement = [measurementStr floatValue];
            max_measurement = (measurement > max_measurement ? measurement : max_measurement);
        }

    }
    
    for (NSInteger i = 0; i < _tempSpliceData.estimateList.count; i++) {
        UIView * tempView = [self.allInfoViews objectAtIndex:i];
        UITextField * lossTF = (UITextField *)[tempView viewWithTag:lossTfTag];
        if (lossTF.text.length == 0) {
            max_display_flag = false;
        }
    }
    
    if (max_display_flag) {
        maxTF.text = [NSString stringWithFormat:@"%0.2f",max_measurement];
        _tempSpliceData.measurement = [NSString stringWithFormat:@"%0.2f",max_measurement];
        _tempCallBack(_tempSpliceData);
    } else {
        maxTF.text = @"--";
        _tempSpliceData.measurement = @"--";
        _tempCallBack(_tempSpliceData);
    }
    
}

-(void)setJudgementCallBack:(JudgementChangedCallBack)callBack{
    _judgementCallBack = callBack;
}

-(void)judgementBtnClicked{
    _judgementCallBack(_tempSpliceData);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString * originalStr = textField.text;
    if ([originalStr containsString:@"."] && [string isEqualToString:@"."]) {
        return false;
    }
    
    if (![originalStr containsString:@"."] &&
        originalStr.length == 2 &&
        ![string isEqualToString:@"."]
        && string.length != 0) {
        return false;
    }
    
    if ([originalStr containsString:@"."]) {
        NSRange dotRange = [originalStr rangeOfString:@"."];
        if ( dotRange.location == 2 && range.location <= 2 && string.length != 0) {
            return false;
        }
        
        if (originalStr.length >= 5 && string.length != 0) {
            return false;
        }
    }
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField == self.allWriteTf) {
        self.editTFBottomPoint = CGPointMake(0, self.allWriteTf.frame.origin.y + self.allWriteTf.frame.size.height);
    } else {
        UIView * textField_super_view = textField.superview;
        self.editTFBottomPoint = CGPointMake(0, textField_super_view.frame.origin.y + textField_super_view.frame.size.height + self.listStackView.frame.origin.y);
    }
    
    [self.delegate shouldBeginEdit:self];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    [self.delegate didEndEdit:self];
    
    if (textField == self.allWriteTf) {
        if (_tempCallBack != nil && _tempSpliceData != nil){
            _tempSpliceData.allwriteStr = textField.text = (textField.text.length == 0) ? @"" : [NSString stringWithFormat:@"%0.2f", [textField.text floatValue]];
            _tempCallBack(_tempSpliceData);
        }
        return;
    }
    UIView * textField_super_view = textField.superview;
    NSInteger index = [self.allInfoViews indexOfObject:textField_super_view];
    float value = [textField.text floatValue];
    if (value < 0 || value > 99.99) {
        textField.text = [_tempSpliceData.measurementList objectAtIndex:index];
        return;
    }
    textField.text = (textField.text.length == 0) ? @"" : [NSString stringWithFormat:@"%0.2f", value];
    if (_tempCallBack != nil && _tempSpliceData != nil) {
        [_tempSpliceData.measurementList replaceObjectAtIndex:index withObject:(textField.text.length == 0) ?  @"" : [NSString stringWithFormat:@"%0.2f", value]];
        
        _tempCallBack(_tempSpliceData);
    }
    [self calculateMax];
}

@end
