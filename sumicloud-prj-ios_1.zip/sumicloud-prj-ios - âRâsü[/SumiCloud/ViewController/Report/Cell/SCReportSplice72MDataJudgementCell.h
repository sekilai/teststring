//
//  SCReportSplice72MDataJudgementCell.h
//  SumiCloud
//
//  Created by fsi_mac_6 on 2019/04/02.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SCSelectSpliceData.h"
#import "SCReportSpliceDataJudgementTableViewCell.h"

@interface SCReportSplice72MDataJudgementCell : UITableViewCell <UITextFieldDelegate>

typedef void (^DataChangedCallBack)(SCSelectSpliceData * dataInfo);
typedef void (^JudgementChangedCallBack)(SCSelectSpliceData * dataInfo);


@property (nonatomic) id<SCReportSpliceDataJudgementTableViewCellDelegate> delegate;
@property (weak, nonatomic) IBOutlet UILabel *timelbl;
@property (weak, nonatomic) IBOutlet UIButton *judgementBtn;
@property (weak, nonatomic) IBOutlet UILabel *judgementLbl;
@property (weak, nonatomic) IBOutlet UILabel *measurementTitle;
@property (weak, nonatomic) IBOutlet UILabel *lossTitle;
@property (weak, nonatomic) IBOutlet UILabel *dateTitle;

@property (weak, nonatomic) IBOutlet UIStackView *listStackView;
@property (weak, nonatomic) IBOutlet UILabel *maxLossLabel;

@property (weak, nonatomic) IBOutlet UIButton *allWriteBtn;
@property (weak, nonatomic) IBOutlet UITextField *allWriteTf;

@property (nonatomic,strong) NSMutableArray * allInfoViews;
@property (nonatomic,assign) CGPoint editTFBottomPoint;

-(void)setSCSelectSpliceDataInfo:(SCSelectSpliceData *)dataInfo andDataChangedCallBack:(DataChangedCallBack)callBack;
-(void)setJudgementCallBack:(JudgementChangedCallBack)callBack;

@end

