//
//  SCReportSpliceDataJudgementTableViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/12/09.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportSpliceDataJudgementTableViewCell.h"
#import "SCLogUtil.h"

#import "SCReportFlow.h"

@interface SCReportSpliceDataJudgementTableViewCell () <UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource>

@property (nonatomic) NSArray* listJudgementSelect;
@property (nonatomic) NSString* selectedJudgement;

@end

@implementation SCReportSpliceDataJudgementTableViewCell

typedef NS_ENUM(NSInteger, ReportUserDefineEntryTag) {
    TagMeasurement = 1000,
    TagJudgement
};

static NSInteger const kSC_MAXLEN_MEASUREMENT = 16;  // 「測定値」入力文字数

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.txtMeasurement.tag = TagMeasurement;
    self.txtMeasurement.keyboardType = UIKeyboardTypeDecimalPad;
    self.txtJudgement.tag = TagJudgement;

    // 判定の選択リスト取得
    self.listJudgementSelect = [SCReportFlow makeJudgementSelect];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


#pragma mark - UITextFieldDelegate

/**
 <#Description#>

 @param textField <#textField description#>
 @return <#return value description#>
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField.tag == TagMeasurement) {
        
    } else if (textField.tag == TagJudgement) {

        self.selectedJudgement = textField.text;
        
        // Cancelボタン
        UIBarButtonItem *btnEditCancel = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_CANCEL", @"キャンセル") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditCancelTouchUpInside:)];
        btnEditCancel.tag = textField.tag;
        
        // フレキシブルスペース
        UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
        
        // 設定ボタン
        UIBarButtonItem *btnEditOk = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_DONE", @"完了") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditOkTouchUpInside:)];
        btnEditOk.tag = textField.tag;
        
        // ツールバー
        UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 44)];
        toolbar.barStyle = UIBarStyleDefault;
        [toolbar sizeToFit];
        [toolbar setItems:@[btnEditCancel, spacer, btnEditOk] animated:YES];
        
        textField.inputAccessoryView = toolbar;
        
        // 合否選択
        UIPickerView *vwPicker = [[UIPickerView alloc] init];
        textField.inputView = vwPicker;
        vwPicker.tag = textField.tag;
        vwPicker.delegate = self;
        vwPicker.dataSource = self;
        [vwPicker sizeToFit];
        
        // 選択項目位置初期化
        for (NSInteger ii=0; ii < self.listJudgementSelect.count; ii++) {
            
            NSDictionary* dicJudgement = [self.listJudgementSelect objectAtIndex:ii];
            if ([textField.text isEqualToString:dicJudgement[kSC_REPORT_JUDGEMENT_TITLE]]) {
                
                [vwPicker selectRow:ii inComponent:0 animated:NO];
                break;
            }
        }
    }
    
    [self.delegate shouldBeginEdit:self];
    
    return YES;
}

/**
 入力項目編集中

 @param textField <#textField description#>
 @param range <#range description#>
 @param string <#string description#>
 @return <#return value description#>
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSMutableString *val = [textField.text mutableCopy];
    [val replaceCharactersInRange:range withString:string];
    
    if (textField.tag == TagMeasurement) {
        
        // 禁則文字チェック(数字、小数点)
        NSCharacterSet *checkStr = [NSCharacterSet characterSetWithCharactersInString:val];
        NSCharacterSet *isDigitCharSet = [NSCharacterSet characterSetWithCharactersInString:@".,0123456789"];
        if (![isDigitCharSet isSupersetOfSet:checkStr]) {
            
            return NO;
        }
        
        // 入力文字数チェック
        if (kSC_MAXLEN_MEASUREMENT < val.length) {
            
            return NO;
        }
        
        return YES;
    }
    
    return NO;
}

/**
 入力項目編集終了

 @param textField <#textField description#>
 */
- (void)textFieldDidEndEditing:(UITextField *)textField {

    [self.delegate didEndEdit:self];
}

/**
 入力項目のOK

 @param sender <#sender description#>
 */
- (void)btnEditOkTouchUpInside:(UIButton *)sender {
    
    if (sender.tag == self.txtJudgement.tag) {
        
        self.txtJudgement.text = self.selectedJudgement;
    }
    
    [self endEditing:YES];
}

/**
 入力項目のCancel

 @param sender <#sender description#>
 */
- (void)btnEditCancelTouchUpInside:(UIButton *)sender {
    
    [self endEditing:YES];
}


#pragma mark - UIPickerViewDelegate

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param row <#row description#>
 @param component <#component description#>
 @param view <#view description#>
 @return <#return value description#>
 */
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    
    UILabel *lblTitle = (id)view;
    if (!lblTitle) {
        
        lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [pickerView rowSizeForComponent:component].width, [pickerView rowSizeForComponent:component].height)];
    }
    
    NSDictionary* dicJudgement = [self.listJudgementSelect objectAtIndex:row];
    lblTitle.text = dicJudgement[kSC_REPORT_JUDGEMENT_TITLE];
    lblTitle.textColor = [UIColor blackColor];
    lblTitle.textAlignment = NSTextAlignmentCenter;
    lblTitle.backgroundColor = [UIColor clearColor];
    lblTitle.font = [UIFont systemFontOfSize:20.0f];
    lblTitle.adjustsFontSizeToFitWidth = YES;
    
    return lblTitle;
}

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param row <#row description#>
 @param component <#component description#>
 */
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    
    NSDictionary* dicJudgement = self.listJudgementSelect[row];
    self.selectedJudgement = dicJudgement[kSC_REPORT_JUDGEMENT_TITLE];
}


#pragma mark - UIPickerViewDataSource

/**
 選択表示

 @param pickerView <#pickerView description#>
 @return <#return value description#>
 */
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
    return 1;
}

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param component <#component description#>
 @return <#return value description#>
 */
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    return self.listJudgementSelect.count;
}

@end
