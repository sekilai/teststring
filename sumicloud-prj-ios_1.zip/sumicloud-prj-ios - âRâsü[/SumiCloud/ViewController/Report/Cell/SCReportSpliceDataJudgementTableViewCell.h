//
//  SCReportSpliceDataJudgementTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/12/09.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SCReportSpliceDataJudgementTableViewCellDelegate <NSObject>

- (void)shouldBeginEdit:(UITableViewCell *)cell;
- (void)didEndEdit:(UITableViewCell *)cell;

@end

@interface SCReportSpliceDataJudgementTableViewCell : UITableViewCell

@property (nonatomic) id<SCReportSpliceDataJudgementTableViewCellDelegate> delegate;

@property (weak, nonatomic) IBOutlet UILabel *lblTitleDateTime;
@property (weak, nonatomic) IBOutlet UILabel *lblDateTime;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleMeasurement;
@property (weak, nonatomic) IBOutlet UITextField *txtMeasurement;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleEstimatedLoss;
@property (weak, nonatomic) IBOutlet UILabel *lblEstimatedLoss;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleJudgement;
@property (weak, nonatomic) IBOutlet UITextField *txtJudgement;

@end
