//
//  SCReportSpliceDataTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/11/21.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SCReportSpliceDataTableViewCellDelegate <NSObject>

// チェックボックスの状態更新
- (void)changeCBState:(UITableViewCell *)cell;

@end

@interface SCReportSpliceDataTableViewCell : UITableViewCell

@property (nonatomic) id<SCReportSpliceDataTableViewCellDelegate> delegate;

@property (nonatomic) BOOL isCheckBoxON;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwCheckBox;
@property (weak, nonatomic) IBOutlet UILabel *lblTime;
@property (weak, nonatomic) IBOutlet UILabel *lblDB;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwGPS;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwPhoto;

// セル更新
- (void)refreshCell;

// 推定ロス値判定
- (void)getColorEstimatedLoss:(NSString *)estimatedLoss estLossLimit:(NSString *)estLossLimit;

@end
