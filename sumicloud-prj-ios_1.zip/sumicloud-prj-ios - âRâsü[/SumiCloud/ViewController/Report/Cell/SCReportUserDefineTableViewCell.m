//
//  SCReportUserDefineTableViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/11/21.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportUserDefineTableViewCell.h"

@interface SCReportUserDefineTableViewCell () <UITextFieldDelegate>

@end

@implementation SCReportUserDefineTableViewCell

typedef NS_ENUM(NSInteger, ReportUserDefineEntryTag) {
    TagItem = 1000,
    TagValue
};

static NSInteger const kSC_MAXLEN_ITEM  = 256; // 「アイテム」入力文字数
static NSInteger const kSC_MAXLEN_VALUE = 256; // 「値」入力文字数

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.txtItem.tag = TagItem;
    self.txtItem.keyboardType = UIKeyboardTypeDefault;
    self.txtValue.tag = TagValue;
    self.txtValue.keyboardType = UIKeyboardTypeDefault;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


#pragma mark - Public Method

/**
 セル更新
 */
- (void)refreshCell {
    
    if (self.isCheckBoxON) {
        
        self.imgvwCheckBox.image = [UIImage imageNamed:@"btn_check_on"];
    } else {
        
        self.imgvwCheckBox.image = [UIImage imageNamed:@"btn_check_off"];
    }
    
    self.lblTitleItem.enabled = self.isCheckBoxON;
    self.lblTitleValue.enabled = self.isCheckBoxON;
    self.txtItem.enabled = self.isCheckBoxON;
    self.txtValue.enabled = self.isCheckBoxON;
}


#pragma mark - Button Action

/**
 チェックボックスの制御

 @param sender <#sender description#>
 */
- (IBAction)btnCheckBoxTouchUpInside:(UIButton *)sender {
    
    [self.delegate changeCBState:self];
}


#pragma mark - UITextFieldDelegate

/**
 入力項目編集開始

 @param textField <#textField description#>
 @return <#return value description#>
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    [self.delegate shouldBeginEdit:self];
    
    return YES;
}

/**
 入力項目編集中

 @param textField <#textField description#>
 @param range <#range description#>
 @param string <#string description#>
 @return <#return value description#>
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    NSMutableString *val = [textField.text mutableCopy];
    [val replaceCharactersInRange:range withString:string];
    
    if (textField.tag == TagItem) {
        
        // 入力文字数チェック
        if (kSC_MAXLEN_ITEM < val.length) {
            
            return NO;
        }
        
        return YES;
    } else if (textField.tag == TagValue) {
        
        // 入力文字数チェック
        if (kSC_MAXLEN_VALUE < val.length) {
            
            return NO;
        }
        
        return YES;
    }

    return NO;
}

/**
 入力項目編集終了

 @param textField <#textField description#>
 */
- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    [self.delegate didEndEdit:self];
}

@end
