//
//  SCReportSpliceDataTableViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/11/21.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportSpliceDataTableViewCell.h"

#import "SCSystemData.h"

@implementation SCReportSpliceDataTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    if (selected) {
        
        self.backgroundColor = [SCSystemData colorWithRGB:0xEC green:0xEE blue:0xF0 alpha:1.0f];
    } else {
        
        self.backgroundColor = [UIColor clearColor];
    }
}


#pragma mark - Public Method

/**
 セル更新
 */
- (void)refreshCell {
    
    if (self.isCheckBoxON) {
        
        self.imgvwCheckBox.image = [UIImage imageNamed:@"btn_check_on"];
    } else {
        
        self.imgvwCheckBox.image = [UIImage imageNamed:@"btn_check_off"];
    }
}

/**
 推定ロス値判定
 
 @param estimatedLoss <#estimatedLoss description#>
 @param estLossLimit <#estLossLimit description#>
 */
- (void)getColorEstimatedLoss:(NSString *)estimatedLoss estLossLimit:(NSString *)estLossLimit {
    
    self.lblDB.textColor = [UIColor blackColor];
    
    if (estimatedLoss.length && estLossLimit.length) {
        
        if ([estimatedLoss doubleValue] >= [estLossLimit doubleValue]) {
            
            self.lblDB.textColor = [UIColor redColor];
        }
    }
}


#pragma mark - Button Action

/**
 チェックボックスの制御

 @param sender <#sender description#>
 */
- (IBAction)btnCheckBoxTouchUpInside:(UIButton *)sender {
    
    [self.delegate changeCBState:self];
}

@end
