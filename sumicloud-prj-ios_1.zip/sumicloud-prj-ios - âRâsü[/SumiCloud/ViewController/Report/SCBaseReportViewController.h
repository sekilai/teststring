//
//  SCBaseReportViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/12/27.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCBaseReportViewController : SCBaseViewController

- (void)cancelSpliceDataEdit;

@end
