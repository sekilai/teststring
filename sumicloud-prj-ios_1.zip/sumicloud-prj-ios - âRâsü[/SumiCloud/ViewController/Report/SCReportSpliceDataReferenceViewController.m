//
//  SCReportSpliceDataReferenceViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/12/09.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportSpliceDataReferenceViewController.h"
#import "SCLogUtil.h"
#import "SCSpliceDataReferenceGPSViewController.h"
#import "SCSystemData.h"
#import "SCReportFlow.h"

@interface SCReportSpliceDataReferenceViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UIView *vwHeading;
@property (weak, nonatomic) IBOutlet UILabel *lblDetailSelect;
@property (weak, nonatomic) IBOutlet UIButton *btnDetail;
@property (weak, nonatomic) IBOutlet UIView *vwDetailSelect;
@property (weak, nonatomic) IBOutlet UILabel *lblImageSelect;
@property (weak, nonatomic) IBOutlet UIButton *btnImage;
@property (weak, nonatomic) IBOutlet UIView *vwImageSelect;
@property (weak, nonatomic) IBOutlet UILabel *lblGPSSelect;
@property (weak, nonatomic) IBOutlet UIButton *btnGPS;
@property (weak, nonatomic) IBOutlet UIView *vwGPSSelect;

@property (weak, nonatomic) IBOutlet UIView *vwContainerDetail;
@property (weak, nonatomic) IBOutlet UIView *vwContainerImage;
@property (weak, nonatomic) IBOutlet UIView *vwContainerGPS;
@property (weak, nonatomic) IBOutlet UIView *vwContainerDetail72M;

@property (weak, nonatomic) IBOutlet UIButton *btnCommit;

- (IBAction)actionBack:(UIBarButtonItem *)sender;
- (IBAction)btnDetailTouchUpInside:(UIButton *)sender;
- (IBAction)btnImageTouchUpInside:(UIButton *)sender;
- (IBAction)btnGPSTouchUpInside:(UIButton *)sender;
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender;

@end

@implementation SCReportSpliceDataReferenceViewController

- (void)dealloc
{
    if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
        [self.vwContainerDetail removeObserver:self forKeyPath:@"hidden"];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");

    // 色味の設定
    self.vwHeading.backgroundColor = [SCSystemData colorWithRGB:0xF4 green:0xF4 blue:0xF4 alpha:1.0f];
    self.vwDetailSelect.backgroundColor = [SCSystemData colorWithRGB:0x4B green:0xC0 blue:0xF6 alpha:1.0f];
    self.vwImageSelect.backgroundColor = [SCSystemData colorWithRGB:0x4B green:0xC0 blue:0xF6 alpha:1.0f];
    self.vwGPSSelect.backgroundColor = [SCSystemData colorWithRGB:0x4B green:0xC0 blue:0xF6 alpha:1.0f];
    [self.btnCommit setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    
    self.vwContainerDetail72M.hidden = true;
    if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
        [self.vwContainerDetail addObserver:self forKeyPath:@"hidden" options:NSKeyValueObservingOptionNew || NSKeyValueChangeOldKey context:nil];
    }

    // 多言語対応
    self.lblDetailSelect.text = NSLocalizedString(@"BTN_SPLICEDATA_DETAIL", @"詳細データ");
    self.lblImageSelect.text = NSLocalizedString(@"BTN_SPLICEDATA_IMAGE", @"画像");
    self.lblGPSSelect.text = NSLocalizedString(@"BTN_SPLICEDATA_GPS", @"GPS");
    [self.btnCommit setTitle:NSLocalizedString(@"BTN_SELECTED", @"選択") forState:UIControlStateNormal];

    // 切り換えボタンの表示制御
    [self btnDetailTouchUpInside:self.btnDetail];
    
    // 画面表示データの更新
    self.title = self.appData.manReport.selectDateTime;
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    [self refreshOnlineSerialNo];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    // 色味の設定（レイアウト確定後）
    [self.btnCommit setBackgroundImage:[self setButtonHilightBackColor:self.btnCommit.bounds] forState:UIControlStateHighlighted];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}

#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {
    
    DDLogDebug(@"");

    [self.navigationController popViewControllerAnimated:YES];
}

/**
 詳細データボタン

 @param sender <#sender description#>
 */
- (IBAction)btnDetailTouchUpInside:(UIButton *)sender {
    
    DDLogInfo(@"詳細データ表示切り替え");
    
    // 切り換えボタンの表示制御
    self.vwContainerDetail.hidden = NO;
    self.vwContainerImage.hidden = YES;
    self.vwContainerGPS.hidden = YES;
    [self selectButtonMode];
}

/**
 画像ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnImageTouchUpInside:(UIButton *)sender {
    
    DDLogInfo(@"画像表示切り替え");
    
    // 切り換えボタンの表示制御
    self.vwContainerDetail.hidden = YES;
    self.vwContainerImage.hidden = NO;
    self.vwContainerGPS.hidden = YES;
    [self selectButtonMode];
}

/**
 GPSボタン

 @param sender <#sender description#>
 */
- (IBAction)btnGPSTouchUpInside:(UIButton *)sender {
    
    DDLogInfo(@"GPS表示切り替え");
    
    // Wi-Fi切り替え確認
    if (![self isMobileConnect]) {
        
        [self connectSplicerAlert];
        
        return;
    }
    
    // 切り換えボタンの表示制御
    self.vwContainerDetail.hidden = YES;
    self.vwContainerImage.hidden = YES;
    self.vwContainerGPS.hidden = NO;
    [self selectButtonMode];
}

/**
 選択ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender {
    
    DDLogInfo(@"選択ボタン -> 接続データ詳細");
    [self.delegate selectedSpliceData];
    [self.navigationController popViewControllerAnimated:YES];
    
}


#pragma mark - Private Method

/**
 切り換えボタンの表示制御
 */
- (void)selectButtonMode {
    
    // 詳細データボタン
    if (self.vwContainerDetail.hidden) {
        
        self.vwDetailSelect.hidden = YES;
        self.lblDetailSelect.textColor = [SCSystemData colorWithRGB:0x00 green:0x00 blue:0x00 alpha:0.5f];
    } else {
        
        self.vwDetailSelect.hidden = NO;
        self.lblDetailSelect.textColor = [SCSystemData colorWithRGB:0x4B green:0xC0 blue:0xF6 alpha:1.0f];
    }
    
    // 画像ボタン
    NSString* image_download_flg = self.appData.detailSpliceData.image_download_flg;
    if ([@"0" isEqualToString:image_download_flg]) {
        
        // 接続データ画像未取得
        self.btnImage.enabled = NO;
        self.vwImageSelect.hidden = YES;
        self.vwContainerImage.hidden = YES;
        self.lblImageSelect.textColor = [SCSystemData colorWithRGB:0x00 green:0x00 blue:0x00 alpha:0.5f];
    } else {
        
        // 詳細データ / 画像 / GPS の選択状態による表示
        self.btnImage.enabled = YES;
        
        if (self.vwContainerImage.hidden) {
            
            self.vwImageSelect.hidden = YES;
            self.lblImageSelect.textColor = [SCSystemData colorWithRGB:0x00 green:0x00 blue:0x00 alpha:0.5f];
        } else {
            
            self.vwImageSelect.hidden = NO;
            self.lblImageSelect.textColor = [SCSystemData colorWithRGB:0x4B green:0xC0 blue:0xF6 alpha:1.0f];
        }
    }
    
    // GPSボタン
    NSString* lat = self.appData.detailSpliceData.lat;
    NSString* lon = self.appData.detailSpliceData.lon;
    if (0 == lat.length || 0 == lon.length) {
        
        // 位置情報が関連付けされていない
        self.btnGPS.enabled = NO;
        self.vwGPSSelect.hidden = YES;
        self.vwContainerGPS.hidden = YES;
        self.lblGPSSelect.textColor = [SCSystemData colorWithRGB:0x00 green:0x00 blue:0x00 alpha:0.5f];
    } else {
        
        // 詳細データ / 画像 / GPS の選択状態による表示
        self.btnGPS.enabled = YES;
        
        if (self.vwContainerGPS.hidden) {
            
            self.vwGPSSelect.hidden = YES;
            self.lblGPSSelect.textColor = [SCSystemData colorWithRGB:0x00 green:0x00 blue:0x00 alpha:0.5f];
        } else {
            
            self.vwGPSSelect.hidden = NO;
            self.lblGPSSelect.textColor = [SCSystemData colorWithRGB:0x4B green:0xC0 blue:0xF6 alpha:1.0f];
        }
    }
    
    // 接続データ詳細（GPS）画面の表示制御
    for (UIViewController* vwCon in self.childViewControllers) {
        
        if ([vwCon isKindOfClass:[SCSpliceDataReferenceGPSViewController class]]) {
            
            if (self.vwContainerGPS.isHidden) {
                
                [(SCSpliceDataReferenceGPSViewController *)vwCon hide];
            } else {
                
                [(SCSpliceDataReferenceGPSViewController *)vwCon show];
            }
        }
    }
}

#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    self.imgvwConnection.image = [self refreshLockState];
}

#pragma mark - observe

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"hidden"]) {
        self.vwContainerDetail72M.hidden = self.vwContainerDetail.hidden;
    }
}

@end
