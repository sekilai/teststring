//
//  SCReportPeriodSettingViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportPeriodSettingViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCReportFlow.h"

@interface SCReportPeriodSettingViewController () <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UIView *vwMessage;
@property (weak, nonatomic) IBOutlet UILabel *lblMessage;

@property (weak, nonatomic) IBOutlet UILabel *lblTitleFromDate;
@property (weak, nonatomic) IBOutlet UITextField *txtFromDate;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleToDate;
@property (weak, nonatomic) IBOutlet UITextField *txtToDate;

@property (weak, nonatomic) IBOutlet UIButton *btnCancel;
@property (weak, nonatomic) IBOutlet UIButton *btnCommit;

- (IBAction)actionBack:(UIBarButtonItem *)sender;
- (IBAction)btnCancelTouchUpInside:(UIButton *)sender;
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender;

@end

@implementation SCReportPeriodSettingViewController

typedef NS_ENUM(NSInteger, ReportUserDefineEntryTag) {
    TagFromDate = 1000,
    TagToDate
};

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.vwMessage.backgroundColor = [SCSystemData colorWithRGB:0xF4 green:0xF4 blue:0xF4 alpha:1.0f];
    [self.btnCancel setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnCommit setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];

    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_REPORT_PERIOD_SETTING", @"接続データ設定");
    self.lblMessage.text = NSLocalizedString(@"MSG_10014", @"接続データを設定します〜");
    self.lblTitleFromDate.text = NSLocalizedString(@"RES_20025", @"開始:");
    self.lblTitleToDate.text = NSLocalizedString(@"RES_20026", @"終了:");
    [self.btnCancel setTitle:NSLocalizedString(@"BTN_CLEAR", @"クリア") forState:UIControlStateNormal];
    [self.btnCommit setTitle:NSLocalizedString(@"BTN_SETTING", @"設定") forState:UIControlStateNormal];

    // タップジェスチャー
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapGestureAction:)];
    [self.view addGestureRecognizer:tapGesture];

    // 画面表示データの更新
    self.txtFromDate.tag = TagFromDate;
    self.txtFromDate.text = self.appData.manReport.fromDate;
    self.txtToDate.tag = TagToDate;
    self.txtToDate.text = self.appData.manReport.toDate;
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    [self refreshOnlineSerialNo];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    // 色味の設定（レイアウト確定後）
    [self.btnCancel setBackgroundImage:[self setButtonHilightBackColor:self.btnCancel.bounds] forState:UIControlStateHighlighted];
    [self.btnCommit setBackgroundImage:[self setButtonHilightBackColor:self.btnCommit.bounds] forState:UIControlStateHighlighted];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}


#pragma mark - Action

/**
 *  画面タップでキーボード非表示
 *
 *  @param sender <#sender description#>
 */
- (void)viewTapGestureAction:(UITapGestureRecognizer *)sender {
    
    [self.view endEditing:YES];
}


#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {

    DDLogDebug(@"");
    
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 キャンセルボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCancelTouchUpInside:(UIButton *)sender {

    DDLogDebug(@"キャンセルボタン -> 接続データ期間設定");

    [self cancelSpliceDataEdit];
}

/**
 設定ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender {
    
    DDLogInfo(@"設定ボタン -> 接続データ期間設定");
    
    // 入力チェック
    NSArray* validateError = [self isValidate];
    if (validateError.count) {
        
        DDLogWarn(@"期間設定NG <<%@>>", validateError);
        
        NSMutableString* errorMsg = [NSMutableString stringWithCapacity:0];
        for (NSString* msg in validateError) {
            
            [errorMsg appendFormat:@"%@\r\n", msg];
        }
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:errorMsg preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        }]];
        
        [self presentViewController:alert animated:YES completion:nil];
        
        return;
    }
    
    self.appData.manReport.fromDate = self.txtFromDate.text;
    self.appData.manReport.toDate = self.txtToDate.text;

    [self performSegueWithIdentifier:@"toReportSpliceData" sender:self];
}


#pragma mark - UITextFieldDelegate

/**
 入力項目編集開始

 @param textField <#textField description#>
 @return <#return value description#>
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {

    // Cancelボタン
    UIBarButtonItem *btnEditCancel = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_CANCEL", @"キャンセル") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditCancelTouchUpInside:)];
    
    // フレキシブルスペース
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    
    // 設定ボタン
    UIBarButtonItem *btnEditOk = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_DONE", @"完了") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditOkTouchUpInside:)];
    btnEditOk.tag = textField.tag;
    
    // ツールバー
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    toolbar.barStyle = UIBarStyleDefault;
    [toolbar sizeToFit];
    [toolbar setItems:@[btnEditCancel, spacer, btnEditOk] animated:YES];
    
    textField.inputAccessoryView = toolbar;

    UIDatePicker* vwPicker = [[UIDatePicker alloc] init];
    if (@available(iOS 13.4, *)){
        vwPicker.preferredDatePickerStyle = UIDatePickerStyleWheels;
    }
    vwPicker.datePickerMode = UIDatePickerModeDate;
    [vwPicker setTimeZone:[NSTimeZone systemTimeZone]];
    [vwPicker setCalendar:[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]];
    textField.inputView = vwPicker;
    [vwPicker sizeToFit];
    
    NSDate* inputDate = [SCSystemData dateFromString:textField.text format:@"yyyy/MM/dd"];
    if (inputDate) {
        
        vwPicker.date = inputDate;
    } else {
        
        vwPicker.date = [NSDate date];
    }
    
    return YES;
}

/**
 入力項目のOK
 
 @param sender <#sender description#>
 */
- (void)btnEditOkTouchUpInside:(UIButton *)sender {
    
    if (self.txtFromDate.tag == sender.tag) {

        NSDate* selectedDate = ((UIDatePicker *)self.txtFromDate.inputView).date;
        self.txtFromDate.text = [SCSystemData stringFromDate:selectedDate format:@"yyyy/MM/dd"];
    } else if (self.txtToDate.tag == sender.tag) {
        
        NSDate* selectedDate = ((UIDatePicker *)self.txtToDate.inputView).date;
        self.txtToDate.text = [SCSystemData stringFromDate:selectedDate format:@"yyyy/MM/dd"];
    }
    
    [self.view endEditing:YES];
}

/**
 入力項目のCancel
 
 @param sender <#sender description#>
 */
- (void)btnEditCancelTouchUpInside:(UIButton *)sender {
    
    [self.view endEditing:YES];
}


#pragma mark - Private Method

/**
 入力項目チェック

 @return <#return value description#>
 */
- (NSArray *)isValidate {
    
    NSMutableArray* ret = [NSMutableArray arrayWithCapacity:0];
    
    // 開始日チェック
    if (0 == self.txtFromDate.text.length) {
        
        [ret addObject:[NSString stringWithFormat:@"%@ %@", NSLocalizedString(@"RES_20025", @"入力項目"), NSLocalizedString(@"MSG_12000", @"必須")]];
    }
    
    // 終了日チェック
    if (0 == self.txtToDate.text.length) {
        
        [ret addObject:[NSString stringWithFormat:@"%@ %@", NSLocalizedString(@"RES_20026", @"入力項目"), NSLocalizedString(@"MSG_12000", @"必須")]];
    }
    
    // 日付逆転チェック
    if ((self.txtFromDate.text.length) && (self.txtToDate.text.length)) {

        NSDate* from = [SCSystemData dateFromString:self.txtFromDate.text format:@"yyyy/MM/dd"];
        NSDate* to = [SCSystemData dateFromString:self.txtToDate.text format:@"yyyy/MM/dd"];
        NSComparisonResult result = [from compare:to];
        if (NSOrderedDescending == result) {
            
            [ret addObject:[NSString stringWithFormat:@"%@", NSLocalizedString(@"MSG_12006", @"日付の指定誤り")]];
        }
    }
    
    return [NSArray arrayWithArray:ret];
}

#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

@end
