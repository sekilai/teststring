//
//  SCReportSpliceDataJudgementViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/12/09.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCReportSpliceDataJudgementViewController.h"
#import "SCReportSpliceDataJudgementTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCReportFlow.h"
#import "SCSelectSpliceData.h"
#import "SCReportSplice72MDataJudgementCell.h"
#import "SCSpliceDataDao.h"

@interface SCReportSpliceDataJudgementViewController () <UITableViewDelegate, UITableViewDataSource, SCReportSpliceDataJudgementTableViewCellDelegate>

@property (nonatomic) NSIndexPath* editRow;
@property (nonatomic) CGSize vwTableOffset;

@property (nonatomic) NSArray* listJudgementSelect;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UIView *vwMessage;
@property (weak, nonatomic) IBOutlet UILabel *lblMessage;

@property (weak, nonatomic) IBOutlet UITableView *tblvwSpliceDataList;

@property (weak, nonatomic) IBOutlet UIButton *btnCancel;
@property (weak, nonatomic) IBOutlet UIButton *btnCommit;

- (IBAction)actionBack:(UIBarButtonItem *)sender;
- (IBAction)btnCancelTouchUpInside:(UIButton *)sender;
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender;

@end

@implementation SCReportSpliceDataJudgementViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    // 色味の設定
    self.vwMessage.backgroundColor = [SCSystemData colorWithRGB:0xF4 green:0xF4 blue:0xF4 alpha:1.0f];
    [self.btnCancel setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnCommit setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];

    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_REPORT_PERIOD_SETTING", @"接続データ設定");
    self.lblMessage.text = NSLocalizedString(@"MSG_10016", @"各接続データの判定を入力してください");
    [self.btnCancel setTitle:NSLocalizedString(@"BTN_CLEAR", @"クリア") forState:UIControlStateNormal];
    [self.btnCommit setTitle:NSLocalizedString(@"BTN_SETTING", @"設定") forState:UIControlStateNormal];

    // 判定の選択リスト取得
    self.listJudgementSelect = [SCReportFlow makeJudgementSelect];

    // 画面表示データの更新
    self.tblvwSpliceDataList.estimatedRowHeight = 141.0f;
    self.tblvwSpliceDataList.rowHeight = UITableViewAutomaticDimension;
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    [self refreshOnlineSerialNo];
    
    [self getErrorCode];
    
    // タップジェスチャー
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapGestureAction:)];
    [self.view addGestureRecognizer:tapGesture];
    
    // 余白セルを表示しない
    self.tblvwSpliceDataList.tableFooterView = [[UIView alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    // キーボード表示制御
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    // 色味の設定（レイアウト確定後）
    [self.btnCancel setBackgroundImage:[self setButtonHilightBackColor:self.btnCancel.bounds] forState:UIControlStateHighlighted];
    [self.btnCommit setBackgroundImage:[self setButtonHilightBackColor:self.btnCommit.bounds] forState:UIControlStateHighlighted];
    
    // オフセットを保持
    self.vwTableOffset = self.tblvwSpliceDataList.contentSize;
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    
    [self.view endEditing:YES];
    
    // キーボード表示制御
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


#pragma mark - Action

/**
 画面タップでキーボード非表示

 @param sender <#sender description#>
 */
- (void)viewTapGestureAction:(UITapGestureRecognizer *)sender {
    
    [self.view endEditing:YES];
}

/**
 キーボード表示制御

 @param notification <#notification description#>
 */
- (void)keyboardWillShow:(NSNotification *)notification {
    
    // 高さ変更(キーボードの分縮める)
    CGRect keyboardRect = [[notification userInfo][UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    // オフセットから表示サイズを求める
    CGSize newSize = CGSizeMake(self.vwTableOffset.width, self.vwTableOffset.height + keyboardRect.size.height);
    [self.tblvwSpliceDataList setContentSize:newSize];
    
    if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
        SCReportSplice72MDataJudgementCell * cell_72M = [self.tblvwSpliceDataList cellForRowAtIndexPath:self.editRow];
        CGFloat cellBottom = cell_72M.frame.origin.y + cell_72M.frame.size.height - self.tblvwSpliceDataList.contentOffset.y + self.tblvwSpliceDataList.frame.origin.y + self.navigationController.navigationBar.frame.size.height + [UIApplication sharedApplication].statusBarFrame.size.height;
        
        CGFloat tfBottom = cellBottom - (cell_72M.contentView.frame.size.height - cell_72M.editTFBottomPoint.y);
        if (keyboardRect.origin.y < tfBottom) {
            
            // 表示中のをキーボードの上に移動
            CGPoint newPos = CGPointMake(self.tblvwSpliceDataList.contentOffset.x, self.tblvwSpliceDataList.contentOffset.y + tfBottom - keyboardRect.origin.y);
            
            [self.tblvwSpliceDataList setContentOffset:newPos animated:YES];
        }
    } else {
        // セル位置（画面上の絶対位置）
        UITableViewCell* cell = [self.tblvwSpliceDataList cellForRowAtIndexPath:self.editRow];
        CGFloat cellBottom = cell.frame.origin.y + cell.frame.size.height - self.tblvwSpliceDataList.contentOffset.y + self.tblvwSpliceDataList.frame.origin.y + self.navigationController.navigationBar.frame.size.height + [UIApplication sharedApplication].statusBarFrame.size.height;
        
        // 位置判定
        if (keyboardRect.origin.y < cellBottom) {
            
            // 表示中のをキーボードの上に移動
            CGPoint newPos = CGPointMake(self.tblvwSpliceDataList.contentOffset.x, self.tblvwSpliceDataList.contentOffset.y + cellBottom - keyboardRect.origin.y);
            
            [self.tblvwSpliceDataList setContentOffset:newPos animated:YES];
        }
    }

    self.tblvwSpliceDataList.scrollEnabled = NO;
}

/**
 キーボード非表示制御

 @param notification <#notification description#>
 */
- (void)keyboardWillHide:(NSNotification *)notification {
    
    self.tblvwSpliceDataList.scrollEnabled = YES;
    
    // オフセットに戻す
    [self.tblvwSpliceDataList setContentSize:self.vwTableOffset];
    
    [self.tblvwSpliceDataList scrollToRowAtIndexPath:self.editRow atScrollPosition:UITableViewScrollPositionTop animated:YES];
}


#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {
    
    DDLogDebug(@"");
    
    // 接続データ編集破棄
    [SCReportFlow endEditingSelectSpliceData:NO];
    
    // 画面戻る
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 キャンセルボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCancelTouchUpInside:(UIButton *)sender {

    DDLogDebug(@"キャンセルボタン -> 接続データ判定");

    [self cancelSpliceDataEdit];
}

/**
 設定ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender {
    
    DDLogInfo(@"設定ボタン -> 接続データ判定");
    
    // 編集済みデータを保存
    [SCReportFlow beginEditingSelectSpliceData];
    [SCReportFlow deleteAllSelectSpliceData];
    for (SCSelectSpliceData* item in self.listReportData) {
        [SCReportFlow updateSelectSpliceData:item];
    }
    [SCReportFlow endEditingSelectSpliceData:YES];
    
    // レポート作成画面へ戻る
    [self.navigationController popToViewController:self.navigationController.viewControllers[1] animated:YES];
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param section <#section description#>
 
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listReportData.count;
}

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SCReportSpliceDataJudgementTableViewCell * cell;
    
    if (![SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        cell.delegate = self;
        SCSelectSpliceData* item = [self.listReportData objectAtIndex:indexPath.row];
        cell.lblTitleDateTime.text = NSLocalizedString(@"RES_20018", @"日時:");
        cell.lblDateTime.text = item.datetime;
        cell.lblTitleMeasurement.text = NSLocalizedString(@"RES_20027", @"測定値:");
        cell.txtMeasurement.text = item.measurement;
        cell.txtMeasurement.keyboardType = UIKeyboardTypeDecimalPad;
        cell.lblTitleEstimatedLoss.text = NSLocalizedString(@"RES_20028", @"推定ロス値:");
        if ([SCSystemData isModelTypeT502:item.serialno]) {
            cell.lblEstimatedLoss.text = [SCSystemData stringFromDoubleString:item.estimated_loss decimalLength:2];
        }
        cell.lblEstimatedLoss.text = [SCSystemData stringFromDoubleString:item.estimated_loss decimalLength:2];
        cell.lblTitleJudgement.text = NSLocalizedString(@"RES_20029", @"判定:");
        cell.txtJudgement.text = [self stringJudgement:item.judgement];
    } else {
        SCReportSplice72MDataJudgementCell * cell_72M = [tableView dequeueReusableCellWithIdentifier:@"72M_DataCell"];
        if (cell_72M == nil) {
            cell_72M = (SCReportSplice72MDataJudgementCell *)[[[NSBundle mainBundle] loadNibNamed:@"SCReportSplice72MDataJudgementCell" owner:nil options:nil] lastObject];
        }
        cell_72M.delegate = self;
        SCSelectSpliceData* item = [self.listReportData objectAtIndex:indexPath.row];
        cell_72M.timelbl.text = item.datetime;
        __weak SCReportSpliceDataJudgementViewController * _weakSelf = self;
        __weak SCReportSplice72MDataJudgementCell * _weakCell = cell_72M;
        [cell_72M setSCSelectSpliceDataInfo:item andDataChangedCallBack:^(SCSelectSpliceData *dataInfo) {
            for (SCSelectSpliceData * tempData in _weakSelf.listReportData) {
                if ([tempData.serialno isEqualToString:dataInfo.serialno] && [tempData.datetime isEqualToString:dataInfo.datetime]) {
                    tempData.measurementList = [NSMutableArray arrayWithArray:dataInfo.measurementList];
                    tempData.allwriteStr = dataInfo.allwriteStr;
                }
            }
        }];
        if (item.judgement == 0) {
            [cell_72M.judgementBtn setTitle:NSLocalizedString(@"REP_JUDGE_NOT", @"未選択") forState:UIControlStateNormal];
        } else if (item.judgement == 1) {
            [cell_72M.judgementBtn setTitle:NSLocalizedString(@"REP_JUDGE_PASS", @"合格") forState:UIControlStateNormal];
        } else if (item.judgement == 2) {
            [cell_72M.judgementBtn setTitle:NSLocalizedString(@"REP_JUDGE_FAIL", @"不合格") forState:UIControlStateNormal];
        }
        [cell_72M setJudgementCallBack:^(SCSelectSpliceData *dataInfo) {
            [_weakSelf showJudgementActionSheet:_weakCell.judgementBtn andDataInfo:dataInfo];
        }];
        return cell_72M;
    }
    
    return cell;
}


#pragma mark - SCReportSpliceDataJudgementTableViewCellDelegate

/**
 編集開始

 @param cell <#cell description#>
 */
- (void)shouldBeginEdit:(UITableViewCell *)cell {
    self.vwTableOffset = self.tblvwSpliceDataList.contentSize;
    self.editRow = [self.tblvwSpliceDataList indexPathForCell:cell];
}

/**
 編集終了

 @param cell <#cell description#>
 */
- (void)didEndEdit:(UITableViewCell *)cell {
    
    if ([cell isKindOfClass:[SCReportSplice72MDataJudgementCell class]]) {
        return;
    }

    NSIndexPath* indexPath = [self.tblvwSpliceDataList indexPathForCell:cell];

    SCSelectSpliceData* item = [self.listReportData objectAtIndex:indexPath.row];
    item.measurement = ((SCReportSpliceDataJudgementTableViewCell *)cell).txtMeasurement.text;
    for (NSInteger ii=0; ii < self.listJudgementSelect.count; ii++) {
        
        NSDictionary* dicJudgement = [self.listJudgementSelect objectAtIndex:ii];
        if ([((SCReportSpliceDataJudgementTableViewCell *)cell).txtJudgement.text isEqualToString:dicJudgement[kSC_REPORT_JUDGEMENT_TITLE]]) {
            
            item.judgement = [dicJudgement[kSC_REPORT_JUDGEMENT_VALUE] intValue];
            break;
        }
    }
}


#pragma mark - Private Method

/**
 判定値を文字列に変換

 @param judgement <#judgement description#>
 @return <#return value description#>
 */
- (NSString *)stringJudgement:(int)judgement {
    
    NSString* ret = @"";
    
    for (NSDictionary* dicJudgement in self.listJudgementSelect) {
        
        int val = [dicJudgement[kSC_REPORT_JUDGEMENT_VALUE] intValue];
        if (val == judgement) {
            
            ret = dicJudgement[kSC_REPORT_JUDGEMENT_TITLE];
            
            break;
        }
    }
    
    return ret;
}

-(void)getErrorCode{
    NSMutableString * sql = [NSMutableString stringWithCapacity:0];
    [sql appendString:@"SELECT * FROM SpliceDataDetail "];
    [sql appendString:@"WHERE serialno = ? "];
    [sql appendString:@"AND datetime = ? "];
    [sql appendString:@"ORDER BY fiber_no ASC "];
    SCSpliceDataDao * spliceDatadao = [[SCSpliceDataDao alloc]init];
    for (SCSelectSpliceData * temp in self.listReportData) {
        temp.errorCodeList = [[NSMutableArray alloc] init];
        [spliceDatadao openSchema];
        FMResultSet * tempResult = [[spliceDatadao getSchemaInstance] executeQuery:sql, temp.serialno, temp.datetime];
        while ([tempResult next]) {
            NSInteger dataIndex = [(NSString *)[tempResult stringForColumn:@"fiber_no"] integerValue];
            NSString * errorCode = [tempResult stringForColumn:@"error"];
            if (dataIndex > temp.errorCodeList.count) {
                [temp.errorCodeList addObject:errorCode];
            } else {
                [temp.errorCodeList insertObject:errorCode atIndex:dataIndex-1];
            }
        }
        [spliceDatadao closeSchema];
    }
    [self.tblvwSpliceDataList reloadData];
}

#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

- (void)showJudgementActionSheet:(UIButton *)sender andDataInfo:(SCSelectSpliceData *)dataInfo {
    __weak UIButton *weakBtn = sender;
    __weak SCReportSpliceDataJudgementViewController * _weakSelf = self;
    UIAlertController * actionSheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction * action1 = [UIAlertAction actionWithTitle:NSLocalizedString(@"REP_JUDGE_NOT", @"未選択") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [weakBtn setTitle:NSLocalizedString(@"REP_JUDGE_NOT", @"未選択") forState:UIControlStateNormal];
        for (SCSelectSpliceData * tempData in _weakSelf.listReportData) {
            if ([tempData.serialno isEqualToString:dataInfo.serialno] && [tempData.datetime isEqualToString:dataInfo.datetime]) {
                tempData.judgement = 0;
            }
        }
    }];
    
    UIAlertAction * action2 = [UIAlertAction actionWithTitle:NSLocalizedString(@"REP_JUDGE_PASS", @"合格") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [weakBtn setTitle:NSLocalizedString(@"REP_JUDGE_PASS", @"合格") forState:UIControlStateNormal];
        for (SCSelectSpliceData * tempData in _weakSelf.listReportData) {
            if ([tempData.serialno isEqualToString:dataInfo.serialno] && [tempData.datetime isEqualToString:dataInfo.datetime]) {
                tempData.judgement = 1;
            }
        }
    }];
    
    
    UIAlertAction * action3 = [UIAlertAction actionWithTitle:NSLocalizedString(@"REP_JUDGE_FAIL", @"不合格") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [weakBtn setTitle:NSLocalizedString(@"REP_JUDGE_FAIL", @"不合格") forState:UIControlStateNormal];
        for (SCSelectSpliceData * tempData in _weakSelf.listReportData) {
            if ([tempData.serialno isEqualToString:dataInfo.serialno] && [tempData.datetime isEqualToString:dataInfo.datetime]) {
                tempData.judgement = 2;
            }
        }
    }];
    
    [actionSheet addAction:action1];
    [actionSheet addAction:action2];
    [actionSheet addAction:action3];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

@end
