//
//  ChangePasswordViewController.m
//  RentalApp
//
//  Created by fsi-mac5d-13 on 2020/06/17.
//  Copyright © 2020 fsi_mac5d_2. All rights reserved.
//

#import "ChangePasswordViewController.h"
#import "ChangePasswordFlow.h"
#import "SCLogUtil.h"
#import "LoginViewController.h"
#import "DbAccessControllDao.h"
#import "DigestTool.h"
#import "AESUtil.h"
#import "Constants.h"

@interface ChangePasswordViewController () <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UILabel *currentPWLabel;
@property (weak, nonatomic) IBOutlet UILabel *setNewPWLabel;
@property (weak, nonatomic) IBOutlet UILabel *confirmPWLabel;

@property (weak, nonatomic) IBOutlet UITextField *currentPWTextField;
@property (weak, nonatomic) IBOutlet UITextField *setNewPWTextField;
@property (weak, nonatomic) IBOutlet UITextField *confirmPWTextField;

@property (weak, nonatomic) IBOutlet UIButton *changeBtn;

@end

@implementation ChangePasswordViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.tabBarController.tabBar.hidden = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = NSLocalizedString(@"change_password_title", @"Change current password");
    
    self.currentPWLabel.text = NSLocalizedString(@"current_password",@"");
    self.setNewPWLabel.text = NSLocalizedString(@"new_password",@"");
    self.confirmPWLabel.text = NSLocalizedString(@"confirming_new_password",@"");
    [self.changeBtn setTitle:NSLocalizedString(@"change",@"") forState:UIControlStateNormal];
    
}

- (IBAction)changeBtnClicked:(id)sender {
    if (!self.currentPWTextField.text.length ||
        !self.setNewPWTextField.text.length ||
        !self.confirmPWTextField.text.length) {
        NSMutableString *temp = [NSMutableString stringWithCapacity:0];
        if (!self.currentPWTextField.text.length) {
            [temp appendString:NSLocalizedString(@"current_password", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"adlg_change_password_required_error", @"確認メッセージ")];
            [temp appendString:@"\n"];
        }
        
        if (!self.setNewPWTextField.text.length) {
            [temp appendString:NSLocalizedString(@"new_password", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"adlg_change_password_required_error", @"確認メッセージ")];
            [temp appendString:@"\n"];
        }
        
        if (!self.confirmPWTextField.text.length) {
            [temp appendString:NSLocalizedString(@"confirming_new_password", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"adlg_change_password_required_error", @"確認メッセージ")];
        }
        
        [self showAlertWithMessage:temp];
        return;
    }
    
    if (![self checkPassWord:self.setNewPWTextField.text]) {
        [self showPasswordStyleAlert];
        return;
    }
    
    if (![self.setNewPWTextField.text isEqualToString:self.confirmPWTextField.text]) {
        [self showPasswordConfirmErrorAlert];
        return;
    }
    
    // Wi-Fi切り替え確認
    if (![self isMobileConnect]) {
        
        [self connectInternetAlert];
        
        return;
    }
    
    NSError *error = [[[ChangePasswordFlow alloc] init] pairingChangePassword:[[NSUserDefaults standardUserDefaults] stringForKey:PRE_ACCOUNT] currentPassword:self.currentPWTextField.text password:self.setNewPWTextField.text];
    if (error) {
        NSString* errorMsg = NSLocalizedString(@"adlg_change_password_failed", @"パスワード変更に失敗しました。");
        id errorResult = error.userInfo[kSC_BF_ErrorResponse];
        if (errorResult){
            if ([errorResult isEqualToString:@"107"]){
                errorMsg = NSLocalizedString(@"adlg_change_password_failed", @"パスワード変更に失敗しました。");
            } else if ([errorResult isEqualToString:@"111"]) {
                errorMsg = NSLocalizedString(@"adlg_change_password_user_password_error", @"パスワードが一致していません。");
            }
        }
        // サーバ通信エラー
        DDLogError(@"パスワード変更異常:%@", error.description);
        UIAlertController *alert  = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"change_password_title", @"") message:errorMsg preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", "OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        }]];
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        DDLogError(@"パスワード変更成功");
        UIAlertController *alert  = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"change_password_title", @"") message:NSLocalizedString(@"adlg_change_password_completed", @"パスワードの変更が完了しました。") preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"BTN_OK", "OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//            LoginViewController * loginVC;
//            for (UIViewController* vc in self.navigationController.parentViewController.navigationController.viewControllers) {
//                if ([vc isKindOfClass:[LoginViewController class]]) {
//                    loginVC = (LoginViewController *)vc;
//                }
//            }
//            loginVC.needChangePassword = YES;
            [[NSUserDefaults standardUserDefaults] setObject:[AESUtil encrypt:PASSCODE_AES_KEY target:self.setNewPWTextField.text] forKey:PRE_PASSWORD];
            [[NSUserDefaults standardUserDefaults] synchronize];
            NSString* newPassWord = [AESUtil encrypt:PASSWORD_AES_KEY target:self.setNewPWTextField.text];
            [[[DbAccessControllDao alloc] init] insertOrUpdateAccount:[[NSUserDefaults standardUserDefaults] stringForKey:PRE_ACCOUNT] password:newPassWord  role:@"0" lastLogin:[[NSDate date] timeIntervalSince1970] * 1000];
            [self.navigationController popViewControllerAnimated:true];
        }]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:true];
}

-(void)showAlertWithMessage:(NSString *)message{
    UIAlertController *alert = [UIAlertController
                                alertControllerWithTitle:NSLocalizedString(@"change_password_title", @"")
                                message:message
                                preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"")
                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                  
                                              }]];
    [self showDetailViewController:alert sender:nil];
}
-(void)showPasswordConfirmErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"adlg_new_password_check_error", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"change_password_title", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showPasswordStyleAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"adlg_new_password_format_error", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"change_password_title", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(BOOL)checkPassWord:(NSString *)password {
    //check password
    if (password.length < 8 || password.length > 32) {
        return false;
    }
    return true;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (range.location > 31){
        return false;
    }
    return true;
}

- (IBAction)doBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

@end
