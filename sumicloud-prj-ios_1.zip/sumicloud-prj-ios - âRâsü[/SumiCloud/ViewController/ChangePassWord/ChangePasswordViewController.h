//
//  ChangePasswordViewController.h
//  RentalApp
//
//  Created by fsi-mac5d-13 on 2020/06/17.
//  Copyright © 2020 fsi_mac5d_2. All rights reserved.
//

#import "SCBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ChangePasswordViewController : SCBaseViewController

@end

NS_ASSUME_NONNULL_END
