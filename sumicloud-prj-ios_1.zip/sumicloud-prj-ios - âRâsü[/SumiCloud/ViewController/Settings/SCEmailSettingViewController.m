//
//  SCEmailSettingViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2019/12/17.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCEmailSettingViewController.h"
#import "SCSystemData.h"

@interface SCEmailSettingViewController ()

@property (weak, nonatomic) IBOutlet UILabel *mainTitleLbl;
@property (weak, nonatomic) IBOutlet UILabel *subTitleLbl;


@end

@implementation SCEmailSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];

    // 多言語対応
    self.title = @"報告設定";
}

- (IBAction)actionBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)actionSet:(id)sender {
    
}

- (IBAction)actionClear:(id)sender {
    
}


@end
