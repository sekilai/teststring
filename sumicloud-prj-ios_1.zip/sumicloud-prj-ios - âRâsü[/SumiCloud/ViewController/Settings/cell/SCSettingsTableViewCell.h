//
//  SCSettingsTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/31.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCSettingsTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblDetail;
@property (weak, nonatomic) IBOutlet UIImageView *imglisrArraw;
@property (weak, nonatomic) IBOutlet UISwitch *switchThreshold;

@end
