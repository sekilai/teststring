//
//  SCThresholdTableViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_8 on 2016/11/29.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCThresholdTableViewCell.h"

#import "SCSystemData.h"

@interface SCThresholdTableViewCell () <UITextFieldDelegate>

@property (nonatomic) id setting;

@property (weak, nonatomic) IBOutlet UIButton *btnResetUpInside;
@end

@implementation SCThresholdTableViewCell
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

#pragma mark - Button Action

/**
 リセットボタン

 @param sender <#sender description#>
 */
- (IBAction)btnResetUpInside:(id)sender {

    // 入力値をクリアする
    self.txtValue.text = @"";
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(endEditing:)]) {
        
        [self.delegate endEditing:self];
    }
}

#pragma mark - UITextFieldDelegate

/**
 テキスト入力開始

 @param textField <#textField description#>
 @return <#return value description#>
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(beginEditing:)]) {
        
        [self.delegate beginEditing:self];
    }
    
    return YES;
}

/**
 テキスト入力終了

 @param textField <#textField description#>
 */
- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(endEditing:)]) {
        
        [self.delegate endEditing:self];
    }
}

/**
 閾値パラメータ設定

 @param param <#param description#>
 @param entryVal <#entryVal description#>
 */
- (void)setParam:(id)param entryVal:(NSString *)entryVal {
    
    self.setting = param;
    
    if ([param isKindOfClass:SCDecimalThreshold.class]) {
        
        SCDecimalThreshold *data = param;
        // キーボード設定
        self.txtValue.keyboardType = UIKeyboardTypeNumberPad;
        
        // 入力値
        self.txtValue.text = entryVal;
        
        // 推奨値
        NSMutableString *recommend = [[NSMutableString alloc] initWithCapacity:0];
        [recommend appendFormat:@"(%@ ", NSLocalizedString(@"MSG_10041", @"推奨")];
        [recommend appendFormat:data.format, data.defaultValue];
        [recommend appendFormat:@")"];
        self.lblRecomm.text = recommend;
    } else {
        
        SCDoubleThreshold *data = param;
        // キーボード設定
        self.txtValue.keyboardType = UIKeyboardTypeDecimalPad;
        
        // 入力値
        self.txtValue.text = [SCSystemData stringFromDoubleString:entryVal decimalLength:2];
        
        // 推奨値
        NSMutableString *recommend = [[NSMutableString alloc] initWithCapacity:0];
        [recommend appendFormat:@"(%@ ", NSLocalizedString(@"MSG_10041", @"推奨")];
        NSString* recommendFormat = [[NSString alloc] initWithFormat:data.format, data.defaultValue];
        [recommend appendFormat:@"%@", [SCSystemData stringFromDoubleString:recommendFormat decimalLength:2]];
        [recommend appendFormat:@")"];
        self.lblRecomm.text = recommend;
    }
}

@end
