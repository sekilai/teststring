//
//  SCThresholdTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_8 on 2016/11/29.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SCThresholdTableViewCellDelegate <NSObject>

- (void)beginEditing:(UITableViewCell *)cell;
- (void)endEditing:(UITableViewCell *)cell;

@end

@interface SCThresholdTableViewCell : UITableViewCell 

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UITextField *txtValue;
@property (weak, nonatomic) IBOutlet UIButton *btnReset;
@property (weak, nonatomic) IBOutlet UILabel *lblRecomm;

@property (nonatomic) id<SCThresholdTableViewCellDelegate> delegate;

- (void)setParam:(id)param entryVal:(NSString *)entryVal;

@end
