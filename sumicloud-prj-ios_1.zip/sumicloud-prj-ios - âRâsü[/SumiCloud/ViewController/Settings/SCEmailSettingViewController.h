//
//  SCEmailSettingViewController.h
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2019/12/17.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCEmailSettingViewController : SCBaseViewController

@end

