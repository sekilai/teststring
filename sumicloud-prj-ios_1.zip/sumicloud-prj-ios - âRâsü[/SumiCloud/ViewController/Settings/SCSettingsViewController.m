//
//  SCSettingsViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSettingsViewController.h"
#import "SCSettingsTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCSpliceDataFlow.h"
#import "SCAutoDiagnosisFlow.h"
#import "SCSettingsFlow.h"
#import "SCInstructionViewController.h"
#import "SCSpliceDataDao.h"
#import "SCConnectSplice.h"
#import "SCConnectSpliceDao.h"
#import "SCPreventiveSplicerInfo.h"

@interface SCSettingsViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) NSMutableArray* listFunctionMenu;
@property (assign, nonatomic) BOOL updatePreventiveStatusAndFWVersion;
@property (assign, nonatomic) BOOL preventiveSettingEnable;

@property (weak, nonatomic) IBOutlet UITableView *tblvwFunctionMenu;

- (IBAction)actionClose:(UIBarButtonItem *)sender;





@end

@implementation SCSettingsViewController

static NSString* const kST_Title = @"Title";     // メニュータイトル
static NSString* const kST_SegueId = @"SegueId"; // 画面遷移ID

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];

    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_SETTING", @"設定");

    // 機能メニュー
    self.listFunctionMenu = [NSMutableArray arrayWithCapacity:0];
    
    // 余白セルを表示しない
    self.tblvwFunctionMenu.tableFooterView = [[UIView alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    // 機能メニュー
    self.listFunctionMenu = [NSMutableArray arrayWithCapacity:0];
    [self.listFunctionMenu addObject:@{
                                       // "Wi-Fiネットワーク"
                                       kST_Title : @"RES_20013",
                                       kST_SegueId : @""
                                       }];
//#if defined(DEBUG) || defined(DEMO) // DEBUG版、DEBUG_DEMO版、RELEASE_DEMO版
    
//    if ([SCSystemData isModelType72C:self.appData.selectedSerialNo]) {
//        [self.listFunctionMenu addObject:@{
//           // "ヘルスモニタ設定"
//           kST_Title : @"RES_20014",
//           kST_SegueId : @""
//        // kST_SegueId : @"toThresholdSpliceData"
//           }];
//    }
    
//#endif
//#if defined(DEBUG) || defined(DEMO) // DEBUG版、DEBUG_DEMO版、RELEASE_DEMO版
//    [self.listFunctionMenu addObject:@{
//                                       // "接続データ一括送信"
//                                       kST_Title : @"RES_20015",
//                                       kST_SegueId : @""
//                                       }];
//#endif
//    if ([SCSystemData isModelType72C:self.appData.selectedSerialNo] || [SCSystemData isModelTypeZ2C:self.appData.selectedSerialNo]) {
//        [self.listFunctionMenu addObject:@{
//                                           // "盗難防止ロック設定"
//                                           kST_Title : @"RES_20016",
//                                           kST_SegueId : @"toSecurityLock"
//                                           }];
//    }
#ifdef DEMO
    [self.listFunctionMenu addObject:@{
                                       // "融着接続機情報削除"
                                       kST_Title : @"MSG_12013",
                                       kST_SegueId : @""
                                       }];
#endif
    [self.listFunctionMenu addObject:@{
                                       // "インストラクション"
                                       kST_Title : @"MSG_13011",
                                       kST_SegueId : @"toInstruction"
                                       }];
    
    BOOL showPreventiveSetting = true;
    _updatePreventiveStatusAndFWVersion = false;
    
    NSDictionary *preventiveStatusDic = [[[SCSpliceDataDao alloc] init] getPreventiveSplicerInfoStatus:self.appData.selectedSerialNo];
    
    SCConnectSpliceDao* daoConnectSplice = [[SCConnectSpliceDao alloc] init];
    SCConnectSplice* connectSplice = [daoConnectSplice getSplicerState:self.appData.selectedSerialNo];
    NSNumber* currentVersion = [NSNumber numberWithFloat:[connectSplice.current_version floatValue]];
    NSNumber* supportVersion = [NSNumber numberWithFloat:1.14];
    
    NSString *versionCheckKey = [NSString stringWithFormat:@"versionCheck%@",self.appData.selectedSerialNo];
    NSString *versionResult = [[NSUserDefaults standardUserDefaults] stringForKey:versionCheckKey];
//
    if ([SCSystemData isModelType72C:self.appData.selectedSerialNo] ||
        [SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
        showPreventiveSetting = true;
        if ([preventiveStatusDic count] == 0 && connectSplice.current_version == 0 && versionResult == nil) {
            _updatePreventiveStatusAndFWVersion = true;
            self.preventiveSettingEnable = true;
        } else {
            NSNumber *preventiveStatus = [preventiveStatusDic objectForKey:@"status"];
            if ([SCSystemData isModelType72C:self.appData.selectedSerialNo]) {
                if (preventiveStatus == nil) {
                    self.preventiveSettingEnable = true;
                }else if ( ([preventiveStatus intValue] == 1 &&
                    [currentVersion compare:supportVersion] == kCFCompareGreaterThan) ||
                    [versionResult isEqualToString:@"supportPreventive"]) {
                    self.preventiveSettingEnable = true;
                } else {
                    self.preventiveSettingEnable = false;
                }
            } else if ([SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
                if ([preventiveStatus intValue] == 1 ||
                    [versionResult isEqualToString:@"supportPreventive"]) {
                    self.preventiveSettingEnable = true;
                } else {
                    self.preventiveSettingEnable = false;
                }
            }
            
        }
    } else {
        showPreventiveSetting = false;
    }
    
    if (![self isSplicerConnect:self.appData.selectedSerialNo]) {
        showPreventiveSetting = true;
        self.preventiveSettingEnable = true;
    }
    
    if (showPreventiveSetting) {
        
        [self.listFunctionMenu addObject:@{
        // "予防保全設定"
        kST_Title : @"MSG_13077",
        kST_SegueId : @""
        }];
        
    }
    
//    [self.listFunctionMenu addObject:@{
//    // "報告設定"
//    kST_Title : @"MSG_13076",
//    kST_SegueId : @""
//    }];
    [self.tblvwFunctionMenu reloadData];
}

#pragma mark - UISwitchButton Action

- (IBAction)healthMonitorSwitch:(UISwitch *)sender {
    
    [[NSUserDefaults standardUserDefaults] setObject:@(sender.isOn) forKey:kSC_ThresholdKey_HealthMonitorStatus];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [SCSystemData changeTotalCheckResult:self.appData.selectedSerialNo updateCheckTime:false];
}

#pragma mark - Button Action

/**
 閉じるボタン

 @param sender <#sender description#>
 */
- (IBAction)actionClose:(UIBarButtonItem *)sender {
    
    DDLogInfo(@"閉じるボタン -> 設定画面を閉じる");
    
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param section   <#section description#>

 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listFunctionMenu.count;
}

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>

 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    SCSettingsTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];

    NSDictionary* dic = [self.listFunctionMenu objectAtIndex:indexPath.row];
    cell.lblTitle.text = NSLocalizedString(dic[kST_Title], @"ラベル");
    cell.lblTitle.enabled = YES;
    cell.lblDetail.text = @"";
    cell.lblDetail.enabled = YES;
    cell.imglisrArraw.hidden =NO;

    if ([@"RES_20015" isEqualToString:dic[kST_Title]]) {
        
        NSInteger count = [SCSpliceDataFlow unsentSpliceDataCount] + [[SCAutoDiagnosisFlow unsentNoticeList] count] + [SCSpliceDataFlow unsentPreventiveDataCount];
        if (0 == count) {
            
            cell.lblDetail.text = NSLocalizedString(@"MSG_13021", @"未送信データなし");
            cell.lblTitle.enabled = NO;
            cell.lblDetail.enabled = NO;
        } else {
            
            cell.lblDetail.text = NSLocalizedString(@"MSG_13022", @"未送信データあり");
        }
    }else if ([@"RES_20014" isEqualToString:dic[kST_Title]]){
        cell.imglisrArraw.hidden =YES;
        cell.switchThreshold.hidden = NO;
        BOOL isHealthMonitorStatus = [[[NSUserDefaults standardUserDefaults] stringForKey:kSC_ThresholdKey_HealthMonitorStatus] boolValue];
        
        if (isHealthMonitorStatus) {
            [cell.switchThreshold setOn:isHealthMonitorStatus];
        }else {
            [cell.switchThreshold setOn:NO];
        }
    } else if ([@"MSG_13077" isEqualToString:dic[kST_Title]]) {
        cell.lblTitle.enabled = self.preventiveSettingEnable;
        cell.lblDetail.enabled = self.preventiveSettingEnable;
    }
    
    return cell;
}

/**
 メニュー選択

 @param tableView <#tableView description#>
 @param indexPath indexPath description
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary* dic = [self.listFunctionMenu objectAtIndex:indexPath.row];
    
    NSString* segueId = dic[kST_SegueId];
    if (segueId.length) {
        
        // "自動診断閾値設定"
        // "盗難防止ロック設定"
        if ([@"RES_20016" isEqualToString:dic[kST_Title]]) {
            // 融着接続機選択確認
            if ([self isUnselectSplicerAlert]) {
                
                return;
            }
            
            if(![SCSystemData isModelType72C:self.appData.selectedSerialNo] && ![SCSystemData isModelTypeZ2C:self.appData.selectedSerialNo]) {
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_13025", "この融着接続機は、ロック機能をサポートしてません。") preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
                [self presentViewController:alert animated:YES completion:nil];
            } else {
                DDLogDebug(@"画面遷移 -->> %@", segueId);
                
                [self performSegueWithIdentifier:segueId sender:self];
            }
        } else {
            DDLogDebug(@"画面遷移 -->> %@", segueId);
            
            [self performSegueWithIdentifier:segueId sender:self];
        }
        
    } else if ([@"RES_20013" isEqualToString:dic[kST_Title]]) {
        
        // "Wi-Fiネットワーク"
        NSMutableString* msg = [NSMutableString stringWithCapacity:0];
        [msg appendString:NSLocalizedString(@"MSG_10001", @"確認メッセージ")];
        [msg appendString:@"\n\n\n\n"];
        [msg appendString:NSLocalizedString(@"MSG_10000", @"確認メッセージ")];
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_SETTING", @"設定") message:msg preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:nil];
    } else if ([@"RES_20015" isEqualToString:dic[kST_Title]]) {

        // "接続データ一括送信"
        SCSettingsTableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
        if (cell.lblTitle.enabled) {
            
            // Wi-Fi切り替え確認
            if (![self isMobileConnect]) {
                
                [self connectSplicerAlert];
                
                return;
            }
            
            // 活性のメニューの場合、接続データ一括送信を実施する
            [self sendSpliceAndAutoDiagData];
        }
    }else if ([@"MSG_12013" isEqualToString:dic[kST_Title]]) {

        // 融着接続機情報削除（デモ用のみ）
        [self clearConnectSplice];
        
    }else if ([@"MSG_13077" isEqualToString:dic[kST_Title]]) {
        
        if (![self isSplicerConnect:self.appData.selectedSerialNo]) {
            
            [self showAlert:NSLocalizedString(@"MSG_13079", @"融着機の情報取得が必要です。融着機を接続してください.")];
            
            return;
        }
        //予防保全設定
        if (_updatePreventiveStatusAndFWVersion){
            [self updatePreventiveStatusAndFWVersionFlow];
        } else {
            if ([SCSystemData isModelType72C:self.appData.selectedSerialNo] || [SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
                SCSettingsTableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
                if (cell.lblTitle.enabled) {
                    NSDictionary *preventiveStatusDic = [[[SCSpliceDataDao alloc] init] getPreventiveSplicerInfoStatus:self.appData.selectedSerialNo];
                 
                    NSNumber *preventiveStatus = [preventiveStatusDic objectForKey:@"status"];
                    if (preventiveStatus == nil) {
                        [self showAlert:NSLocalizedString(@"MSG_13079", @"融着機の情報取得が必要です。融着機を接続してください.")];
                        
                        return;
                    }
                    [self performSegueWithIdentifier:@"toPreventiveSetting" sender:self];
                }
            } else {
                [self performSegueWithIdentifier:@"toPreventiveSetting" sender:self];
            }
        }
    }else if ([@"MSG_13076" isEqualToString:dic[kST_Title]]) {
        //報告先設定
        [self performSegueWithIdentifier:@"toEmailSetting" sender:self];
    }
}

#pragma mark - Segue

/**
 画面遷移
 
 @param segue  <#segue description#>
 @param sender <#sender description#>
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    DDLogDebug(@"%@", segue.identifier);
    
    if ([@"toInstruction" isEqualToString:segue.identifier]) {
        SCInstructionViewController * vc = ((UINavigationController *)segue.destinationViewController).viewControllers[0];
        vc.hideCheck = YES;
    }
}


#pragma mark - Private Method

/**
 接続データ一括送信
 */
- (void)sendSpliceAndAutoDiagData {
    
    DDLogDebug(@"接続データ一括送信");
    
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        NSError* error = nil;
        
        NSArray* listSpliceData = [SCSpliceDataFlow unsentSpliceDataList];
        DDLogInfo(@"融着/自動診断データ送信（接続データ）:未送信件数<%@>", [NSNumber numberWithInteger:listSpliceData.count]);
        SCSpliceDataFlow* flow = [[SCSpliceDataFlow alloc] init];
        [flow runSentPreventingResultFlow];
        for (SCSpliceData* item in listSpliceData) {
            // 接続データ送信
            error = [flow uploadSpliceData:item];
            // 接続データ送信エラー判定
            if (error) {
                break;
            }
        }
        
        NSArray* listAutoDiag = [SCAutoDiagnosisFlow unsentNoticeList];
        DDLogInfo(@"融着/自動診断データ送信（自動診断データ）:未送信件数<%@>", [NSNumber numberWithInteger:listAutoDiag.count]);
        SCAutoDiagnosisFlow* autoDiagFlow = [[SCAutoDiagnosisFlow alloc] init];
        for (SCAutoDiagnosisData* item in listAutoDiag) {
            error = [autoDiagFlow uploadAutoDiagnosisNotice:item];
            if (error) {
                break;
            }
        }
        
        [self hideProgress];
        
        if (error) {
            
            DDLogError(@"融着/自動診断データ送信エラー:<<%@>>", error.description);
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10022", @"エラーメッセージ") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            
            [self presentViewController:alert animated:YES completion:^{
            }];
        } else {
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:NSLocalizedString(@"MSG_10021", @"完了メッセージ") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            
            [self presentViewController:alert animated:YES completion:^{
            }];
        }
        
        // メニュー更新
        [self.tblvwFunctionMenu reloadData];
    });
}


/**
 *  融着機接続情報クリア
 */
- (void)clearConnectSplice {
    
    // 開始メッセージ
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_12011", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_DELETE", @"削除") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        DDLogDebug(@"融着機接続情報削除");
        
        // データクリア開始
        [self showProgress:NSLocalizedString(@"DLG_PROCESS", @"処理中....") cancelHandler:nil];
        
        // 融着接続機テーブルのクリア
        SCSettingsFlow* flow = [[SCSettingsFlow alloc] init];
        [flow clearConnectSplice];
        
        // データクリア完了
        [self hideProgress];
        
        // 完了メッセージ
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:NSLocalizedString(@"MSG_12012", @"完了メッセージ") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            // Top画面へ戻る
            [self dismissViewControllerAnimated:YES completion:^{
            }];
        }]];
        
        [self presentViewController:alert animated:YES completion:nil];
    }]];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)updatePreventiveStatusAndFWVersionFlow{
    
    if (![self isSplicerConnect:self.appData.selectedSerialNo]) {
        
        [self showAlert:NSLocalizedString(@"MSG_13079", @"融着機の情報取得が必要です。融着機を接続してください.")];
        
        return;
    }
    
    [self showProgress:NSLocalizedString(@"MSG_10011", @"接続データを取得しています") cancelHandler:^{

    }];
    
    [self checkUpdateDataFlowWithComplete:^(bool status) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideProgress];
            if (status) {
                [self performSegueWithIdentifier:@"toPreventiveSetting" sender:self];
            } else {
                [self viewWillAppear:true];
                [self showAlert:NSLocalizedString(@"MSG_13078", @"この融着機は予防保全の対象ではありません.")];
            }
        });
    }];
}

-(void)checkUpdateDataFlowWithComplete:(void (^)(bool status))complete{
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        SCFlashAirService* serviceFlashAir = [[SCFlashAirService alloc] init];
        NSError* err = nil;
        NSDictionary* listCommandResult = nil;
        NSString *serialNo = self.appData.selectedSerialNo;
        serviceFlashAir.serialNo = serialNo;
        
        // ファイル削除
        [serviceFlashAir removeFile:kSC_RET_TXT];
        
        // シリアル番号の融着接続機の状況を取得
        SCConnectSpliceDao* daoConnectSplice = [[SCConnectSpliceDao alloc] init];
        SCConnectSplice* connectSplice = [daoConnectSplice getSplicerState:self.appData.selectedSerialNo];

        NSString* now = [SCSystemData stringFromDate:[NSDate date] format:@"yyyyMMdd"];
        
        if (![now isEqualToString:connectSplice.timesync_date]) {
        
        // 6.ソフトバージョン情報取得
            NSArray* listVersionCmd = @[@"MM888"];
            if ([SCSystemData isModelType72C:serialNo] ||
                [SCSystemData isModelTypeZ2C:serialNo] ||
                [SCSystemData isModelType72M:serialNo] ||
                [SCSystemData isModelTypeT502:serialNo]) {

                listVersionCmd = @[@"MM888",@"MM881",@"MM882",@"MM883",@"MM884",@"MM886"];
                
                err = [serviceFlashAir getVersionMulti:listVersionCmd];
                [serviceFlashAir removeFile:kSC_RET_TXT];
                listCommandResult = [serviceFlashAir getVersionResult:listVersionCmd];
                connectSplice.current_version = listCommandResult[kSC_GETVERSION];
                NSNumber* currentVersion = [NSNumber numberWithFloat:[connectSplice.current_version floatValue]];
                NSNumber* supportVersion = [NSNumber numberWithFloat:1.14];
                if ([currentVersion compare:supportVersion] == kCFCompareLessThan && ![SCSystemData isModelTypeT502:serialNo]) {
                    NSString *versionCheckKey = [NSString stringWithFormat:@"versionCheck%@",self.appData.selectedSerialNo];
                    [[NSUserDefaults standardUserDefaults] setValue:@"unSupportPreventive" forKey:versionCheckKey];
                    complete(false);
                    return;
                } else {
                    NSString *versionCheckKey = [NSString stringWithFormat:@"versionCheck%@",self.appData.selectedSerialNo];
                    [[NSUserDefaults standardUserDefaults] setValue:@"supportPreventive" forKey:versionCheckKey];
                }

            }
            
            
            BOOL isCheckPreventive = [serviceFlashAir getPreventiveStatus];
            SCPreventiveSplicerInfo *spliceInfo = [[SCPreventiveSplicerInfo alloc] init];
            spliceInfo.serialNo = self.appData.selectedSerialNo;
            spliceInfo.status = isCheckPreventive ? 1 : 0;
            [[[SCSpliceDataDao alloc] init] updatePreventiveSplicerInfoStatus:spliceInfo];
            if (!isCheckPreventive) {
                NSString *versionCheckKey = [NSString stringWithFormat:@"versionCheck%@",self.appData.selectedSerialNo];
                [[NSUserDefaults standardUserDefaults] setValue:@"unSupportPreventive" forKey:versionCheckKey];
                complete(false);
                return;
            } else {
                NSString *versionCheckKey = [NSString stringWithFormat:@"versionCheck%@",self.appData.selectedSerialNo];
                [[NSUserDefaults standardUserDefaults] setValue:@"supportPreventive" forKey:versionCheckKey];
            }
            
        }
        
        complete(true);
        
    });
}

-(void)showAlert:(NSString *)alertString{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:alertString preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }]];
    [self showDetailViewController:alert sender:nil];
}

@end
