//
//  UIView+Border.m
//  SumiCloud
//
//  Created by fsi_mac5d_8 on 2016/11/16.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "UIView+Border.h"

@implementation UIView (Border)

/**
 枠線の色
 */
- (UIColor *)borderColor
{
    return [UIColor colorWithCGColor:self.layer.borderColor];
}
- (void)setBorderColor:(UIColor *)borderColor
{
    self.layer.borderColor = borderColor.CGColor;
}

/**
 枠線のWidth
 */
-(CGFloat)borderWidth
{
    return self.layer.borderWidth;
}
- (void)setBorderWidth:(CGFloat)borderWidth
{
    self.layer.borderWidth = borderWidth;
}

@end
