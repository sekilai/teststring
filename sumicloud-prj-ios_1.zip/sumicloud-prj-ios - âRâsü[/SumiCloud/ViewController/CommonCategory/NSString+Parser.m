//
//  NSString+Parser.m
//  SumiCloud
//
//  Created by fsi_mac5d_8 on 2016/12/20.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "NSString+Parser.h"

@implementation NSString (Parser)

/**
 文字列 -> NSTimeInterval変換

 @param format <#format description#>
 @return <#return value description#>
 */
- (NSTimeInterval)timeIntervalWithFormat:(NSString *)format {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"ss"];
    NSDate *start = [dateFormatter dateFromString:@"0"];
    [dateFormatter setDateFormat:format];
    NSDate *end = [dateFormatter dateFromString:self];
    NSTimeInterval interval = [end timeIntervalSinceDate:start];
    return interval;
}

/**
 文字列 -> UIColor変換

 @return <#return value description#>
 */
- (UIColor *)colorValue {
    
    unsigned int c;
    if ([self characterAtIndex:0] == '#') {
        [[NSScanner scannerWithString:[self substringFromIndex:1]] scanHexInt:&c];
    } else {
        [[NSScanner scannerWithString:self] scanHexInt:&c];
    }
    return [UIColor colorWithRed:((c & 0xff0000) >> 16)/255.0 green:((c & 0xff00) >> 8)/255.0 blue:(c & 0xff)/255.0 alpha:1.0];
}

/**
 文字列を指定した文字数で分割して配列に格納する

 @param number <#number description#>
 @return <#return value description#>
 */
- (NSArray *)splitString:(NSUInteger)number {
    if ([self length] <= number) {
        return @[self];
    }
    
    NSMutableArray  *mArray = [NSMutableArray new];
    NSMutableString *mStr   = [NSMutableString stringWithString:self];
    
    NSRange range = NSMakeRange(0, number);
    
    while ([mStr length] > 0) {
        if ([mStr length] < number) {
            [mArray addObject:[NSString stringWithString:mStr]];
            [mStr deleteCharactersInRange:NSMakeRange(0, [mStr length])];
        }
        else {
            [mArray addObject:[mStr substringWithRange:range]];
            [mStr deleteCharactersInRange:range];
        }
    }
    
    return [NSArray arrayWithArray:mArray];
}

@end
