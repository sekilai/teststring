//
//  SCCustomAlertViewController.h
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2021/03/01.
//  Copyright © 2021 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SCCustomAlertViewController : SCBaseViewController

@property (nonatomic,copy)NSString* errorCode;
@property (nonatomic,copy)NSString* errorMsg;
@property (nonatomic,copy) NSString* customMsg;

@end

NS_ASSUME_NONNULL_END
