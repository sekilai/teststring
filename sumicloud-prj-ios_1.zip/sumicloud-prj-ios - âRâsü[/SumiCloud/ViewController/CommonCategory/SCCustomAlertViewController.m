//
//  SCCustomAlertViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2021/03/01.
//  Copyright © 2021 fsi_mac5d_5. All rights reserved.
//

#import "SCCustomAlertViewController.h"

@interface SCCustomAlertViewController ()
@property (weak, nonatomic) IBOutlet UIView *mainView;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@end

@implementation SCCustomAlertViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.lblMsg.text = [NSString stringWithFormat:self.errorMsg,self.errorCode];
    self.view.backgroundColor = [UIColor clearColor];
    [self showMainView];
}

-(void)showMainView{
    [UIView animateWithDuration:0.3 animations:^{
        self.mainView.alpha = 1;
    }];
}

- (IBAction)OkBtnClicked:(id)sender {
    [self dismissViewControllerAnimated:false completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
