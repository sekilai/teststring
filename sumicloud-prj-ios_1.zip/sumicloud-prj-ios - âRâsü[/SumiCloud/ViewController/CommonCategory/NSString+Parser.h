//
//  NSString+Parser.h
//  SumiCloud
//
//  Created by fsi_mac5d_8 on 2016/12/20.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (Parser)

// 文字列 -> NSTimeInterval変換
- (NSTimeInterval)timeIntervalWithFormat:(NSString *)format;

// 文字列 -> UIColor変換
- (UIColor *)colorValue;

// 文字列を指定した文字数で分割して配列に格納する
- (NSArray *)splitString:(NSUInteger)number;


@end
