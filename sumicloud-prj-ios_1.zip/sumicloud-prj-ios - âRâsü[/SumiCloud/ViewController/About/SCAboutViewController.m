//
//  SCAboutViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCAboutViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"

@interface SCAboutViewController () <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tblMenu;
@property (weak, nonatomic) IBOutlet UILabel *lblVersion;

@property (nonatomic) NSArray *aboutList;

- (IBAction)btnCloseAction:(id)sender;

@end

@implementation SCAboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_ABOUT", @"このアプリについて");
    
    self.aboutList = @[NSLocalizedString(@"TITLE_TERMS_SERVICE", @"利用規約"),
                       NSLocalizedString(@"TITLE_PRIVACYPOLICY", @"プライバシーポリシー"),
                       NSLocalizedString(@"TITLE_OSS_LICENCE", @"オープンソースライセンス")];
    
    self.lblVersion.text = [NSString stringWithFormat:@"Ver%@", [SCSystemData getAppVersion]];
    
    // 余白セルを表示しない
    self.tblMenu.tableFooterView = [[UIView alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Button Action

/**
 閉じるボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCloseAction:(id)sender {
    
    DDLogDebug(@"");
    
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}

#pragma mark - UITableViewDelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.aboutList.count;
}

/**
 メニュー項目作成

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"aboutListCell"];
    
    UILabel *lblTitle = [cell viewWithTag:1];
    lblTitle.text = self.aboutList[indexPath.row];
    
    return cell;
}

/**
 メニュー項目の選択

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.row) {
        case 0:
            // 利用規約
            [self performSegueWithIdentifier:@"toTermsOfService" sender:self];
            break;
            
        case 1:
            // プライバシーポリシー
            [self performSegueWithIdentifier:@"toPrivacyPolicy" sender:self];
            break;

        case 2:
            // オープンソースライセンス
            [self performSegueWithIdentifier:@"toOpenSourceSoftwareLicence" sender:self];
            break;
            
        default:
            break;
    }
}

@end
