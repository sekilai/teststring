//
//  SCOpenSourceSoftwareLicenceViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCOpenSourceSoftwareLicenceViewController.h"
#import "SCLogUtil.h"

@interface SCOpenSourceSoftwareLicenceViewController () <UITableViewDataSource, UITableViewDelegate>
{
    NSString *cocoaLumberjack;
    NSString *fmdb;
    NSString *lumberjackConsole;
    NSString *mrProgress;
    NSString *nbuCore;
    NSString *zipArchive;
}
@property (nonatomic) NSArray *ossList;

- (IBAction)actionBack:(UIBarButtonItem *)sender;

@end

@implementation SCOpenSourceSoftwareLicenceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_OSS_LICENCE", @"オープンソースライセンス");
    
    // オープンソース一覧
    self.ossList = @[@"CocoaLumberjack",
                     @"FMDB",
                     @"LumberjackConsole",
                     @"MRProgress",
                     @"NBUCore",
                     @"ZipArchive"];
    
    // オープンソースライセンス情報
    cocoaLumberjack = [self getCocoaLumberjackText];
    fmdb = [self getFmdbText];
    lumberjackConsole = [self getLumberjackConsoleText];
    mrProgress = [self getMRProgressText];
    nbuCore = [self getNBUCoreText];
    zipArchive = [self getZipArchiveText];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIButton Action

/**
 Backボタン
 
 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {
    
    DDLogDebug(@"");
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UITableViewDelegate

/**
 セクション数の設定

 @param tableView <#tableView description#>
 @return <#return value description#>
 */
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    // タイトルとライセンス情報で個別にセクションを作成
    return 12;
}

/**
 テーブルの列数

 @param tableView <#tableView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    // タイトルはフッターのみを表示
    if (section % 2 == 0) {
        
        return 0;
    }else {
        
        return 1;
    }
}

/**
 列の高さ

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // テキストの長さによって高さを変更
    NSString * licenseString = [self licenseString:indexPath];
    NSAttributedString *attributedText = [[NSAttributedString alloc]
                                          initWithString:licenseString
                                          attributes:@{
                                                       NSFontAttributeName: [UIFont systemFontOfSize:14]
                                                       }];
    CGRect rect = [attributedText boundingRectWithSize:
                   (CGSize){tableView.frame.size.width - 30, CGFLOAT_MAX}
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                               context:nil];
    
    return rect.size.height + 10;
}

/**
 タイトルの設定

 @param tableView <#tableView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    
    // タイトル行のみオープンソース名を設定
    if (section % 2 == 0) {
        
        NSInteger index = section / 2;
        return self.ossList[index];
    }else {
        
        return @"";
    }
}

/**
 ライセンス情報の表示

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"licenceCell"];
    
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.font = [UIFont systemFontOfSize:14];
    cell.textLabel.text = [self licenseString:indexPath];
    
    return cell;
}


#pragma mark - Private Methods

/**
 CocoaLumberjackのライセンス情報

 @return <#return value description#>
 */
- (NSString *)getCocoaLumberjackText {

    // LICENSE
    return [self getTextFile:@"About/Licence/CocoaLumberjack/LICENSE"];
}

/**
 FMDBのライセンス情報

 @return <#return value description#>
 */
- (NSString *)getFmdbText {

    // LICENSE
    return [self getTextFile:@"About/Licence/FMDB/LICENSE"];
}

/**
 LumberjackConsoleのライセンス情報

 @return <#return value description#>
 */
- (NSString *)getLumberjackConsoleText {

    // NOTICE
    NSString *notice = [self getTextFile:@"About/Licence/LumberjackConsole/NOTICE"];
    
    // LICENSE
    NSString *license = [self getTextFile:@"About/Licence/LumberjackConsole/LICENSE"];
    
    NSString *result = [notice stringByAppendingString:license];
    
    return result;
}

/**
 MRProgressのライセンス情報

 @return <#return value description#>
 */
- (NSString *)getMRProgressText {
    
    //LICENSE
    return [self getTextFile:@"About/Licence/MRProgress/LICENSE"];
}

/**
 NBUCoreのライセンス情報

 @return <#return value description#>
 */
- (NSString *)getNBUCoreText {
    
    // NOTICE
    NSString *notice = [self getTextFile:@"About/Licence/NBUCore/NOTICE"];
    
    // LICENSE
    NSString *license = [self getTextFile:@"About/Licence/NBUCore/LICENSE"];
    
    NSString *result = [notice stringByAppendingString:license];
    
    return result;
}

/**
 ZipArchiveのライセンス情報

 @return <#return value description#>
 */
- (NSString *)getZipArchiveText {
    
    //LICENSE
    return [self getTextFile:@"About/Licence/ZipArchive/LICENSE"];
}

/**
 ライセンス情報取得

 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (NSString *)licenseString:(NSIndexPath *)indexPath {

    NSString * ret;
    
    NSInteger index = indexPath.section / 2;
    switch (index) {
        case 0:
            // CocoaLumberjack
            ret = cocoaLumberjack;
            break;
            
        case 1:
            // FMDB
            ret = fmdb;
            break;
            
        case 2:
            // LumberjackConsole
            ret = lumberjackConsole;
            break;
            
        case 3:
            // MRProgress
            ret = mrProgress;
            break;
            
        case 4:
            // NBUCore
            ret = nbuCore;
            break;
            
        case 5:
            // ZipArchive
            ret = zipArchive;
            break;
            
        default:
            break;
    }
    
    return ret;
}


/**
 テキスト読み込み

 @param fileName <#fileName description#>
 @return <#return value description#>
 */
- (NSString *)getTextFile:(NSString *)fileName {
    
    // テキストファイルの読み込み
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:@"txt"];
    NSError *error;
    NSString *text = [[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
    
    if (error) {
        
        // 拡張子の存在しないファイルの読み込み
        error = nil;
        NSString *noExtPath = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
        text = [[NSString alloc] initWithContentsOfFile:noExtPath encoding:NSUTF8StringEncoding error:&error];
        
        if (error) {
            
            DDLogError(@"%@.txt読み込み失敗", fileName);
            text = @"";
        }
    }
    
    return text;
}

@end
