//
//  SCTermsOfServiceViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCTermsOfServiceViewController.h"
#import "SCLogUtil.h"

@interface SCTermsOfServiceViewController ()

@property (weak, nonatomic) IBOutlet UITextView *textView;

- (IBAction)actionBack:(UIBarButtonItem *)sender;

@end

@implementation SCTermsOfServiceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_TERMS_SERVICE", @"利用規約");
    
    // 利用規約
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"About/Terms" ofType:@"txt"];
    NSError *error;
    NSString *text = [[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
    
    if (error != nil) {
        DDLogError(@"読み込み失敗");
        text = @"";
    }
    self.textView.text = text;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLayoutSubviews {
    
    [super viewDidLayoutSubviews];
    
    // デバイスによって先頭が表示されない対策
    self.textView.contentOffset = CGPointZero;
}

#pragma mark - UIButton Action

/**
 Backボタン
 
 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {
    
    DDLogDebug(@"");
    
    [self.navigationController popViewControllerAnimated:YES];
}

@end
