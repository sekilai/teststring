//
//  SCFirmwareUpdateConfirmVerViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_2 on 2017/11/28.
//  Copyright © 2017年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCFirmwareUpdateConfirmVerViewController : SCBaseViewController
@property (nonatomic) NSString *targetSerialNo;
@end
