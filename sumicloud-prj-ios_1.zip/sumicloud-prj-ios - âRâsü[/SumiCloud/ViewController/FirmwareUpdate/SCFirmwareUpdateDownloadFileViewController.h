//
//  SCFirmwareUpdateDownloadFileViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_2 on 2017/11/28.
//  Copyright © 2017年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCFirmwareUpdateDownloadFileViewController : SCBaseViewController
@property (nonatomic) NSString *targetSerialNo; // 融着接続機のシリアル番号
@end
