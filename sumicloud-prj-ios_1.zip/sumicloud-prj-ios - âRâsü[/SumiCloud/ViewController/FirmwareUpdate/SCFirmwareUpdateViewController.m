//
//  SCFirmwareUpdateViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCFirmwareUpdateViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCFirmwareUpdateFlow.h"
#import "SCConnectSplice.h"

@interface SCFirmwareUpdateViewController ()

@property (nonatomic) SCFirmwareUpdateFlow* flow;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UILabel *lblTitleModel;
@property (weak, nonatomic) IBOutlet UILabel *lblModel;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleSelectedSerialNo;
@property (weak, nonatomic) IBOutlet UILabel *lblSelectedSerialNo;

@property (weak, nonatomic) IBOutlet UILabel *lblTitleCurrentVersion;
@property (weak, nonatomic) IBOutlet UILabel *lblCurrentVersion;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleLatestVersion;
@property (weak, nonatomic) IBOutlet UILabel *lblLatestVersion;
@property (weak, nonatomic) IBOutlet UILabel *lblUpdateMsg1;
@property (weak, nonatomic) IBOutlet UILabel *lblErrorRetryMsg;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwSplicerMenu;
@property (weak, nonatomic) IBOutlet UILabel *lblUpdateMsg2;

@property (weak, nonatomic) IBOutlet UIButton *btnCommit;
@property (weak, nonatomic) IBOutlet UIButton *btnCancel;

- (IBAction)actionClose:(UIBarButtonItem *)sender;
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender;

@end

@implementation SCFirmwareUpdateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    [self.btnCommit setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnCommit setTitleColor:[UIColor grayColor] forState:UIControlStateDisabled];
    [self.btnCancel setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];

    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_FIRMWARE_UPDATE", @"ファームウェアの更新");
    self.lblTitleModel.text = NSLocalizedString(@"RES_20031", @"モデル:");
    self.lblTitleSelectedSerialNo.text = NSLocalizedString(@"RES_20032", @"シリアル番号:");
    self.lblTitleCurrentVersion.text = NSLocalizedString(@"RES_20036", @"現在の〜");
    self.lblTitleLatestVersion.text = NSLocalizedString(@"RES_20037", @"最新の〜");
    self.lblUpdateMsg1.text = NSLocalizedString(@"MSG_10052", @"更新メッセージ");
    self.lblUpdateMsg2.text = NSLocalizedString(@"MSG_10053", @"更新メッセージ");
    [self.btnCommit setTitle:NSLocalizedString(@"BTN_COMMIT", @"更新") forState:UIControlStateNormal];
    [self.btnCancel setTitle:NSLocalizedString(@"BTN_CANCEL", @"キャンセル") forState:UIControlStateNormal];

    // FWファイル削除
    [SCFirmwareUpdateFlow clearFWFile];
    
    // 画面表示データの更新
    self.isSelectedSplicer = YES;
    self.lblSelectedSerialNo.text = self.targetSerialNo;
    self.lblModel.text = [SCSystemData getSpliceModelName:self.lblSelectedSerialNo.text];
    self.imgvwSplicerMenu.image = [self getSplicerNotReadyImage];
    [self.imgvwSplicerMenu addConstraint:[NSLayoutConstraint constraintWithItem:self.imgvwSplicerMenu
                                                                      attribute:NSLayoutAttributeHeight
                                                                      relatedBy:NSLayoutRelationEqual
                                                                         toItem:self.imgvwSplicerMenu
                                                                      attribute:NSLayoutAttributeWidth
                                                                     multiplier:self.imgvwSplicerMenu.image.size.height / self.imgvwSplicerMenu.image.size.width
                                                                       constant:0]];
    [self refreshSelectedSerialNo];
    [self refreshViewController];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    // 色味の設定（レイアウト確定後）
    [self.btnCommit setBackgroundImage:[self setButtonHilightBackColor:self.btnCommit.bounds] forState:UIControlStateHighlighted];
    
    [self.btnCancel setBackgroundImage:[self setButtonHilightBackColor:self.btnCancel.bounds] forState:UIControlStateHighlighted];
}


- (void)viewDidDisappear:(BOOL)animated {

    [super viewDidDisappear:animated];
    
    // FWファイル削除
    [SCFirmwareUpdateFlow clearFWFile];
}

/**
 融着接続機メニュー画面表示イメージ取得
 
 @return <#return value description#>
 */
- (UIImage *)getSplicerNotReadyImage {
    
    // TODO:NOT READY アラート表示に使用するイメージを取得するように共通化したい
    NSString *imageFile = @"";
    NSString *fileType = @"";
    
    // 言語を判断して画像を切り替える
    NSString *language = [SCSystemData getLanguage];
    if (![language isEqualToString:@"ja"]) {
        language = @"en";
    }
    
    // モデルによりファイル名を切り替える
    if (![SCSystemData isModelType72C:self.targetSerialNo] &&
        ![SCSystemData isModelTypeZ2C:self.targetSerialNo] &&
        ![SCSystemData isModelType72M:self.targetSerialNo] &&
        ![SCSystemData isModelTypeT502:self.targetSerialNo]) {
        
        imageFile = [NSString stringWithFormat:@"not_ready_%@", language];
        fileType = @"png";
    } else {
        // TODO:T72Cのファイル名(英語のみ)
        //imageFile = [NSString stringWithFormat:@"not_ready_%@_2", language];
        imageFile = [NSString stringWithFormat:@"not_ready_72"];
        fileType = @"png";
    }
    
    NSString* contentsFile = [[NSBundle mainBundle] pathForResource:[@"Dialog" stringByAppendingPathComponent:imageFile] ofType:fileType];
    return [UIImage imageWithContentsOfFile:contentsFile];
}

#pragma mark - Button Action

/**
 閉じるボタン

 @param sender <#sender description#>
 */
- (IBAction)actionClose:(UIBarButtonItem *)sender {

    DDLogInfo(@"閉じるボタン -> ファームウェアの更新画面を閉じる");
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知")  message:NSLocalizedString(@"MSG_13003", @"ファームウェアのアップデート処理を終了しますか？") preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:nil]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

/**
 更新ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender {
    
    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }
    
    // Wi-Fi切り替え確認
    if (![self isSplicerConnect:self.lblSerialNo.text]) {
        
        [self connectInternetAlert];
        
        return;
    }
    
    // 異なる融着機に接続
    if (![self.lblSelectedSerialNo.text isEqualToString:self.lblSerialNo.text]) {
        
        DDLogWarn(@"FW更新対象の融着機と異なる");
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知")  message:NSLocalizedString(@"MSG_10033", @"FW更新対象の融着機と異なる") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }

    DDLogInfo(@"更新ボタン -> ファームウェアの更新");
    
    self.flow = [[SCFirmwareUpdateFlow alloc] init];
    [self firmwareUpdate];
}


#pragma mark - Private Method

/**
 FWアップデート機能フロー
 */
- (void)firmwareUpdate {
    
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        
        [self.flow cancelFlow];
    }];

    // ビジネスフロー
    DDLogInfo(@"8.FWアップデート機能フロー:開始");
    [self.flow runFlow:self.appData.onlineSerialNo completion:^(NSError *error) {
        
        DDLogInfo(@"8.FWアップデート機能フロー:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideProgress];
            
            // ビジネスフロー結果メッセージ表示
            [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                
                if (ResultAction_RETRY == actionType) {
                    
                    // 再試行
                    [self firmwareUpdate];
                } else {
                    
                    if (!error && (kBF_FW_SUCCESS == self.flow.resultFlow)) {
                        
                        DDLogInfo(@"FW更新完了");
                        
                        [self dismissViewControllerAnimated:YES completion:^{
                        }];
                    } else if (!error && (kBF_FW_NOT_SUPPORT == self.flow.resultFlow)) {
                        
                        DDLogWarn(@"FW更新サポート対象外");
                        
                        [self dismissViewControllerAnimated:YES completion:^{
                        }];
                    } else if (!error && (kBF_FW_NO_NEED_UPDATE == self.flow.resultFlow)) {
                        
                        DDLogInfo(@"FW更新更新不要");
                        
                        [self dismissViewControllerAnimated:YES completion:^{
                        }];
                    } else if (!error && (kBF_FW_PAIRED_ERROR == self.flow.resultFlow)) {
                        DDLogInfo(@"FW更新前ペアリング解除が必要");
                        
                        [self dismissViewControllerAnimated:YES completion:^{
                        }];
                    }
                }
            }];
            
            [self refreshViewController];
        });
    }];
}

/**
 画面表示更新
 */
- (void)refreshViewController {
    
    // バージョン表示更新
    self.lblCurrentVersion.text = @"";
    self.lblLatestVersion.text = @"";
    SCConnectSplice* connectSplice = [SCFirmwareUpdateFlow getFWUpdateSplicer:self.lblSelectedSerialNo.text];
    if (connectSplice.current_version.length) {
        
        self.lblCurrentVersion.text = [connectSplice.current_version substringWithRange:NSMakeRange(0, connectSplice.current_version.length-1)];
    }
    if (connectSplice.lastest_version.length) {
        
        self.lblLatestVersion.text = [connectSplice.lastest_version substringWithRange:NSMakeRange(0, connectSplice.lastest_version.length-1)];
    }
    if([self.lblCurrentVersion.text isEqualToString:self.lblLatestVersion.text] && self.lblCurrentVersion.text.length > 0){
        self.lblUpdateMsg1.text = NSLocalizedString(@"MSG_10037", @"融着接続機は最新のバージョンです。");
        self.imgvwSplicerMenu.hidden = YES;
        self.lblUpdateMsg2.hidden = YES;
        self.btnCommit.enabled = NO;
    }else {
        self.lblUpdateMsg1.text = NSLocalizedString(@"MSG_10052", @"更新メッセージ");
        self.lblUpdateMsg2.text = NSLocalizedString(@"MSG_10053", @"更新メッセージ");
        self.imgvwSplicerMenu.hidden = NO;
        self.lblUpdateMsg2.hidden = NO;
        self.btnCommit.enabled = YES;

    }
    if(([SCSystemData isModelType72C:self.targetSerialNo] || [SCSystemData isModelTypeZ2C:self.targetSerialNo])
       && [SCFirmwareUpdateFlow isErrorRetryMessage:connectSplice.current_version]){
        self.lblErrorRetryMsg.text = NSLocalizedString(@"MSG_13013", @"");
    }else{
        self.lblErrorRetryMsg.text = @"";
    }
}


#pragma mark - Override Method

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    // シリアル番号
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    [super refreshOnlineSerialNo];
    
    if (![NSLocalizedString(@"NO_SERIAL", @"---") isEqualToString:self.appData.onlineSerialNo]) {
        
        self.appData.selectedSerialNo = self.appData.onlineSerialNo;
    }

}

@end
