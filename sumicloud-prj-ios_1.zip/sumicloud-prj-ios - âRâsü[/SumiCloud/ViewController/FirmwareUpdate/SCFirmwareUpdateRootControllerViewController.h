//
//  SCFirmwareUpdateRootControllerViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_2 on 2017/11/28.
//  Copyright © 2017年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCFirmwareUpdateRootControllerViewController : SCBaseViewController

@property (nonatomic) NSString *fromFlag; // nil:from menu 0:form need download 1:from firmwareupdate
@end
