//
//  SCFirmwareUpdateDownloadFileViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_2 on 2017/11/28.
//  Copyright © 2017年 fsi_mac5d_5. All rights reserved.
//

#import "SCFirmwareUpdateDownloadFileViewController.h"
#import "SCFirmwareUpdateViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCFirmwareUpdateFlow.h"
#import "SCConnectSplice.h"

@interface SCFirmwareUpdateDownloadFileViewController ()

@property (nonatomic) SCFirmwareUpdateFlow* flow;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UILabel *lblTitleModel;
@property (weak, nonatomic) IBOutlet UILabel *lblModel;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleSelectedSerialNo;
@property (weak, nonatomic) IBOutlet UILabel *lblSelectedSerialNo;

@property (weak, nonatomic) IBOutlet UILabel *lblUpdateMsg1;

@property (weak, nonatomic) IBOutlet UIButton *btnCommit;
@property (weak, nonatomic) IBOutlet UIButton *btnCancel;

- (IBAction)actionClose:(id)sender;
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender;
@end

@implementation SCFirmwareUpdateDownloadFileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    [self.btnCommit setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnCancel setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_FIRMWARE_UPDATE", @"ファームウェアの更新");
    self.lblTitleModel.text = NSLocalizedString(@"RES_20031", @"モデル:");
    self.lblTitleSelectedSerialNo.text = NSLocalizedString(@"RES_20032", @"シリアル番号:");
    self.lblUpdateMsg1.text = NSLocalizedString(@"MSG_13001", @"更新メッセージ");
    [self.btnCommit setTitle:NSLocalizedString(@"BTN_OK", @"OK") forState:UIControlStateNormal];
    [self.btnCancel setTitle:NSLocalizedString(@"BTN_CANCEL", @"キャンセル") forState:UIControlStateNormal];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(counterFirmwareData:) name:kSC_SDM_FirmwareDataCount object:nil];
    
    // 画面表示データの更新
    self.isSelectedSplicer = YES;
    self.lblSelectedSerialNo.text = self.targetSerialNo;
    self.lblModel.text = [SCSystemData getSpliceModelName:self.lblSelectedSerialNo.text];
    [self refreshSelectedSerialNo];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 画面表示制御
 
 @param animated <#animated description#>
 */
- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    // 色味の設定
    [self.btnCommit setBackgroundImage:[self setButtonHilightBackColor:self.btnCommit.bounds] forState:UIControlStateHighlighted];
    
    [self.btnCancel setBackgroundImage:[self setButtonHilightBackColor:self.btnCancel.bounds] forState:UIControlStateHighlighted];
    
}

/*
選択シリアル番号更新
*/
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    // シリアル番号
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

/**
 <#Description#>

 @param sender <#sender description#>
 */
- (IBAction)actionClose:(id)sender {
    DDLogInfo(@"閉じるボタン -> ファームウェアの更新画面を閉じる");
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知")  message:NSLocalizedString(@"MSG_13003", @"ファームウェアのアップデート処理を終了しますか？") preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:^{
        }];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:nil]];
    
    [self presentViewController:alert animated:YES completion:nil];
}
- (IBAction)btnCommitTouchUpInside:(UIButton *)sender {
    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }
    
    // Wi-Fi切り替え確認
    if (![self isMobileConnect]) {
        
        [self connectSplicerAlert];
        
        return;
    }
    

    [self downloadFWFile];
}
- (IBAction)btnCancelTouchUpInside:(UIButton *)sender {
    
}
- (void)downloadFWFile {
    DDLogInfo(@"更新ボタン -> ファームウェアの更新");
    
    self.flow = [[SCFirmwareUpdateFlow alloc] init];
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        
        [self.flow cancelFlow];
    }];
    
    // ビジネスフロー
    DDLogInfo(@"8.FWアップデート機能フロー:開始");
    [self.flow downloadFWFile:self.lblSelectedSerialNo.text completion:^(NSError *error) {
        
        DDLogInfo(@"8.FWアップデート機能フロー:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideProgress];
            
            if (!error && (
                           kBF_FW_SUCCESS == self.flow.resultFlow
                           || kBF_FW_NO_NEED_UPDATE == self.flow.resultFlow
                           || kBF_OK == self.flow.resultFlow
                           )) {
                
                DDLogInfo(@"FW更新完了");
                SCFirmwareUpdateViewController * fwViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"fwViewController"];
                fwViewController.targetSerialNo = self.targetSerialNo;
                [self.navigationController pushViewController:fwViewController animated:YES];
                
            } else {
                
                // ビジネスフロー結果メッセージ表示
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知")  message:NSLocalizedString(@"MSG_10012", @"サーバーとの接続に失敗しました。") preferredStyle:UIAlertControllerStyleAlert];
                
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
                [self presentViewController:alert animated:YES completion:nil];
            }
        });
    }];
}

- (void)counterFirmwareData:(NSNotification *)notification {
    
    NSDictionary* dicCount = notification.object;
    NSInteger maxCount = [dicCount[kSC_SDM_FirmwareDataMaxCount] integerValue];
    NSInteger currentCount = [dicCount[kSC_SDM_FirmwareDataCurrentCount] integerValue];
    
    [self updateProgressCounter:currentCount maxCount:maxCount];
}

@end
