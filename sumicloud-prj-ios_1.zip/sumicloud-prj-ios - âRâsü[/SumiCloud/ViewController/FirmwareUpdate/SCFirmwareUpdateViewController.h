//
//  SCFirmwareUpdateViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCFirmwareUpdateViewController : SCBaseViewController
@property (nonatomic) NSString *targetSerialNo; // 融着接続機のシリアル番号
@end
