//
//  SCFirmwareUpdateRootControllerViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_2 on 2017/11/28.
//  Copyright © 2017年 fsi_mac5d_5. All rights reserved.
//

#import "SCFirmwareUpdateRootControllerViewController.h"
#import "SCFirmwareUpdateViewController.h"
#import "SCFirmwareUpdateConfirmVerViewController.h"
#import "SCFirmwareUpdateDownloadFileViewController.h"
#import "SCLogUtil.h"
#import "SCConnectSpliceDao.h"

#import "SCSystemData.h"
#import "SCFirmwareUpdateFlow.h"
#import "SCConnectSplice.h"

@interface SCFirmwareUpdateRootControllerViewController ()

@property (nonatomic) SCFirmwareUpdateViewController *fwViewController;
@property (nonatomic) SCFirmwareUpdateConfirmVerViewController *fwVerViewController;
@property (nonatomic) SCFirmwareUpdateDownloadFileViewController *fwFileViewController;

@end

@implementation SCFirmwareUpdateRootControllerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    self.fwViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"fwViewController"];
    self.fwVerViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"fwVerViewController"];
    self.fwFileViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"fwFileViewController"];
    
    if([self.fromFlag isEqualToString:@"0"]){
        self.fwFileViewController.targetSerialNo = self.appData.selectedSerialNo;
        [self.navigationController pushViewController:self.fwFileViewController animated:NO];
    }else if([self.fromFlag isEqualToString:@"1"]){
        self.fwViewController.targetSerialNo = self.appData.selectedSerialNo;
        [self.navigationController pushViewController:self.fwViewController animated:NO];
    }else{
        SCConnectSpliceDao * connectSpliceDao = [[SCConnectSpliceDao alloc] init];
        SCConnectSplice * connectSplice = [connectSpliceDao getSplicerState:self.appData.selectedSerialNo];
        NSString* now = [SCSystemData stringFromDate:[NSDate date] format:@"yyyyMMdd"];
        if(!(connectSplice.timesync_date && connectSplice.timesync_date.length >= 8 && [[connectSplice.timesync_date substringToIndex:8] compare:now] >= 0 && connectSplice.current_version && connectSplice.current_version.length > 0)) {
            self.fwVerViewController.targetSerialNo = self.appData.selectedSerialNo;
            [self.navigationController pushViewController:self.fwVerViewController animated:NO];
        }else if([SCFirmwareUpdateFlow isFirmwareUpdate:self.appData.selectedSerialNo] && connectSplice.lastest_version.length > 0){
            self.fwViewController.targetSerialNo = self.appData.selectedSerialNo;
            [self.navigationController pushViewController:self.fwViewController animated:NO];
        }else{
            self.fwFileViewController.targetSerialNo = self.appData.selectedSerialNo;
            [self.navigationController pushViewController:self.fwFileViewController animated:NO];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
