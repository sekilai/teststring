//
//  SCSplicerListTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/27.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCSplicerListTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgvwOnlineState;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwLockState;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@end
