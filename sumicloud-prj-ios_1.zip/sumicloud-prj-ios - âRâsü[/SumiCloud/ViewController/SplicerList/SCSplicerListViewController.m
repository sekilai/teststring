//
//  SCSplicerListViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSplicerListViewController.h"
#import "SCSplicerListTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCSplicerListFlow.h"
#import "SCSecurityLockFlow.h"
#import "SCConnectSplice.h"

@interface SCSplicerListViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) NSArray* listData;

@property (weak, nonatomic) IBOutlet UITableView *tblvwSplicerList;

- (IBAction)actionClose:(UIBarButtonItem *)sender;

@end

@implementation SCSplicerListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_DEVICE_LIST", @"融着機一覧");
    
    // 画面表示データの更新
    [self refreshOnlineSerialNo];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Button Action

/**
 閉じるボタン

 @param sender <#sender description#>
 */
- (IBAction)actionClose:(UIBarButtonItem *)sender {
    
    DDLogInfo(@"閉じるボタン -> 融着機一覧画面を閉じる");
    
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param section   <#section description#>
 
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listData.count;
}

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SCSplicerListTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];

    SCConnectSplice* item = [self.listData objectAtIndex:indexPath.row];
    cell.lblSerialNo.text = item.serialno;
    cell.imgvwOnlineState.image = [UIImage imageNamed:@"icon_offline"];
    if ([self isSplicerConnect:item.serialno]) {
        
        cell.imgvwOnlineState.image = [UIImage imageNamed:@"icon_online"];
    }
    cell.imgvwLockState.hidden = YES;
    NSDictionary* dicSecurityLock = [SCSystemData loadSecurityLock];
    if (dicSecurityLock) {
        
        if ([item.serialno isEqualToString:dicSecurityLock[kSC_ITEM_SERIAL_NO]]) {
            
            cell.imgvwLockState.hidden = NO;
        }
    }

    return cell;
}

/**
 融着接続機選択

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    DDLogDebug(@"");
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [self dismissViewControllerAnimated:YES completion:^{
        
        SCSplicerListTableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
        self.appData.selectedSerialNo = cell.lblSerialNo.text;
    }];
}


#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.listData = [SCSplicerListFlow getSplicerList];
    [self.tblvwSplicerList reloadData];
}

@end
