//
//  SCSecurityLockCreateAccountViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/01/30.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityLockCreateAccountViewController.h"
#import "SCLogUtil.h"
#import "SCSystemData.h"
#import "SCAccountCheck.h"
#import "SCSecurityLockFlow.h"

@interface SCSecurityLockCreateAccountViewController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UILabel *lblMail;
@property (weak, nonatomic) IBOutlet UITextField *txtfdMail;
@property (weak, nonatomic) IBOutlet UILabel *lblPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtfdPassword;
@property (weak, nonatomic) IBOutlet UILabel *lblPasswordConfirm;
@property (weak, nonatomic) IBOutlet UITextField *txtfdPasswordConfirm;
@property (weak, nonatomic) IBOutlet UIButton *btnRegister;
@end

@implementation SCSecurityLockCreateAccountViewController

static NSString* const ACCOUNT_REGIST_FAILED = @"-1";
static NSString* const ACCOUNT_ALREADY_EXIST = @"-2";

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = NSLocalizedString(@"TITLE_SECURITY_LOCK", @"盗難防止ロック");
    self.lblMail.text = NSLocalizedString(@"RES_20047", @"");
    self.lblPassword.text = NSLocalizedString(@"RES_20048", @"");
    self.lblPasswordConfirm.text = NSLocalizedString(@"RES_20049", @"");
    
    [self refreshSelectedSerialNo];
    [self.btnRegister setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnRegister setTitle:NSLocalizedString(@"BTN_REGISTER", @"") forState:UIControlStateNormal];
    
}

- (IBAction)actionBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.btnRegister setBackgroundImage:[self setButtonHilightBackColor:self.btnRegister.bounds] forState:UIControlStateHighlighted];
}

- (IBAction)creatAccount:(id)sender {
    
    if (![_txtfdMail.text length] || ![_txtfdPassword.text length] || ![_txtfdPasswordConfirm.text length]) {
        NSMutableString *temp = [NSMutableString stringWithCapacity:0];
        
        if (![_txtfdMail.text length]) {
            [temp appendString:NSLocalizedString(@"RES_20047", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"MSG_12000", @"確認メッセージ")];
            [temp appendString:@"\n"];
        }
        
        if (![_txtfdPassword.text length]) {
            [temp appendString:NSLocalizedString(@"RES_20048", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"MSG_12000", @"確認メッセージ")];
            [temp appendString:@"\n"];
        }
        
        if (![_txtfdPasswordConfirm.text length]) {
            [temp appendString:NSLocalizedString(@"RES_20049", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"MSG_12000", @"確認メッセージ")];
        }
        [self showUnWriteAlertWithMsg:temp];
        return;
    }
    
    if (![SCAccountCheck checkEmail:_txtfdMail.text]) {
        [self showErrorEmailStyleAlert];
        return;
    }
    
    if (![SCAccountCheck checkPassWord:_txtfdPassword.text]) {
        [self showPasswordStyleAlert];
        return;
    }
    
    if (![_txtfdPassword.text isEqualToString:_txtfdPasswordConfirm.text]) {
        [self showPasswordConfirmErrorAlert];
        return;
    }
    // Wi-Fi切り替え確認
    if (![self isMobileConnect]) {
        
        [self connectSplicerAlert];
        
        return;
    }
    
    __weak SCSecurityLockCreateAccountViewController *weakSelf = self;
    [self showConfirmAlert:^{
        [weakSelf submit];
    }];
}

-(void)submit {
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
    __weak SCSecurityLockCreateAccountViewController *weekSelf = self;
    [[[SCSecurityLockFlow alloc] init] doPairingAccountRegister:_txtfdMail.text password:_txtfdPassword.text completion:^(NSError *error) {
        [weekSelf hideProgress];
        
        // 結果判定
        if (error) {
            // サーバ通信エラー
            DDLogError(@"新アカウント登録異常:%@", error.description);
            NSString *errorResult = error.userInfo[kSC_BF_ErrorResponse];
            if (!errorResult) {
                [weekSelf showNetWorkErrorAlert];
            } else if ([errorResult isEqualToString:ACCOUNT_REGIST_FAILED]){
                [weekSelf showSubmitErrorAlert];
            } else if([errorResult isEqualToString:ACCOUNT_ALREADY_EXIST]) {
                [weekSelf showAccountAlreadyExistAlert];
            }
        } else {
            DDLogError(@"新アカウント登録成功");
            [weekSelf showCreatCompleteAlert:^{
                [weekSelf.navigationController popViewControllerAnimated:YES];
            }];
        }
    }];
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:true];
}

#pragma mark - UITextFieldDelegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return true;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (range.length == 1 && string.length == 0) {
        return YES;
    }
    if (textField == self.txtfdMail && textField.text.length >= 257) {
        self.txtfdMail.text = [textField.text substringToIndex:256];
        return NO;
    }
    if (textField == self.txtfdPassword && textField.text.length >= 33) {
        self.txtfdPassword.text = [textField.text substringToIndex:32];
        return NO;
    }
    if (textField == self.txtfdPasswordConfirm && textField.text.length >= 33) {
        self.txtfdPasswordConfirm.text = [textField.text substringToIndex:32];
        return NO;
    }
    return YES;
}

#pragma mark - alertType

-(void)showUnWriteAlertWithMsg:(NSString *)msg {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showConfirmAlert:(void(^)(void))submit {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13047", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        submit();
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"CANCEL") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showCreatCompleteAlert:(void(^)(void))ok {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13048", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        ok();
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showErrorEmailStyleAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_12001", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showPasswordStyleAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13050", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showPasswordConfirmErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13049", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showAccountAlreadyExistAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13051", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showSubmitErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13052", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showNetWorkErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13044", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
