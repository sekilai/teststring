//
//  SCSecurityLockTableViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/11/25.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityLockTableViewCell.h"

@implementation SCSecurityLockTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
