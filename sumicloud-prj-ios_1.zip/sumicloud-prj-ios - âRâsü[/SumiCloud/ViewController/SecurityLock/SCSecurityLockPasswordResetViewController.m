//
//  SCSecurityLockPasswordResetViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/01/30.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityLockPasswordResetViewController.h"
#import "SCLogUtil.h"
#import "SCSystemData.h"
#import "SCAccountCheck.h"
#import "SCSecurityLockFlow.h"

@interface SCSecurityLockPasswordResetViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;
@property (weak, nonatomic) IBOutlet UIButton *btnIssue;
@property (weak, nonatomic) IBOutlet UITextView *txtvwMessage;
@property (weak, nonatomic) IBOutlet UILabel *lblEmail;
@property (weak, nonatomic) IBOutlet UITextField *txtfdEmail;

@end

@implementation SCSecurityLockPasswordResetViewController

static NSString* const PASSWORD_RESET_FAILED = @"-1";
static NSString* const EMAIL_UNEXIST = @"-2";

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = NSLocalizedString(@"TITLE_SECURITY_LOCK", @"盗難防止ロック");
    self.lblEmail.text = NSLocalizedString(@"RES_20047", @"E-mailアドレス：");
    self.txtvwMessage.text = NSLocalizedString(@"MSG_13031", @"仮パスワード送信");
    [self refreshSelectedSerialNo];
    [self.btnIssue setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnIssue setTitle:NSLocalizedString(@"BTN_ISSUE", @"") forState:UIControlStateNormal];
}
- (IBAction)actionBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)submit:(id)sender {
    if (![_txtfdEmail.text length]) {
        [self showUnWriteAlertWithMsg:NSLocalizedString(@"RES_20047", @"確認メッセージ")];
        return;
    }
    
    if (![SCAccountCheck checkEmail:_txtfdEmail.text]) {
        [self showErrorEmailStyleAlert];
        return;
    }
    
    // Wi-Fi切り替え確認
    if (![self isMobileConnect]) {
        
        [self connectSplicerAlert];
        
        return;
    }
    
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
    __weak SCSecurityLockPasswordResetViewController *weekSelf = self;
    [[[SCSecurityLockFlow alloc] init] doPairingResetPassword:_txtfdEmail.text completion:^(NSError *error) {
        [weekSelf hideProgress];
        
        // 結果判定
        if (error) {
            // サーバ通信エラー
            DDLogError(@"パスワードリセット異常:%@", error.description);
            NSString * errorResult = error.userInfo[kSC_BF_ErrorResponse];
            if (!errorResult) {
                [weekSelf showNetWorkErrorAlert];
            } else if ([errorResult  isEqualToString:PASSWORD_RESET_FAILED]){
                [weekSelf showResetFailAlert];
            } else if([errorResult  isEqualToString:EMAIL_UNEXIST]) {
                [weekSelf showEmailUnexistAlert];
            }
        } else {
            DDLogError(@"パスワードリセット成功");
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:NSLocalizedString(@"MSG_13060","パスワードリセット成功") preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", "OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                [weekSelf.navigationController popViewControllerAnimated:YES];
            }]];
            [self presentViewController:alert animated:YES completion:nil];
        }
    }];
}

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.btnIssue setBackgroundImage:[self setButtonHilightBackColor:self.btnIssue.bounds] forState:UIControlStateHighlighted];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:true];
}


#pragma mark - UITextFieldDelegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return true;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (range.length == 1 && string.length == 0) {
        return YES;
    }
    if (textField == self.txtfdEmail && textField.text.length >= 257) {
        self.txtfdEmail.text = [textField.text substringToIndex:256];
        return NO;
    }
    return YES;
}

#pragma mark - alertType

-(void)showNetWorkErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13044", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showEmailUnexistAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13055", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showErrorEmailStyleAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_12001", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showUnWriteAlertWithMsg:(NSString *)msg {
    NSMutableString *temp = [NSMutableString stringWithCapacity:0];
    [temp appendString:msg];
    [temp appendString:NSLocalizedString(@"MSG_12000", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:temp preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showResetFailAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13056", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
