//
//  SCSecurityFAQViewController.h
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/03/07.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityLockBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SCSecurityFAQViewController : SCSecurityLockBaseViewController
@property (nonatomic) NSArray *titleArray;
@property (nonatomic) NSString* interval;
@property (nonatomic) NSNumber* notifyType;
@property (nonatomic) NSInteger checkCount;
@end

NS_ASSUME_NONNULL_END
