//
//  SCSecurityLockLoginViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/01/30.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityLockLoginViewController.h"
#import "SCSystemData.h"
#import "SCLogUtil.h"
#import "SCAccountCheck.h"
#import "SCSecurityLockFlow.h"

@interface SCSecurityLockLoginViewController ()
@property (weak, nonatomic) IBOutlet UILabel *lblMail;
@property (weak, nonatomic) IBOutlet UITextField *tfMail;
@property (weak, nonatomic) IBOutlet UILabel *lblPassword;
@property (weak, nonatomic) IBOutlet UITextField *tfPassword;
@property (weak, nonatomic) IBOutlet UIButton *btnCreateAccount;
@property (weak, nonatomic) IBOutlet UIButton *btnForgetPassword;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;
@property (weak, nonatomic) IBOutlet UIButton *btnLogin;

@property (nonatomic) SCSecurityLockFlow *flow;

@end

@implementation SCSecurityLockLoginViewController

static NSString* const PAIRING_LOGIN_FAILED = @"-1";
static NSString* const PAIRING_MAILORPASSWORD_MISMATCH = @"-2";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    self.title = NSLocalizedString(@"TITLE_SECURITY_LOCK", @"盗難防止ロック");
    self.lblMail.text = NSLocalizedString(@"RES_20047", @"");
    self.lblPassword.text = NSLocalizedString(@"RES_20043", @"");
    [self.btnCreateAccount setTitle:NSLocalizedString(@"RES_20044", @"") forState:UIControlStateNormal];
    [self.btnForgetPassword setTitle:NSLocalizedString(@"RES_20045", @"") forState:UIControlStateNormal];
    
    [self refreshSelectedSerialNo];
    [self.btnLogin setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnLogin setTitle:NSLocalizedString(@"BTN_LOGIN", @"") forState:UIControlStateNormal];
}

- (IBAction)actionBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)clickLoginButton:(id)sender {
    
    if ([_tfMail.text length] == 0 || [_tfPassword.text length] == 0) {
        NSMutableString *temp = [NSMutableString stringWithCapacity:0];
        if ([_tfMail.text length] == 0) {
            [temp appendString:NSLocalizedString(@"RES_20047", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"MSG_12000", @"確認メッセージ")];
            [temp appendString:@"\n"];
        }
        if ([_tfPassword.text length] == 0) {
            [temp appendString:NSLocalizedString(@"RES_20048", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"MSG_12000", @"確認メッセージ")];
        }
        
        [self showUnWriteAlertWithMsg:temp];
        return;
    }
    
    if (![SCAccountCheck checkEmail:_tfMail.text]) {
        [self showErrorEmailStyleAlert];
        return;
    }

    // Wi-Fi切り替え確認
    if (![self isMobileConnect]) {
        
        [self connectSplicerAlert];
        
        return;
    }
    
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
    __weak SCSecurityLockLoginViewController *weekSelf = self;
    // ビジネスフロー
    [[[SCSecurityLockFlow alloc] init] doPairingLogin:self.tfMail.text password:self.tfPassword.text completion:^(NSError *error) {
        
        [weekSelf hideProgress];
        
        // 結果判定
        if (error) {
            // サーバ通信エラー
            DDLogError(@"ペアリングログイン異常:%@", error.description);
            id errorResult = error.userInfo[kSC_BF_ErrorResponse];
            if (!errorResult) {
                [weekSelf showNetWorkErrorAlert];
            } else if ([errorResult isEqualToString:PAIRING_LOGIN_FAILED]){
                [weekSelf showLoginFailAlert];
            } else if([errorResult isEqualToString:PAIRING_MAILORPASSWORD_MISMATCH]) {
                [weekSelf showWrongAccountErrorAlert];
            }
        } else {
            DDLogError(@"ペアリングログイン成功");
            [weekSelf.navigationController popViewControllerAnimated:YES];
        }
    }];
}

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.btnLogin setBackgroundImage:[self setButtonHilightBackColor:self.btnLogin.bounds] forState:UIControlStateHighlighted];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:true];
}

#pragma mark - UITextFieldDelegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return true;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (range.length == 1 && string.length == 0) {
        return YES;
    }
    if (textField == self.tfMail && textField.text.length >= 257) {
        self.tfMail.text = [textField.text substringToIndex:256];
        return NO;
    }
    if (textField == self.tfPassword && textField.text.length >= 33) {
        self.tfMail.text = [textField.text substringToIndex:32];
        return NO;
    }
    return YES;
}

#pragma mark - alertType

-(void)showUnWriteAlertWithMsg:(NSString *)msg {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showErrorEmailStyleAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_12001", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showNetWorkErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13044", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

//
-(void)showWrongAccountErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13045", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showLoginFailAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13046", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
