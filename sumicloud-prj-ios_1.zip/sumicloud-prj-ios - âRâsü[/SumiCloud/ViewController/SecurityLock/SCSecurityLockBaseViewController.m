//
//  SCSecurityLockBaseViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/03/07.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityLockBaseViewController.h"

@interface SCSecurityLockBaseViewController ()

@end

@implementation SCSecurityLockBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
/**
 盗難防止ロックチェック間隔の文字列を取得
 
 @param type <#type description#>
 @param value <#value description#>
 @return <#return value description#>
 */
- (NSString *)getIntervalString:(IntervalType)type value:(NSInteger)value {
    
    NSString *ret = @"";
    
    switch (type) {
        case IT_SECOND:
#ifdef DEMO
            ret = [NSString stringWithFormat:@"%08zd", value];
#else
            ret = [NSString stringWithFormat:@"%08zd", value/3];
#endif
            break;
        case IT_MINUTE:
            ret = [NSString stringWithFormat:@"%08zd", (value * 60/3)];
            break;
        case IT_HOUR:
            ret = [NSString stringWithFormat:@"%08zd", (value * 60 * 60/3)];
            break;
        case IT_DAY:
            ret = [NSString stringWithFormat:@"%08zd", (value * 60 * 60 * 24/3)];
            break;
    }
    
    return ret;
}
@end
