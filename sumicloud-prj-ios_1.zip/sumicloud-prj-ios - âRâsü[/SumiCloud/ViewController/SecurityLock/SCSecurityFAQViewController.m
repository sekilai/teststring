//
//  SCSecurityFAQViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/03/07.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityFAQViewController.h"
#import "SCSecurityLockFlow.h"
#import "SCSystemData.h"
#import "SCLogUtil.h"
#import "SCSecurityLockService.h"

@interface SCSecurityFAQViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (nonatomic) SCSecurityLockFlow* flow;
@property (nonatomic) NSDictionary* dicSecurityLockInfo;
@property (nonatomic) NSString *loginID;
@end

@implementation SCSecurityFAQViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = NSLocalizedString(@"TITLE_FAQ", @"FAQタイトル");
    self.titleArray = [NSArray arrayWithObjects:NSLocalizedString(@"MSG_13063", @""),NSLocalizedString(@"MSG_13064", @""),NSLocalizedString(@"MSG_13065", @""), nil];
    [self refreshSelectedSerialNo];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

- (IBAction)actionBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

/**
 リペアリング
 */
- (void)repairing {
    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }
   
    DDLogInfo(@"リペアリング -> 盗難防止ロック");
    
    self.flow = [[SCSecurityLockFlow alloc] init];
    [self resetPairing];
}

/**
 盗難防止ロック機能フロー（盗難防止ロックリペアリング）
 */
- (void)resetPairing {
    
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        
        [self.flow cancelFlow];
    }];
    
    NSString* passCode = [self.flow makePassCode];
    
    // ビジネスフロー
    DDLogInfo(@"盗難防止ロック機能フロー（リペアリング）:開始");
    [self.flow resetPairing:self.appData.onlineSerialNo passCode:passCode interval:self.interval loginID:self.loginID completion:^(NSError *error) {
        
        DDLogInfo(@"盗難防止ロック機能フロー（リペアリング）:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideProgress];
            
            // ビジネスフロー結果メッセージ表示
            if (!error && (kBF_OK == self.flow.resultFlow)) {
                
                // 盗難防止ロック情報保存
                NSMutableDictionary* dicSecurityLock = [NSMutableDictionary dictionaryWithCapacity:0];
                dicSecurityLock[kSC_ITEM_SERIAL_NO] = self.appData.onlineSerialNo;
                dicSecurityLock[kSC_ITEM_PASS_CODE] = passCode;
                dicSecurityLock[kSC_ITEM_INTERVAL] = self.interval;
                dicSecurityLock[kSC_ITEM_NOTIFY_TYPE] = self.notifyType;
                dicSecurityLock[kSC_ITEM_CHECK_COUNT] = [NSNumber numberWithInteger:self.checkCount];
                [SCSystemData saveSecurityLock:dicSecurityLock];
                
                // 盗難防止ロック開始
                [SCSecurityLockService sharedInstance].isResetSecurityLockResult = YES;
                [[SCSecurityLockService sharedInstance] startHealthCheck];
                
                // 新しいペアリング成功
                UIAlertController* confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"MSG_13040", @"新しいペアリングを開始しました") message:nil preferredStyle:UIAlertControllerStyleAlert];
                [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", "") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                }]];
                [self presentViewController:confirm animated:YES completion:nil];
                
                self.flow = nil;
            } else {
                
                [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                    
                    if (ResultAction_RETRY == actionType) {
                        
                        // 再試行
                        [self resetPairing];
                    } else {
                        
                        if (!error && (kBF_SC_NOT_SUPPORT == self.flow.resultFlow)) {
                            
                            DDLogWarn(@"盗難防止ロックサポート対象外");
                            
                            [self.navigationController popViewControllerAnimated:YES];
                        }
                        
                        self.flow = nil;
                    }
                }];
            }
        });
    }];
}

- (void)unlock {
    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }
    
    DDLogInfo(@"期間限定（１日）ロック解除 -> 盗難防止ロック");
    
    self.flow = [[SCSecurityLockFlow alloc] init];
    [self startUnlockForOneDay];
}

-(void)startUnlockForOneDay {
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        
        [self.flow cancelFlow];
    }];
    
    //1日の1/3
    NSString* interval = [self getIntervalString:IT_HOUR value:24/3];
    
    // ビジネスフロー
    DDLogInfo(@"盗難防止ロック機能フロー（期間限定（１日）ロック解除）:開始");
    [self.flow startUnlock:self.appData.onlineSerialNo interval:interval loginID:self.loginID completion:^(NSError *error) {
        DDLogInfo(@"盗難防止ロック機能フロー（期間限定（１日）ロック解除）:終了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideProgress];
            
            if (!error && (kBF_OK == self.flow.resultFlow)) {
                
                if (![self checkPaired]) {
                    // ログイン状態をクリア
                    NSUserDefaults *userdefault = [NSUserDefaults standardUserDefaults];
                    [userdefault setObject:@"" forKey:KEY_PAIRING_LAST_LOGIN_DATE];
                    [userdefault setObject:@"" forKey:KEY_PAIRING_LOGIN_ID];
                    [userdefault setObject:@"" forKey:KEY_PAIRING_EMAIL_ADDR];
                    [userdefault synchronize];
                }
                
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:NSLocalizedString(@"MSG_13038", "期間限定（１日）ロック解除") preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", "OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self.navigationController popViewControllerAnimated:YES];
                }]];
                [self presentViewController:alert animated:YES completion:nil];
            } else {
                [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                    
                    if (ResultAction_RETRY == actionType) {
                        
                        // 再試行
                        [self startUnlockForOneDay];
                    } else {
                        
                        if (!error && (kBF_SC_NOT_SUPPORT == self.flow.resultFlow)) {
                            
                            DDLogWarn(@"盗難防止ロックサポート対象外");
                            
                            [self.navigationController popViewControllerAnimated:YES];
                        }
                        
                        self.flow = nil;
                    }
                }];
            }
        });
    }];
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"faqcell"];

    long row = [indexPath row];
    
    cell.textLabel.text = [self.titleArray objectAtIndex:row];
    
    return cell;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    long row = [indexPath row];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    if (row == 0) {
        if ([self checkLogin]) {
            if ([self checkPaired]) {
                [self showAlertWithMessage:NSLocalizedString(@"MSG_13071", @"")];
            } else {
                if ([self isSplicerConnect:self.lblSerialNo.text]) {
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:NSLocalizedString(@"MSG_13069", @"") preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction: [UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", "Cancel") style:UIAlertActionStyleCancel handler:nil]];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", "OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        [self repairing];
                    }]];
                    [self presentViewController:alert animated:YES completion:nil];
                } else {
                    [self showAlertWithMessage:NSLocalizedString(@"MSG_13070", @"")];
                }
            }
        } else {
            [self showAlertWithMessage:NSLocalizedString(@"MSG_13072", @"")];
        }
    } else if (row == 1) {
        if ([self checkLogin]) {
            if ([self checkPaired] && [self.lblSerialNo.text isEqualToString:self.dicSecurityLockInfo[kSC_ITEM_SERIAL_NO]]) {
                [self showAlertWithMessage:NSLocalizedString(@"MSG_13073", @"")];
            } else {
                if ([self isSplicerConnect:self.lblSerialNo.text]) {
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:NSLocalizedString(@"MSG_13067", @"") preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction: [UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", "Cancel") style:UIAlertActionStyleCancel handler:nil]];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", "OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        [self unlock];
                    }]];
                    [self presentViewController:alert animated:YES completion:nil];
                } else {
                    [self showAlertWithMessage:NSLocalizedString(@"MSG_13068", @"")];
                }
            }
        } else {
            [self showAlertWithMessage:NSLocalizedString(@"MSG_13072", @"")];
        }
    } else {
        [self showAlertWithMessage:NSLocalizedString(@"MSG_13066", @"")];
    }
}


-(void)showAlertWithMessage:(NSString *) msg {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

/**
 ログイン状態チェック
 
 @return ログイン状態
 */
- (BOOL) checkLogin {
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    if ([userDefault stringForKey:KEY_PAIRING_LAST_LOGIN_DATE] != nil && [[userDefault stringForKey:KEY_PAIRING_LAST_LOGIN_DATE] length] > 0) {
        self.loginID = [userDefault stringForKey:KEY_PAIRING_LOGIN_ID];
        return YES;
    }
    self.loginID = DEFAULT_LOGIN_ID;
    return NO;
}

- (BOOL) checkPaired {
    self.dicSecurityLockInfo = [SCSystemData loadSecurityLock];
    if (self.dicSecurityLockInfo) {
        return YES;
    }
    return NO;
}
@end
