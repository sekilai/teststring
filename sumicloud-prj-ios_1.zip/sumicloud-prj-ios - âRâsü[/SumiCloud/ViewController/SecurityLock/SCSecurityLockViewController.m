//
//  SCSecurityLockViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/11/25.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityLockViewController.h"
#import "SCSecurityLockTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCSecurityLockFlow.h"
#import "SCSecurityLockService.h"
#import "SCSecurityFAQViewController.h"

@interface SCSecurityLockViewController () <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource>

@property (nonatomic) SCSecurityLockFlow* flow;

@property (nonatomic) NSMutableArray* listEntry;
@property (nonatomic) NSString *selectedList;
@property (nonatomic) NSDictionary* dicSecurityLockInfo;
@property (nonatomic) NSString *loginID;

@property (nonatomic) NSArray* listIntervalPicker;
@property (nonatomic) NSArray* listCheckCountPicker;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UILabel *lblTitlePassCode;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleLockSerialNo;
@property (weak, nonatomic) IBOutlet UILabel *lblLockSerialNo;
@property (weak, nonatomic) IBOutlet UILabel *lblLoginStatus;
@property (weak, nonatomic) IBOutlet UIButton *btnAccount;
@property (weak, nonatomic) IBOutlet UIButton *btnLogin;

@property (weak, nonatomic) IBOutlet UITableView *tblvwSecurityLock;

@property (weak, nonatomic) IBOutlet UIButton *btnStart;
@property (weak, nonatomic) IBOutlet UIButton *btnRelease;
@property (weak, nonatomic) IBOutlet UIButton *btnDetail;

- (IBAction)actionBack:(UIBarButtonItem *)sender;
- (IBAction)btnStartTouchUpInside:(UIButton *)sender;
- (IBAction)btnReleaseTouchUpInside:(UIButton *)sender;

@end

@implementation SCSecurityLockViewController

typedef NS_ENUM(NSInteger, CustomerRegistEntryTag) {
    TagInterval = 1000,
    TagNotify,
    TagCheckCount
};

static NSString* const kSL_TITLE    = @"title";    // 入力項目名
static NSString* const kSL_TagNo    = @"tagNo";    // タグ番号
static NSString* const kSL_VALUE    = @"value";    // 入力値
static NSString* const kSL_CellType = @"CellType"; // 表示タイプ

static NSString* const kSL_PickerTitle = @"pikcerTitle";
static NSString* const kSL_INTERVAL = @"interval";
static NSString* const kSL_NOTIFY = @"notify";
static NSString* const kSL_CHECK_COUNT = @"check_count";



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];

    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_SECURITY_LOCK", @"盗難防止ロック");
    self.lblTitlePassCode.text = NSLocalizedString(@"RES_20030", @"パスコード:");
    self.lblTitleLockSerialNo.text = NSLocalizedString(@"RES_20032", @"シリアル番号:");
    [self.btnStart setTitle:NSLocalizedString(@"BTN_START", @"設定") forState:UIControlStateNormal];
    [self.btnRelease setTitle:NSLocalizedString(@"BTN_RELEASE", @"解除") forState:UIControlStateNormal];
    [self.btnDetail setTitle:NSLocalizedString(@"MSG_13062", @"") forState:UIControlStateNormal];
    self.lblLoginStatus.text = NSLocalizedString(@"RES_20052", @"");
    [self.btnLogin setTitle:NSLocalizedString(@"BTN_LOGIN", @"") forState:UIControlStateNormal];
    
    // 入力項目のリストを生成
    self.listEntry = [NSMutableArray arrayWithCapacity:0];
    NSMutableDictionary* dicInterval = [NSMutableDictionary dictionaryWithCapacity:0];
    dicInterval[kSL_TITLE] = @"RES_20033";
    dicInterval[kSL_TagNo] = [NSNumber numberWithInteger:TagInterval];
    dicInterval[kSL_VALUE] = NSLocalizedString(@"PAIRING_INTERVAL_38", @"1日");
    dicInterval[kSL_CellType] = @"cell";
    [self.listEntry addObject:dicInterval];
    NSMutableDictionary* dicNotify = [NSMutableDictionary dictionaryWithCapacity:0];
    dicNotify[kSL_TITLE] = @"RES_20034";
    dicNotify[kSL_TagNo] = [NSNumber numberWithInteger:TagNotify];
    dicNotify[kSL_VALUE] = [NSNumber numberWithBool:YES];
    dicNotify[kSL_CellType] = @"cellSw";
    [self.listEntry addObject:dicNotify];
    NSMutableDictionary* dicCheckCount = [NSMutableDictionary dictionaryWithCapacity:0];
    dicCheckCount[kSL_TITLE] = @"RES_20035";
    dicCheckCount[kSL_TagNo] = [NSNumber numberWithInteger:TagCheckCount];
    dicCheckCount[kSL_VALUE] = NSLocalizedString(@"PAIRING_COUNT_3", @"3回");
    dicCheckCount[kSL_CellType] = @"cell";
    [self.listEntry addObject:dicCheckCount];
    
    // チェック間隔リスト
    self.listIntervalPicker = @[
#ifdef DEMO
                                @{kSL_INTERVAL : [self getIntervalString:IT_SECOND value:10],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_50", @"10秒")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_SECOND value:20],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_51", @"20秒")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_SECOND value:30],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_52", @"30秒")},
#endif
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:1],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_01", @"1分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:2],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_02", @"2分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:3],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_03", @"3分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:4],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_04", @"4分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:5],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_05", @"5分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:6],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_06", @"6分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:7],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_07", @"7分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:8],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_08", @"8分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:9],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_09", @"9分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:10],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_10", @"10分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:20],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_11", @"20分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:30],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_12", @"30分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:40],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_13", @"40分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_MINUTE value:50],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_14", @"50分")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:1],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_15", @"1時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:2],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_16", @"2時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:3],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_17", @"3時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:4],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_18", @"4時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:5],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_19", @"5時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:6],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_20", @"6時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:7],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_21", @"7時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:8],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_22", @"8時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:9],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_23", @"9時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:10],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_24", @"10時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:11],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_25", @"11時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:12],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_26", @"12時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:13],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_27", @"13時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:14],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_28", @"14時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:15],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_29", @"15時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:16],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_30", @"16時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:17],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_31", @"17時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:18],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_32", @"18時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:19],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_33", @"19時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:20],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_34", @"20時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:21],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_35", @"21時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:22],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_36", @"22時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_HOUR value:23],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_37", @"23時間")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:1],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_38", @"1日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:2],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_39", @"2日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:3],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_40", @"3日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:4],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_41", @"4日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:5],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_42", @"5日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:6],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_43", @"6日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:7],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_44", @"7日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:8],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_45", @"8日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:9],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_46", @"9日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:10],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_47", @"10日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:20],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_48", @"20日")},
                                @{kSL_INTERVAL : [self getIntervalString:IT_DAY value:30],
                                  kSL_PickerTitle : NSLocalizedString(@"PAIRING_INTERVAL_49", @"30日")}
                                ];
    
    // チェック回数（デバッグ版のみ）
    self.listCheckCountPicker = @[
                                  @{kSL_CHECK_COUNT: [NSNumber numberWithInteger:1],
                                    kSL_PickerTitle : NSLocalizedString(@"PAIRING_COUNT_1", @"1回")},
                                  @{kSL_CHECK_COUNT: [NSNumber numberWithInteger:2],
                                    kSL_PickerTitle : NSLocalizedString(@"PAIRING_COUNT_2", @"2回")},
                                  @{kSL_CHECK_COUNT: [NSNumber numberWithInteger:3],
                                    kSL_PickerTitle : NSLocalizedString(@"PAIRING_COUNT_3", @"3回")},
                                  @{kSL_CHECK_COUNT: [NSNumber numberWithInteger:4],
                                    kSL_PickerTitle : NSLocalizedString(@"PAIRING_COUNT_4", @"4回")},
                                  @{kSL_CHECK_COUNT: [NSNumber numberWithInteger:5],
                                    kSL_PickerTitle : NSLocalizedString(@"PAIRING_COUNT_5", @"5回")}
                                  ];

    
    // 画面表示データの更新
    self.isSelectedSplicer = YES;
    [self refreshSelectedSerialNo];

    // タップジェスチャー
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapGestureAction:)];
    [self.view addGestureRecognizer:tapGesture];
    [self refreshLoginStatusView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    [self refreshLoginStatusView];
}

- (void)refreshLoginStatusView {
    if ([self checkLogin]) {
        [self.btnLogin setHidden:YES];
        [self.btnAccount setHidden:NO];
        [self.btnAccount setTitle:[[NSUserDefaults standardUserDefaults] stringForKey:KEY_PAIRING_EMAIL_ADDR] forState:UIControlStateNormal];

    } else {
        [self.btnLogin setHidden:NO];
        [self.btnAccount setHidden:YES];
    }
    if ([self checkPaired]) {
        [self.btnStart setHidden:YES];
        [self.btnRelease setHidden:NO];
    } else {
        [self.btnStart setHidden:NO];
        [self.btnRelease setHidden:YES];
    }
}

#pragma mark - Action

/**
 画面タップでキーボード非表示

 @param sender <#sender description#>
 */
- (void)viewTapGestureAction:(UITapGestureRecognizer *)sender {
    
    [self.view endEditing:YES];
}


#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {
    
    DDLogDebug(@"");
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnLoginTouchUpInside:(id)sender {
    if ([self checkPaired]) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:NSLocalizedString(@"MSG_13057", @"ペアリング中") preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        [self performSegueWithIdentifier:@"toSecurityLockLogin" sender:nil];
    }
}

- (IBAction)btnAccountTouchUpInside:(id)sender {
    if ([self checkPaired]) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:NSLocalizedString(@"MSG_13058", @"ペアリング中") preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        [self performSegueWithIdentifier:@"toSecurityLockLoginDetail" sender:nil];
    }
}

/**
 設定ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnStartTouchUpInside:(UIButton *)sender {

    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }
    
    // Wi-Fi切り替え確認
    if (![self isSplicerConnect:self.lblSerialNo.text]) {
        
        [self connectInternetAlert];
        
        return;
    }

    // 盗難防止ロック開始判定
    if (self.dicSecurityLockInfo) {
        
        DDLogWarn(@"盗難防止ロック開始済み");
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10031", @"盗難防止ロック開始済み") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:nil];
        
        return;
    }

    if (![self checkLogin]) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:NSLocalizedString(@"MSG_13029", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            DDLogInfo(@"ログインせず -> 盗難防止ロック");
            self.flow = [[SCSecurityLockFlow alloc] init];
            [self startPairing];
        }]];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"CANCEL") style:UIAlertActionStyleDefault handler:nil]];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_LOGIN", @"LOGIN") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self performSegueWithIdentifier:@"toSecurityLockLogin" sender:nil];
        }]];
        
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        DDLogInfo(@"設定ボタン -> 盗難防止ロック");
        self.flow = [[SCSecurityLockFlow alloc] init];
        [self startPairing];
    }
    
}

/**
 解除ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnReleaseTouchUpInside:(UIButton *)sender {

    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }
    
    // Wi-Fi切り替え確認
    if (![self isSplicerConnect:self.lblSerialNo.text]) {
        
        [self connectInternetAlert];
        
        return;
    }
    
    // 盗難防止ロック解除判定
    if (!self.dicSecurityLockInfo) {
        
        DDLogWarn(@"盗難防止ロック解除済み");
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10032", @"盗難防止ロック解除済み") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    // 異なる融着機に接続
    if (![self.lblLockSerialNo.text isEqualToString:self.lblSerialNo.text]) {
        
        DDLogWarn(@"盗難防止ロックを開始した融着機と異なる");
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知")  message:NSLocalizedString(@"MSG_10033", @"盗難防止ロックを開始した融着機と異なる") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    
    DDLogInfo(@"解除ボタン -> 盗難防止ロック");
    
    self.flow = [[SCSecurityLockFlow alloc] init];
    [self releasePairing];
}


#pragma mark - UITextFieldDelegate

/**
 入力項目編集開始

 @param textField <#textField description#>
 @return <#return value description#>
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    // Cancelボタン
    UIBarButtonItem *btnEditCancel = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_CANCEL", @"キャンセル") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditCancelTouchUpInside:)];
    btnEditCancel.tag = textField.tag;
    
    // フレキシブルスペース
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    
    // 設定ボタン
    UIBarButtonItem *btnEditOk = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_DONE", @"完了") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditOkTouchUpInside:)];
    btnEditOk.tag = textField.tag;
    
    // ツールバー
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
    toolbar.barStyle = UIBarStyleDefault;
    [toolbar sizeToFit];
    [toolbar setItems:@[btnEditCancel, spacer, btnEditOk] animated:YES];
    
    textField.inputAccessoryView = toolbar;
    
    UIPickerView *vwPicker = [[UIPickerView alloc] init];
    textField.inputView = vwPicker;
    vwPicker.tag = textField.tag;
    vwPicker.delegate = self;
    vwPicker.dataSource = self;
    [vwPicker sizeToFit];

    if (TagInterval ==  textField.tag) {
        
        // チェック間隔の選択項目を生成
        for (NSInteger posPicker=0; posPicker < self.listIntervalPicker.count; posPicker++) {
            
            if ([textField.text isEqualToString:self.listIntervalPicker[posPicker][kSL_PickerTitle]]) {
                
                [vwPicker selectRow:posPicker inComponent:0 animated:NO];
                self.selectedList = textField.text;
                break;
            }
        }
        if (0 == self.selectedList.length) {
            
            [vwPicker selectRow:0 inComponent:0 animated:NO];
            self.selectedList = self.listIntervalPicker[0][kSL_PickerTitle];
        }
    } else if (TagCheckCount == textField.tag) {
        
        // チェック間隔の選択項目を生成
        for (NSInteger posPicker=0; posPicker < self.listCheckCountPicker.count; posPicker++) {
            
            if ([textField.text isEqualToString:self.listCheckCountPicker[posPicker][kSL_PickerTitle]]) {
                
                [vwPicker selectRow:posPicker inComponent:0 animated:NO];
                self.selectedList = textField.text;
                break;
            }
        }
        if (0 == self.selectedList.length) {
            
            [vwPicker selectRow:0 inComponent:0 animated:NO];
            self.selectedList = self.listCheckCountPicker[0][kSL_PickerTitle];
        }
    }

    return YES;
}

/**
 入力項目編集中

 @param textField <#textField description#>
 @param range <#range description#>
 @param string <#string description#>
 @return <#return value description#>
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSMutableString *val = [textField.text mutableCopy];
    [val replaceCharactersInRange:range withString:string];
    
    if (TagInterval == textField.tag) {
        
        // 選択項目チェック
        return ![self isInterval:val];
    } else if (TagCheckCount == textField.tag) {
        
        // 選択項目チェック
        return ![self isCheckCount:val];
    }
    
    return NO;
}

/**
 入力項目のOK

 @param sender <#sender description#>
 */
- (void)btnEditOkTouchUpInside:(UIButton *)sender {
    
    [self.view endEditing:YES];
    
    if (TagInterval == sender.tag) {
        
        NSMutableDictionary* dicEntry = [self.listEntry objectAtIndex:0];
        dicEntry[kSL_VALUE] = self.selectedList;
    } else if (TagCheckCount == sender.tag) {
        
        NSMutableDictionary* dicEntry = [self.listEntry objectAtIndex:2];
        dicEntry[kSL_VALUE] = self.selectedList;
    }
    
    NSIndexPath* indexPath = [NSIndexPath indexPathForRow:1 inSection:0];
    SCSecurityLockTableViewCell* cell = [self.tblvwSecurityLock cellForRowAtIndexPath:indexPath];
    NSNumber* notifyType = [NSNumber numberWithBool:cell.swValue.on];
    NSMutableDictionary* dicEntry = [self.listEntry objectAtIndex:1];
    dicEntry[kSL_VALUE] = notifyType;

    [self.tblvwSecurityLock reloadData];
}

/**
 入力項目のCancel

 @param sender <#sender description#>
 */
- (void)btnEditCancelTouchUpInside:(UIButton *)sender {
    
    [self.view endEditing:YES];
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param section <#section description#>
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

//#ifdef DEMO
//    return self.listEntry.count;
//#else
//    // チェック回数はデバッグ版のみ
    return self.listEntry.count - 1;
//#endif
}

/**
 TableView初期化

 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSMutableDictionary* dicEntry = [self.listEntry objectAtIndex:indexPath.row];
    NSString* cellType = dicEntry[kSL_CellType];

    SCSecurityLockTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellType];
    
    cell.lblTitle.text = NSLocalizedString(dicEntry[kSL_TITLE], @"ラベル");
    cell.txtValue.tag = [dicEntry[kSL_TagNo] integerValue];
    
    if ([cellType isEqualToString:@"cell"]) {
        
        cell.txtValue.text = dicEntry[kSL_VALUE];
        cell.txtValue.hidden = NO;
        cell.swValue.hidden = YES;
    } else {
        
        cell.swValue.on = [dicEntry[kSL_VALUE] boolValue];
        cell.txtValue.hidden = YES;
        cell.swValue.hidden = NO;
    }
    
    return cell;
}


#pragma mark - UIPickerViewDelegate

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param row <#row description#>
 @param component <#component description#>
 @param view <#view description#>
 @return <#return value description#>
 */
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    
    UILabel *lblTitle = (id)view;
    if (!lblTitle) {
        
        lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [pickerView rowSizeForComponent:component].width, [pickerView rowSizeForComponent:component].height)];
    }
    lblTitle.textColor = [UIColor blackColor];
    lblTitle.textAlignment = NSTextAlignmentCenter;
    lblTitle.backgroundColor = [UIColor clearColor];
    lblTitle.font = [UIFont systemFontOfSize:20.0f];
    lblTitle.adjustsFontSizeToFitWidth = YES;
    
    if (TagInterval == pickerView.tag) {
        
        lblTitle.text = self.listIntervalPicker[row][kSL_PickerTitle];
    } else if (TagCheckCount == pickerView.tag) {
        
        lblTitle.text = self.listCheckCountPicker[row][kSL_PickerTitle];
    }
    
    return lblTitle;
}

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param row <#row description#>
 @param component <#component description#>
 */
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    
    if (TagInterval == pickerView.tag) {
        
        self.selectedList = self.listIntervalPicker[row][kSL_PickerTitle];
    } else if (TagCheckCount == pickerView.tag) {
        
        self.selectedList = self.listCheckCountPicker[row][kSL_PickerTitle];
    }
}


#pragma mark - UIPickerViewDataSource

/**
 選択表示

 @param pickerView <#pickerView description#>
 @return <#return value description#>
 */
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
    return 1;
}

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param component <#component description#>
 @return <#return value description#>
 */
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    NSInteger ret = 0;
    
    if (TagInterval == pickerView.tag) {
        
        ret = self.listIntervalPicker.count;
    } else if (TagCheckCount == pickerView.tag) {
        
        ret = self.listCheckCountPicker.count;
    }
    
    return ret;
}


#pragma mark - Override Method

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");

    self.lblLockSerialNo.text = NSLocalizedString(@"NO_SERIAL", @"---");
    self.btnStart.hidden = YES;
    self.btnRelease.hidden = YES;

    // 盗難防止ロック情報取得
    self.dicSecurityLockInfo = [SCSystemData loadSecurityLock];

    // シリアル番号
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
    
    if (self.dicSecurityLockInfo) {

        // 盗難防止ロック設定済みの場合は、設定済みの融着接続機を表示
        self.lblLockSerialNo.text = self.dicSecurityLockInfo[kSC_ITEM_SERIAL_NO];

        // チェック間隔
        NSString* interval = self.dicSecurityLockInfo[kSC_ITEM_INTERVAL];
        for (NSDictionary* dicInterval in self.listIntervalPicker) {
            
            if ([interval isEqualToString:dicInterval[kSL_INTERVAL]]) {
                
                NSMutableDictionary* entryInterval = [self.listEntry objectAtIndex:0];
                entryInterval[kSL_VALUE] = dicInterval[kSL_PickerTitle];
                
                break;
            }
        }
        
        // 通知方法
        NSNumber* notifyType = self.dicSecurityLockInfo[kSC_ITEM_NOTIFY_TYPE];
        NSMutableDictionary* entryNotifyType = [self.listEntry objectAtIndex:1];
        entryNotifyType[kSL_VALUE] = notifyType;
        
        // チェック回数
        NSInteger checkCount = [self.dicSecurityLockInfo[kSC_ITEM_CHECK_COUNT] integerValue];
        for (NSDictionary* dicCheckCount in self.listCheckCountPicker) {
            
            if (checkCount == [dicCheckCount[kSL_CHECK_COUNT] integerValue]) {
                
                NSMutableDictionary* entryCheckCount = [self.listEntry objectAtIndex:2];
                entryCheckCount[kSL_VALUE] = dicCheckCount[kSL_PickerTitle];

                break;
            }
        }
        
        // 解除ボタンを表示
        self.btnRelease.hidden = NO;
    } else {

        // 盗難防止ロック未設定の場合は、開始ボタンを表示
        self.btnStart.hidden = NO;
    }
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    [super refreshOnlineSerialNo];
    
    if (![NSLocalizedString(@"NO_SERIAL", @"---") isEqualToString:self.appData.onlineSerialNo]) {
        
        self.appData.selectedSerialNo = self.appData.onlineSerialNo;
    }
}


#pragma mark - Private Method

/**
 盗難防止ロック機能フロー（盗難防止ロック開始）
 */
- (void)startPairing {
    
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        [self.flow cancelFlow];
    }];
    
    NSString* passCode = [self.flow makePassCode];
    NSMutableDictionary* dicInterval = [self.listEntry objectAtIndex:0];
    NSString* interval = [self getIntervalValue:dicInterval[kSL_VALUE]];
    NSIndexPath* indexPath = [NSIndexPath indexPathForRow:1 inSection:0];
    SCSecurityLockTableViewCell* cell = [self.tblvwSecurityLock cellForRowAtIndexPath:indexPath];
    NSNumber* notifyType = [NSNumber numberWithBool:cell.swValue.on];
    NSMutableDictionary* dicCheckCount = [self.listEntry objectAtIndex:2];
    NSInteger checkCount = [self getCheckCountValue:dicCheckCount[kSL_VALUE]];

    
    // ビジネスフロー
    DDLogInfo(@"12.盗難防止ロック機能フロー（盗難防止ロック開始）:開始");
    [self.flow startPairing:self.appData.onlineSerialNo passCode:passCode interval:interval checkCount:checkCount loginID:self.loginID completion:^(NSError *error) {
        
        DDLogInfo(@"12.盗難防止ロック機能フロー（盗難防止ロック開始）:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideProgress];
            
            // ビジネスフロー結果メッセージ表示
            if (!error && (kBF_SC_START_SUCCESS == self.flow.resultFlow)) {
                
                // 盗難防止ロック情報保存
                NSMutableDictionary* dicSecurityLock = [NSMutableDictionary dictionaryWithCapacity:0];
                dicSecurityLock[kSC_ITEM_SERIAL_NO] = self.appData.onlineSerialNo;
                dicSecurityLock[kSC_ITEM_PASS_CODE] = passCode;
                dicSecurityLock[kSC_ITEM_INTERVAL] = interval;
                dicSecurityLock[kSC_ITEM_NOTIFY_TYPE] = notifyType;
                dicSecurityLock[kSC_ITEM_CHECK_COUNT] = [NSNumber numberWithInteger:checkCount];
                [SCSystemData saveSecurityLock:dicSecurityLock];
                
                // 盗難防止ロック開始
                [SCSecurityLockService sharedInstance].isResetSecurityLockResult = YES;
                [[SCSecurityLockService sharedInstance] startHealthCheck];
                
                [self refreshLoginStatusView];
                // ペアリング成功（トースト表示（３秒））
                UIAlertController* confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"MSG_10024", @"盗難防止ロック開始") message:nil preferredStyle:UIAlertControllerStyleAlert];
                
                [self presentViewController:confirm animated:YES completion:^{
                    
                    [NSThread sleepForTimeInterval:3];
                    [confirm dismissViewControllerAnimated:YES completion:nil];
                }];
                
                self.flow = nil;
            } else {
                
                [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                    
                    if (ResultAction_RETRY == actionType) {
                        
                        // 再試行
                        [self startPairing];
                    } else {
                        
                        if (!error && (kBF_SC_NOT_SUPPORT == self.flow.resultFlow)) {
                            
                            DDLogWarn(@"盗難防止ロックサポート対象外");
                            
                            [self.navigationController popViewControllerAnimated:YES];
                        }

                        self.flow = nil;
                    }
                }];
            }
        });
    }];
}

/**
 盗難防止ロック機能フロー（盗難防止ロック解除）
 */
- (void)releasePairing {
    
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
    
    // ビジネスフロー
    DDLogInfo(@"12.盗難防止ロック機能フロー（盗難防止ロック解除）:開始");
    [self.flow releasePairing:self.appData.onlineSerialNo completion:^(NSError *error) {
        
        DDLogInfo(@"12.盗難防止ロック機能フロー（盗難防止ロック解除）:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideProgress];
            
            // ビジネスフロー結果メッセージ表示
            if (!error && (kBF_SC_RELEASE_SUCCESS == self.flow.resultFlow)) {
                
                // 盗難防止ロック情報保存（情報クリア）
                [SCSystemData saveSecurityLock:nil];
                
                // 盗難防止ロック停止
                [[SCSecurityLockService sharedInstance] releaseHealthCheck];
                [self refreshLoginStatusView];
                // ペアリング成功（トースト表示（３秒））
                UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"MSG_10028", @"盗難防止ロック解除") message:nil preferredStyle:UIAlertControllerStyleAlert];
                
                [self presentViewController:confirm animated:YES completion:^{
                    
                    [NSThread sleepForTimeInterval:3];
                    [confirm dismissViewControllerAnimated:YES completion:nil];
                }];
                 
                self.flow = nil;
            } else {
                
                [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                    
                    if (ResultAction_RETRY == actionType) {
                        
                        // 再試行
                        [self releasePairing];
                    } else {
                        
                        if (!error && (kBF_SC_RELEASED == self.flow.resultFlow || kBF_SC_LOGIN_ID_DIFFERENT == self.flow.resultFlow || KBF_SC_RELEASE_PASSCODE_MISMATCH == self.flow.resultFlow)) {
                            
                            // 盗難防止ロック情報保存（情報クリア）
                            [SCSystemData saveSecurityLock:nil];
                            
                            // 盗難防止ロック停止
                            [[SCSecurityLockService sharedInstance] releaseHealthCheck];
                            [self refreshLoginStatusView];
                        }
                        self.flow = nil;
                    }
                }];
            }
        });
    }];
}

/**
 チェック間隔の表示文字列を取得

 @param value <#value description#>
 @return <#return value description#>
 */
- (NSString *)getIntervalTitle:(NSString *)value {
    
    NSString *ret = @"";
    
    for (NSDictionary *title in self.listIntervalPicker) {
        
        if ([value isEqualToString:title[kSL_INTERVAL]]) {
            
            ret = title[kSL_PickerTitle];
            break;
        }
    }
    
    return ret;
}

/**
 チェック間隔の値を取得

 @param value <#value description#>
 
 @return <#return value description#>
 */
- (NSString *)getIntervalValue:(NSString *)value {
    
    NSString *ret = [self getIntervalString:IT_SECOND value:0];
    
    for (NSDictionary *title in self.listIntervalPicker) {
        
        if ([value isEqualToString:title[kSL_PickerTitle]]) {
            
            ret = title[kSL_INTERVAL];
            break;
        }
    }
    
    return ret;
}

/**
 チェック回数の表示文字列を取得

 @param value <#value description#>
 @return <#return value description#>
 */
- (NSString *)getCheckCountTitle:(NSInteger)value {
    
    NSString* ret = @"";
    
    for (NSDictionary *title in self.listCheckCountPicker) {
        
        if (value == [title[kSL_CHECK_COUNT] integerValue]) {
            
            ret = title[kSL_PickerTitle];
            break;
        }
    }
    
    return ret;
}

/**
 チェック回数の値を取得

 @param value <#value description#>
 
 @return <#return value description#>
 */
- (NSInteger)getCheckCountValue:(NSString *)value {
    
    NSInteger ret = 0;
    
    for (NSDictionary *title in self.listCheckCountPicker) {
        
        if ([value isEqualToString:title[kSL_PickerTitle]]) {
            
            ret = [title[kSL_CHECK_COUNT] integerValue];
            break;
        }
    }
    
    return ret;
}

/**
 *  チェック間隔の選択判定
 *
 *  @param value <#value description#>
 *
 *  @return YES:入力項目にNGあり / NO:入力項目はOK
 */
- (BOOL)isInterval:(NSString *)value {
    
    BOOL ret = YES;
    
    for (NSDictionary* title in self.listIntervalPicker) {
        
        if ([value isEqualToString:title[kSL_PickerTitle]]) {
            
            ret = NO;
            break;
        }
    }
    
    return ret;
}

/**
 *  チェック回数の選択判定
 *
 *  @param value <#value description#>
 *
 *  @return YES:入力項目にNGあり / NO:入力項目はOK
 */
- (BOOL)isCheckCount:(NSString *)value {
    
    BOOL ret = YES;
    
    for (NSDictionary* title in self.listCheckCountPicker) {
        
        if ([value isEqualToString:title[kSL_PickerTitle]]) {
            
            ret = NO;
            break;
        }
    }
    
    return ret;
}

/**
 ログイン状態チェック

 @return ログイン状態
 */
- (BOOL) checkLogin {
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    if ([userDefault stringForKey:KEY_PAIRING_LAST_LOGIN_DATE] != nil && [[userDefault stringForKey:KEY_PAIRING_LAST_LOGIN_DATE] length] > 0) {
        self.loginID = [userDefault stringForKey:KEY_PAIRING_LOGIN_ID];
        return YES;
    }
    self.loginID = DEFAULT_LOGIN_ID;
    return NO;
}

- (BOOL) checkPaired {
    self.dicSecurityLockInfo = [SCSystemData loadSecurityLock];
    if (self.dicSecurityLockInfo) {
        return YES;
    }
    return NO;
}

- (IBAction)toFAQClicked:(id)sender {
    [self performSegueWithIdentifier:@"toFAQ" sender:self];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"toFAQ"]) {
        NSMutableDictionary* dicInterval = [self.listEntry objectAtIndex:0];
        NSString* interval = [self getIntervalValue:dicInterval[kSL_VALUE]];
        NSIndexPath* indexPath = [NSIndexPath indexPathForRow:1 inSection:0];
        SCSecurityLockTableViewCell* cell = [self.tblvwSecurityLock cellForRowAtIndexPath:indexPath];
        NSNumber* notifyType = [NSNumber numberWithBool:cell.swValue.on];
        NSMutableDictionary* dicCheckCount = [self.listEntry objectAtIndex:2];
        NSInteger checkCount = [self getCheckCountValue:dicCheckCount[kSL_VALUE]];
        
        if ([[segue destinationViewController] isKindOfClass:[SCSecurityFAQViewController class]]) {
            SCSecurityFAQViewController *faqVC = (SCSecurityFAQViewController *)[segue destinationViewController];
            faqVC.interval = interval;
            faqVC.notifyType = notifyType;
            faqVC.checkCount = checkCount;
        }
    }
}
@end
