//
//  SCSecurityLockChangePasswordViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/01/30.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityLockPasswordChangeViewController.h"
#import "SCLogUtil.h"
#import "SCSystemData.h"
#import "SCSecurityLockFlow.h"
#import "SCSecurityLockViewController.h"
#import "SCAccountCheck.h"

@interface SCSecurityLockPasswordChangeViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UILabel *lblNowPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtfdNowPassword;
@property (weak, nonatomic) IBOutlet UILabel *lblPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtfdNewPassword;
@property (weak, nonatomic) IBOutlet UILabel *lblPasswordConfirm;
@property (weak, nonatomic) IBOutlet UITextField *txtfdPasswordConfirm;
@property (weak, nonatomic) IBOutlet UIButton *btnChange;

@end

@implementation SCSecurityLockPasswordChangeViewController

static NSString* const PASSWORD_CHANGE_FAILED = @"-1";
static NSString* const NOWPASSWORD_WRONG = @"-2";

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = NSLocalizedString(@"TITLE_SECURITY_LOCK", @"盗難防止ロック");
    
    self.lblNowPassword.text = NSLocalizedString(@"RES_20051", "現在のパスワード");
    self.lblPassword.text = NSLocalizedString(@"RES_20053", "パスワード");
    self.lblPasswordConfirm.text = NSLocalizedString(@"RES_20054", "パスワード(確認):");

    [self refreshSelectedSerialNo];
    [self.btnChange  setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnChange setTitle:NSLocalizedString(@"BTN_CHANGE", @"") forState:UIControlStateNormal];
}
- (IBAction)actionBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

- (IBAction)clickChangeBtn:(id)sender {
    if (![_txtfdNowPassword.text length] ||
        ![_txtfdNewPassword.text length] ||
        ![_txtfdPasswordConfirm.text length]) {
        NSMutableString *temp = [NSMutableString stringWithCapacity:0];
        
        if (![_txtfdNowPassword.text length]) {
            [temp appendString:NSLocalizedString(@"RES_20051", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"MSG_12000", @"確認メッセージ")];
            [temp appendString:@"\n"];
        }
        
        if (![_txtfdNewPassword.text length]) {
            [temp appendString:NSLocalizedString(@"RES_20053", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"MSG_12000", @"確認メッセージ")];
            [temp appendString:@"\n"];
        }
        
        if (![_txtfdPasswordConfirm.text length]) {
            [temp appendString:NSLocalizedString(@"RES_20054", @"確認メッセージ")];
            [temp appendString:NSLocalizedString(@"MSG_12000", @"確認メッセージ")];
        }
        [self showUnWriteAlertWithMsg:temp];
        return;
    }
    
    if (![SCAccountCheck checkPassWord:_txtfdNewPassword.text]) {
        [self showPasswordStyleAlert];
        return;
    }
    
    if (![_txtfdNewPassword.text isEqualToString:_txtfdPasswordConfirm.text]) {
        [self showPasswordConfirmErrorAlert];
        return;
    }
    
    // Wi-Fi切り替え確認
    if (![self isMobileConnect]) {
        
        [self connectSplicerAlert];
        
        return;
    }
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
    __weak SCSecurityLockPasswordChangeViewController *weekSelf = self;
    [[[SCSecurityLockFlow alloc] init] doPairingChangePassword:(NSString *)[[NSUserDefaults standardUserDefaults] objectForKey:KEY_PAIRING_LOGIN_ID] currentPassword:_txtfdNowPassword.text password:_txtfdNewPassword.text completion:^(NSError *error) {
        [weekSelf hideProgress];
        
        // 結果判定
        if (error) {
            // サーバ通信エラー
            DDLogError(@"パスワード変更異常:%@", error.description);
            id errorResult = error.userInfo[kSC_BF_ErrorResponse];
            if (!errorResult) {
                [weekSelf showNetWorkErrorAlert];
            } else if ([errorResult  isEqualToString:PASSWORD_CHANGE_FAILED]){
                [weekSelf showChangeErrorAlert];
            } else if([errorResult  isEqualToString:NOWPASSWORD_WRONG]) {
                [weekSelf showWrongPasswordAlert];
            }
        } else {
            DDLogError(@"パスワード変更成功");
            UIAlertController *alert  = [UIAlertController alertControllerWithTitle:@"" message:NSLocalizedString(@"MSG_13061", @"パスワード変更完了") preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", "OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                for (UIViewController *vc in weekSelf.navigationController.childViewControllers) {
                    if ([vc isKindOfClass:[SCSecurityLockViewController class]]) {
                        [weekSelf.navigationController popToViewController:vc animated:true];
                    }
                }
            }]];
            [self presentViewController:alert animated:YES completion:nil];
            
        }
    }];
    
}

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.btnChange setBackgroundImage:[self setButtonHilightBackColor:self.btnChange.bounds] forState:UIControlStateHighlighted];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:true];
}

#pragma mark - UITextFieldDelegate

-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return true;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    if (range.length == 1 && string.length == 0) {
        return YES;
    }
    if (textField == self.txtfdNowPassword && textField.text.length >= 33) {
        self.txtfdNowPassword.text = [textField.text substringToIndex:32];
        return NO;
    }
    if (textField == self.txtfdNewPassword && textField.text.length >= 33) {
        self.txtfdNewPassword.text = [textField.text substringToIndex:32];
        return NO;
    }
    if (textField == self.txtfdPasswordConfirm && textField.text.length >= 33) {
        self.txtfdPasswordConfirm.text = [textField.text substringToIndex:32];
        return NO;
    }
    return YES;
}
#pragma mark - alertType

-(void)showUnWriteAlertWithMsg:(NSString *)msg {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showWrongPasswordAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13053", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showChangeErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13054", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showNetWorkErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13044", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_INFORMATION", @"情報") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showPasswordConfirmErrorAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13049", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showPasswordStyleAlert {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13050", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
