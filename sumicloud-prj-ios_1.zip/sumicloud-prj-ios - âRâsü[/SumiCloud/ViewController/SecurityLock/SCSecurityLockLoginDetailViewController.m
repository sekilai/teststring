//
//  SCSecurityLockLoginDetailViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/01/30.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCSecurityLockLoginDetailViewController.h"
#import "SCLogUtil.h"
#import "SCSystemData.h"
#import "SCSecurityLockFlow.h"

@interface SCSecurityLockLoginDetailViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;
@property (weak, nonatomic) IBOutlet UIButton *btnLogout;
@property (weak, nonatomic) IBOutlet UILabel *lblEmailAddr;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleEmail;
@property (weak, nonatomic) IBOutlet UIButton *btnChangePassword;

@end

@implementation SCSecurityLockLoginDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = NSLocalizedString(@"TITLE_SECURITY_LOCK", @"盗難防止ロック");
    [self refreshSelectedSerialNo];
    [self.btnLogout  setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    [self.btnLogout setTitle:NSLocalizedString(@"BTN_LOGOUT", @"") forState:UIControlStateNormal];
    self.lblTitleEmail.text = NSLocalizedString(@"RES_20047", @"E-mailアドレス");
    [self.btnChangePassword setTitle:NSLocalizedString(@"RES_20042", @"パスワード変更") forState:UIControlStateNormal];
    
    self.lblEmailAddr.text = [[NSUserDefaults standardUserDefaults] stringForKey:KEY_PAIRING_EMAIL_ADDR];
    [self.lblEmailAddr sizeToFit];
    
    if (self.lblEmailAddr.frame.size.height <= 20.5) {
        self.lblEmailAddr.text = [NSString stringWithFormat: @"\n\n%@", self.lblEmailAddr.text];
    } else if (self.lblEmailAddr.frame.size.height <= 20.5 * 3) {
        self.lblEmailAddr.text = [NSString stringWithFormat: @"\n%@", self.lblEmailAddr.text];
    }
}

- (IBAction)actionBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    self.imgvwConnection.image = [self refreshLockState];
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.btnLogout setBackgroundImage:[self setButtonHilightBackColor:self.btnLogout.bounds] forState:UIControlStateHighlighted];
}

- (IBAction)logout:(id)sender {
    __weak SCSecurityLockLoginDetailViewController *weakSelf = self;
    [self showConfirmAlert:^{
        __weak NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault setObject:@"" forKey:KEY_PAIRING_LAST_LOGIN_DATE];
        [userDefault setObject:@"" forKey:KEY_PAIRING_LOGIN_ID];
        [userDefault setObject:@"" forKey:KEY_PAIRING_EMAIL_ADDR];
        [userDefault synchronize];
        [weakSelf.navigationController popViewControllerAnimated:true];
    }];
}


#pragma mark - alertType

-(void)showConfirmAlert:(void(^)(void))submit {
    NSMutableString* msg = [NSMutableString stringWithCapacity:0];
    [msg appendString:NSLocalizedString(@"MSG_13059", @"確認メッセージ")];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        submit();
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"CANCEL") style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
