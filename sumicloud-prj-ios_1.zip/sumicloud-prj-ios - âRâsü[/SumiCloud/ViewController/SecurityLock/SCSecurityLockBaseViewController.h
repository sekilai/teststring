//
//  SCSecurityLockBaseViewController.h
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/03/07.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, IntervalType) {
    IT_SECOND = 0,  // 秒単位
    IT_MINUTE,      // 分単位
    IT_HOUR,        // 時間単位
    IT_DAY          // 日単位
};

@interface SCSecurityLockBaseViewController : SCBaseViewController

- (NSString *)getIntervalString:(IntervalType)type value:(NSInteger)value;
    
@end

NS_ASSUME_NONNULL_END
