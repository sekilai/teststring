//
//  SCBaseLeftMenuViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/12/15.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseLeftMenuViewController.h"
#import "SCLogUtil.h"

#import "SCOverlayController.h"
#import "SCOverlayControllerAnimatedTransitioning.h"

@interface SCBaseLeftMenuViewController ()

@end

@implementation SCBaseLeftMenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 左メニュー画面のオーバーレイ表示制御

 @param presented <#presented description#>
 @param presenting <#presenting description#>
 @param source <#source description#>
 @return <#return value description#>
 */
- (UIPresentationController *)presentationControllerForPresentedViewController:(UIViewController *)presented presentingViewController:(UIViewController *)presenting sourceViewController:(UIViewController *)source {
    
    DDLogDebug(@"");
    
    SCOverlayController* overlay = [[SCOverlayController alloc] initWithPresentedViewController:presented presentingViewController:presenting];
    
    // サイズ指定
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    overlay.overlaySize = CGSizeMake(300.0f, floorf(screenSize.height * 95.0f / 100.0f));
    
    // 画面の左端・下端
    overlay.overlayHorizontally = kOLH_Left;
    overlay.overlayVertically = kOLV_Bottom;
    
    return overlay;
}

/**
 左メニュー画面のオーバーレイ表示制御

 @param presented <#presented description#>
 @param presenting <#presenting description#>
 @param source <#source description#>
 @return <#return value description#>
 */
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    
    DDLogDebug(@"");
    
    SCOverlayControllerAnimatedTransitioning* animation = [[SCOverlayControllerAnimatedTransitioning alloc] initWithPresent:YES];
    
    // アニメーション方向（左から右）
    animation.overlayAnimationDirection = kOLAD_LeftToRight;
    
    return animation;
}

/**
 左メニュー画面のオーバーレイ表示制御

 @param dismissed <#dismissed description#>
 @return <#return value description#>
 */
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    
    DDLogDebug(@"");
    
    SCOverlayControllerAnimatedTransitioning* animation = [[SCOverlayControllerAnimatedTransitioning alloc] initWithPresent:NO];
    
    // アニメーション方向（左から右）
    animation.overlayAnimationDirection = kOLAD_LeftToRight;
    
    return animation;
}

@end
