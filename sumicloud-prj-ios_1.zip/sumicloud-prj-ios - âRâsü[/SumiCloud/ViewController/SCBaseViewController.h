//
//  SCBaseViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/28.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SCApplicationData.h"
#import "SCBusinessFlowBase.h"
#import "Constants.h"

@interface SCBaseViewController : UIViewController

// アプリケーションデータインスタンス
@property (nonatomic) SCApplicationData* appData;

// 融着接続機の選択切り替えフラグ
@property (nonatomic) BOOL isSelectedSplicer; // YES:切り替え有効 / NO:切り替え無効


#pragma mark - Override Method

// 選択シリアル番号更新
- (void)refreshSelectedSerialNo;

// オンラインシリアル番号の更新
- (void)refreshOnlineSerialNo;


#pragma mark - Public Method

// プログレス表示
- (void)showProgress:(NSString *)title cancelHandler:(void(^)())cancelHandler;

-(void)setProgressTitleText:(NSString *)title;

// プログレス非表示
- (void)hideProgress;

// プログレスの進捗表示
- (void)updateProgressCounter:(NSInteger)currentCount maxCount:(NSInteger)maxCount;

// ビジネスフロー処理結果のメッセージ表示
typedef NS_ENUM(NSInteger, SCBFResultAction) {
    ResultAction_OK,
    ResultAction_NG,
    ResultAction_RETRY
};

- (void)alertMessage:(NSString *)msg;
- (void)alertExceptMessage:(NSString *)msg;
- (void)alertWifiErrorMessage:(NSString *)msg;
- (void)alertShowWithTitle:(NSString *)titleStr andMessage:(NSString *)messageStr;
- (void)messageBFResult:(SCBusinessFlowResult)result error:(NSError *)error actionHandler:(void(^)(SCBFResultAction actionType))actionHandler;
//メッセージ表示
typedef NS_ENUM(NSInteger, SCBFAction) {
    SCBFAction_UNLOCK,
    SCBFAction_LOCK,
    SCBFAction_LOCKCLEAR,
    SCBFAction_WIFIERROR
};
- (void)messageBFAction:(SCBFAction)action result:(RESULT_CODE)result error:(NSError *)error;

// 選択中の融着接続機のステータスの更新
- (UIImage *)refreshSplicerState;
- (UIImage *)refreshLockState;

// ボタンタップ時の背景色設定
- (UIImage *)setButtonHilightBackColor:(CGRect)rect;

// インターネット接続中アラート
- (void)connectInternetAlert;

// 融着機接続中アラート
- (void)connectSplicerAlert;

// 融着機未選択アラート
- (BOOL)isUnselectSplicerAlert;

// モバイル通信が可能か判定
- (BOOL)isMobileConnect;

// 融着接続機通信が可能か判定
- (BOOL)isSplicerConnect:(NSString *)serialNo;

- (BOOL)isSplicerConnect;

// 融着接続機メニュー画面表示イメージ取得
- (UIImage *)getSplicerNotReadyImage;

// 写真アクセス不可アラート
- (BOOL)isPhotosAuthDeniedAlert;

// アプリ使用期限確認
- (BOOL)isPassedExpirationDateMsg;

@end
