//
//  SCBaseViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/28.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"
#import "SCLogUtil.h"

#import <MRProgressOverlayView.h>

#import "SCSystemData.h"
#import "SCBusinessFlowBase.h"
#import "SCSplicerListFlow.h"
#import "SCScreenCaptureFlow.h"
#import "SCCustomAlertViewController.h"

@class SCMainTabBarViewController;

@interface SCBaseViewController ()

@property (nonatomic) MRProgressOverlayView* vwProgress;

@property (copy, nonatomic) void(^cancelHandler)();

@end

@implementation SCBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.appData = [SCApplicationData sharedInstance];
    
    self.isSelectedSplicer = NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateSelectedSerialNo:) name:kSC_ADP_SelectedSerialNo object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateOnlineSerialNo:) name:kSC_ADP_OnlineSerialNo object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateSecurityLock:) name:kSC_ADP_IsStartedSecurityLock object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {

    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSC_ADP_IsStartedSecurityLock object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSC_ADP_OnlineSerialNo object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kSC_ADP_SelectedSerialNo object:nil];
}


#pragma mark - Override Method

/**
 選択シリアル番号更新
 ＊画面の更新が必要な場合は、必ずオーバーライドする（基底クラスはNOP）
 */
- (void)refreshSelectedSerialNo {
}

/**
 オンラインシリアル番号更新
 ＊画面の更新が必要な場合は、必ずオーバーライドする（基底クラスはNOP）
 */
- (void)refreshOnlineSerialNo {
    
    if (self.isSelectedSplicer) {
        
        DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
        
        if ([NSLocalizedString(@"NO_SERIAL", @"---") isEqualToString:self.appData.onlineSerialNo]) {
            
            // オフラインになった場合は、手動で画面を更新する
            DDLogDebug(@"Wi-Fi切り替え[NO_SERIAL] -->> 画面更新");
            
            [self refreshSelectedSerialNo];
        } else {
            
            // 融着機接続更新
            [SCSplicerListFlow registSplicer:self.appData.onlineSerialNo];
            
            // 最前面の画面を確認し、画面更新
            UINavigationController* mainNavi = (UINavigationController *)[UIApplication sharedApplication].keyWindow.rootViewController;
            if (mainNavi.viewControllers.count < 2) {
                mainNavi = (UINavigationController *)mainNavi.presentedViewController;
            }
            UIViewController* vwconTop = mainNavi.viewControllers[1];
            while (vwconTop.presentedViewController) {
                
                vwconTop = vwconTop.presentedViewController;
            }
            if ([vwconTop isKindOfClass:[self.tabBarController class]]) {
                
                // UITabBarController の画面が最前面だった場合は、表示中の画面を確認
                UINavigationController* naviCon = self.tabBarController.selectedViewController;
                if ([self isKindOfClass:[naviCon.topViewController class]]) {
                    
                    // TOP画面が表示されていたら、シリアル選択とする
                    DDLogDebug(@"Wi-Fi切り替え[%@] -->> シリアル選択", [naviCon.topViewController class]);
                    
                    // 選択シリアル番号を更新すると、自動で画面が更新される
                    self.appData.selectedSerialNo = self.appData.onlineSerialNo;
                } else {
                    
                    // TOP画面以外が表示されていたら、画面表示のみ更新
                    DDLogDebug(@"Wi-Fi切り替え[%@] -->> 画面更新", [naviCon.topViewController class]);
                    
                    [self refreshSelectedSerialNo];
                }
            } else {
                
                // UITabBarController 以外の画面が最前面だった場合は、画面表示のみ更新
                DDLogDebug(@"Wi-Fi切り替え[%@] -->> 画面更新", [vwconTop class]);
                
                [self refreshSelectedSerialNo];
            }
        }
    }
}


#pragma mark - Public Method

/**
 プログレス表示

 @param title <#title description#>
 @param cancelHandler <#cancelHandler description#>
 */
- (void)showProgress:(NSString *)title cancelHandler:(void (^)())cancelHandler {
    
    self.cancelHandler = cancelHandler;
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    
    self.vwProgress = [MRProgressOverlayView showOverlayAddedTo:self.view.window animated:YES];
    self.vwProgress.mode = MRProgressOverlayViewModeIndeterminate;
    self.vwProgress.titleLabelText = title;
    if (title.length > 16) {
        self.vwProgress.titleLabel.font = [UIFont systemFontOfSize:12];
        self.vwProgress.titleLabel.numberOfLines = 2;
    }
    if (cancelHandler) {
        
        __unsafe_unretained typeof (self) weakVwCon = self;
        self.vwProgress.stopBlock = ^(MRProgressOverlayView *view) {
            if (weakVwCon.cancelHandler) {
                weakVwCon.cancelHandler();
            }
        };
    }
}

-(void)setProgressTitleText:(NSString *)title {
    self.vwProgress.titleLabelText = title;
}

/**
 プログレス非表示
 */
- (void)hideProgress {
    
    self.cancelHandler = nil;
    if (MRProgressOverlayViewModeDeterminateCircular == self.vwProgress.mode) {
        
        [self.vwProgress setProgress:1.0f animated:YES];
    }
    [self.vwProgress dismiss:YES];
    self.vwProgress = nil;
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

/**
 プログレスの進捗表示

 @param currentCount <#currentCount description#>
 @param maxCount <#maxCount description#>
 */
- (void)updateProgressCounter:(NSInteger)currentCount maxCount:(NSInteger)maxCount {

    dispatch_sync(dispatch_get_main_queue(), ^{
        
        if (1 == currentCount) {
            
            self.vwProgress.mode = MRProgressOverlayViewModeDeterminateCircular;
        }
        float pos = (float)currentCount / (float)maxCount;
        [self.vwProgress setProgress:pos animated:YES];
    });
}

/**
 ビジネスフロー処理結果のメッセージ表示

 @param result <#result description#>
 @param error <#error description#>
 @param actionHandler <#actionHandler description#>
 */
- (void)messageBFResult:(SCBusinessFlowResult)result error:(NSError *)error actionHandler:(void (^)(SCBFResultAction))actionHandler {
    
    UIViewController* view = nil;
    NSString* msg = @"";
    
    if (error) {
        
        DDLogError(@"%@", error.description);
        
        msg = NSLocalizedString(@"MSG_10005", @"確認メッセージ");
    } else {
        
        switch (result) {
            case kBF_OK:
                break;
                
            case kBF_LOCK:
                // 融着接続機(LOCK)
                msg = NSLocalizedString(@"MSG_10002", @"確認メッセージ");
                break;
                
            case kBF_NOT_READY:
                // 融着接続機(NOT READY)
                msg = NSLocalizedString(@"MSG_10003", @"確認メッセージ");
                // アラートの中に表示する画像領域を作成
                view = [self createContentView];
                break;
                
            case kBF_BUSY:
                // 融着接続機(BUSY)
                msg = NSLocalizedString(@"MSG_10004", @"確認メッセージ");
                break;
                
            case kBF_PAIRING_LOCK:
                // 融着接続機(PAIRING_LOCK)
                msg = NSLocalizedString(@"MSG_13042", @"確認メッセージ");
                break;
                
            case kBF_CANCEL:
                // プログレスのキャンセル
                break;
                
            case kBF_TIMEOUT:
                // 融着接続機(コマンドタイムアウト)
                msg = NSLocalizedString(@"MSG_10063", @"確認メッセージ");
                DDLogWarn(@"融着接続機(コマンドタイムアウト)");
                break;
                
            case kBF_NEST:
                // 融着接続機(コマンドネスト（入れ子）)
                msg = NSLocalizedString(@"MSG_10063", @"確認メッセージ");
                DDLogWarn(@"融着接続機(コマンドネスト（入れ子）)");
                break;
                
            case kBF_SP_NOT_SUPPORT:
                // 接続データ取得サポート対象外
                msg = NSLocalizedString(@"MSG_10056", @"確認メッセージ");
                break;
                
            case kBF_FW_NOT_SUPPORT:
                // FW更新サポート対象外
                msg = NSLocalizedString(@"MSG_10036", @"確認メッセージ");
                break;
                
            case kBF_FW_PAIRED_ERROR:
                // FW更新前ペラリング解除が必要
                msg = NSLocalizedString(@"MSG_13026", @"確認メッセージ");
                break;
                
            case kBF_FW_NO_NEED_UPDATE:
                // FW更新更新不要
                msg = NSLocalizedString(@"MSG_13002", @"確認メッセージ");
                break;
                
            case kBF_FW_DOWNLOAD_FILE_ERROR:
                // FW更新ダウンロードファイル異常
                msg = NSLocalizedString(@"MSG_10038", @"確認メッセージ");
                break;
                
            case kBF_FW_SUCCESS:
                // FW更新完了
                msg = NSLocalizedString(@"MSG_10035", @"確認メッセージ");
                break;
                
            case kBF_AD_SUCCESS:
                // 自動診断完了
                msg = NSLocalizedString(@"MSG_10045", @"確認メッセージ");
                break;
                
            case kBF_AD_NOT_SUPPORT:
                // 自動診断サポート対象外
                msg = NSLocalizedString(@"MSG_10044", @"確認メッセージ");
                break;
                
            case kBF_AD_MASK_MODEL:
                // マスク対象機種
                msg = NSLocalizedString(@"MSG_10065", @"確認メッセージ");
                break;
                
            case kBF_MU_LOCK:
                // 本体ロック
                DDLogWarn(@"本体ロック");
                break;
                
            case kBF_MU_UNLOCK:
                // 本体ロック解除
                DDLogWarn(@"本体ロック解除");
                break;

            case kBF_SC_NOT_SUPPORT:
                // 盗難防止ロックサポート対象外
                msg = NSLocalizedString(@"MSG_10057", @"確認メッセージ");
                break;
                
            case kBF_SC_START_SUCCESS:
                // 盗難防止ロック開始成功
                break;
                
            case kBF_SC_CANCEL:
                // 盗難防止ロックキャンセル
                msg = NSLocalizedString(@"MSG_10025", @"確認メッセージ");
                break;
                
            case kBF_SC_TIMEOUT:
                // 盗難防止ロックタイムアウト
                msg = NSLocalizedString(@"MSG_10026", @"確認メッセージ");
                break;
                
            case kBF_SC_HEALTH_CHECK:
                // 盗難防止ロックヘルスチェック実施中
                msg = NSLocalizedString(@"MSG_10027", @"確認メッセージ");
                break;
                
            case kBF_SC_RELEASE_SUCCESS:
                // 盗難防止ロック解除成功
                break;
                
            case kBF_SC_RELEASED:
                // 盗難防止ロック解除済み
                msg = NSLocalizedString(@"MSG_10029", @"確認メッセージ");
                break;
            
            case KBF_SC_PAIRED_OTHER:
                // 盗難防止ロックペアリング済み済み
                msg = NSLocalizedString(@"MSG_13027", @"確認メッセージ");
                break;
            case KBF_SC_LOGIN_ID_MISMATCH:
                // 盗難防止ロックログインID不一致
                msg = NSLocalizedString(@"MSG_13041", @"確認メッセージ");
                break;
            case kBF_SC_LOGIN_ID_DIFFERENT:
                // 盗難防止ロックログインID異なる
                msg = NSLocalizedString(@"MSG_13043", @"確認メッセージ");
                break;
            case KBF_SC_RELEASE_PASSCODE_MISMATCH:
                // 盗難防止ロックパスコード不一致
                msg = NSLocalizedString(@"MSG_13030", @"確認メッセージ");
                break;
            case kBF_FW_NEED_REBOOT:
                // 融着接続機再起動必要
                msg = NSLocalizedString(@"MSG_13014", @"確認メッセージ");
                break;
            case kBF_FW_WRITEPROTECT_ERROR:
                // WRITEPROTECTかける失敗
                msg = NSLocalizedString(@"MSG_13015", @"確認メッセージ");
                break;
            case kBF_PEV_UNSUPPORT:
                // 予防保全の対象ではありません。
                msg = NSLocalizedString(@"MSG_13078", @"確認メッセージ");
                break;
            case kBF_AD_T502_OP058_ERROR:
                msg = NSLocalizedString(@"MSG_13080", @"確認メッセージ");
                break;
            default:
                msg = NSLocalizedString(@"MSG_10005", @"確認メッセージ");
                break;
        }
    }
    
    if (msg.length) {
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
        
        if (view) {

            // 画像用の画面が存在すればアラートに設定する
            [alert setValue:view forKey:@"contentViewController"];
        }
        
        if (actionHandler && (kBF_NOT_READY == result)) {
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"CANCEL") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
                actionHandler(ResultAction_OK);
            }]];

            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_RETRY", @"再試行") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
                actionHandler(ResultAction_RETRY);
            }]];
        } else {
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
                if (actionHandler) {
                    
                    actionHandler(ResultAction_OK);
                }
            }]];
        }
        
        [self presentViewController:alert animated:YES completion:^{
        }];
    }
}

- (void)messageBFAction:(SCBFAction)action result:(RESULT_CODE)result error:(NSError *)error {
    
    NSString* msg = @"";
    NSString* title = @"";
    BOOL showImageAlert = false;
    NSString* errorCode = @"";
    if (error) {
        
        DDLogError(@"%@", error.description);
        switch (action) {
            case SCBFAction_UNLOCK: // ロック解除
                msg = NSLocalizedString(@"error_message_unlock_failed", @"確認メッセージ");
                break;
            case SCBFAction_LOCK: // ロック
                msg = NSLocalizedString(@"error_message_lock_failed", @"確認メッセージ");
                break;
            case SCBFAction_LOCKCLEAR: // ロッククリア
                msg = NSLocalizedString(@"error_message_unlock_failed", @"確認メッセージ");
                break;
                
            default:
                break;
        }
        
        
        switch (error.code) {
            case COMMAND_POST_ERROR:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"C2";
                        break;
                        
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"C2";
                        break;
                    case SCBFAction_LOCKCLEAR:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"C2";
                        break;
                        
                    default:
                        break;
                }
            }
                break;
            case COMMAND_PO00_POST_ERROR:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_po00_post_error", @"確認メッセージ");
                        break;
                        
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock_po00_post_error", @"確認メッセージ");
                        break;
                    case SCBFAction_LOCKCLEAR:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lockclear_po00_post_error", @"確認メッセージ");
                        break;
                        
                    default:
                        break;
                }
            }
                break;
            case COMMAND_TIME_OUT:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"C3";
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"C3";
                        break;
                    case SCBFAction_LOCKCLEAR:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"C3";
                        break;
                        
                    default:
                        break;
                }
            }
                break;
            case COMMAND_PO00_COMMAND_TIME_OUT:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_po00_time_out", @"確認メッセージ");
                        errorCode = @"C3";
                        showImageAlert = true;
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock_po00_time_out", @"確認メッセージ");
                        errorCode = @"C3";
                        showImageAlert = true;
                        break;
                    case SCBFAction_LOCKCLEAR:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lockclear_po00_time_out", @"確認メッセージ");
                        errorCode = @"C3";
                        showImageAlert = true;
                        break;
                        
                    default:
                        break;
                }
            }
                break;
                
            default:
                break;
        }
        
    } else {
        
        switch (result) {
            case SUCCESS:
                break;
                
            case COMMAND_ERROR_LOCK:
                // 融着接続機(LOCK)
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_failed", @"確認メッセージ");
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"adlg_lock", @"確認メッセージ");
                        break;
                    default:
                        break;
                }
            }
                break;
                
            case COMMAND_RESULT_ERROR:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"C1";
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"C1";
                        break;
                    case SCBFAction_LOCKCLEAR:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"C1";
                        break;
                        
                    default:
                        break;
                }
            }
                break;
             case COMMAND_DATE_ERROR: // 日付が昨日以前
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_failed", @"確認メッセージ");
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock_failed", @"確認メッセージ");
                        break;
                    default:
                        break;
                }
            }
                break;
            case COMMAND_RESULT_ERROR_2: // 日付が2050年12月31日以降
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_failed", @"確認メッセージ");
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock_failed", @"確認メッセージ");
                        break;
                    default:
                        break;
                }
            }
                break;
            case COMMAND_RESULT_ERROR_3: // 繰り返し設定が不正
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_failed", @"確認メッセージ");
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock_failed", @"確認メッセージ");
                        break;
                    default:
                        break;
                }
            }
                break;
            case COMMAND_RESULT_ERROR_4: // パスワードが'0'~'9' 'A'~'Z'以外
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_failed", @"確認メッセージ");
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock_failed", @"確認メッセージ");
                        break;
                    default:
                        break;
                }
            }
                break;
            case COMMAND_RESULT_ERROR_9:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_failed", @"確認メッセージ");
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock_failed", @"確認メッセージ");
                        break;
                    default:
                        break;
                }
            }
                break;
            case COMMAND_RESULT_ERROR_E1: //
                
                title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                msg = NSLocalizedString(@"error_message_unlock_failed_e1", @"確認メッセージ");
                break;
                
            case COMMAND_RESULT_ERROR_E2:
                
                title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                msg = NSLocalizedString(@"error_message_unlock_failed_e2", @"確認メッセージ");
                break;
            case COMMAND_RESULT_ERROR_E3:
                
                title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                msg = NSLocalizedString(@"error_message_unlock_failed_e3", @"確認メッセージ");
                break;
            case COMMAND_RESULT_ERROR_E4:
            
                title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                msg = NSLocalizedString(@"error_message_unlock_failed_e1", @"確認メッセージ");
                break;
            case COMMAND_RESULT_ERROR_E9:
                switch (action) {
                    case SCBFAction_UNLOCK:
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"";
                        break;
                    case SCBFAction_LOCK:
                        msg = NSLocalizedString(@"error_message_lock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"";
                        break;
                    case SCBFAction_LOCKCLEAR:
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"";
                        break;
                        
                    default:
                        break;
                }
                break;
            case COMMAND_ERROR_BUSY:
                // 融着接続機(BUSY)
                title =NSLocalizedString(@"dlg_alert", @"設定");
                msg = NSLocalizedString(@"adlg_busy", @"確認メッセージ");
                break;
                //            case kBF_CANCEL:
                //                // プログレスのキャンセル
                //                break;
                //
            case COMMAND_SPLICER_NOT_READY:
                title = NSLocalizedString(@"dlg_alert", @"設定");
                msg = NSLocalizedString(@"error_message_not_ready", @"融着接続機をSumiCloud設定メニュー画面以外に設定してください。");
                break;
            case COMMAND_TIME_OUT:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        errorCode = @"C3";
                        showImageAlert = true;
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock", @"確認メッセージ");
                        errorCode = @"C3";
                        showImageAlert = true;
                        break;
                    case SCBFAction_LOCKCLEAR:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        errorCode = @"C3";
                        showImageAlert = true;
                        break;
                        
                    default:
                        break;
                }
            }
                break;
            case COMMAND_PO00_COMMAND_TIME_OUT:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_po00_time_out", @"確認メッセージ");
                        errorCode = @"C3";
                        showImageAlert = true;
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock_po00_time_out", @"確認メッセージ");
                        errorCode = @"C3";
                        showImageAlert = true;
                        break;
                    case SCBFAction_LOCKCLEAR:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lockclear_po00_time_out", @"確認メッセージ");
                        errorCode = @"C3";
                        showImageAlert = true;
                        break;
                        
                    default:
                        break;
                }
            }
                break;
            case COMMAND_PO00_COMMAND_ERROR:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_unlock_po00_error", @"確認メッセージ");
                        break;
                    case SCBFAction_LOCK:
                        title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lock_po00_error", @"確認メッセージ");
                        break;
                    case SCBFAction_LOCKCLEAR:
                        title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                        msg = NSLocalizedString(@"error_message_lockclear_po00_error", @"確認メッセージ");
                        break;
                        
                    default:
                        break;
                }
            }
                break;
                
            case kBF_MU_LOCK:
                // 本体ロック
                title = NSLocalizedString(@"adlg_title_lock", @"確認メッセージ");
                msg = NSLocalizedString(@"lock_title_text", @"確認メッセージ");
                DDLogWarn(@"本体ロック");
                break;
                
            case kBF_MU_UNLOCK:
                // 本体ロック解除
                title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                msg = NSLocalizedString(@"unlock_success_text", @"確認メッセージ");
                DDLogWarn(@"本体ロック解除");
                break;
            case kBF_MU_LOCK_CLEAR:
                // 本体ロック解除
                title = NSLocalizedString(@"adlg_title_unlock", @"確認メッセージ");
                msg = NSLocalizedString(@"unlock_title_text", @"確認メッセージ");
                DDLogWarn(@"本体ロック解除CLEAR");
                break;
                
            case WIFI_ERROR:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"";
                        break;
                    case SCBFAction_LOCK:
                        msg = NSLocalizedString(@"error_message_lock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"";
                        break;
                    case SCBFAction_LOCKCLEAR:
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"";
                        break;
                        
                    case SCBFAction_WIFIERROR:
                        msg = NSLocalizedString(@"online_setting", @"メッセージ");
                        showImageAlert = true;
                        errorCode = @"";
                    default:
                        break;
                }
            }
                break;
                
            default:
            {
                switch (action) {
                    case SCBFAction_UNLOCK:
                        msg = NSLocalizedString(@"error_message_unlock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"";
                        break;
                    case SCBFAction_LOCK:
                        msg = NSLocalizedString(@"error_message_lock", @"確認メッセージ");
                        showImageAlert = true;
                        errorCode = @"";
                        break;
                    case SCBFAction_LOCKCLEAR:
                        msg = NSLocalizedString(@"error_message_unlock_failed", @"確認メッセージ");
                        break;
                        
                    default:
                        break;
                }
            }
                break;
        }
    }
    
    if (showImageAlert){
        
        SCCustomAlertViewController* customeAlertVC = [[SCCustomAlertViewController alloc] initWithNibName:NSStringFromClass([SCCustomAlertViewController class]) bundle:nil];
        customeAlertVC.errorMsg = msg;
        customeAlertVC.errorCode = errorCode;
        customeAlertVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
        [self presentViewController:customeAlertVC animated:false completion:nil];
        
    } else if (msg.length) {
        
        DDLogError(@"msg = %@", msg);
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
        
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:^{
        }];
    }
}

/**
 ボタンタップ時の背景色設定

 @param rect <#rect description#>
 @return <#return value description#>
 */
- (UIImage *)setButtonHilightBackColor:(CGRect)rect {
    
    UIImage* ret = nil;
    
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [[SCSystemData colorWithRGB:0x4B green:0xC0 blue:0xF6 alpha:1.0f] CGColor]);
    CGContextFillRect(context, rect);
    ret = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

    return ret;
}

/**
 選択中の融着接続機のステータスの更新
 
 @return <#return value description#>
 */
- (UIImage *)refreshSplicerState {
    
    UIImage* ret = nil;
    
    // 融着接続機の状態
    switch (self.appData.spliceStete) {
        case kSCS_OnlineUnlock:
            // オンライン ロックなし
            ret = [UIImage imageNamed:@"image_common_connection-on"];
            break;
        case kSCS_Onlinelock:
            // オンライン ロックあり
            ret = [UIImage imageNamed:@"image_common_connection-on_keyon"];
            break;
        case kSCS_Offlinelock:
            // オフライン ロックあり
            ret = [UIImage imageNamed:@"image_common_connection-off_keyon"];
            break;
        default:
            // オフライン ロックなし
            ret = [UIImage imageNamed:@"image_common_connection-off"];
            break;
    }
    
    return ret;
}

-(UIImage *)refreshLockState{
    UIImage* ret = nil;
    NSString* state = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"%@_lockState", self.appData.selectedSerialNo]];
    if (self.appData.spliceStete == kSCS_OnlineUnlock || self.appData.spliceStete == kSCS_Onlinelock) {
        if ([state isEqualToString:@"Locked"]) {
            ret = [UIImage imageNamed:@"image_common_connection-on_keyon"];
        } else {
            ret = [UIImage imageNamed:@"image_common_connection-on"];
        }
    } else {
        if ([state isEqualToString:@"Locked"]) {
            ret = [UIImage imageNamed:@"image_common_connection-off_keyon"];
        } else {
            ret = [UIImage imageNamed:@"image_common_connection-off"];
        }
    }
    return ret;
}

/**
 インターネット接続中アラート
 */
- (void)connectInternetAlert {
    
    DDLogWarn(@"【インターネット接続中】");
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_SETTING", @"設定") message:NSLocalizedString(@"MSG_10001", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

/**
 融着機接続中アラート
 */
- (void)connectSplicerAlert {
    
    DDLogWarn(@"【融着機接続中】");
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_SETTING", @"設定") message:NSLocalizedString(@"MSG_10000", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
    
    [self presentViewController:alert animated:YES completion:nil];
}

/**
 融着機が未選択か判定してアラート表示

 @return YES:融着機未選択 / NO:融着機選択済み
 */
- (BOOL)isUnselectSplicerAlert {
    
    if (![self.appData.selectedSerialNo isEqualToString:NSLocalizedString(@"NO_SERIAL", @"---")]) {
        
        return NO;
    }
    
    DDLogWarn(@"【融着機未選択状態】");
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_12008", @"") preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", nil) style:UIAlertActionStyleDefault handler:nil]];
    
    [self presentViewController:alert animated:YES completion:nil];
    
    return YES;
}

/**
 モバイル通信が可能か判定

 @return YES:モバイル通信可能 / NO:モバイル通信不可
 */
- (BOOL)isMobileConnect {

    BOOL ret = self.appData.isReaching;
    if (ret) {
        
        if ([self.appData.onlineSerialNo isEqualToString:NSLocalizedString(@"NO_SERIAL", @"---")]) {
            
            ret = YES;
        } else {
            
            ret = NO;
        }
    }
    
    return ret;
}

/**
 融着接続機通信が可能か判定

 @return YES:融着接続機通信可能 / NO:融着接続機通信不可
 */
- (BOOL)isSplicerConnect {
    
    BOOL ret = self.appData.isReaching;
    if (ret) {
        
        if ([self.appData.onlineSerialNo isEqualToString:NSLocalizedString(@"NO_SERIAL", @"---")]) {
            
            ret = NO;
        } else {
            
            ret = YES;
        }
    }
    
    return ret;
}

/**
 融着接続機通信が可能か判定

 @param serialNo <#serialNo description#>

 @return YES:融着接続機通信可能 / NO:融着接続機通信不可
 */
- (BOOL)isSplicerConnect:(NSString *)serialNo {
    
    BOOL ret = self.appData.isReaching;
    if (ret) {
        
        if ([self.appData.onlineSerialNo isEqualToString:NSLocalizedString(@"NO_SERIAL", @"---")]) {
            
            ret = NO;
        } else {

            if ([serialNo isEqualToString:self.appData.onlineSerialNo]) {
                
                ret = YES;
            } else {
                
                ret = NO;
            }
        }
    }
    
    return ret;
}

/**
 融着接続機メニュー画面表示イメージ取得

 @return <#return value description#>
 */
- (UIImage *)getSplicerNotReadyImage {
    
    // TODO:NOT READY アラート表示に使用するイメージを取得するように共通化したい
    NSString *imageFile = @"";
    NSString *fileType = @"";
    
    // 言語を判断して画像を切り替える
    NSString *language = [SCSystemData getLanguage];
    if (![language isEqualToString:@"ja"]) {
        language = @"en";
    }
    
    // モデルによりファイル名を切り替える
    if (![SCSystemData isModelType72C:self.appData.selectedSerialNo] &&
        ![SCSystemData isModelTypeZ2C:self.appData.selectedSerialNo] &&
        ![SCSystemData isModelType72M:self.appData.selectedSerialNo] &&
        ![SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
        
        imageFile = [NSString stringWithFormat:@"not_ready_%@", language];
        fileType = @"png";
    } else {
        // TODO:T72Cのファイル名(英語のみ)
        //imageFile = [NSString stringWithFormat:@"not_ready_%@_2", language];
        imageFile = [NSString stringWithFormat:@"not_ready_72"];
        fileType = @"png";
    }

    NSString* contentsFile = [[NSBundle mainBundle] pathForResource:[@"Dialog" stringByAppendingPathComponent:imageFile] ofType:fileType];
    return [UIImage imageWithContentsOfFile:contentsFile];
}

/**
 写真アクセスが不可か判定してアラート表示

 @return YES:アクセス不可 / NO:アクセス可能
 */
- (BOOL)isPhotosAuthDeniedAlert {
    
    BOOL ret = NO;
    if ([SCScreenCaptureFlow getAuthorizationStatus] != kPAS_Authorized) {
        
        ret = YES;
        NSString *msg = NSLocalizedString(@"MSG_12010", @"");
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:^{
        }];
    }
    return ret;
}

/**
 アプリ使用期限確認

 @return YES:使用期限を過ぎている / NO:使用期限を過ぎていない
 */
- (BOOL)isPassedExpirationDateMsg {
    
    // 使用期限の確認
    BOOL ret = [SCSystemData isPassedExpirationDate];
    if (ret) {
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10059", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
    return ret;
}


#pragma mark - Private Method

/**
 アラート画像作成

 @return <#return value description#>
 */
- (UIViewController *)createContentView {
    
    UIViewController* vc = [[UIViewController alloc] init];
    
    // 座標指定（iPhone6、iPhone6Plus、iPhoneSEで確認済み）
    UIImageView* imageView = [[UIImageView alloc] init];
    UIImage* image = [self getSplicerNotReadyImage];
    imageView.frame = CGRectMake(71, 0, 128, 96);
    imageView.image = image;
    [vc.view addSubview:imageView];
    
    return vc;
}

-(UIViewController *)createWifiErrorView{
    UIViewController* vc = [[UIViewController alloc] init];
    
    // 座標指定（iPhone6、iPhone6Plus、iPhoneSEで確認済み）
    UIImageView* imageView = [[UIImageView alloc] init];
    UIImage* image = [UIImage imageNamed:@"img_WiFiError_iOS"];
    imageView.frame = CGRectMake(0, 0, 70, 100);
    imageView.image = image;
    [vc.view addSubview:imageView];
    
    return vc;
}

- (void)alertMessage:(NSString *)msg {
    
    UIViewController *topCon = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (topCon.presentedViewController) {
        topCon = topCon.presentedViewController;
    }
    if ([topCon isKindOfClass:[UIAlertController class]]) {
        
        DDLogDebug(@"アラート表示中");
        return;
    }
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"dlg_alert", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }]];
    
    [topCon presentViewController:alert animated:YES completion:nil];
}

- (void)alertShowWithTitle:(NSString *)titleStr andMessage:(NSString *)messageStr {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:titleStr message:messageStr preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"OK") style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:cancelAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)alertExceptMessage:(NSString *)msg {
    
    UIViewController* view = nil;
    
    UIViewController *topCon = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (topCon.presentedViewController) {
        topCon = topCon.presentedViewController;
    }
    if ([topCon isKindOfClass:[UIAlertController class]]) {
        
        DDLogDebug(@"アラート表示中");
        return;
    }
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"adlg_title_splice_connection", @"確認メッセージ") message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    view = [self createContentView];
    
    // 画像用の画面が存在すればアラートに設定する
    [alert setValue:view forKey:@"contentViewController"];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }]];
    
    [topCon presentViewController:alert animated:YES completion:nil];
}

- (void)alertWifiErrorMessage:(NSString *)msg {
    
    UIViewController* view = nil;
    
    UIViewController *topCon = [UIApplication sharedApplication].keyWindow.rootViewController;
    while (topCon.presentedViewController) {
        topCon = topCon.presentedViewController;
    }
    if ([topCon isKindOfClass:[UIAlertController class]]) {
        
        DDLogDebug(@"アラート表示中");
        return;
    }
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"adlg_title_splice_connection", @"確認メッセージ") message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    view = [self createWifiErrorView];
    
    // 画像用の画面が存在すればアラートに設定する
    [alert setValue:view forKey:@"contentViewController"];
    
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_positive", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }]];
    
    [topCon presentViewController:alert animated:YES completion:nil];
}

#pragma mark - NotificationCenter

/**
 選択シリアル番号更新

 @param notification <#notification description#>
 */
- (void)updateSelectedSerialNo:(NSNotification *)notification {
    
    DDLogDebug(@"選択シリアル番号更新【%@】", notification);

    if ([self respondsToSelector:@selector(refreshSelectedSerialNo)]) {
        
        [self refreshSelectedSerialNo];
    }
}

/**
 オンラインシリアル番号更新

 @param notification <#notification description#>
 */
- (void)updateOnlineSerialNo:(NSNotification *)notification {

    if (self.appData.isForeground) {
        
        DDLogDebug(@"オンラインシリアル番号更新【%@】", notification);
        
        if ([self respondsToSelector:@selector(refreshOnlineSerialNo)]) {
            
            [self refreshOnlineSerialNo];
        }
    }
}

/**
 盗難防止ロック設定更新

 @param notification <#notification description#>
 */
- (void)updateSecurityLock:(NSNotification *)notification {
    
    DDLogDebug(@"盗難防止ロック設定更新【%@】", notification);
    
    if ([self respondsToSelector:@selector(refreshSelectedSerialNo)]) {
        
        [self refreshSelectedSerialNo];
    }
}

@end
