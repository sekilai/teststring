//
//  SCInstructionViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_2 on 2017/12/01.
//  Copyright © 2017年 fsi_mac5d_5. All rights reserved.
//

#import "SCInstructionViewController.h"
#import "SCSystemData.h"
#import "SCLogUtil.h"

@interface SCInstructionViewController ()
<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *instructionImage1;
@property (weak, nonatomic) IBOutlet UIImageView *instructionImage2;
@property (weak, nonatomic) IBOutlet UIImageView *instructionImage3;
@property (weak, nonatomic) IBOutlet UIImageView *instructionImage4;
@property (weak, nonatomic) IBOutlet UIImageView *instructionImage5;
@property (weak, nonatomic) IBOutlet UIImageView *instructionImage6;
@property (weak, nonatomic) IBOutlet UILabel *instructionText1;
@property (weak, nonatomic) IBOutlet UILabel *instructionText2;
@property (weak, nonatomic) IBOutlet UILabel *instructionText3;
@property (weak, nonatomic) IBOutlet UILabel *instructionText4;
@property (weak, nonatomic) IBOutlet UILabel *instructionText5;
@property (weak, nonatomic) IBOutlet UILabel *instructionText6;
@property (weak, nonatomic) IBOutlet UIScrollView *instructionArea;
@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;

@property (weak, nonatomic) IBOutlet UIImageView *checkImage;
@property (weak, nonatomic) IBOutlet UILabel *checkText;
@property (weak, nonatomic) IBOutlet UIView *checkArea;
@property (nonatomic) BOOL check;
@end

#define PAGE_COUNT 6

@implementation SCInstructionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];

    // 多言語対応
    self.title = NSLocalizedString(@"MSG_13011", @"インストラクション");
    self.checkText.text = NSLocalizedString(@"MSG_13005", @"以後表示しない");
    self.instructionText1.text = NSLocalizedString(@"MSG_13004", @"ようこそ、SumiCloudへ！");
    self.instructionText2.text = NSLocalizedString(@"MSG_13006", @"1. iPhoneの設定を開く...");
    self.instructionText3.text = NSLocalizedString(@"MSG_13007", @"お使いの融着接続機...");
    self.instructionText4.text = NSLocalizedString(@"MSG_13008", @"この画面が表示された...");
    self.instructionText5.text = NSLocalizedString(@"MSG_13009", @"インターネットに接続せず...");
    self.instructionText6.text = NSLocalizedString(@"MSG_13010", @"上の画面のように表示...");
    [self.instructionText1 sizeToFit];
    [self.instructionText2 sizeToFit];
    [self.instructionText3 sizeToFit];
    [self.instructionText4 sizeToFit];
    [self.instructionText5 sizeToFit];
    [self.instructionText6 sizeToFit];

    // タップジェスチャー
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapGestureAction:)];
    [self.checkArea addGestureRecognizer:tapGesture];
    if(self.hideCheck){
        self.checkArea.hidden = YES;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)viewDidLayoutSubviews{
    float width = self.instructionArea.bounds.size.width;
    float height = self.instructionArea.bounds.size.height;
    self.instructionArea.contentSize = CGSizeMake(width * 6, height);
    
    self.instructionImage1.frame = CGRectMake(0, 0, width - 20, (width - 20) / self.instructionImage1.image.size.width * self.instructionImage1.image.size.height);
    self.instructionImage1.center = CGPointMake(width / 2 , height / 2);
    self.instructionText1.center = CGPointMake(width / 2 , self.instructionImage1.frame.origin.y - self.instructionText1.bounds.size.height - 10);

    self.instructionImage2.frame = CGRectMake(0, 0, width *0.6, (width * 0.6) / self.instructionImage2.image.size.width * self.instructionImage2.image.size.height);
    self.instructionImage2.center = CGPointMake(width / 2 + width , height / 2 - 80);
    self.instructionText2.frame = CGRectMake(0, 0, width - 80, self.instructionText2.bounds.size.height);
    self.instructionText2.center = CGPointMake(width / 2 + width, self.instructionImage2.frame.origin.y + self.instructionImage2.bounds.size.height  + self.instructionText2.bounds.size.height / 2 + 20);
    if(self.instructionText2.frame.origin.y + self.instructionText2.frame.size.height > height){
        self.instructionText2.frame = CGRectMake(self.instructionText2.frame.origin.x,
                                                 height - self.instructionText2.frame.size.height,
                                                 self.instructionText2.frame.size.width,
                                                 self.instructionText2.frame.size.height);
    }

    self.instructionImage3.frame = CGRectMake(0, 0, width *0.6, (width * 0.6) / self.instructionImage3.image.size.width * self.instructionImage3.image.size.height);
    self.instructionImage3.center = CGPointMake(width / 2 + (width * 2) , height / 2 - 80);
    self.instructionText3.frame = CGRectMake(0, 0, width - 40, self.instructionText3.bounds.size.height);
    self.instructionText3.center = CGPointMake(width / 2 + (width * 2), self.instructionImage3.frame.origin.y + self.instructionImage3.bounds.size.height + self.instructionText3.bounds.size.height / 2 + 20);
    if(self.instructionText3.frame.origin.y + self.instructionText3.frame.size.height > height){
        self.instructionText3.frame = CGRectMake(self.instructionText3.frame.origin.x,
                                                 height - self.instructionText3.frame.size.height,
                                                 self.instructionText3.frame.size.width,
                                                 self.instructionText3.frame.size.height);
        self.instructionImage3.frame = CGRectMake(self.instructionImage3.frame.origin.x,
                                                  self.instructionImage3.frame.origin.y,
                                                  self.instructionImage3.frame.size.width,
                                                  self.instructionText3.frame.origin.y - self.instructionImage3.frame.origin.y);
    }

    self.instructionImage4.frame = CGRectMake(0, 0, width *0.6, (width * 0.6) / self.instructionImage4.image.size.width * self.instructionImage4.image.size.height);
    self.instructionImage4.center = CGPointMake(width / 2 + (width * 3) , height / 2 - 20);
    self.instructionText4.frame = CGRectMake(0, 0, width - 40, self.instructionText4.bounds.size.height);
    self.instructionText4.center = CGPointMake(width / 2 + (width * 3), self.instructionImage4.frame.origin.y + self.instructionImage4.bounds.size.height  + self.instructionText4.bounds.size.height / 2 + 20);
    if(self.instructionText4.frame.origin.y + self.instructionText4.frame.size.height > height){
        self.instructionText4.frame = CGRectMake(self.instructionText4.frame.origin.x,
                                                 height - self.instructionText4.frame.size.height,
                                                 self.instructionText4.frame.size.width,
                                                 self.instructionText4.frame.size.height);
        self.instructionImage4.frame = CGRectMake(self.instructionImage4.frame.origin.x,
                                                  self.instructionImage4.frame.origin.y > 0
                                                  ? self.instructionImage4.frame.origin.y : 0,
                                                  self.instructionImage4.frame.size.width,
                                                  self.instructionText4.frame.origin.y - self.instructionImage4.frame.origin.y - 10);
    }

    self.instructionImage5.frame = CGRectMake(0, 0, width *0.6, (width * 0.6) / self.instructionImage5.image.size.width * self.instructionImage5.image.size.height);
    self.instructionImage5.center = CGPointMake(width / 2 + (width * 4) , height / 2 - 80);
    self.instructionText5.frame = CGRectMake(0, 0, width - 80, self.instructionText5.bounds.size.height);
    self.instructionText5.center = CGPointMake(width / 2 + (width * 4), self.instructionImage5.frame.origin.y + self.instructionImage5.bounds.size.height + self.instructionText5.bounds.size.height / 2 + 20);
    if(self.instructionText5.frame.origin.y + self.instructionText5.frame.size.height > height){
        self.instructionText5.frame = CGRectMake(self.instructionText5.frame.origin.x,
                                                 height - self.instructionText5.frame.size.height,
                                                 self.instructionText5.frame.size.width,
                                                 self.instructionText5.frame.size.height);
    }
    
    self.instructionImage6.frame = CGRectMake(0, 0, width *0.6, (width * 0.6) / self.instructionImage6.image.size.width * self.instructionImage6.image.size.height);
    self.instructionImage6.center = CGPointMake(width / 2 + (width * 5) , height / 2 - 80);
    self.instructionText6.frame = CGRectMake(0, 0, width - 80, self.instructionText6.bounds.size.height);
    self.instructionText6.center = CGPointMake(width / 2 + (width * 5), self.instructionImage6.frame.origin.y + self.instructionImage6.bounds.size.height  + self.instructionText6.bounds.size.height / 2 + 20);
    if(self.instructionText6.frame.origin.y + self.instructionText6.frame.size.height > height){
        self.instructionText6.frame = CGRectMake(self.instructionText6.frame.origin.x,
                                                 height - self.instructionText6.frame.size.height,
                                                 self.instructionText6.frame.size.width,
                                                 self.instructionText6.frame.size.height);
    }
    
}

/**
 現在のページ

 @param scrollView <#scrollView description#>
 */
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    self.pageControl.currentPage = scrollView.contentOffset.x / scrollView.frame.size.width;
}

/**
 閉じるボタン
 
 @param sender <#sender description#>
 */
- (IBAction)actionClose:(UIBarButtonItem *)sender {
    
    DDLogInfo(@"閉じるボタン -> Instruction画面を閉じる");
    
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}

/**
 pageの変更

 @param sender <#sender description#>
 */
- (IBAction)pageCtrlValueChanged:(id)sender {
    [self.instructionArea setContentOffset:CGPointMake(self.instructionArea.bounds.size.width * self.pageControl.currentPage, 0) animated:YES];
}

/**
 checkImage状態表示

 @param sender <#sender description#>
 */
- (void)viewTapGestureAction:(id)sender {
    if(self.check){
        self.checkImage.image = [UIImage imageNamed:@"btn_check_off"];
    }else{
        self.checkImage.image = [UIImage imageNamed:@"btn_check_on"];
    }
    self.check = !self.check;
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:self.check forKey:@"InstructionCheck"];
    [defaults synchronize];
}
@end
