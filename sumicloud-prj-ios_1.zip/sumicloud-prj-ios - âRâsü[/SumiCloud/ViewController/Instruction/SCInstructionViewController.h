//
//  SCInstructionViewController.h
//  SumiCloud
//
//  Created by fsi_mac5d_2 on 2017/12/01.
//  Copyright © 2017年 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

@interface SCInstructionViewController : SCBaseViewController
@property (nonatomic) BOOL hideCheck;
@end
