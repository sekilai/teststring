//
//  SCCustomerLicenceViewController.h
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2021/03/03.
//  Copyright © 2021 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SCCustomerLicenceViewController : SCBaseViewController

@property (weak, nonatomic) IBOutlet UILabel *licenceTitle;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UIButton *checkBoxBtn;

@end

NS_ASSUME_NONNULL_END
