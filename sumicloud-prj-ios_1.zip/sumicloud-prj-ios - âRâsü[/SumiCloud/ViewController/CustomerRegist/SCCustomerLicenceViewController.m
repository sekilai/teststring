//
//  SCCustomerLicenceViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2021/03/03.
//  Copyright © 2021 fsi_mac5d_5. All rights reserved.
//

#import "SCCustomerLicenceViewController.h"
#import "SCCustomerRegistViewController.h"

@interface SCCustomerLicenceViewController ()

@property (nonatomic, copy)NSString* step;
@property (nonatomic, assign)BOOL isChecked;
@property (weak, nonatomic) IBOutlet UIButton *continueBtn;
@property (weak, nonatomic) IBOutlet UIView *mainView;
@property (weak, nonatomic) IBOutlet UILabel *agreeTitle;

@end

@implementation SCCustomerLicenceViewController

{
    UILabel* licenceInfo;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.step = @"step1";
    self.isChecked = false;
    self.continueBtn.enabled = false;
    self.licenceTitle.text = NSLocalizedString(@"licence_title", @"利用規約");
    self.agreeTitle.text = NSLocalizedString(@"licence_agree", @"同意する。");
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"About/Terms" ofType:@"txt"];
    NSError *error;
    NSString *text = [[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
    licenceInfo = [[UILabel alloc] initWithFrame:CGRectMake(8, 8, self.scrollView.frame.size.width - 16, 0)];
    licenceInfo.text = text;
    licenceInfo.numberOfLines = 0;
    [licenceInfo sizeToFit];
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width, licenceInfo.frame.size.height + 16);
    [self.scrollView addSubview:licenceInfo];
}

- (IBAction)continueClicked:(id)sender {
    
    if ([self.step isEqualToString:@"step1"]){
        self.step = @"step2";
        [UIView animateWithDuration:0.3 animations:^{
            self.mainView.alpha = 0;
        } completion:^(BOOL finished) {
            self.licenceTitle.text = NSLocalizedString(@"licence_title2", @"利用規約");
            NSString *filePath = [[NSBundle mainBundle] pathForResource:@"About/Policy" ofType:@"txt"];
            NSError *error;
            NSString *text = [[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
            licenceInfo.text = text;
            [licenceInfo sizeToFit];
            self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width, licenceInfo.frame.size.height + 16);
            self.scrollView.contentOffset = CGPointMake(0, 0);
            self.isChecked = false;
            self.continueBtn.enabled = false;
            UIImage* uncheckImage = [UIImage imageNamed:@"btn_check_off"];
            [self.checkBoxBtn setBackgroundImage:uncheckImage forState:UIControlStateNormal];
        }];
        
        [UIView animateWithDuration:0.3 delay:0.3 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            self.mainView.alpha = 1;
        } completion:nil];
        
    } else if ([self.step isEqualToString:@"step2"]) {
        [self dismissViewControllerAnimated:false completion:^{
            [[NSNotificationCenter defaultCenter] postNotificationName:@"showCustomerRegistView" object:nil];
        }];
    }
}

- (IBAction)checkBoxClicked:(id)sender {
    UIImage* uncheckImage = [UIImage imageNamed:@"btn_check_off"];
    UIImage* checkedImage = [UIImage imageNamed:@"btn_check_on"];
    UIButton* checkBtn = sender;
    [checkBtn setBackgroundImage:self.isChecked ? uncheckImage : checkedImage forState:UIControlStateNormal];
    self.continueBtn.enabled = !self.isChecked;
    self.isChecked = !self.isChecked;
    
}

@end
