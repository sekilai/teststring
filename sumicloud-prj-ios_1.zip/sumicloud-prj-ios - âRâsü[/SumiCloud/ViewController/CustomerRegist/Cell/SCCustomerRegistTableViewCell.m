//
//  SCCustomerRegistTableViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/14.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCCustomerRegistTableViewCell.h"

@implementation SCCustomerRegistTableViewCell

/**
 <#Description#>
 */
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

/**
 <#Description#>

 @param selected <#selected description#>
 @param animated <#animated description#>
 */
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
