//
//  SCCustomerRegistTableViewCell.h
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/14.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCCustomerRegistTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@property (weak, nonatomic) IBOutlet UITextField *txtValue;

@end
