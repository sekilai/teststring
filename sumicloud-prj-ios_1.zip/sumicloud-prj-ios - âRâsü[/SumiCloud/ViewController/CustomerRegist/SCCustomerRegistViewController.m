//
//  SCCustomerRegistViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCCustomerRegistViewController.h"
#import "SCCustomerRegistTableViewCell.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCCustomerRegistFlow.h"

#define PRE_CEHCKBOX @"CEHCKBOX"

@interface SCCustomerRegistViewController () <UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource>
{
    BOOL isCheck;
    UIPickerView *categoryPicker;
    UIPickerView *countryPicker;
}

@property (nonatomic) NSMutableDictionary* dicEntryData;

@property (nonatomic) NSMutableArray* listEntry;
@property (nonatomic) NSArray* listCategoryCode;
@property (nonatomic) NSArray* listCountryCode;
@property (nonatomic) NSMutableArray* listCategoryPicker;
@property (nonatomic) NSMutableArray* listCountryPicker;

@property (nonatomic) NSString* selectedCategory;
@property (nonatomic) NSString* selectedCountry;
@property (nonatomic) NSIndexPath* editRow;

@property (nonatomic) CGSize vwTableOffset;

@property (weak, nonatomic) IBOutlet UITableView *vwTable;
@property (weak, nonatomic) IBOutlet UIButton *btnRegist;

- (IBAction)btnRegistTouchUpInside:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet UIImageView *checkBoxView;
@property (weak, nonatomic) IBOutlet UILabel *tosLabel1;
@property (weak, nonatomic) IBOutlet UILabel *tosLabelTitle;
@property (weak, nonatomic) IBOutlet UILabel *tosLabel2;

@end

@implementation SCCustomerRegistViewController

typedef NS_ENUM(NSInteger, CustomerRegistEntryTag) {
    TagCompany = 1000,
    TagCountry,
    TagCategory,
    TagDepartment,
    TagTel,
    TagEMail
};

static NSInteger const kSC_MAXLEN_ENTRY = 256; // 入力文字数
static NSInteger const kSC_MAXLEN_TEL   = 19;  // 入力文字数（電話番号）

static NSString* const kCR_TITLE        = @"title";        // 入力項目名
static NSString* const kCR_TagNo        = @"TagNo";        // タグ番号
static NSString* const kCR_KeyboardType = @"KeyboardType"; // キーボード種別
static NSString* const kCR_ITEM_NAME    = @"ItemName";     // 項目名

static NSString* const KCR_COUNTRY_CODE   = @"code";   // 国名のコード
static NSString* const KCR_COUNTRY_NAME = @"countryName"; // 国名
static NSString* const KCR_COUNTRY_NAME_JA = @"countryNameJa"; // 国名(JP)

static NSString* const kCR_CATEGORY_NO   = @"no";   // 業種の項番
static NSString* const kCR_CATEGORY_NAME = @"name"; // 業種名

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    [self.btnRegist setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_CUSTOMER_REGIST", @"顧客情報登録");
    [self.btnRegist setTitle:NSLocalizedString(@"BTN_REGIST", @"登録ボタン") forState:UIControlStateNormal];

    // テーブル設定
    self.vwTable.estimatedRowHeight = 44.0f;
    self.vwTable.rowHeight = UITableViewAutomaticDimension;

    // 入力項目のリストを生成
    self.listEntry = [NSMutableArray arrayWithCapacity:0];
    [self.listEntry addObject:@{
                                // 企業名*:
                                kCR_TITLE : @"RES_20000",
                                kCR_TagNo : [NSNumber numberWithInteger:TagCompany],
                                kCR_KeyboardType : [NSNumber numberWithInteger:UIKeyboardTypeDefault],
                                kCR_ITEM_NAME : kCR_ITEM_COMPANY
                                }];
    [self.listEntry addObject:@{
                                // 国名*:
                                kCR_TITLE : @"RES_20041",
                                kCR_TagNo : [NSNumber numberWithInteger:TagCountry],
                                kCR_KeyboardType : [NSNumber numberWithInteger:UIKeyboardTypeDefault],
                                kCR_ITEM_NAME : kCR_ITEM_COUNTRY
                                }];
    [self.listEntry addObject:@{
                                // 業種*:
                                kCR_TITLE : @"RES_20001",
                                kCR_TagNo : [NSNumber numberWithInteger:TagCategory],
                                kCR_KeyboardType : [NSNumber numberWithInteger:UIKeyboardTypeDefault],
                                kCR_ITEM_NAME : kCR_ITEM_CATEGORY
                                }];
    [self.listEntry addObject:@{
                                // 部署名*:
                                kCR_TITLE : @"RES_20002",
                                kCR_TagNo : [NSNumber numberWithInteger:TagDepartment],
                                kCR_KeyboardType : [NSNumber numberWithInteger:UIKeyboardTypeDefault],
                                kCR_ITEM_NAME : kCR_ITEM_DEPARTMENT
                                }];
    [self.listEntry addObject:@{
                                // 電話番号*:
                                kCR_TITLE : @"RES_20003",
                                kCR_TagNo : [NSNumber numberWithInteger:TagTel],
                                kCR_KeyboardType : [NSNumber numberWithInteger:UIKeyboardTypeNumbersAndPunctuation],
                                kCR_ITEM_NAME : kCR_ITEM_TEL
                                }];
    [self.listEntry addObject:@{
                                // E-mail:
                                kCR_TITLE : @"RES_20004",
                                kCR_TagNo : [NSNumber numberWithInteger:TagEMail],
                                kCR_KeyboardType : [NSNumber numberWithInteger:UIKeyboardTypeURL],
                                kCR_ITEM_NAME : kCR_ITEM_EMAIL
                                }];
    
    // 入力データ初期化
    self.dicEntryData = [NSMutableDictionary dictionaryWithCapacity:0];
    self.dicEntryData[kCR_ITEM_COMPANY] = @"";
    self.dicEntryData[kCR_ITEM_COUNTRY] = @"";
    self.dicEntryData[kCR_ITEM_CATEGORY] = @"";
    self.dicEntryData[kCR_ITEM_DEPARTMENT] = @"";
    self.dicEntryData[kCR_ITEM_TEL] = @"";
    self.dicEntryData[kCR_ITEM_EMAIL] = @"";
    
    
    //国名リスト
    NSString *plistPath = [[NSBundle mainBundle]pathForResource:@"CountryName" ofType:@"plist"];
    self.listCountryCode = [[NSArray alloc] initWithContentsOfFile:plistPath];
    
    // LocalizedString
//    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//    NSArray *languages = [defaults objectForKey:@"AppleLanguages"];
//    NSString* currentLanguage = [languages objectAtIndex:0];
    // 国名の場合は、選択入力
    self.listCountryPicker = [NSMutableArray arrayWithCapacity:0];
    for (NSDictionary* dicCountryCode in self.listCountryCode) {
        
//        NSString *countryTitle = [currentLanguage isEqualToString:@"ja-JP"] ? dicCountryCode[KCR_COUNTRY_NAME_JA]: dicCountryCode[KCR_COUNTRY_NAME];
          NSString *countryTitle = dicCountryCode[KCR_COUNTRY_NAME];
        if (![countryTitle isEqualToString:@"-"]) {
            
            [self.listCountryPicker addObject:countryTitle];
        }
    }
    
    // 業種名リスト
    self.listCategoryCode = @[
                              // "情報通信業"
                              @{kCR_CATEGORY_NO : [NSNumber numberWithInteger:7],
                                kCR_CATEGORY_NAME : NSLocalizedString(@"CR_CATEGORY_07",nil)},
                              // "物品賃貸業"
                              @{kCR_CATEGORY_NO : [NSNumber numberWithInteger:12],
                                kCR_CATEGORY_NAME : NSLocalizedString(@"CR_CATEGORY_12",nil)},
                              // "電気・ガス・熱供給・水道業"
                              @{kCR_CATEGORY_NO : [NSNumber numberWithInteger:6],
                                kCR_CATEGORY_NAME : NSLocalizedString(@"CR_CATEGORY_06",nil)},
                              // "建設業"
                              @{kCR_CATEGORY_NO : [NSNumber numberWithInteger:4],
                                kCR_CATEGORY_NAME : NSLocalizedString(@"CR_CATEGORY_04",nil)},
                              // "製造業"
                              @{kCR_CATEGORY_NO : [NSNumber numberWithInteger:5],
                                kCR_CATEGORY_NAME : NSLocalizedString(@"CR_CATEGORY_05",nil)},
                              // "学術研究、専門・技術サービス業"
                              @{kCR_CATEGORY_NO : [NSNumber numberWithInteger:13],
                                kCR_CATEGORY_NAME : NSLocalizedString(@"CR_CATEGORY_13",nil)},
                              // "その他"
                              @{kCR_CATEGORY_NO : [NSNumber numberWithInteger:99],
                                kCR_CATEGORY_NAME : NSLocalizedString(@"CR_CATEGORY_99",nil)}
                              ];
    
    // 業種の場合は、選択入力
    self.listCategoryPicker = [NSMutableArray arrayWithCapacity:0];
    for (NSDictionary* dicCategoryCode in self.listCategoryCode) {
        
        NSString *categoryTitle = dicCategoryCode[kCR_CATEGORY_NAME];
        if (![categoryTitle isEqualToString:@"-"]) {
            
            [self.listCategoryPicker addObject:categoryTitle];
        }
    }

    // タップジェスチャー
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewTapGestureAction:)];
    [self.view addGestureRecognizer:tapGesture];
    

    // tosLabelTitle
    NSMutableAttributedString *content = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:NSLocalizedString(@"TITLE_TERMS_SERVICE_MESSAGE", @"")]];
    NSRange contentRange = {0,[content length]};
    [content addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:contentRange];
    [content addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:14.0] range:contentRange];
    [content addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:contentRange];
    self.tosLabelTitle.attributedText = content;
    
    
    // tosLabel1 tosLabel2
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];
    NSString * preferredLang = [allLanguages objectAtIndex:0];
    
    if ([preferredLang rangeOfString:@"ja"].location != NSNotFound) {
        // に同意します
        self.tosLabel2.text = NSLocalizedString(@"TITLE_MESSAGE_ACCEPT_TITLE", @"");
    }else
    {
        // I accept the
        self.tosLabel1.text = NSLocalizedString(@"TITLE_MESSAGE_ACCEPT", @"");
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 画面表示制御

 @param animated <#animated description#>
 */
- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    // キーボード表示制御
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
 
    
}

/**
 画面表示制御

 @param animated <#animated description#>
 */
- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    // 色味の設定
    [self.btnRegist setBackgroundImage:[self setButtonHilightBackColor:self.btnRegist.bounds] forState:UIControlStateHighlighted];

    // オフセットを保持
    self.vwTableOffset = CGSizeMake(self.vwTable.contentSize.width, self.vwTable.contentSize.height);
    
}

/**
 画面非表示制御

 @param animated <#animated description#>
 */
- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    
    [self.view endEditing:YES];
    
    // キーボード表示制御
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


#pragma mark - Action

/**
 *  画面タップでキーボード非表示
 *
 *  @param sender <#sender description#>
 */
- (void)viewTapGestureAction:(UITapGestureRecognizer *)sender {
    
    [self.view endEditing:YES];
}

/**
 キーボード表示制御

 @param notification <#notification description#>
 */
- (void)keyboardWillShow:(NSNotification *)notification {
    
    // 高さ変更(キーボードの分縮める)
    CGRect keyboardRect = [[notification userInfo][UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    // オフセットから表示サイズを求める
    CGSize newSize = CGSizeMake(self.vwTableOffset.width, self.vwTableOffset.height + keyboardRect.size.height);
    [self.vwTable setContentSize:newSize];
    
    // セル位置（画面上の絶対位置）
    UITableViewCell* cell = [self.vwTable cellForRowAtIndexPath:self.editRow];
    CGFloat cellBottom = cell.frame.origin.y + cell.frame.size.height - self.vwTable.contentOffset.y + self.vwTable.frame.origin.y + self.navigationController.navigationBar.frame.size.height + [UIApplication sharedApplication].statusBarFrame.size.height;
    
    // 位置判定
    if (keyboardRect.origin.y < cellBottom) {
        
        // 表示中のキーボードの上に移動
        CGPoint newPos = CGPointMake(self.vwTable.contentOffset.x, self.vwTable.contentOffset.y + cellBottom - keyboardRect.origin.y);
        [self.vwTable setContentOffset:newPos animated:YES];
    }
    
    self.vwTable.scrollEnabled = NO;
}

/**
 キーボード非表示制御

 @param notification <#notification description#>
 */
- (void)keyboardWillHide:(NSNotification *)notification {

    self.vwTable.scrollEnabled = YES;

    // オフセットに戻す
    [self.vwTable setContentSize:self.vwTableOffset];
    
    [self.vwTable scrollToRowAtIndexPath:self.editRow atScrollPosition:UITableViewScrollPositionNone animated:YES];
}

/**
 checkBox情報保存

 @param sender <#sender description#>
 */
- (IBAction)termsOfServiceTapGesture:(UITapGestureRecognizer *)sender {
    
}

/**
 利用規約画面へ

 @param sender <#sender description#>
 */
- (IBAction)tosTapGesture:(id)sender {
    
    UIViewController *viewController =
    [[UIStoryboard storyboardWithName:@"About"
                               bundle:NULL] instantiateViewControllerWithIdentifier:@"SCTermsOfServiceViewController"];
    [self.navigationController pushViewController:viewController animated:YES];
    
}

#pragma mark - Button Action

/**
 Backボタン

 @param sender <#sender description#>
 */
- (IBAction)actionBack:(UIBarButtonItem *)sender {
    
    DDLogDebug(@"");
    
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 登録ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnRegistTouchUpInside:(UIButton *)sender {

    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }
    
    DDLogInfo(@"登録ボタン -> 顧客情報登録要求");
    
    // 入力チェック
    NSArray* validateError = [self isValidate:self.dicEntryData];
    if (validateError.count) {
        
        DDLogWarn(@"顧客情報入力NG <<%@>>", validateError);

        NSMutableString* errorMsg = [NSMutableString stringWithCapacity:0];
        for (NSString* msg in validateError) {
            
            [errorMsg appendFormat:@"%@\r\n", msg];
        }
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", nil) message:errorMsg preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        }]];
        
        [self presentViewController:alert animated:YES completion:nil];

        return;
    }
    
    // サーバ送信（顧客情報登録要求）
    [self showProgress:NSLocalizedString(@"DLG_CONNECT", @"接続中...") cancelHandler:nil];
    
    NSMutableDictionary* entryData = [NSMutableDictionary dictionaryWithDictionary:self.dicEntryData];
    
    entryData[kCR_ITEM_COUNTRY] = [self getCountryCode:self.dicEntryData[kCR_ITEM_COUNTRY]];
    
    entryData[kCR_ITEM_CATEGORY] = [NSNumber numberWithInteger:[self getCategoryCode:self.dicEntryData[kCR_ITEM_CATEGORY]]];
    
    // ビジネスフロー
    [[[SCCustomerRegistFlow alloc] init] runFlow2:entryData completion:^(NSError *error) {

        [self hideProgress];
        
        // 結果判定
        if (error) {
            
            // サーバ通信エラー
            DDLogError(@"顧客情報登録異常:%@", error.description);

            [self dismissViewControllerAnimated:true completion:nil];
            
            
        } else {

            DDLogInfo(@"顧客情報登録正常");
            
            [self dismissViewControllerAnimated:true completion:nil];
            
        }
    }];
}


#pragma mark - UITextFieldDelegate

/**
 入力項目編集開始
 
 @param textField <#textField description#>
 
 @return <#return value description#>
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    for (NSInteger ii=0; ii < self.listEntry.count; ii++) {
        
        NSDictionary* dicEntry = [self.listEntry objectAtIndex:ii];
        if (textField.tag == [dicEntry[kCR_TagNo] integerValue]) {
            
            self.editRow = [NSIndexPath indexPathForRow:ii inSection:0];
        }
    }
    
    // 業種選択
    if (TagCategory == textField.tag || TagCountry == textField.tag) {
        
        // Cancelボタン
        UIBarButtonItem *btnEditCancel = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_CANCEL", @"キャンセル") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditCancelTouchUpInside:)];
        
        // フレキシブルスペース
        UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
        
        // 設定ボタン
        UIBarButtonItem *btnEditOk = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"BTN_DONE", @"完了") style:UIBarButtonItemStylePlain target:self action:@selector(btnEditOkTouchUpInside:)];
        
        // ツールバー
        UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
        toolbar.barStyle = UIBarStyleDefault;
        [toolbar sizeToFit];
        [toolbar setItems:@[btnEditCancel, spacer, btnEditOk] animated:YES];
        
        textField.inputAccessoryView = toolbar;
        

        
        if (TagCategory == textField.tag ) {
            
            categoryPicker = [[UIPickerView alloc] init];
            textField.inputView = categoryPicker;
            categoryPicker.delegate = self;
            categoryPicker.dataSource = self;
            [categoryPicker sizeToFit];
            // 選択項目位置初期化
            for (NSInteger posPicker=0; posPicker < self.listCategoryPicker.count; posPicker++) {
                
                if ([textField.text isEqualToString:self.listCategoryPicker[posPicker]]) {
                    
                    [categoryPicker selectRow:posPicker inComponent:0 animated:NO];
                    self.selectedCategory = textField.text;
                    break;
                }
            }
            if (0 == self.selectedCategory.length) {
                
                [categoryPicker selectRow:0 inComponent:0 animated:NO];
                self.selectedCategory = self.listCategoryPicker[0];
            }
        }else {
            countryPicker = [[UIPickerView alloc] init];
            textField.inputView = countryPicker;
            countryPicker.delegate = self;
            countryPicker.dataSource = self;
            [countryPicker sizeToFit];
            // 選択項目位置初期化
            for (NSInteger posPicker=0; posPicker < self.listCountryPicker.count; posPicker++) {
                
                if ([textField.text isEqualToString:self.listCountryPicker[posPicker]]) {
                    
                    [countryPicker selectRow:posPicker inComponent:0 animated:NO];
                    self.selectedCountry = textField.text;
                    break;
                }
            }
            if (0 == self.selectedCountry.length) {
                
                [countryPicker selectRow:0 inComponent:0 animated:NO];
                self.selectedCountry = self.listCountryPicker[0];
            }
        }
    
    }
    
    return YES;
}

/**
 入力項目編集中

 @param textField <#textField description#>
 @param range     <#range description#>
 @param string    <#string description#>

 @return <#return value description#>
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSMutableString *val = [textField.text mutableCopy];
    [val replaceCharactersInRange:range withString:string];
    
    if (TagCategory == textField.tag) {
        
        // 選択項目チェック
        return ![self isCategory:val];
    }else if (TagCountry == textField.tag) {
        // 選択項目チェック
        return ![self isCountry:val];
    }else if ((TagCompany == textField.tag)
               || (TagDepartment == textField.tag)
               || (TagEMail == textField.tag)) {
        
        // 入力文字数チェック
        if (kSC_MAXLEN_ENTRY < val.length) {
            
            return NO;
        }
        
        return YES;
    } else if (TagTel == textField.tag) {
        
        // 入力文字数チェック
        if (kSC_MAXLEN_TEL < val.length) {
            
            return NO;
        }
        
        // 文字種チェック
        return ![self isTel:val];
    }
    
    return NO;
}

/**
 入力項目編集終了
 
 @param textField <#textField description#>
 */
- (void)textFieldDidEndEditing:(UITextField *)textField {
    
    [self.view endEditing:YES];
    
    for (NSMutableDictionary* dicEntry in self.listEntry) {
        
        NSInteger tagNo = [dicEntry[kCR_TagNo] integerValue];
        if (tagNo == textField.tag) {
            
            self.dicEntryData[dicEntry[kCR_ITEM_NAME]] = textField.text;
        }
    }
}

/**
 入力項目のOK
 
 @param sender <#sender description#>
 */
- (void)btnEditOkTouchUpInside:(UIButton *)sender {
    
    NSInteger row = self.editRow.row;
    
    NSInteger CountryRow =  [self.listEntry indexOfObject:@{
                                   // 国名*:
                                   kCR_TITLE : @"RES_20041",
                                   kCR_TagNo : [NSNumber numberWithInteger:TagCountry],
                                   kCR_KeyboardType : [NSNumber numberWithInteger:UIKeyboardTypeDefault],
                                   kCR_ITEM_NAME : kCR_ITEM_COUNTRY
                                   }];
    
    SCCustomerRegistTableViewCell* cellEdit = [self.vwTable cellForRowAtIndexPath:self.editRow];
    cellEdit.txtValue.text = row == CountryRow ? self.selectedCountry : self.selectedCategory;

    [self.view endEditing:YES];
}

/**
 入力項目のCancel
 
 @param sender <#sender description#>
 */
- (void)btnEditCancelTouchUpInside:(UIButton *)sender {
    
    [self.view endEditing:YES];
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param section   <#section description#>
 
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listEntry.count;
}

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSDictionary* dicEntry = [self.listEntry objectAtIndex:indexPath.row];

    SCCustomerRegistTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.lblTitle.text = NSLocalizedString(dicEntry[kCR_TITLE], @"ラベル");
    cell.txtValue.text = self.dicEntryData[dicEntry[kCR_ITEM_NAME]];
    cell.txtValue.keyboardType = [dicEntry[kCR_KeyboardType] integerValue];
    cell.txtValue.tag = [dicEntry[kCR_TagNo] integerValue];
    
    // 色味の設定
    NSMutableAttributedString* attrString = [[NSMutableAttributedString alloc] initWithString:cell.lblTitle.text];
    [attrString addAttribute:NSForegroundColorAttributeName value:[SCSystemData colorWithRGB:0xC5 green:0x23 blue:0x23 alpha:1.0f] range:[cell.lblTitle.text rangeOfString:@"*"]];
    cell.lblTitle.attributedText = attrString;
    
    return cell;
}


#pragma mark - UIPickerViewDelegate

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param row        <#row description#>
 @param component  <#component description#>
 @param view       <#view description#>

 @return <#return value description#>
 */
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    
    UILabel *lblTitle = (id)view;
    if (!lblTitle) {
        
        lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [pickerView rowSizeForComponent:component].width, [pickerView rowSizeForComponent:component].height)];
    }
    if (categoryPicker == pickerView) {
         lblTitle.text = self.listCategoryPicker[row];
    }else {
        lblTitle.text = self.listCountryPicker[row];
    }
   
    lblTitle.textColor = [UIColor blackColor];
    lblTitle.textAlignment = NSTextAlignmentCenter;
    lblTitle.backgroundColor = [UIColor clearColor];
    lblTitle.font = [UIFont systemFontOfSize:20.0f];
    lblTitle.adjustsFontSizeToFitWidth = YES;
    
    return lblTitle;
}

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param row        <#row description#>
 @param component  <#component description#>
 */
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (categoryPicker == pickerView) {
        self.selectedCategory = self.listCategoryPicker[row];
    }else {
        self.selectedCountry = self.listCountryPicker[row];
    }
}


#pragma mark - UIPickerViewDataSource

/**
 選択表示

 @param pickerView <#pickerView description#>

 @return <#return value description#>
 */
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    
    return 1;
}

/**
 選択表示

 @param pickerView <#pickerView description#>
 @param component  <#component description#>

 @return <#return value description#>
 */
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    if (categoryPicker == pickerView) {
        return self.listCategoryPicker.count;
    }else {
        return self.listCountryPicker.count;
    }
    
}


#pragma mark - Private Method

/**
 入力項目チェック

 @param entryData <#entryData description#>

 @return <#return value description#>
 */
- (NSArray *)isValidate:(NSDictionary *)entryData {

    NSMutableArray* ret = [NSMutableArray arrayWithCapacity:0];
    
    // 企業名チェック
    NSString* company = entryData[kCR_ITEM_COMPANY];
    if ((0 == company.length)
        || (kSC_MAXLEN_ENTRY < company.length)) {
        
        [ret addObject:[NSString stringWithFormat:@"%@ %@", NSLocalizedString(@"RES_20000", @"入力項目"), NSLocalizedString(@"MSG_12000", @"必須")]];
    }
    
    // 国名チェック
    NSString* country = entryData[kCR_ITEM_COUNTRY];
    if ((0 == country.length)
        || ([self isCountry:country])) {
        
        [ret addObject:[NSString stringWithFormat:@"%@ %@", NSLocalizedString(@"RES_20041", @"入力項目"), NSLocalizedString(@"MSG_12000", @"必須")]];
    }
    
    
    // 業種名チェック
    NSString* category = entryData[kCR_ITEM_CATEGORY];
    if ((0 == category.length)
        || ([self isCategory:category])) {
        
        [ret addObject:[NSString stringWithFormat:@"%@ %@", NSLocalizedString(@"RES_20001", @"入力項目"), NSLocalizedString(@"MSG_12000", @"必須")]];
    }
    
    // 部署名チェック
    NSString* department = entryData[kCR_ITEM_DEPARTMENT];
    if ((0 == department.length)
        || (kSC_MAXLEN_ENTRY < department.length)) {
        
        [ret addObject:[NSString stringWithFormat:@"%@ %@", NSLocalizedString(@"RES_20002", @"入力項目"), NSLocalizedString(@"MSG_12000", @"必須")]];
    }

    // 電話番号チェック
    NSString* tel = entryData[kCR_ITEM_TEL];
    if ((0 == tel.length)
        || (kSC_MAXLEN_TEL < tel.length)) {
        
        [ret addObject:[NSString stringWithFormat:@"%@ %@", NSLocalizedString(@"RES_20003", @"入力項目"), NSLocalizedString(@"MSG_12000", @"必須")]];
    } else {
        
        if ([self isTel:tel]) {
            
            // 入力文字種
            [ret addObject:[NSString stringWithFormat:@"%@ %@", NSLocalizedString(@"RES_20003", @"入力項目"), NSLocalizedString(@"MSG_12000", @"文字種")]];
        }
    }

    // E-Mailチェック
    NSString* email = entryData[kCR_ITEM_EMAIL];
    if (kSC_MAXLEN_ENTRY < email.length) {
        
        [ret addObject:[NSString stringWithFormat:@"%@", NSLocalizedString(@"MSG_12001", @"入力チェック")]];
        return [NSArray arrayWithArray:ret];
    }
    if (0 != email.length) {
        
        // @入力異常
        NSArray *split = [email componentsSeparatedByString:@"@"];
        if (2 != split.count) {
            
            [ret addObject:[NSString stringWithFormat:@"%@", NSLocalizedString(@"MSG_12001", @"入力チェック")]];
            return [NSArray arrayWithArray:ret];
        }
        
        // @が先頭または終端
        if (([email hasPrefix:@"@"])
            || ([email hasSuffix:@"@"])) {
            
            [ret addObject:[NSString stringWithFormat:@"%@", NSLocalizedString(@"MSG_12001", @"入力チェック")]];
            return [NSArray arrayWithArray:ret];
        }
    }

    return [NSArray arrayWithArray:ret];
}

/**
 国名コードをサーバ通信データに変換
 
 @param value <#value description#>
 @return <#return value description#>
 */
- (NSString*)getCountryCode:(NSString *)value {
    
    NSString *ret = 0;
    
    for (NSDictionary *dicCountryCode in self.listCountryCode) {
        
        NSString *countryTitle = dicCountryCode[KCR_COUNTRY_NAME];
        if ([countryTitle isEqualToString:value]) {
            
            ret = dicCountryCode[KCR_COUNTRY_CODE];
            break;
        }
    }
    
    return ret;
}

/**
 業種名をサーバ通信データに変換（１〜）
 
 @param value <#value description#>
 
 @return <#return value description#>
 */
- (int)getCategoryCode:(NSString *)value {
    
    int ret = 0;
    
    for (NSDictionary *dicCategoryCode in self.listCategoryCode) {
        
        NSString *categoryTitle = dicCategoryCode[kCR_CATEGORY_NAME];
        if ([categoryTitle isEqualToString:value]) {
            
            ret = [dicCategoryCode[kCR_CATEGORY_NO] intValue];
            break;
        }
    }
    
    return ret;
}

/**
  国名の選択判定

 @param value <#value description#>
 
 @return YES:入力項目にNGあり / NO:入力項目はOK
 */
- (BOOL)isCountry:(NSString *)value {
    
    BOOL ret = YES;
    
    for (NSString *countryTitle in self.listCountryPicker) {
        
        if ([countryTitle isEqualToString:value]) {
            
            ret = NO;
            break;
        }
    }
    
    return ret;
}


/**
 業種の選択判定

 @param value <#value description#>

 @return YES:入力項目にNGあり / NO:入力項目はOK
 */
- (BOOL)isCategory:(NSString *)value {
    
    BOOL ret = YES;
    
    for (NSString *categoryTitle in self.listCategoryPicker) {
        
        if ([categoryTitle isEqualToString:value]) {
            
            ret = NO;
            break;
        }
    }
    
    return ret;
}

/**
 電話番号の入力チェク

 @param value <#value description#>

 @return YES:入力項目にNGあり / NO:入力項目はOK
 */
- (BOOL)isTel:(NSString *)value {
    
    BOOL ret = YES;
    
    NSCharacterSet *checkTel = [NSCharacterSet characterSetWithCharactersInString:value];
    NSCharacterSet *isTelFormat = [NSCharacterSet characterSetWithCharactersInString:@"0123456789+-()"];
    if ([isTelFormat isSupersetOfSet:checkTel]) {
        
        ret = NO;
    }
    
    return ret;
}

@end
