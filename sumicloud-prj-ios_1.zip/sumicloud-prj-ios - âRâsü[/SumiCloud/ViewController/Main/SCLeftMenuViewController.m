//
//  SCLeftMenuViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCLeftMenuViewController.h"
#import "SCLeftMenuTableViewCell.h"
#import "SCLogUtil.h"
#import "Constants.h"

#import "SCSystemData.h"
#import "SCFirmwareUpdateFlow.h"
#import <ZipArchive/ZipArchive.h>

#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

#import "SCSpliceDataViewController.h"
#import "SCScreenCaptureViewController.h"
#import "SCHelpVideoMenuViewController.h"
#import "SCReportViewController.h"
#import "SCAutoDiagnosis72mViewController.h"
#import "DbAccessControllDao.h"
#import "ChangePasswordViewController.h"


@interface SCLeftMenuViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic) NSMutableArray* listFunctionMenu;

@property (weak, nonatomic) IBOutlet UIView *vwHeading;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;
@property (weak, nonatomic) IBOutlet UIImageView *imgvwOnlineState;
@property (weak, nonatomic) IBOutlet UILabel *lblOnlineState;
@property (weak, nonatomic) IBOutlet UILabel *lblAccount;


@property (nonatomic) NSString * account;
@property (nonatomic) NSString * role;

@property (nonatomic) DbAccessControllDao * dbController;

@end

@implementation SCLeftMenuViewController

static NSString* const kLM_Title = @"Title";     // メニュータイトル
static NSString* const kLM_SegueId = @"SegueId"; // 画面遷移ID

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.vwHeading.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"image_leftmenu_bg"]];
    
    // 画面表示データの更新
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    [self refreshOnlineSerialNo];

    // 機能メニュー
    self.listFunctionMenu = [NSMutableArray arrayWithCapacity:0];
    [self.listFunctionMenu addObject:@{
                                       // "融着機切替え"
                                       kLM_Title : @"TITLE_SELECT_SPLICER",
                                       kLM_SegueId : @"toSplicerList"
                                       }];
//#if defined(DEBUG) || defined(DEMO) // DEBUG版、DEBUG_DEMO版、RELEASE_DEMO版
    [self.listFunctionMenu addObject:@{
                                       // "ファームウェアの更新"
                                       kLM_Title : @"TITLE_FIRMWARE_UPDATE",
                                       kLM_SegueId : @"toFirmwareUpdate"
                                       }];
//#else
//    if (![SCSystemData isModelType72C:self.lblSerialNo.text] && ![SCSystemData isModelTypeZ2C:self.appData.selectedSerialNo]) {
//        
//        [self.listFunctionMenu addObject:@{
//                                           // "ファームウェアの更新"
//                                           kLM_Title : @"TITLE_FIRMWARE_UPDATE",
//                                           kLM_SegueId : @"toFirmwareUpdate"
//                                           }];
//    }
//#endif
//#if defined(DEBUG) || defined(DEMO) // DEBUG版、DEBUG_DEMO版、RELEASE_DEMO版
    
    [self.listFunctionMenu addObject:@{
                                       // "自動診断"
                                       kLM_Title : @"TITLE_AUTO_DIAGNOSIS",
                                       kLM_SegueId : @"toAutoDiagnosis"
                                       }];
//#endif
    [self.listFunctionMenu addObject:@{
                                       // "設定"
                                       kLM_Title : @"TITLE_SETTING",
                                       kLM_SegueId : @"toSettings"
                                       }];
    [self.listFunctionMenu addObject:@{
                                       // "このアプリについて"
                                       kLM_Title : @"TITLE_ABOUT",
                                       kLM_SegueId : @"toAbout"
                                       }];
    [self.listFunctionMenu addObject:@{
                                       // "フィードバックを送信"
                                       kLM_Title : @"TITLE_FEEDBACK",
                                       kLM_SegueId : @"toFeedback"
                                       }];
    
    self.dbController = [[DbAccessControllDao alloc] init];
    self.role = [self.dbController getAccountRole:[[NSUserDefaults standardUserDefaults] stringForKey:PRE_ACCOUNT]];
    self.account = [[NSUserDefaults standardUserDefaults] stringForKey:PRE_ACCOUNT];
    if([self.role isEqualToString:@"1"]){
        self.lblAccount.text = [NSString stringWithFormat:@"%@%@   \t",
                                 NSLocalizedString(@"nav_header_admin", @""), self.account];
    }else{
        self.lblAccount.text = [NSString stringWithFormat:@"%@%@   \t",
                                 NSLocalizedString(@"nav_header_user", @""), self.account];
    }
    if ([self.role isEqualToString:@"0"]) {
        [self.listFunctionMenu addObject:@{
                                           // "パスワード変更"
                                           kLM_Title : @"TITLE_CHANGEPW",
                                           kLM_SegueId : @"toChangePW"
                                           }];
    }
    
    [self.listFunctionMenu addObject:@{
                                       // "ログアウト"
                                       kLM_Title : @"TITLE_LOGOUT",
                                       kLM_SegueId : @"logout"
                                       }];
    
    // 画面を閉じるトリガーをOKボタンから、左スワイプに変更
    UISwipeGestureRecognizer* leftSwipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(viewLeftSwipeGestureAction:)];
    leftSwipeGesture.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:leftSwipeGesture];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Action

/**
 左スワイプ
 
 @param sender <#sender description#>
 */
- (void)viewLeftSwipeGestureAction:(UISwipeGestureRecognizer *)sender {
    
    DDLogInfo(@"左スワイプ -> 左メニュー画面を閉じる");
    
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}


#pragma mark - UITableViewDelegate

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param section   <#section description#>
 
 @return <#return value description#>
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.listFunctionMenu.count;
}

/**
 TableView初期化
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 
 @return <#return value description#>
 */
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SCLeftMenuTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    NSDictionary* dic = [self.listFunctionMenu objectAtIndex:indexPath.row];
    cell.lblTitle.text = NSLocalizedString(dic[kLM_Title], @"ラベル");
    cell.lblTitle.enabled = YES;
    
    // "ファームウェアの更新" メニューの非活性判定
    if ([@"TITLE_FIRMWARE_UPDATE" isEqualToString:dic[kLM_Title]]) {
        
        cell.lblTitle.enabled = NO;

        // ファームウェアの最新バージョン有無判定
        if (![NSLocalizedString(@"NO_SERIAL", @"---") isEqualToString:self.lblSerialNo.text]) {
//            
//            // ファームウェア更新実施可否判定
//            BOOL isFirmwareUpdate = [SCFirmwareUpdateFlow isFirmwareUpdate:self.lblSerialNo.text];
//            if (isFirmwareUpdate) {
//                
                cell.lblTitle.enabled = YES;
//            }
        }
    }
    
    // "自動診断" メニューの非活性判定
    if ([@"TITLE_AUTO_DIAGNOSIS" isEqualToString:dic[kLM_Title]]) {

        if ([NSLocalizedString(@"NO_SERIAL", @"---") isEqualToString:self.lblSerialNo.text]) {
            
            cell.lblTitle.enabled = NO;
        }
    }
    return cell;
}

/**
 メニュー選択
 
 @param tableView <#tableView description#>
 @param indexPath <#indexPath description#>
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary* dic = [self.listFunctionMenu objectAtIndex:indexPath.row];
    NSString * title = dic[kLM_Title];
    SCLeftMenuTableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
    if (cell.lblTitle.enabled) {

        // 活性のメニューの場合、画面遷移する
        UIViewController* vwCon = self.preVC.parentViewController;
        [self dismissViewControllerAnimated:true completion:^{
            
            NSDictionary* dic = [self.listFunctionMenu objectAtIndex:indexPath.row];
            if ([@"TITLE_FEEDBACK" isEqualToString:dic[kLM_Title]]) {
                [self sendFeedback:vwCon];
            } else if([SCSystemData isModelType72M:self.appData.selectedSerialNo] &&
                      [@"TITLE_AUTO_DIAGNOSIS" isEqualToString:dic[kLM_Title]]) {
                //マスク対象機種
                if ([[self.appData.selectedSerialNo substringToIndex:2] isEqualToString:@"41"] ||
                    [[self.appData.selectedSerialNo substringToIndex:2] isEqualToString:@"50"] ||
                    [[self.appData.selectedSerialNo substringToIndex:2] isEqualToString:@"51"] ||
                    [[self.appData.selectedSerialNo substringToIndex:2] isEqualToString:@"54"] ||
                    [[self.appData.selectedSerialNo substringToIndex:2] isEqualToString:@"57"]) {
        
                    [vwCon performSegueWithIdentifier:@"toAutoDiagnosis72m" sender:vwCon];
                    DDLogDebug(@"画面遷移 -->> toAutoDiagnosis72m");
                } else {
                    NSString *msg = NSLocalizedString(@"MSG_10065", @"確認メッセージ");
                        
                    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                            
                    }]];
                    [vwCon presentViewController:alert animated:true completion:nil];
                }
            } else if (([SCSystemData isModelType72C:self.appData.selectedSerialNo] ||
                       [SCSystemData isModelTypeZ2C:self.appData.selectedSerialNo]) &&
                       [@"TITLE_AUTO_DIAGNOSIS" isEqualToString:dic[kLM_Title]]) {
                [vwCon performSegueWithIdentifier:@"toAutoDiagnosis72c" sender:vwCon];
                DDLogDebug(@"画面遷移 -->> toAutoDiagnosis72c");
            } else if ([SCSystemData isModelTypeT502:self.appData.selectedSerialNo] &&
                       [@"TITLE_AUTO_DIAGNOSIS" isEqualToString:dic[kLM_Title]]) {
                [vwCon performSegueWithIdentifier:@"toAutoDiagnosisT502" sender:vwCon];
                DDLogDebug(@"画面遷移 -->> toAutoDiagnosisT502");
            } else if ([@"TITLE_LOGOUT" isEqualToString:dic[kLM_Title]]) {
                
                NSString *msg = NSLocalizedString(@"adlg_logout_message", @"確認メッセージ");
                    
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"adlg_negative", @"Cancel") style:UIAlertActionStyleCancel handler:nil]];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self.preVC.navigationController popViewControllerAnimated:true];
                }]];
                [vwCon presentViewController:alert animated:true completion:nil];
                
            } else if ([@"TITLE_CHANGEPW" isEqualToString:dic[kLM_Title]]) {
                ChangePasswordViewController* changePWVC = [[UIStoryboard storyboardWithName:@"ChangePW" bundle:nil] instantiateInitialViewController];
                [self.preVC showViewController:changePWVC sender:nil];
            } else {
                [vwCon performSegueWithIdentifier:dic[kLM_SegueId] sender:vwCon];
                
                DDLogDebug(@"画面遷移 -->> %@", dic[kLM_SegueId]);
            }

        }];
    }
}


#pragma mark - Override Method

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    // 融着接続機の状態
    switch (self.appData.spliceStete) {
        case kSCS_OnlineUnlock:
            // オンライン ロックなし
            self.imgvwConnection.image = [UIImage imageNamed:@"image_leftmenu_connection-on"];
            
            self.imgvwOnlineState.image = [UIImage imageNamed:@"icon_online"];
            self.lblOnlineState.text = NSLocalizedString(@"ONLINE", @"オンライン");
            break;
        case kSCS_Onlinelock:
            // オンライン ロックあり
            self.imgvwConnection.image = [UIImage imageNamed:@"image_leftmenu_connection-on_keyon"];
            
            self.imgvwOnlineState.image = [UIImage imageNamed:@"icon_online"];
            self.lblOnlineState.text = NSLocalizedString(@"ONLINE", @"オンライン");
            break;
        case kSCS_Offlinelock:
            // オフライン ロックあり
            self.imgvwConnection.image = [UIImage imageNamed:@"image_leftmenu_connection-off_keyon"];
            
            self.imgvwOnlineState.image = [UIImage imageNamed:@"icon_offline"];
            self.lblOnlineState.text = NSLocalizedString(@"OFFLINE", @"オフライン");
            break;
        default:
            // オフライン ロックなし
            self.imgvwConnection.image = [UIImage imageNamed:@"image_leftmenu_connection-off"];
            
            self.imgvwOnlineState.image = [UIImage imageNamed:@"icon_offline"];
            self.lblOnlineState.text = NSLocalizedString(@"OFFLINE", @"オフライン");
            break;
    }
    
    [self refreshLockState];
}

-(void)refreshLockState{
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString* state = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"%@_lockState", self.appData.selectedSerialNo]];
        if ([self.appData.selectedSerialNo isEqualToString:@"---"]) {return;}
        if (self.appData.spliceStete == kSCS_OnlineUnlock || self.appData.spliceStete == kSCS_Onlinelock) {
            if ([state isEqualToString:@"Locked"]) {
                self.imgvwConnection.image = [UIImage imageNamed:@"image_leftmenu_connection-on_keyon"];
            } else {
                self.imgvwConnection.image = [UIImage imageNamed:@"image_leftmenu_connection-on"];
            }
        } else {
            if ([state isEqualToString:@"Locked"]) {
                self.imgvwConnection.image = [UIImage imageNamed:@"image_leftmenu_connection-off_keyon"];
            } else {
                self.imgvwConnection.image = [UIImage imageNamed:@"image_leftmenu_connection-off"];
            }
        }
    });
}


#pragma mark - private Method


/**
  フィードバックを送信

 @param vwCon <#vwCon description#>
 */
- (void) sendFeedback:(UIViewController *)vwCon{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        // ログファイルアップロードの確認
        UIAlertController* confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", nil)  message:NSLocalizedString(@"MSG_13012", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
        
        [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"キャンセル") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        }]];

        [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            
            // メール設定確認
            if (![MFMailComposeViewController canSendMail]) {
                
                DDLogError(@"メール設定異常");
                
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", nil) message:NSLocalizedString(@"MSG_10018", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
                
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                }]];
                
                [vwCon presentViewController:alert animated:YES completion:nil];
                
                return;
            }
            
            
            DDLogDebug(@"ログファイルフィードバック");
            NSString* zipFileName = [[NSString alloc] initWithFormat:@"logs.zip"];
            NSString* zipFile = [NSTemporaryDirectory() stringByAppendingPathComponent:zipFileName];
            // ファイルアップロード
            ZipArchive *zip = [[ZipArchive alloc] init];
            [zip CreateZipFile2:zipFile Password:@"04585372220458527922"];
            
            NSString *logPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Logs/"];
            NSArray *aryLogFile = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:logPath error:nil];
            for (NSString *fileName in aryLogFile) {
                
                NSString *logFileName = [logPath stringByAppendingPathComponent:fileName];
                [zip addDataToZip:[NSData dataWithContentsOfFile:logFileName] fileAttributes:nil newname:fileName];
            }
            
            [zip CloseZipFile2];
            
            //  フィードバックファイル作成
            NSData* fendbackData = [NSData dataWithContentsOfFile:zipFile];
            DDLogDebug(@"ログファイルフィードバック >> <<%@>>", zipFile);
            
            // メーラー起動
            MFMailComposeViewController *vwConMail = [[MFMailComposeViewController alloc] init];
            vwConMail.mailComposeDelegate = (id)vwCon;
            [vwConMail setToRecipients:[NSArray arrayWithObject:@"sumifi@info.sei.co.jp"]];
            [vwConMail setSubject:NSLocalizedString(@"TITLE_FEEDBACK", @"サブジェクト")];
            [vwConMail addAttachmentData:fendbackData mimeType:@"application/octet-stream" fileName:[zipFile lastPathComponent]];
            
            [vwCon presentViewController:vwConMail animated:YES completion:nil];
            // フィードバックファイル削除
            [[NSFileManager defaultManager] removeItemAtPath:zipFile error:nil];
        }]];
        

        [vwCon presentViewController:confirm animated:YES completion:^{
        }];
    });
    
}




@end
