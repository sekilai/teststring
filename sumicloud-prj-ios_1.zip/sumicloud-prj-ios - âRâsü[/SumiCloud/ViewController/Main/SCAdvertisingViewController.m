//
//  SCAdvertisingViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCAdvertisingViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCAdvertisementFlow.h"
#import <WebKit/WebKit.h>

@interface SCAdvertisingViewController () <WKNavigationDelegate>

@property (nonatomic) SCAdvertisementFlow* flow;

@property (nonatomic) UIViewController *presentingController;
@property (nonatomic,strong) WKWebView *vwWebContents;
@property (weak, nonatomic) IBOutlet UIView *wkWebViewContents;
@property (weak, nonatomic) IBOutlet UIButton *btnOK;

- (IBAction)btnOKTouchUpInside:(UIButton *)sender;

@end

@implementation SCAdvertisingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"広告画面");
    
    WKWebViewConfiguration *wkWebConfig = [[WKWebViewConfiguration alloc] init];

    self.vwWebContents = [[WKWebView alloc] initWithFrame:CGRectMake(0, 0, self.wkWebViewContents.bounds.size.width*0.9, self.wkWebViewContents.bounds.size.height*0.9) configuration:wkWebConfig];
    self.vwWebContents.navigationDelegate = self;
    [self.wkWebViewContents addSubview:self.vwWebContents];
    // 色味の設定
    [self.btnOK setTitleColor:[SCSystemData colorWithRGB:0x13 green:0x9C blue:0xD6 alpha:1.0f] forState:UIControlStateNormal];

    // 多言語対応
    [self.btnOK setTitle:NSLocalizedString(@"BTN_OK", @"OK") forState:UIControlStateNormal];

    self.flow = [[SCAdvertisementFlow alloc] init];
    
    // ローカル広告の表示
    [self.flow loadLocalContents:self.vwWebContents];

    dispatch_async(dispatch_get_main_queue(), ^{

        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;

        // Wi-Fi接続確認
        if ([self isMobileConnect]) {

            // リモート広告の表示
            [self.flow loadGlobalContents:self.vwWebContents];
        }
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    self.presentingController = self.presentingViewController;
    // 色味の設定
    [self.btnOK setBackgroundImage:[self setButtonHilightBackColor:self.btnOK.bounds] forState:UIControlStateHighlighted];
}
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
//    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"InstructionCheck"]){
//        [self.presentingController performSegueWithIdentifier:@"toInstruction" sender:self.presentingController];
//    }
}

#pragma mark - Button Action

/**
 OKボタン

 @param sender <#sender description#>
 */
- (IBAction)btnOKTouchUpInside:(UIButton *)sender {
    
    DDLogInfo(@"OKボタン -> 広告画面を閉じる");
    [self dismissViewControllerAnimated:YES completion:^{
        [self.delegate advertiseViewClose];
    }];
}


#pragma mark - UIWebViewDelegate

/**
 広告のリンクをクリック
 */

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    if (navigationAction.navigationType == WKNavigationTypeLinkActivated) {
        NSURLRequest *request = navigationAction.request;
           // ローカル広告の表示している時は、画面を閉じる
           if (self.flow.isLocalContents) {

               dispatch_async(dispatch_get_main_queue(), ^{
                   [self dismissViewControllerAnimated:YES completion:^{
                    }];
               });
           } else {
               
               // Wi-Fi接続確認
               if ([self isMobileConnect]) {
                   
                   // 画面遷移あり（URLスキーム起動）
                   [self.flow transferAdvertisement:[request URL]];
                   decisionHandler(WKNavigationActionPolicyCancel);
                   return;
               } else {
                   
                   // 画面遷移なし
                   [self connectSplicerAlert];
                   decisionHandler(WKNavigationActionPolicyCancel);
                   return;
               }
           }
       }
       decisionHandler(WKNavigationActionPolicyAllow);
}

/**
 Webページ表示完了

 @param webView <#webView description#>
 */
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    DDLogDebug(@"Webページ表示完了");

    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

@end
