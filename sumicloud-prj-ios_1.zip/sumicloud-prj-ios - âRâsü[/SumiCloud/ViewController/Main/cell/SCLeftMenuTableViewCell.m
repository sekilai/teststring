//
//  SCLeftMenuTableViewCell.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/28.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCLeftMenuTableViewCell.h"

#import "SCSystemData.h"

@implementation SCLeftMenuTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    if (selected) {
        
        self.backgroundColor = [SCSystemData colorWithRGB:0xEC green:0xEE blue:0xF0 alpha:1.0f];
    } else {
        
        self.backgroundColor = [UIColor clearColor];
    }
}

@end
