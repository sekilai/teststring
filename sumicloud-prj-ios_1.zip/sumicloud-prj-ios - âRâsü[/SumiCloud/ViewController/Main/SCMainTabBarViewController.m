//
//  SCMainTabBarViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCMainTabBarViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCApplicationData.h"
#import "SCOverlayController.h"
#import "SCOverlayControllerAnimatedTransitioning.h"
#import "SCAdvertisingViewController.h"

#import "SCReportFlow.h"

#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

@interface SCMainTabBarViewController () <UITabBarControllerDelegate, UIViewControllerTransitioningDelegate,MFMailComposeViewControllerDelegate,AdvertiseDelegate>

@end

@implementation SCMainTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    self.delegate = self;
    
    // 色味の設定
    [UITabBar appearance].barTintColor = [SCSystemData colorWithRGB:0xF4 green:0xF4 blue:0xF4 alpha:1.0f];
    NSDictionary* dicFontNormal = @{
                                    NSFontAttributeName : [UIFont boldSystemFontOfSize:10.0f],
                                    NSForegroundColorAttributeName : [SCSystemData colorWithRGB:0x00 green:0x26 blue:0x60 alpha:1.0f]
                                    };
    [[UITabBarItem appearance] setTitleTextAttributes:dicFontNormal forState:UIControlStateNormal];
    
    // 使用期限の確認
    if ([SCSystemData isPassedExpirationDate]) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_10059", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            
            [self presentViewController:alert animated:YES completion:nil];
        });
    } else {

        // 広告画面表示判定
        if ([SCSystemData isTodayAdvertising]) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [self performSegueWithIdentifier:@"toAdvertising" sender:self];
            });
        }else{
            if(![[NSUserDefaults standardUserDefaults] boolForKey:@"InstructionCheck"]){
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [self performSegueWithIdentifier:@"toInstruction" sender:self];
                });
            }
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 <#Description#>
 
 @param animated <#animated description#>
 */
- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    DDLogDebug(@"");
    
    UITabBarItem* tabBarItem;
    tabBarItem = self.tabBar.items[0];
    tabBarItem.tag = 0;
    tabBarItem.title = NSLocalizedString(@"TITLE_TOP", @"TOP");
    tabBarItem.image = [UIImage imageNamed:@"btn_bottom_top"];
    tabBarItem.selectedImage = [UIImage imageNamed:@"btn_bottom_top_selected"];
    
    tabBarItem = self.tabBar.items[1];
    tabBarItem.tag = 1;
    tabBarItem.title = NSLocalizedString(@"TITLE_CAPTURE", @"キャプチャ");
    tabBarItem.image = [UIImage imageNamed:@"btn_bottom_capture"];
    tabBarItem.selectedImage = [UIImage imageNamed:@"btn_bottom_capture_selected"];
    
    tabBarItem = self.tabBar.items[2];
    tabBarItem.tag = 2;
    tabBarItem.title = NSLocalizedString(@"TITLE_HELP", @"ヘルプ");
    tabBarItem.image = [UIImage imageNamed:@"btn_bottom_help"];
    tabBarItem.selectedImage = [UIImage imageNamed:@"btn_bottom_help_selected"];
}


#pragma mark - Segue

/**
 画面遷移
 
 @param segue  <#segue description#>
 @param sender <#sender description#>
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    DDLogDebug(@"%@", segue.identifier);
    
    if ([@"toAdvertising" isEqualToString:segue.identifier]) {
        
        segue.destinationViewController.modalPresentationStyle = UIModalPresentationCustom;
        segue.destinationViewController.transitioningDelegate = self;
        SCAdvertisingViewController* advc = segue.destinationViewController;
        advc.delegate = self;
    }
}


#pragma mark - UITabBarControllerDelegate

/**
 タブ切り替え判定

 @param tabBarController <#tabBarController description#>
 @param viewController <#viewController description#>
 @return <#return value description#>
 */
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController {

    BOOL ret = YES;
    
    if ([viewController isKindOfClass:[UINavigationController class]]) {
        
        if (3 == tabBarController.selectedIndex) {
            
            // レポート機能の画面表示中にボトムバーをタップした
            SCApplicationData* appData = [SCApplicationData sharedInstance];
            if (appData.manReport) {
                
                // レポート作成中
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_11004", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
                
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    
                    self.selectedIndex = viewController.tabBarItem.tag;
                    
                    UINavigationController* naviCon = (UINavigationController *)viewController;
                    [naviCon popToRootViewControllerAnimated:NO];
                    
                    // 作成中のユーザ定義設定をクリアする
                    [SCReportFlow setSelectUserDefineList:appData.manReport.defaultUserDefineList];
                    [SCReportFlow endEditingSelectUserDefine:YES];

                    // 作成中のレポート情報をクリアする
                    [SCReportFlow endEditingSelectSpliceData:NO];

                    appData.manReport = nil;
                }]];
                
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"CANCEL") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                }]];
                
                [self presentViewController:alert animated:YES completion:^{
                }];
                
                ret = NO;
            } else {
                
                // レポート画面表示中
                if (tabBarController.selectedIndex != viewController.tabBarItem.tag) {
                    
                    UINavigationController* naviCon = (UINavigationController *)viewController;
                    [naviCon popToRootViewControllerAnimated:NO];
                }
            }
        } else if (0 == tabBarController.selectedIndex) {
            
            // TOP画面選択中にボトムバーをタップした
            SCApplicationData* appData = [SCApplicationData sharedInstance];
            if (appData.manReport) {
                
                // 「今日のレポート」
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:NSLocalizedString(@"MSG_11004", @"確認メッセージ") preferredStyle:UIAlertControllerStyleAlert];
                
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    
                    self.selectedIndex = viewController.tabBarItem.tag;
                    
                    UINavigationController* naviCon = (UINavigationController *)viewController;
                    [naviCon popToRootViewControllerAnimated:NO];
                    
                    // 作成中のユーザ定義設定をクリアする
                    [SCReportFlow setSelectUserDefineList:appData.manReport.defaultUserDefineList];
                    [SCReportFlow endEditingSelectUserDefine:YES];
                    
                    // 作成中のレポート情報をクリアする
                    [SCReportFlow endEditingSelectSpliceData:NO];
                    
                    appData.manReport = nil;
                }]];
                
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_CANCEL", @"CANCEL") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                }]];
                
                [self presentViewController:alert animated:YES completion:^{
                }];
                
                ret = NO;
            } else {
                
                // レポート機能以外の画面表示中にボトムバーをタップした
                if (tabBarController.selectedIndex != viewController.tabBarItem.tag) {
                    
                    UINavigationController* naviCon = (UINavigationController *)viewController;
                    [naviCon popToRootViewControllerAnimated:NO];
                }
            }
        } else {

            // レポート機能以外の画面表示中にボトムバーをタップした
            if (tabBarController.selectedIndex != viewController.tabBarItem.tag) {
                
                UINavigationController* naviCon = (UINavigationController *)viewController;
                [naviCon popToRootViewControllerAnimated:NO];
            }
        }
    }

    return ret;
}


#pragma mark - UIViewControllerTransitioningDelegate

/**
 Overlay表示
 
 @param presented  <#presented description#>
 @param presenting <#presenting description#>
 @param source     <#source description#>
 
 @return <#return value description#>
 */
- (UIPresentationController *)presentationControllerForPresentedViewController:(UIViewController *)presented presentingViewController:(UIViewController *)presenting sourceViewController:(UIViewController *)source {
    
    DDLogDebug(@"");
    
    SCOverlayController* overlay = [[SCOverlayController alloc] initWithPresentedViewController:presented presentingViewController:presenting];
    
    // デバイスサイズの90%
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    overlay.overlaySize = CGSizeMake(floorf(screenSize.width * 90.0f / 100.0f), floorf(screenSize.height * 90.0f / 100.0f));
    
    // 画面の中央
    overlay.overlayHorizontally = kOLH_Center;
    overlay.overlayVertically = kOLV_Center;
    
    return overlay;
}


/**
 Overlay表示
 
 @param presented  <#presented description#>
 @param presenting <#presenting description#>
 @param source     <#source description#>
 
 @return <#return value description#>
 */
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    
    DDLogDebug(@"");
    
    SCOverlayControllerAnimatedTransitioning* animation = [[SCOverlayControllerAnimatedTransitioning alloc] initWithPresent:YES];
    
    // アニメーション方向（アニメーションなし）
    animation.overlayAnimationDirection = kOLAD_None;
    
    return animation;
}

/**
 Overlay非表示
 
 @param dismissed <#dismissed description#>
 
 @return <#return value description#>
 */
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    
    DDLogDebug(@"");
    
    SCOverlayControllerAnimatedTransitioning* animation = [[SCOverlayControllerAnimatedTransitioning alloc] initWithPresent:NO];
    
    // アニメーション方向（アニメーションなし）
    animation.overlayAnimationDirection = kOLAD_None;
    
    return animation;
}


#pragma mark - MFMailComposeViewControllerDelegate

/**
 メール送信後アクション
 
 @param controller <#controller description#>
 @param result <#result description#>
 @param error <#error description#>
 */
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    
    switch (result) {
        case MFMailComposeResultSaved:
        case MFMailComposeResultSent:
            DDLogDebug(@"メール送信操作（保存）または（送信）");
            break;
        case MFMailComposeResultFailed:
            DDLogError(@"メール送信操作（失敗）");
            break;
        case MFMailComposeResultCancelled:
        default:
            DDLogDebug(@"メール送信操作（キャンセル）");
            break;
    }
    
    
    
    [controller dismissViewControllerAnimated:YES completion:^{
    }];
}

#pragma mark - AdvertiseDelegate
-(void)advertiseViewClose{
    [self performSegueWithIdentifier:@"toInstruction" sender:self];
}

@end
