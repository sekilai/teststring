//
//  SCAutoDiagnosisViewController.m
//  SumiCloud
//
//  Created by fsi_mac5d_5 on 2016/10/12.
//  Copyright © 2016年 fsi_mac5d_5. All rights reserved.
//

#import "SCAutoDiagnosisViewController.h"
#import "SCLogUtil.h"

#import "SCSystemData.h"
#import "SCAutoDiagnosisFlow.h"

@interface SCAutoDiagnosisViewController ()

@property (nonatomic) SCAutoDiagnosisFlow* flow;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;

@property (weak, nonatomic) IBOutlet UILabel *lblTitleModel;
@property (weak, nonatomic) IBOutlet UILabel *lblModel;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleSelectedSerialNo;
@property (weak, nonatomic) IBOutlet UILabel *lblSelectedSerialNo;
@property (weak, nonatomic) IBOutlet UILabel *lblMsg;

@property (weak, nonatomic) IBOutlet UIButton *btnOK1;
@property (weak, nonatomic) IBOutlet UIButton *btnOK2;

- (IBAction)actionClose:(UIBarButtonItem *)sender;
- (IBAction)btnOK1TouchUpInside:(UIButton *)sender;
- (IBAction)btnOK2TouchUpInside:(UIButton *)sender;

@end

@implementation SCAutoDiagnosisViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    DDLogDebug(@"");
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_AUTO_DIAGNOSIS", @"自動診断");
    self.lblTitleModel.text = NSLocalizedString(@"RES_20031", @"モデル:");
    self.lblTitleSelectedSerialNo.text = NSLocalizedString(@"RES_20032", @"シリアル番号:");
    [self.btnOK1 setTitle:NSLocalizedString(@"BTN_OK", @"OK") forState:UIControlStateNormal];
    [self.btnOK2 setTitle:NSLocalizedString(@"BTN_OK", @"OK") forState:UIControlStateNormal];
    
    // 画面表示データの更新
    self.isSelectedSplicer = YES;
    if ([self.FlowStep length] == 0) {
        self.btnOK1.hidden = NO;
        self.btnOK2.hidden = YES;
    } else if ([self.FlowStep isEqualToString:@"step2"]) {
        self.btnOK1.hidden = YES;
        self.btnOK2.hidden = NO;
    }
    
    self.lblSelectedSerialNo.text = self.appData.selectedSerialNo;
    self.lblModel.text = [SCSystemData getSpliceModelName:self.lblSelectedSerialNo.text];
    [self refreshSelectedSerialNo];
    [self refreshViewController];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    // 色味の設定（レイアウト確定後）
    [self.btnOK1 setBackgroundImage:[self setButtonHilightBackColor:self.btnOK1.bounds] forState:UIControlStateHighlighted];
    [self.btnOK2 setBackgroundImage:[self setButtonHilightBackColor:self.btnOK2.bounds] forState:UIControlStateHighlighted];
}

- (void)viewDidDisappear:(BOOL)animated {
    
    [super viewDidDisappear:animated];
    
}


#pragma mark - Button Action

/**
 閉じるボタン

 @param sender <#sender description#>
 */
- (IBAction)actionClose:(UIBarButtonItem *)sender {
    
    DDLogInfo(@"閉じるボタン -> 自動診断画面を閉じる");
    
    // 画面を閉じる時は、RESET送信
    if (self.flow
        && ((kBF_AD_SUCCESS != self.flow.resultFlow) &&
            (kBF_LOCK != self.flow.resultFlow) &&
            (kBF_AD_NOT_SUPPORT != self.flow.resultFlow))) {
            
            // 異なる融着機に接続している場合は、送信しない
            if ([self.lblSelectedSerialNo.text isEqualToString:self.lblSerialNo.text]) {
                
                [self.flow resetSplicer];
            }
        }
    
    self.flow = nil;
    
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}

/**
 自動診断１回目ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnOK1TouchUpInside:(UIButton *)sender {

    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }
    
    // Wi-Fi切り替え確認
    if (![self isSplicerConnect:self.lblSerialNo.text]) {
        
        [self connectInternetAlert];
        
        return;
    }
    
    // 異なる融着機に接続
    if (![self.lblSelectedSerialNo.text isEqualToString:self.lblSerialNo.text]) {
        
        DDLogWarn(@"自動診断対象の融着機と異なる");
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知")  message:NSLocalizedString(@"MSG_10033", @"自動診断対象の融着機と異なる") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
        
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }

    DDLogInfo(@"自動診断１回目ボタン");
    
    self.flow = [[SCAutoDiagnosisFlow alloc] init];
    [self autoDiagnosisFirst];
}

/**
 自動診断２回目ボタン

 @param sender <#sender description#>
 */
- (IBAction)btnOK2TouchUpInside:(UIButton *)sender {
    
    // アプリ使用期限の確認
    if ([self isPassedExpirationDateMsg]) {
        
        return;
    }
    
    // Wi-Fi切り替え確認
    if (![self isSplicerConnect:self.lblSerialNo.text]) {
        
        [self connectInternetAlert];
        
        return;
    }
    
    // 異なる融着機に接続
    if (![self.lblSelectedSerialNo.text isEqualToString:self.lblSerialNo.text]) {
        
        DDLogWarn(@"自動診断対象の融着機と異なる");
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知")  message:NSLocalizedString(@"MSG_10033", @"自動診断対象の融着機と異なる") preferredStyle:UIAlertControllerStyleAlert];
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self dismissViewControllerAnimated:true completion:nil];
        }]];
        
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }

    DDLogInfo(@"自動診断２回目ボタン");
    [self autoDiagnosisSecond];
}

#pragma mark - Private Method

/**
 自動診断機能フロー（自動診断１回目）
 */
- (void)autoDiagnosisFirst {
    
    
    [self showProgress:NSLocalizedString(@"RES_20057", @"実行中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        
        [self.flow cancelFlow];
    }];
    
    // ビジネスフロー
    DDLogInfo(@"5.自動診断機能フロー（自動診断１回目）:開始");
    [self.flow runFlowFirst:self.appData.onlineSerialNo completion:^(NSError *error) {
        
        DDLogInfo(@"5.自動診断機能フロー（自動診断１回目）:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideProgress];
            
            // ビジネスフロー結果メッセージ表示
            if (!error && (kBF_OK == self.flow.resultFlow)) {
                
                UIStoryboard * storybd = [UIStoryboard storyboardWithName:@"AutoDiagnosis" bundle:[NSBundle mainBundle]];
                SCAutoDiagnosisViewController * step2VC = (SCAutoDiagnosisViewController *)[storybd instantiateViewControllerWithIdentifier:@"autodiagnosis"];
                step2VC.FlowStep = @"step2";
                step2VC.flow = self.flow;
                [self.navigationController pushViewController:step2VC animated:true];
 
            } else if (!error && (kBF_CANCEL == self.flow.resultFlow)) {
                
                DDLogWarn(@"プログレスのキャンセル操作");

                [self dismissViewControllerAnimated:YES completion:^{
                    [self.flow resetSplicer];
                }];
            } else if (!error && (kBF_NG == self.flow.resultFlow)) {
                
                NSMutableString* msg = [NSMutableString stringWithCapacity:0];
                [msg appendString:NSLocalizedString(@"MSG_13023", @"確認メッセージ")];
                if (self.flow.resultCommand.length) {
                    
                    NSString* errFormat = NSLocalizedString(@"MSG_10054", @"自動診断エラー");
                    [msg appendString:@"\n"];
                    [msg appendFormat:errFormat, [self.flow.resultCommand substringFromIndex:2]];
                }
                
                // コマンドエラーで画面戻る
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    
                    [self dismissViewControllerAnimated:YES completion:^{
                        [self.flow resetSplicer];
                    }];
                }]];
                
                [self presentViewController:alert animated:YES completion:^{
                }];
            } else {
                
                [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                    
                    if (ResultAction_RETRY == actionType) {
                        
                        // 再試行
                        [self autoDiagnosisFirst];
                    } else {
                        
                        if (!error && (kBF_AD_NOT_SUPPORT == self.flow.resultFlow)) {
                            
                            DDLogWarn(@"自動診断サポート対象外");
                            
                            [self dismissViewControllerAnimated:YES completion:^{
                            }];
                        }
                    }
                }];
            }
            
            // 自動診断シーケンス切り替え
            [self refreshViewController];
        });
    }];
}

/**
 自動診断機能フロー（自動診断２回目）
 */
- (void)autoDiagnosisSecond {
    
    [self showProgress:NSLocalizedString(@"RES_20057", @"実行中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        
        [self.flow cancelFlow];
    }];
    
    // ビジネスフロー
    DDLogInfo(@"5.自動診断機能フロー（自動診断２回目）:開始");
    [self.flow runFlowSecond:self.appData.onlineSerialNo completion:^(NSError *error) {
        
        DDLogInfo(@"5.自動診断機能フロー（自動診断２回目）:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideProgress];
            
            if (!error && (kBF_NG == self.flow.resultFlow)) {
                
                NSMutableString* msg = [NSMutableString stringWithCapacity:0];
                [msg appendString:NSLocalizedString(@"MSG_13024", @"確認メッセージ")];
                if (self.flow.resultCommand.length) {
                    NSString* errFormat = NSLocalizedString(@"MSG_10054", @"自動診断エラー");
                    [msg appendString:@"\n"];
                    [msg appendFormat:errFormat, [self.flow.resultCommand substringFromIndex:2]];
                }
                
                // コマンドエラーで画面戻る
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    
                    [self dismissViewControllerAnimated:YES completion:^{
                        [self.flow resetSplicer];
                    }];
                }]];
                
                [self presentViewController:alert animated:YES completion:^{
                }];
            } else if (!error && (kBF_CANCEL == self.flow.resultFlow)) {
                // ビジネスフロー結果メッセージ表示
                DDLogWarn(@"プログレスのキャンセル操作");
                // プログレスのキャンセル操作で画面戻る
                [self dismissViewControllerAnimated:YES completion:^{
                    [self.flow resetSplicer];
                }];
            } else if ( !error && (self.flow.resultFlow == kBF_AD_GET_BIN_72C)) {
                
                [self showProgress:NSLocalizedString(@"RES_20058", @"データ取得中...") cancelHandler:^{
                    
                    DDLogDebug(@"プログレスのキャンセル");
                    
                    [self.flow cancelFlow];
                }];
                
                [self.flow getAutoDiag72CFileWithSerialNo:self.appData.onlineSerialNo completion:^(NSError *error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self hideProgress];
                        
                        if (!error && (kBF_CANCEL == self.flow.resultFlow)) {
                            // ビジネスフロー結果メッセージ表示
                            DDLogWarn(@"プログレスのキャンセル操作");
                            // プログレスのキャンセル操作で画面戻る
                            [self dismissViewControllerAnimated:YES completion:^{
                                [self.flow resetSplicer];
                            }];
                        } else if (!error && (kBF_NG == self.flow.resultFlow)) {
                            
                            NSMutableString* msg = [NSMutableString stringWithCapacity:0];
                            [msg appendString:NSLocalizedString(@"MSG_13024", @"確認メッセージ")];
                            if (self.flow.resultCommand.length) {
                                
                                NSString* errFormat = NSLocalizedString(@"MSG_10054", @"自動診断エラー");
                                [msg appendString:@"\n"];
                                [msg appendFormat:errFormat, [self.flow.resultCommand substringFromIndex:2]];
                            }
                            
                            // コマンドエラーで画面戻る
                            UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                            
                            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                                
                                [self dismissViewControllerAnimated:YES completion:^{
                                    [self.flow resetSplicer];
                                }];
                            }]];
                            
                            [self presentViewController:alert animated:YES completion:^{
                            }];
                        } else {
                            NSArray * resultArray = self.flow.resultCheckArray;
                            NSNumber *error_X_Num = [resultArray objectAtIndex:0];
                            NSNumber *error_Y_Num = [resultArray objectAtIndex:1];
                            SCAutoDiagnosisErrorOption errorX = [error_X_Num unsignedIntegerValue];
                            SCAutoDiagnosisErrorOption errorY = [error_Y_Num unsignedIntegerValue];
                            if (errorX != 0 || errorY != 0) {
                                [self messageBFResultAD:self.flow.resultFlow resultCode:resultArray error:error actionHandler:^(SCBFResultAction actionType) {
                                    
                                    if (ResultAction_OK == actionType) {
                                        
                                        if (!error && (kBF_AD_SUCCESS == self.flow.resultFlow)) {
                                            
                                            DDLogInfo(@"自動診断完了");
                                            
                                            [self dismissViewControllerAnimated:YES completion:^{
                                            }];
                                        }
                                    }
                                }];
                            } else {
                                [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                                    
                                    if (ResultAction_OK == actionType) {
                                        
                                        if (!error && (kBF_AD_SUCCESS == self.flow.resultFlow)) {
                                            
                                            DDLogInfo(@"自動診断完了");
                                            
                                            [self dismissViewControllerAnimated:YES completion:^{
                                            }];
                                        }
                                    }
                                }];
                            }
                        }
                        // 自動診断シーケンス切り替え
                        [self refreshViewController];
                    });
                }];
            } else {
                [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                    
                    if (ResultAction_OK == actionType) {
                        
                        if (!error && (kBF_AD_SUCCESS == self.flow.resultFlow)) {
                            
                            DDLogInfo(@"自動診断完了");
                            
                            [self dismissViewControllerAnimated:YES completion:^{
                            }];
                        }
                    }
                }];
            }
        });
    }];
}

/**
 画面表示更新
 */
- (void)refreshViewController {

    if ([self.FlowStep length] == 0) {
        
        // １回目の自動診断メッセージ表示
        self.lblMsg.text = NSLocalizedString(@"MSG_10042", @"１回目");
    } else if ([self.FlowStep isEqualToString:@"step2"]){
        
        // ２回目の自動診断メッセージ表示
        self.lblMsg.text = NSLocalizedString(@"MSG_10043", @"２回目");
    } else if ([self.FlowStep isEqualToString:@"step3"]) {
        self.lblMsg.text = @"72M step3 文言";
    }
}

#pragma mark - Override Method

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    // シリアル番号
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {

    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");

    [super refreshOnlineSerialNo];

    if (![NSLocalizedString(@"NO_SERIAL", @"---") isEqualToString:self.appData.onlineSerialNo]) {

        self.appData.selectedSerialNo = self.appData.onlineSerialNo;
    }
}

/**
 ビジネスフロー処理結果のメッセージ表示
 
 @param result <#result description#>
 @param error <#error description#>
 @param actionHandler <#actionHandler description#>
 */
- (void)messageBFResultAD:(SCBusinessFlowResult)result resultCode:(NSArray *)resultArray error:(NSError *)error actionHandler:(void (^)(SCBFResultAction))actionHandler {
    NSString* msg = @"";
    
    NSNumber *error_X_Num = [resultArray objectAtIndex:0];
    NSNumber *error_Y_Num = [resultArray objectAtIndex:1];
    SCAutoDiagnosisErrorOption errorX = [error_X_Num unsignedIntegerValue];
    SCAutoDiagnosisErrorOption errorY = [error_Y_Num unsignedIntegerValue];
    
    NSMutableString *videoStr = [NSMutableString stringWithCapacity:0];

    if ( (errorX & Led2_Error) || (errorY & Led2_Error) ) {
        // 風防閉まり切れている
        // LED BrightnessのXの[1023]
        // LED BrightnessのYの[1023]
        msg = NSLocalizedString(@"MSG_13017", @"融着機の状態が良くありません。風防が適切に閉まっているか確認してください。もし閉まっている場合には、ヘルプビデオを参照し、以下の融着機の部品を清掃することで状態が改善することがあります。\n%@");
    } else {
        msg = NSLocalizedString(@"MSG_13016", @"融着機の状態が良くありません。ヘルプビデオを参照し、以下の融着機の部品を清掃することで状態が改善することがあります。\n%@");
    }
    BOOL isVideoSet = false;
    if ( (errorX & Led0_Error) || (errorY & Led0_Error) ||
        (errorX & Led2_Error) || (errorY & Led2_Error) ||
        (errorX & PointDiff_Error) || (errorY & PointDiff_Error)) {
        // LED清掃
        // LED BrightnessのX,Yの[0];LED BrightnessのX,Yの[1023];9 Point Brightness X,YのMAX-MIN
        isVideoSet = true;
        [videoStr appendString:NSLocalizedString(@"MSG_13018", @"LED")];
    }

    if ( (errorX & AngleDiff_Error) || (errorY & AngleDiff_Error) ||
        (errorX & LeftFiberCenter_Error) || (errorY & LeftFiberCenter_Error) ||
        (errorX & RightFiberCenter_Error) || (errorY & RightFiberCenter_Error) ) {
        // V溝清掃
        // Fiber Angle X,Yの|L-R|;Origin Position VLRの X,Yの左側右側
        if (isVideoSet) {
            [videoStr appendString:@","];
        } else {
            isVideoSet = true;
        }
        [videoStr appendString:NSLocalizedString(@"MSG_13020", @"V溝")];
    }
    if ((errorX & Led0_Error) || (errorY & Led0_Error) ||
        (errorX & Led2_Error) || (errorY & Led2_Error) ||
        (errorX & PointDiff_Error) || (errorY & PointDiff_Error) ||
        (errorX & LeftBb_Error) || (errorY & LeftBb_Error) ||
        (errorX & RightBb_Error) || (errorY & RightBb_Error)) {
        // レンズ保護ガラス清掃
        // LED BrightnessのX,Yの[0];LED BrightnessのX,Yの[1023];9 Point Brightness X,YのMAX-MIN
        // Image processing B/B LRのX,Yの左側右側
        if (isVideoSet) {
            [videoStr appendString:@","];
        } else {
            isVideoSet = true;
        }
        [videoStr appendString:NSLocalizedString(@"MSG_13019", @"レンズ保護ガラス")];

    }

    msg = [NSString stringWithFormat:msg,videoStr];

    
    if (msg.length) {
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];

            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
                if (actionHandler) {
                    
                    actionHandler(ResultAction_OK);
                }
            }]];
        
        [self presentViewController:alert animated:YES completion:^{
        }];
    }
}
- (void)messageBFResultAD_72m:(SCBusinessFlowResult)result resultCode:(NSDictionary *)resultDic error:(NSError *)error actionHandler:(void (^)(SCBFResultAction))actionHandler {
    NSMutableString * msg = [[NSMutableString alloc] init];
    for (NSString *checkKey in [resultDic allKeys]) {
        NSString *checkResult = [resultDic objectForKey:checkKey];
        [msg appendFormat:@"%@: %@ \n", checkKey, checkResult];
    }
    if (msg.length) {
        
        UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
        
        
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
            if (actionHandler) {
                
                actionHandler(ResultAction_OK);
            }
        }]];
        
        [self presentViewController:alert animated:YES completion:^{
        }];
    }
}
@end
