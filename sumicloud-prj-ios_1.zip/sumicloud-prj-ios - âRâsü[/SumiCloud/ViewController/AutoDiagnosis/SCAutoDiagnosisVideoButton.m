//
//  SCAutoDiagnosisVideoButton.m
//  SumiCloud
//
//  Created by fsi_mac_6 on 2019/10/15.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCAutoDiagnosisVideoButton.h"

@implementation SCAutoDiagnosisVideoButton


@end
