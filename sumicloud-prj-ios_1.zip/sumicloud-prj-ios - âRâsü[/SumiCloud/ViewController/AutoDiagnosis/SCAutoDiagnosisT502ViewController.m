//
//  SCAutoDiagnosis72CViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-13 on 2020/02/06.
//  Copyright © 2020 fsi_mac5d_5. All rights reserved.
//

#import "SCAutoDiagnosisT502ViewController.h"
#import "SCLogUtil.h"
#import "SCSystemData.h"
#import "SCAutoDiagnosisFlow.h"
#import "SCImageBrowseViewController.h"
#import "SCHelpVideoFlow.h"
#import "SCAutoDiagnosisVideoButton.h"
#import "SCHelpVideoPlayViewController.h"
#import "SCAutoDiagnosis72mGuidanceViewController.h"

@interface SCAutoDiagnosisT502ViewController ()

typedef NS_ENUM(NSInteger, CheckState) {
    AD_Step1,
    AD_Step2,
    AD_Step3
};

@property (nonatomic) SCAutoDiagnosisFlow* flow;
@property (nonatomic) SCHelpVideoFlow * helpVideoFlow;
@property (nonatomic) NSMutableDictionary *helpVideoList;
@property (nonatomic,assign) BOOL isFirstShowGuidence;
@property (nonatomic,assign) BOOL check_step2;
@property (nonatomic,strong) NSArray *guidanceImgList;

@property (weak, nonatomic) IBOutlet UIImageView *imgvwConnection;
@property (weak, nonatomic) IBOutlet UILabel *lblSerialNo;
@property (weak, nonatomic) IBOutlet UILabel *lblTItleModel;
@property (weak, nonatomic) IBOutlet UILabel *lblModel;
@property (weak, nonatomic) IBOutlet UILabel *lblTitleSelectedSerialNo;
@property (weak, nonatomic) IBOutlet UILabel *lblSelectedSerialNo;
@property (weak, nonatomic) IBOutlet UIButton *btnScanStart;

@property (weak, nonatomic) IBOutlet UIImageView *num1_icon;
@property (weak, nonatomic) IBOutlet UIImageView *num2_icon;
@property (weak, nonatomic) IBOutlet UIImageView *num3_icon;

@property (weak, nonatomic) IBOutlet UILabel *step1_lbl;
@property (weak, nonatomic) IBOutlet UILabel *step2_lbl;
@property (weak, nonatomic) IBOutlet UILabel *step3_lbl;

@property (weak, nonatomic) IBOutlet UILabel *step1_checkTime;
@property (weak, nonatomic) IBOutlet UILabel *step2_checkTime;


@property (assign, nonatomic) CheckState flowStep;

@property (weak, nonatomic) IBOutlet UIPageControl *step1_pageControl;
@property (weak, nonatomic) IBOutlet UIScrollView *step1_scrollView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *step1_guide1_leading;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *step1_contentWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *step1_guideViewHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *step2_guide1_leading;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *step2_contentWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *step2_guideViewHeight;
@property (weak, nonatomic) IBOutlet UIScrollView *step2_scrollView;
@property (weak, nonatomic) IBOutlet UIPageControl *step2_pageControl;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *step2_guideTotalHeight;

@property (weak, nonatomic) IBOutlet UILabel *step1_readyLbl;
@property (weak, nonatomic) IBOutlet UILabel *step1_guideLbl_1;
@property (weak, nonatomic) IBOutlet UILabel *step1_guideLbl_2;
@property (weak, nonatomic) IBOutlet UILabel *step1_guideLbl_3;

@property (weak, nonatomic) IBOutlet UILabel *step2_readyLbl;
@property (weak, nonatomic) IBOutlet UILabel *step2_guideLbl_1;
@property (weak, nonatomic) IBOutlet UILabel *step2_guideLbl_2;
@property (weak, nonatomic) IBOutlet UILabel *step2_guideLbl_3;
@property (weak, nonatomic) IBOutlet UILabel *step2_guideLbl_4;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *step3_guideViewHeight;
@property (weak, nonatomic) IBOutlet UILabel *step3_main_title;
@property (weak, nonatomic) IBOutlet UIImageView *step3_result1_icon;
@property (weak, nonatomic) IBOutlet UILabel *step3_result1_title;
@property (weak, nonatomic) IBOutlet UIView *result1_videoView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *result1_videoViewHeight;

@property (weak, nonatomic) IBOutlet UIImageView *step3_result2_icon;
@property (weak, nonatomic) IBOutlet UILabel *step3_result2_title;
@property (weak, nonatomic) IBOutlet UIView *result2_videoView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *result2_videoViewHeight;

@property (weak, nonatomic) IBOutlet UILabel *resultMainTitleLbl;


@end

@implementation SCAutoDiagnosisT502ViewController

static float GuideImageWidth = 260;
static float GuideImageInterval = 10;
static float HelpMovieWidth = 90;
static float HelpMovieHeight = 50;
static float HelpMovieInterval = 10;
static float HelpMovieWidth_SE = 72;
static float HelpMovieHeight_SE = 40;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // 色味の設定
    self.isFirstShowGuidence = true;
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    self.guidanceImgList = [NSArray arrayWithObjects:
                            @"502_simplecheck_img_large_1",
                            @"502_simplecheck_img_large_2",
                            @"502_simplecheck_img_large_3",
                            @"502_detailcheck_img_large_1",
                            @"502_detailcheck_img_large_2",
                            @"502_detailcheck_img_large_3",
                            @"502_detailcheck_img_large_4",nil];
    // 多言語対応
    self.title = NSLocalizedString(@"TITLE_AUTO_DIAGNOSIS", @"自動診断");
    self.lblTItleModel.text = NSLocalizedString(@"RES_20031", @"モデル:");
    self.lblTitleSelectedSerialNo.text = NSLocalizedString(@"RES_20032", @"シリアル番号:");
    self.lblSelectedSerialNo.text = self.appData.selectedSerialNo;
    self.lblModel.text = [SCSystemData getSpliceModelName:self.lblSelectedSerialNo.text];
    [self refreshSelectedSerialNo];
    
    [self initHelpVideos];
    [self initInfoView];
    [self initResource];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (self.isFirstShowGuidence) {
        if ([SCSystemData isAutoDiagGuideNeedDisplayWithType:[SCSystemData getModelType:self.appData.selectedSerialNo]]) {
            [self performSegueWithIdentifier:@"toGuidance" sender:self];
        }
        self.isFirstShowGuidence = false;
    }
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([@"toHelpVideoPlay" isEqualToString:segue.identifier]) {
        SCHelpVideoPlayViewController* vwCon = segue.destinationViewController;
        vwCon.showPreAndNext = false;
    }
    
    if ([segue.identifier isEqualToString:@"toGuidance"]) {
        SCAutoDiagnosis72mGuidanceViewController *des = ((UINavigationController *) segue.destinationViewController).viewControllers[0];
        des.isFromClick = !self.isFirstShowGuidence;
    }
}

#pragma mark - TableViewMethod

-(void)initHelpVideos{
    self.helpVideoList = [[NSMutableDictionary alloc] init];
    self.helpVideoFlow = [[SCHelpVideoFlow alloc] init];
    self.appData.manHelpVideo = [[SCHelpVideoManager alloc] init];
    self.appData.manHelpVideo.selectLanguage = @"";
    
    // 選択可能言語を取得する
    NSArray *langList = [self.helpVideoFlow getSelectableLaunguageList:self.appData.selectedSerialNo];
    // 言語コードを昇順に並び替える
    NSArray *sortList = [SCHelpVideoFlow sortAscending:langList key:kSC_HVL_No];
    
    // デフォルト言語取得
    self.appData.manHelpVideo.defaultLanguage = sortList.firstObject[kSC_HVL_Code];
    // 選択可能言語の取得
    if (self.appData.selectedSerialNo) {
        
        if ([self.appData.manHelpVideo.selectLanguage isEqualToString:@""]) {
            
            self.appData.manHelpVideo.selectLanguage = self.appData.manHelpVideo.defaultLanguage;
        }
        
        // 選択言語のヘルプリストを取得する
        NSArray *list = [self.helpVideoFlow getHelpMoviesInfo:self.appData.selectedSerialNo];
        
        // IDを昇順に並び替える
        NSArray *movieList = [SCHelpVideoFlow sortAscending:list key:@"id_no"];
        
        for (SCHelpMovie *helpMovie in movieList) {
            if ([helpMovie.id_no hasSuffix:@"0402"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"LED_Video"];
            } else if ([helpMovie.id_no hasSuffix:@"0404"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"Microscope_Video"];
            } else if ([helpMovie.id_no hasSuffix:@"0401"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"V_Video"];
            } else if ([helpMovie.id_no hasSuffix:@"0403"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"Clamp_Video"];
            } else if ([helpMovie.id_no hasSuffix:@"0104"]) {
                [self.helpVideoList setObject:helpMovie forKey:@"Fiber_Video"];
            }
        }
        
    }
}

-(void)initInfoView{
    
    self.flowStep = AD_Step1;
    self.step1_scrollView.delegate = self;
    self.step2_scrollView.delegate = self;
    
    //guideImageWidth: 260
    //写真間隔: 10
    //第一写真の左間隔　＝　最後の写真の右間隔　＝ ([UIScreen mainScreen].bounds.size.width - 260)
    self.step1_guide1_leading.constant = ([UIScreen mainScreen].bounds.size.width - GuideImageWidth)/2;
    self.step1_contentWidth.constant = ([UIScreen mainScreen].bounds.size.width - GuideImageWidth) + (GuideImageWidth * 3) + (GuideImageInterval * 2);
    
    self.step2_guide1_leading.constant = ([UIScreen mainScreen].bounds.size.width - GuideImageWidth)/2;
    self.step2_contentWidth.constant = ([UIScreen mainScreen].bounds.size.width - GuideImageWidth) + (GuideImageWidth * 4) + (GuideImageInterval * 3);
    
    self.num1_icon.image = [UIImage imageNamed:@"number1"];
    self.num2_icon.image = [UIImage imageNamed:@"number2_gray"];
    self.num3_icon.image = [UIImage imageNamed:@"number3_gray"];
    
    self.step1_lbl.textColor = [UIColor blackColor];
    self.step2_lbl.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1
                                ];
    self.step3_lbl.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1
                                ];
    
    self.step1_lbl.font = [UIFont systemFontOfSize:18];
    self.step2_lbl.font = [UIFont systemFontOfSize:18];
    self.step3_lbl.font = [UIFont systemFontOfSize:18];
    
    self.step1_checkTime.font = [UIFont systemFontOfSize:14];
    self.step2_checkTime.font = [UIFont systemFontOfSize:14];
    
    self.step1_guideViewHeight.constant = 280;
    self.step2_guideViewHeight.constant = 0;
    self.step2_guideTotalHeight.constant = 30;
    self.step3_guideViewHeight.constant = 0;
    
    [self.btnScanStart setTitle:NSLocalizedString(@"AD_MSG_047", @"1.診断開始") forState:UIControlStateNormal];
}

- (void)initResource {
    
    self.step1_guideLbl_1.text = NSLocalizedString(@"AD_MSG_044", @"Remove the fibers.");
    self.step1_guideLbl_2.text = NSLocalizedString(@"AD_MSG_045", @"Close the hood.");
    self.step1_guideLbl_3.text = NSLocalizedString(@"AD_MSG_046", @"Display the \"MENU\" screen..");
    
    self.step2_guideLbl_1.text = NSLocalizedString(@"AD_MSG_058", @"Open the hood.");
    self.step2_guideLbl_2.text = NSLocalizedString(@"AD_MSG_059", @"Cleaning the V-grooves.");
    
    self.step2_guideLbl_3.text = NSLocalizedString(@"AD_72C_MSG_064", @"Load Sumitomo.");
 
    self.step2_guideLbl_4.text = NSLocalizedString(@"AD_MSG_065", @"Close the hood.");
    
    self.step1_readyLbl.text = NSLocalizedString(@"AD_MSG_043", @"Are you ready to do the followings?");
    self.step2_readyLbl.text = NSLocalizedString(@"AD_MSG_043", @"Are you ready to do the followings?");
    
    self.step1_checkTime.text = NSLocalizedString(@"AD_502_MSG_042", @"約30秒");
    self.step2_checkTime.text = NSLocalizedString(@"AD_502_MSG_057", @"約40秒");
    
    self.step1_lbl.text = NSLocalizedString(@"AD_MSG_041", @"明るさ、LEDチェック");
    self.step2_lbl.text = NSLocalizedString(@"AD_MSG_056", @"ファイバ画像チェック");
    self.step3_lbl.text = NSLocalizedString(@"AD_MSG_048", @"結果");
    self.step3_main_title.text = @"";
    self.step3_result1_title.text = NSLocalizedString(@"AD_MSG_089", @"1. Parts are well cleaned.");
    self.step3_result2_title.text = NSLocalizedString(@"AD_MSG_090", @"2. Fiber image is properly viewed.");
}

-(void)refreshView{
    switch (self.flowStep) {
        case AD_Step1:
            self.num1_icon.image = [UIImage imageNamed:@"number1"];
            self.num2_icon.image = [UIImage imageNamed:@"number2_gray"];
            self.num3_icon.image = [UIImage imageNamed:@"number3_gray"];
            
            self.step2_lbl.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1
                                        ];
            self.step3_lbl.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1
                                        ];
            
            self.step1_guideViewHeight.constant = 280;
            self.step2_guideViewHeight.constant = 0;
            self.step2_guideTotalHeight.constant = 30;
            self.step3_guideViewHeight.constant = 0;
            
            self.step1_checkTime.text = NSLocalizedString(@"AD_72C_MSG_042", @"約30秒");
            self.step2_checkTime.text = NSLocalizedString(@"AD_72C_MSG_057", @"約40秒");
            
            [self.btnScanStart setTitle:NSLocalizedString(@"AD_MSG_047", @"1.診断開始") forState:UIControlStateNormal];
            
            break;
        case AD_Step2:
            self.num1_icon.image = [UIImage imageNamed:@"number1_small"];
            self.num2_icon.image = [UIImage imageNamed:@"number2"];
            self.num3_icon.image = [UIImage imageNamed:@"number3_gray"];
            
            self.step1_checkTime.text = NSLocalizedString(@"AD_MSG_055", @"Passed");
            self.step1_checkTime.font = [UIFont systemFontOfSize:12];
            self.step1_lbl.font = [UIFont systemFontOfSize:14];
            self.step1_lbl.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1];
            self.step2_lbl.textColor = [UIColor blackColor];
            
            self.step1_guideViewHeight.constant = 0;
            self.step2_guideViewHeight.constant = 240;
            self.step2_guideTotalHeight.constant = 270;
            self.step3_guideViewHeight.constant = 0;
            
            [self.btnScanStart setTitle:NSLocalizedString(@"AD_MSG_070", @"2.診断開始") forState:UIControlStateNormal];
            
            break;
        case AD_Step3:
            self.num1_icon.image = [UIImage imageNamed:@"number1_small"];
            self.num2_icon.image = [UIImage imageNamed:@"number2_small"];
            self.num3_icon.image = [UIImage imageNamed:@"number3"];
            
            self.step1_lbl.font = [UIFont systemFontOfSize:14];
            self.step1_lbl.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1];
            self.step2_lbl.font = [UIFont systemFontOfSize:14];
            self.step2_lbl.textColor = [UIColor colorWithRed:102/255.0 green:102/255.0 blue:102/255.0 alpha:1
                                        ];
            self.step3_lbl.textColor = [UIColor blackColor];
            
            
            self.step1_guideViewHeight.constant = 0;
            self.step2_guideViewHeight.constant = 0;
            self.step2_guideTotalHeight.constant = 0;
            self.step3_guideViewHeight.constant = 450;
            
            self.btnScanStart.hidden = true;
            break;
    }
    
    [UIView animateWithDuration:0.5 animations:^{
        
        [self.view layoutIfNeeded];
        
    }];
}

#pragma mark - Flow Method

/**
 自動診断機能フロー（自動診断１回目）
 */
- (void)autoDiagnosisFirst {
    self.flow = [[SCAutoDiagnosisFlow alloc] init];
    [self showProgress:NSLocalizedString(@"RES_20057", @"実行中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        [self setProgressTitleText:NSLocalizedString(@"AD_MSG_124", @"Canceling...")];
        [self.flow cancelFlow];
    }];
    
    // ビジネスフロー
    DDLogInfo(@"5.自動診断機能フロー（自動診断１回目）:開始");
    [self.flow runFlowFirst:self.appData.onlineSerialNo completion:^(NSError *error) {
        
        DDLogInfo(@"5.自動診断機能フロー（自動診断１回目）:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideProgress];
            
            // ビジネスフロー結果メッセージ表示
            if (!error && (kBF_OK == self.flow.resultFlow)) {
                
                self.flowStep = AD_Step2;
                [self refreshView];
                
            } else if (!error && (kBF_CANCEL == self.flow.resultFlow)) {
                DDLogWarn(@"プログレスのキャンセル操作");
                [self.flow resetSplicer];
                [self dismissViewControllerAnimated:YES completion:^{
                    
                }];
            } else if (!error && (kBF_NG == self.flow.resultFlow)) {
                
                NSString* msg;
                msg = NSLocalizedString(@"MSG_13023", @"確認メッセージ");
                NSString* errorCode;
                if (self.flow.resultCommand.length) {
                    errorCode = [self.flow.resultCommand substringFromIndex:self.flow.resultCommand.length-2];
                    if ([errorCode isEqualToString:@"00"]) {
                       msg = [NSString stringWithFormat:NSLocalizedString(@"AD_MSG_080", @""),[self.flow.resultCommand substringFromIndex:2]];
                       [self.flow resetSplicer];
                    } else {
                       msg = [NSString stringWithFormat:NSLocalizedString(@"AD_MSG_052", @""),[self.flow.resultCommand substringFromIndex:2]];
                    }
                }
            
                // コマンドエラーで画面戻る
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    if ([errorCode isEqualToString:@"00"]) {
                        [self dismissViewControllerAnimated:YES completion:^{
                        }];
                    } else {
                        [self initInfoView];
                        [self initResource];
                        [self refreshView];
                    }
                }]];
                
                [self presentViewController:alert animated:YES completion:^{
                }];
            } else {
                if (self.flow.resultFlow == kBF_AD_T502_OP058_ERROR) {
                    self.flow.resetFlag = false;
                }
                
                [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                    
                    if (ResultAction_RETRY == actionType) {
                        
                        // 再試行
                        [self autoDiagnosisFirst];
                    } else {
                        
                        if ((kBF_SP_NOT_SUPPORT == self.flow.resultFlow)) {
                            
                            DDLogWarn(@"自動診断サポート対象外");
                            
                            [self dismissViewControllerAnimated:YES completion:^{
                            }];
                        }
                    }
                }];
            }
        });
    }];
}

/**
 自動診断機能フロー（自動診断２回目）
 */
- (void)autoDiagnosisSecond {
    
    [self showProgress:NSLocalizedString(@"RES_20057", @"実行中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        [self setProgressTitleText:NSLocalizedString(@"AD_MSG_124", @"Canceling...")];
        [self.flow cancelFlow];
    }];
    
    // ビジネスフロー
    DDLogInfo(@"5.自動診断機能フロー（自動診断２回目）:開始");
    [self.flow runFlowSecond:self.appData.onlineSerialNo completion:^(NSError *error) {
        
        DDLogInfo(@"5.自動診断機能フロー（自動診断２回目）:完了");
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self hideProgress];
            
            if (!error && (kBF_AD_GET_BIN_72C == self.flow.resultFlow)) {
                [self runGetBin72cFlow];
            } else if (!error && (kBF_CANCEL == self.flow.resultFlow)) {
                // ビジネスフロー結果メッセージ表示
                DDLogWarn(@"プログレスのキャンセル操作");
                [self.flow resetSplicer];
                [self dismissViewControllerAnimated:YES completion:^{
                    
                }];
            } else if (!error && (kBF_NG == self.flow.resultFlow)) {
                
                NSString* msg;
                UIAlertController* alert;
                if (self.flow.zeroPointResultCommand.length && [self.flow.zeroPointResultCommand isEqualToString:@"MM17E00"]){
                    msg = [NSString stringWithFormat:NSLocalizedString(@"AD_MSG_074", @""),[self.flow.resultCommand substringFromIndex:2]];
                    
                    alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                    
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"AD_MSG_076", @"Retry") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        
                    }]];
                    
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"AD_MSG_075", @"Cancel") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        
                        [self dismissViewControllerAnimated:YES completion:^{
                            [self.flow resetSplicer];
                        }];
                    }]];
                } else {
                    [self.flow resetSplicer];
                    msg = [NSString stringWithFormat:NSLocalizedString(@"AD_72C_MSG_053", @""),
                           [self.flow.resultCommand substringFromIndex:2]];
                    alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        self.flowStep = AD_Step1;
                        self.flow.resetFlag = false;
                        [self refreshView];
                    }]];
                }
                
                [self presentViewController:alert animated:YES completion:^{
                    
                }];
            } else {
                
                [self messageBFResult:self.flow.resultFlow error:error actionHandler:^(SCBFResultAction actionType) {
                    
                    if (ResultAction_RETRY == actionType) {
                        
                        // 再試行
                        [self autoDiagnosisSecond];
                    } else {
                        
                        if (!error && (kBF_AD_NOT_SUPPORT == self.flow.resultFlow)) {
                            
                            DDLogWarn(@"自動診断サポート対象外");
                            [self.flow resetSplicer];
                            [self dismissViewControllerAnimated:YES completion:^{
                            }];
                        }
                    }
                }];
            }
        });
    }];
}

-(void)runGetBin72cFlow{
    [self showProgress:NSLocalizedString(@"RES_20058", @"データ取得中...") cancelHandler:^{
        
        DDLogDebug(@"プログレスのキャンセル");
        [self setProgressTitleText:NSLocalizedString(@"AD_MSG_124", @"Canceling...")];
        [self.flow cancelFlow];
    }];
    
    [self.flow getAutoDiag72CFileWithSerialNo:self.appData.onlineSerialNo completion:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideProgress];
            
            if (!error && (kBF_CANCEL == self.flow.resultFlow)) {
                // ビジネスフロー結果メッセージ表示
                DDLogWarn(@"プログレスのキャンセル操作");
                // プログレスのキャンセル操作で画面戻る
                [self.flow resetSplicer];
                [self dismissViewControllerAnimated:YES completion:^{
                    
                }];
            } else if (kBF_TIMEOUT == self.flow.resultFlow) {
                [self.flow resetSplicer];
                NSString *msg = NSLocalizedString(@"MSG_10026", @"確認メッセージ");
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                    
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self dismissViewControllerAnimated:YES completion:^{
                        
                    }];
                }]];
                    
                [self presentViewController:alert animated:YES completion:^{
                }];
            } else if (!error && (kBF_NG == self.flow.resultFlow)) {
                [self.flow resetSplicer];
                NSString* msg;
                msg = NSLocalizedString(@"MSG_13023", @"確認メッセージ");
                if (self.flow.resultCommand.length) {
                    msg = [NSString stringWithFormat:NSLocalizedString(@"AD_MSG_080", @""),self.flow.resultCommand];
                }
    
                // コマンドエラーで画面戻る
                UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知") message:msg preferredStyle:UIAlertControllerStyleAlert];
                    
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self dismissViewControllerAnimated:YES completion:^{
                    }];
                }]];
                    
                [self presentViewController:alert animated:YES completion:^{
                }];
            } else {
                NSArray * resultArray = self.flow.resultCheckArray;
                NSNumber *error_X_Num = [resultArray objectAtIndex:0];
                NSNumber *error_Y_Num = [resultArray objectAtIndex:1];
                SCAutoDiagnosisErrorOption errorX = [error_X_Num unsignedIntegerValue];
                SCAutoDiagnosisErrorOption errorY = [error_Y_Num unsignedIntegerValue];
                NSMutableDictionary *resultDic = [[NSMutableDictionary alloc] init];
                [resultDic setObject:[NSNumber numberWithInteger:errorX] forKey:@"errorX"];
                [resultDic setObject:[NSNumber numberWithInteger:errorY] forKey:@"errorY"];
                [self resultSolut:resultDic];
            }
        });
    }];
}

- (void)resultSolut:(NSDictionary *)resultDic{
    
    SCAutoDiagnosisErrorOption errorX = [[resultDic objectForKey:@"errorX"] unsignedIntegerValue];
    SCAutoDiagnosisErrorOption errorY = [[resultDic objectForKey:@"errorY"] unsignedIntegerValue];
    
    BOOL isTypeSE = false;
    BOOL simpleCheckError = false;
    BOOL detailCheckError = false;
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        isTypeSE = true;
    }
    
    CGFloat movieWidth = isTypeSE ? HelpMovieWidth_SE : HelpMovieWidth;
    CGFloat movieHeight = isTypeSE ? HelpMovieHeight_SE : HelpMovieHeight;
    
    BOOL need_solut = false;
    if (errorX != 0 || errorY != 0) {
        need_solut = true;
    }
    
    if ((errorX & Led0_Error) ||
        (errorY & Led0_Error) ||
        (errorX & Led2_Error) ||
        (errorY & Led2_Error) ||
        (errorX & PointDiff_Error) ||
        (errorY & PointDiff_Error)) {
        
        simpleCheckError = true;
    }
    
    if ((errorX & AngleDiff_Error) ||
        (errorY & AngleDiff_Error) ||
        (errorX & LeftFiberCenter_Error) ||
        (errorY & LeftFiberCenter_Error) ||
        (errorX & RightFiberCenter_Error) ||
        (errorY & RightFiberCenter_Error) ||
        (errorX & LeftBb_Error) ||
        (errorY & LeftBb_Error) ||
        (errorX & RightBb_Error) ||
        (errorY & RightBb_Error)) {
        
        detailCheckError = true;
    }
    
    if (need_solut) {
        self.resultMainTitleLbl.text = NSLocalizedString(@"AD_MSG_095", @"If the same result continues, please contact an authorized Sumitomo representative.");
        NSMutableArray * result1_videoList = [[NSMutableArray alloc] init];
        
        if ((errorX & Led0_Error) ||
            (errorY & Led0_Error) ||
            (errorX & Led2_Error) ||
            (errorY & Led2_Error) ||
            (errorX & PointDiff_Error) ||
            (errorY & PointDiff_Error)) {
            
            if ([self.helpVideoList objectForKey:@"LED_Video"] != nil) {
                [result1_videoList addObject:[self.helpVideoList objectForKey:@"LED_Video"]];
                self.step3_result1_title.text = NSLocalizedString(@"AD_MSG_118", @"1.清掃の方法");
            } else {
                DDLogDebug(@"--> Have no LED_Video <--");
            }
            
            if ([self.helpVideoList objectForKey:@"Microscope_Video"] != nil) {
                [result1_videoList addObject:[self.helpVideoList objectForKey:@"Microscope_Video"]];
                self.step3_result1_title.text = NSLocalizedString(@"AD_MSG_118", @"1.清掃の方法");
            } else {
                DDLogDebug(@"--> Have no Microscope_Video <--");
            }
            
        }
        
        if ((errorX & LeftFiberCenter_Error) ||
            (errorY & LeftFiberCenter_Error) ||
            (errorX & RightFiberCenter_Error) ||
            (errorY & RightFiberCenter_Error) ||
            (errorX & AngleDiff_Error) ||
            (errorY & AngleDiff_Error)) {
            
           if ([self.helpVideoList objectForKey:@"V_Video"] != nil) {
                [result1_videoList addObject:[self.helpVideoList objectForKey:@"V_Video"]];
                self.step3_result1_title.text = NSLocalizedString(@"AD_MSG_118", @"1.清掃の方法");
            } else {
                DDLogDebug(@"--> Have no V_Video <--");
            }
            
            if ([self.helpVideoList objectForKey:@"Clamp_Video"] != nil) {
                [result1_videoList addObject:[self.helpVideoList objectForKey:@"Clamp_Video"]];
                self.step3_result1_title.text = NSLocalizedString(@"AD_MSG_118", @"1.清掃の方法");
            } else {
                DDLogDebug(@"--> Have no Clamp_Video <--");
            }
            
            self.result2_videoViewHeight.constant = movieHeight;
            SCHelpMovie *fiberResetMovie = [self.helpVideoList objectForKey:@"Fiber_Video"];
            NSString *thumbnailFile = [self.helpVideoFlow.rootHelpVideoFolder stringByAppendingPathComponent:fiberResetMovie.thumbnailfile];
            UIImage *thumbnail = [self getThumbnailImage:thumbnailFile];
            self.step3_result2_icon.image = [UIImage imageNamed:@"icon_check_red"];
            SCAutoDiagnosisVideoButton *videoButton = [SCAutoDiagnosisVideoButton buttonWithType:UIButtonTypeCustom];
            videoButton.helpMovie = fiberResetMovie;
            videoButton.frame = CGRectMake(0, 0, movieWidth, movieHeight);
            [videoButton setBackgroundImage:thumbnail forState:UIControlStateNormal];
            [videoButton setImage:[UIImage imageNamed:@"Video_play"] forState:UIControlStateNormal];
            [videoButton addTarget:self action:@selector(showHelpMovie:) forControlEvents:UIControlEventTouchUpInside];
            [self.result2_videoView addSubview:videoButton];
            self.step3_result2_title.text = NSLocalizedString(@"AD_MSG_119", @"2.ファイバ取り付け状態の修正");
        } else {
            self.step3_result2_icon.image = [UIImage imageNamed:@"icon_check_green"];
            self.step3_result2_title.textColor = [UIColor blackColor];
            self.result2_videoViewHeight.constant = 0;
        }
        
        if ((errorX & LeftBb_Error) ||
            (errorY & LeftBb_Error) ||
            (errorX & RightBb_Error) ||
            (errorY & RightBb_Error)) {
            
            if ([self.helpVideoList objectForKey:@"Microscope_Video"] != nil) {
                SCHelpMovie *microscopeVideo = [self.helpVideoList objectForKey:@"Microscope_Video"];
                if (![result1_videoList containsObject:microscopeVideo]) {
                    [result1_videoList addObject:microscopeVideo];
                    self.step3_result1_title.text = NSLocalizedString(@"AD_MSG_118", @"1.清掃の方法");
                }
            } else {
                DDLogDebug(@"--> Have no Microscope_Video <--");
            }
        }
        
        if ([result1_videoList count]) {
            self.step3_result1_icon.image = [UIImage imageNamed:@"icon_check_red"];
            self.result1_videoViewHeight.constant = [result1_videoList count] == 4 ? (movieHeight * 2 + HelpMovieInterval) : movieHeight;
            for (int i = 0 ; i < [result1_videoList count]; i++) {
                SCHelpMovie *helpMovie = [result1_videoList objectAtIndex:i];
                NSString *thumbnailFile = [self.helpVideoFlow.rootHelpVideoFolder stringByAppendingPathComponent:helpMovie.thumbnailfile];
                UIImage *thumbnail = [self getThumbnailImage:thumbnailFile];
                SCAutoDiagnosisVideoButton *videoButton = [SCAutoDiagnosisVideoButton buttonWithType:UIButtonTypeCustom];
                videoButton.helpMovie = helpMovie;
                videoButton.frame = CGRectMake((i % 3) * (movieWidth + HelpMovieInterval), (i/3) * (movieHeight + HelpMovieInterval), movieWidth, movieHeight);
                [videoButton setBackgroundImage:thumbnail forState:UIControlStateNormal];
                [videoButton setImage:[UIImage imageNamed:@"Video_play"] forState:UIControlStateNormal];
                [videoButton addTarget:self action:@selector(showHelpMovie:) forControlEvents:UIControlEventTouchUpInside];
                [self.result1_videoView addSubview:videoButton];
            }
            
        } else {
            self.step3_result1_icon.image = [UIImage imageNamed:@"icon_check_green"];
            self.step3_result1_title.textColor = [UIColor blackColor];
            self.result1_videoViewHeight.constant = 0;
        }
        
        if ((errorX & Led2_Error) || (errorY & Led2_Error)) {
            self.resultMainTitleLbl.text  = [NSString stringWithFormat:@"%@ \n%@",
                                            NSLocalizedString(@"AD_72C_MSG_095", @"Make sure that the windhood is properly closed."),
                                            NSLocalizedString(@"AD_MSG_095", @"If the same result continues, please contact an authorized Sumitomo representative.")];
        }
        
        self.step3_main_title.text = NSLocalizedString(@"AD_MSG_122", @"Not Good");
        self.step3_main_title.textColor = [UIColor redColor];
    } else {
        self.resultMainTitleLbl.text = NSLocalizedString(@"AD_MSG_082", @"融着機の状態は正常です。");
        self.step3_main_title.text = NSLocalizedString(@"AD_MSG_123", @"Good");
        self.step3_main_title.textColor = [UIColor colorWithRed:92/255.0f green:198/255.0f blue:102/255.0f alpha:1];
        self.step3_result1_icon.image = [UIImage imageNamed:@"icon_check_green"];
        self.step3_result2_icon.image = [UIImage imageNamed:@"icon_check_green"];
        self.step3_result1_title.textColor = [UIColor blackColor];
        self.step3_result2_title.textColor = [UIColor blackColor];
        self.result1_videoViewHeight.constant = 0;
        self.result2_videoViewHeight.constant = 0;
    }
    
    if (simpleCheckError) {
        self.step1_checkTime.text = NSLocalizedString(@"AD_MSG_093", @"Failed");
    } else {
        self.step1_checkTime.text = NSLocalizedString(@"AD_MSG_055", @"Passed");
    }
    

    if (detailCheckError) {
        self.step2_checkTime.text = NSLocalizedString(@"AD_MSG_093", @"Failed");
    } else {
        self.step2_checkTime.text = NSLocalizedString(@"AD_MSG_055", @"Passed");
    }

    self.step1_checkTime.font = [UIFont systemFontOfSize:12];
    self.step2_checkTime.font = [UIFont systemFontOfSize:12];
    
    self.flowStep = AD_Step3;
    [self refreshView];
}

#pragma mark - Override Method

/**
 選択シリアル番号更新
 */
- (void)refreshSelectedSerialNo {
    
    DDLogDebug(@"選択シリアル番号更新【画面更新】");
    
    // シリアル番号
    self.lblSerialNo.text = self.appData.selectedSerialNo;
    self.imgvwConnection.image = [self refreshLockState];
}

/**
 オンラインシリアル番号更新
 */
- (void)refreshOnlineSerialNo {
    
    DDLogDebug(@"オンラインシリアル番号更新【画面更新】");
    
    [super refreshOnlineSerialNo];
    if (![NSLocalizedString(@"NO_SERIAL", @"---") isEqualToString:self.appData.onlineSerialNo]) {
        
        self.appData.selectedSerialNo = self.appData.onlineSerialNo;
    }
    [self refreshSelectedSerialNo];
}

#pragma mark - Button Action

- (IBAction)scanStartClicked:(id)sender {
    
    // Wi-Fi切り替え確認
    if (![self isSplicerConnect:self.lblSerialNo.text]) {
        
        [self connectInternetAlert];
        
        return;
    }
    
    if (self.flowStep == AD_Step1) {
        if ([self.lblSerialNo.text isEqualToString:self.lblSelectedSerialNo.text]) {
            [self autoDiagnosisFirst];
        } else {
            DDLogWarn(@"自動診断対象の融着機と異なる");
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知")  message:NSLocalizedString(@"MSG_10033", @"自動診断対象の融着機と異なる") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:nil]];
            
            [self presentViewController:alert animated:YES completion:nil];
            return;
        }
    } else if (self.flowStep == AD_Step2) {
        if ([self.lblSerialNo.text isEqualToString:self.lblSelectedSerialNo.text]) {
            [self autoDiagnosisSecond];
        } else {
            DDLogWarn(@"自動診断対象の融着機と異なる");
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"DLG_ALERT", @"通知")  message:NSLocalizedString(@"MSG_10033", @"自動診断対象の融着機と異なる") preferredStyle:UIAlertControllerStyleAlert];
            
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"DLG_OK", @"OK") style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                [self dismissViewControllerAnimated:true completion:nil];
            }]];
            
            [self presentViewController:alert animated:YES completion:nil];
            return;
        }
    }
}


/**
 閉じるボタン
 
 @param sender <#sender description#>
 */
- (IBAction)actionClose:(UIBarButtonItem *)sender {
    
    DDLogInfo(@"閉じるボタン -> 自動診断画面を閉じる");
    
    // 画面を閉じる時は、RESET送信
    if (self.flow
        && ((kBF_AD_SUCCESS != self.flow.resultFlow) &&
            (kBF_LOCK != self.flow.resultFlow) &&
            (kBF_AD_NOT_SUPPORT != self.flow.resultFlow))) {
            
            // 異なる融着機に接続している場合は、送信しない
            if ([self.lblSelectedSerialNo.text isEqualToString:self.lblSerialNo.text]) {
                if (self.flow.resetFlag == true) {
                    [self.flow resetSplicer];
                }
            }
        }
    
    self.flow = nil;
    
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}

- (IBAction)showImageDetail:(UIButton *)sender {
    SCImageBrowseViewController *browser = [[SCImageBrowseViewController alloc] init];
    browser.mainImage = [UIImage imageNamed:[self.guidanceImgList objectAtIndex:sender.tag-1]];
    browser.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:browser animated:false completion:nil];
}

- (void)showHelpMovie:(SCAutoDiagnosisVideoButton *)button {
    self.appData.manHelpVideo.selectHelpID = button.helpMovie.id_no;
    [self performSegueWithIdentifier:@"toHelpVideoPlay" sender:self];
}

#pragma mark - CustomeMethod

- (UIImage *)getThumbnailImage:(NSString *)fileName {
    
    UIImage *ret;
    if (fileName) {
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        BOOL isExist = [fileManager fileExistsAtPath:fileName];
        if(isExist) {
            NSData *data = [[NSData alloc] initWithContentsOfFile:fileName];
            if (data) {
                ret = [UIImage imageWithData:data];
            }
        }
    }
    
    return ret;
}

#pragma - mark UIScrollViewDelegate
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    if (scrollView == self.step1_scrollView) {
        if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2) {
            
            [scrollView setContentOffset:CGPointZero animated:true];
            self.step1_pageControl.currentPage = 0;
            
        } else if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2 + GuideImageWidth + GuideImageInterval) {
            
            [scrollView setContentOffset:CGPointMake(GuideImageWidth + GuideImageInterval, 0) animated:true];
            self.step1_pageControl.currentPage = 1;
            
        } else {
            
            [scrollView setContentOffset:CGPointMake((GuideImageWidth + GuideImageInterval) * 2, 0) animated:true];
            self.step1_pageControl.currentPage = 2;
            
        }
    } else if (scrollView == self.step2_scrollView) {
        if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2) {
            
            [scrollView setContentOffset:CGPointZero animated:true];
            self.step2_pageControl.currentPage = 0;
            
        } else if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2 + GuideImageWidth + GuideImageInterval) {
            
            [scrollView setContentOffset:CGPointMake(GuideImageWidth + GuideImageInterval, 0) animated:true];
            self.step2_pageControl.currentPage = 1;
            
        } else if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2 + (GuideImageWidth * 2) + (GuideImageInterval * 2)) {
            
            [scrollView setContentOffset:CGPointMake((GuideImageWidth + GuideImageInterval) * 2, 0) animated:true];
            self.step2_pageControl.currentPage = 2;
            
        } else {
            [scrollView setContentOffset:CGPointMake((GuideImageWidth + GuideImageInterval) * 3, 0) animated:true];
            self.step2_pageControl.currentPage = 3;
        }
    }
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (scrollView == self.step1_scrollView) {
        if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2) {
            
            [scrollView setContentOffset:CGPointZero animated:true];
            self.step1_pageControl.currentPage = 0;
            
        } else if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2 + GuideImageWidth + GuideImageInterval) {
            
            [scrollView setContentOffset:CGPointMake(GuideImageWidth + GuideImageInterval, 0) animated:true];
            self.step1_pageControl.currentPage = 1;
            
        } else {
            
            [scrollView setContentOffset:CGPointMake((GuideImageWidth + GuideImageInterval) * 2, 0) animated:true];
            self.step1_pageControl.currentPage = 2;
            
        }
    } else if (scrollView == self.step2_scrollView) {
        if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2) {
            
            [scrollView setContentOffset:CGPointZero animated:true];
            self.step2_pageControl.currentPage = 0;
            
        } else if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2 + GuideImageWidth + GuideImageInterval) {
            
            [scrollView setContentOffset:CGPointMake(GuideImageWidth + GuideImageInterval, 0) animated:true];
            self.step2_pageControl.currentPage = 1;
            
        } else if (scrollView.contentOffset.x < [UIScreen mainScreen].bounds.size.width/2 + (GuideImageWidth * 2) + (GuideImageInterval * 2)) {
            
            [scrollView setContentOffset:CGPointMake((GuideImageWidth + GuideImageInterval) * 2, 0) animated:true];
            self.step2_pageControl.currentPage = 2;
            
        } else {
            [scrollView setContentOffset:CGPointMake((GuideImageWidth + GuideImageInterval) * 3, 0) animated:true];
            self.step2_pageControl.currentPage = 3;
        }
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
