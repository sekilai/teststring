//
//  SCAutoDiagnosis72mGuidanceViewController.m
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/10/08.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCAutoDiagnosis72mGuidanceViewController.h"
#import "SCAutoDiagnosis72mViewController.h"
#import "SCSystemData.h"
#import "SCImageBrowseViewController.h"

@interface SCAutoDiagnosis72mGuidanceViewController ()
@property (weak, nonatomic) IBOutlet UILabel *purposeTitleLbl;
@property (weak, nonatomic) IBOutlet UILabel *puposeContentLbl;
@property (weak, nonatomic) IBOutlet UILabel *purposeListLbl1;
@property (weak, nonatomic) IBOutlet UIImageView *imageView1;
@property (weak, nonatomic) IBOutlet UIImageView *imageView2;
@property (weak, nonatomic) IBOutlet UIImageView *imageView3;
@property (weak, nonatomic) IBOutlet UIImageView *imageView4;
@property (weak, nonatomic) IBOutlet UILabel *purposeListLbl2;
@property (weak, nonatomic) IBOutlet UILabel *purposeListLbl3;
@property (weak, nonatomic) IBOutlet UIImageView *imageView5;
@property (weak, nonatomic) IBOutlet UIImageView *imageView6;
    
@property (weak, nonatomic) IBOutlet UILabel *preparationTitleLbl;
@property (weak, nonatomic) IBOutlet UILabel *preparationLbl1;
@property (weak, nonatomic) IBOutlet UILabel *preparationLbl2;

@property (weak, nonatomic) IBOutlet UIView *checkboxView;
@property (weak, nonatomic) IBOutlet UIButton *checkBoxBtn;
@property (weak, nonatomic) IBOutlet UILabel *checkBoxLbl;
@property (weak, nonatomic) IBOutlet UIView *checkboxClickArea;

@property (weak, nonatomic) IBOutlet UIView *closeView;
@property (weak, nonatomic) IBOutlet UIButton *closeButton;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@property (nonatomic) BOOL isFirstShow;
@property (nonatomic) NSArray *largeImageArray;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lbl2ToPurposeViewBottom;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lbl2ToImageView6Top;

@end

@implementation SCAutoDiagnosis72mGuidanceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // 色味の設定
    self.navigationController.navigationBar.barTintColor = [SCSystemData colorWithRGB:0x0F green:0x48 blue:0x9F alpha:1.0f];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    // 多言語対応
    self.title = NSLocalizedString(@"AD_MSG_002", @"自動診断ガイダンス");
    
    self.purposeTitleLbl.text = NSLocalizedString(@"AD_MSG_003",@"Purpose");
    self.puposeContentLbl.text = ([SCSystemData isModelType72C:self.appData.selectedSerialNo] ||
                                  [SCSystemData isModelTypeZ2C:self.appData.selectedSerialNo] ) ? NSLocalizedString(@"AD_72C_MSG_004",@"") : NSLocalizedString(@"AD_MSG_004",@"");
    if ([SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
        self.puposeContentLbl.text = NSLocalizedString(@"AD_502_MSG_004",@"");
    }
    
    self.purposeListLbl1.text = NSLocalizedString(@"AD_MSG_005",@"");
    self.purposeListLbl2.text = NSLocalizedString(@"AD_MSG_011",@"");
    self.purposeListLbl3.text = NSLocalizedString(@"AD_MSG_018",@"");
    self.preparationTitleLbl.text = NSLocalizedString(@"AD_MSG_020",@"");
    self.preparationLbl1.text = [NSString stringWithFormat:NSLocalizedString(@"AD_MSG_021",@""), [SCSystemData getAutoDiagFiber:self.appData.selectedSerialNo]];
    self.preparationLbl2.text = ([SCSystemData isModelType72C:self.appData.selectedSerialNo] ||
                                 [SCSystemData isModelTypeZ2C:self.appData.selectedSerialNo]) ? [NSString stringWithFormat:NSLocalizedString(@"AD_72C_MSG_022",@""),[SCSystemData getAutoDiagFolder:self.appData.selectedSerialNo]] : [NSString stringWithFormat:NSLocalizedString(@"AD_MSG_022",@""),[SCSystemData getAutoDiagFolder:self.appData.selectedSerialNo]];
    if ([SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
        self.preparationLbl2.text = [NSString stringWithFormat:NSLocalizedString(@"AD_502_MSG_022",@""),[SCSystemData getAutoDiagFolder:self.appData.selectedSerialNo]];
    }

    if (self.isFromClick) {
        [self.checkboxView setHidden:YES];
    } else {
        [self.checkboxView setHidden:NO];
        self.isNeedDisplayCheckBox = true;
        self.checkBoxLbl.text = NSLocalizedString(@"AD_MSG_001",@"");
        [self.checkBoxBtn addTarget:self action:@selector(clickCheckBox) forControlEvents:UIControlEventTouchUpInside];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickCheckBox)];
        [self.checkboxClickArea setUserInteractionEnabled:YES];
        [self.checkboxClickArea addGestureRecognizer:tap];
    }
    
    [self.closeButton setTitle:NSLocalizedString(@"AD_MSG_006", @"") forState:UIControlStateNormal];
    
    NSArray *array = [NSArray arrayWithObjects: self.imageView1,self.imageView2,self.imageView3,self.imageView4,
                      self.imageView5,self.imageView6,nil];

    for (int i = 0; i < array.count; i++) {
        UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showImage:)];
        [[array objectAtIndex:i] setUserInteractionEnabled:YES];
        [[array objectAtIndex:i] addGestureRecognizer:tapGR];
    }
    self.isFirstShow = true;
    if ([SCSystemData isModelType72M:self.appData.selectedSerialNo]) {
        self.largeImageArray = [NSArray arrayWithObjects: @"Guidance_img_large_1-1",@"Guidance_img_large_1-2",@"Guidance_img_large_1-3",@"Guidance_img_large_1-4",
        @"Guidance_img_large_2",@"img_Fiber_image_check",nil];
    } else if ([SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
        self.imageView1.image = [UIImage imageNamed:@"502_guidance_img_1_1"];
        self.imageView2.image = [UIImage imageNamed:@"502_guidance_img_1_2"];
        self.imageView3.image = [UIImage imageNamed:@"502_guidance_img_1_3"];
        self.largeImageArray = [NSArray arrayWithObjects:
                                @"502_guidance_img_large_1_1",
                                @"502_guidance_img_large_1_2",
                                @"502_guidance_img_large_1_3",
                                @"Guidance_img_large_2",
                                @"img_Fiber_image_check",nil];
    } else {
        self.imageView1.image = [UIImage imageNamed:@"72c_guidance_img_1_1"];
        self.imageView2.image = [UIImage imageNamed:@"72c_guidance_img_1_2"];
        self.imageView3.image = [UIImage imageNamed:@"72c_guidance_img_1_3"];
        self.imageView4.image = [UIImage imageNamed:@"72c_guidance_img_1_4"];
        self.largeImageArray = [NSArray arrayWithObjects:
                                @"72c_guidance_img_large_1_1",
                                @"72c_guidance_img_large_1_2",
                                @"72c_guidance_img_large_1_3",
                                @"72c_guidance_img_large_1_4",
                                @"Guidance_img_large_2",
                                @"img_Fiber_image_check",nil];
    }
    
    if ([SCSystemData isModelType72C:self.appData.selectedSerialNo] ||
        [SCSystemData isModelTypeZ2C:self.appData.selectedSerialNo] ||
        [SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
        _lbl2ToImageView6Top.priority = 500;
        _lbl2ToPurposeViewBottom.priority = 1000;
        self.imageView6.hidden = true;
        self.imageView5.hidden = true;
        self.purposeListLbl3.hidden = true;
    }
    
    if ([SCSystemData isModelTypeT502:self.appData.selectedSerialNo]) {
        self.imageView4.hidden = true;
    }
    
}

-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (self.isFromClick) {
        if (self.isFirstShow) {
            self.isFirstShow = false;
            [self.closeView setFrame:CGRectMake(self.closeView.frame.origin.x, self.checkboxView.frame.origin.y, self.closeView.frame.size.width, self.closeView.frame.size.height)];
            [self.scrollView setContentSize:CGSizeMake(self.scrollView.contentSize.width,self.scrollView.contentSize.height-self.checkboxView.frame.size.height)];
        }
    }
}

-(void)showImage:(UITapGestureRecognizer *)sender {
    UIImageView *imageView = (UIImageView *) [sender view];
    
    SCImageBrowseViewController *browser = [[SCImageBrowseViewController alloc] init];
    browser.mainImage = [UIImage imageNamed:[self.largeImageArray objectAtIndex:imageView.tag-1]];
    browser.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:browser animated:false completion:nil];
}

- (IBAction)clickCloseButton:(id)sender {
    [self closeGuidance];
}

- (void)clickCheckBox{
    if (self.checkBoxBtn.tag == 0) {
        self.checkBoxBtn.tag = 1;
        [self.checkBoxBtn setImage:[UIImage imageNamed:@"check_on"] forState:UIControlStateNormal];
        self.isNeedDisplayCheckBox = false;
    } else {
        self.checkBoxBtn.tag = 0;
        [self.checkBoxBtn setImage:[UIImage imageNamed:@"check_off"] forState:UIControlStateNormal];
        self.isNeedDisplayCheckBox = true;
    }
}

- (IBAction)actionClose:(id)sender {
    [self closeGuidance];
}

- (void)closeGuidance {
    if (!self.isFromClick) {
        [SCSystemData setAutoDiagGuideDisplay:self.isNeedDisplayCheckBox withType:[SCSystemData getModelType:self.appData.selectedSerialNo]];
    }
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}

-(UIViewController *) topMostController {
    UIViewController*topController = [UIApplication sharedApplication].keyWindow.rootViewController;
    while(topController.presentedViewController){
        topController=topController.presentedViewController;
    }
    return topController;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
