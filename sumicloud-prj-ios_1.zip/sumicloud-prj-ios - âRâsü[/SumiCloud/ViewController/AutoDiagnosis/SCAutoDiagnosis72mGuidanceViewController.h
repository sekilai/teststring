//
//  SCAutoDiagnosis72mGuidanceViewController.h
//  SumiCloud
//
//  Created by fsi-mac5d-10 on 2019/10/08.
//  Copyright © 2019 fsi_mac5d_5. All rights reserved.
//

#import "SCBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SCAutoDiagnosis72mGuidanceViewController : SCBaseViewController
@property(nonatomic) BOOL isFromClick;
@property(nonatomic) BOOL isNeedDisplayCheckBox;
@end

NS_ASSUME_NONNULL_END
