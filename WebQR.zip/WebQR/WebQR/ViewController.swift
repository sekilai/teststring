//
//  ViewController.swift
//  WebQR
//
//  Created by 石磊 on 2021/03/25.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate, QRViewControllerDelegate {
    @IBOutlet var webView : WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.navigationDelegate = self
        loadLocalHTML()
    }

    func loadLocalHTML() {
        guard let path: String = Bundle.main.path(forResource: "index", ofType: "html") else { return }
        let localHTMLUrl = URL(fileURLWithPath: path, isDirectory: false)
        webView.loadFileURL(localHTMLUrl, allowingReadAccessTo: localHTMLUrl)
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        let app = UIApplication.shared
        if let url = navigationAction.request.url {
            // Handle target="_blank"
            print(url)
            if navigationAction.targetFrame == nil {
                if app.canOpenURL(url) {
                    app.open(url, options: [:], completionHandler: nil)
                    decisionHandler(.cancel)
                    return
                }
            }
            
            if (url.path as NSString).lastPathComponent == "readqr" {
                let vc = QRViewController(nibName: "QRViewController", bundle: nil)
                vc.delegate = self
                self.present(vc, animated: true, completion: nil)
            }
            
            decisionHandler(.allow)
        }
    }
    
    func controller(_ viewController: QRViewController, didReadQrCode qrCode: String?) {
        if let qr = qrCode{
            print("qr:\(qr)")
            let script = "setQr('\(qr)');"
            webView.evaluateJavaScript(script) { object, error in
                print(error ?? "成功")
            }
        }
    }

}

